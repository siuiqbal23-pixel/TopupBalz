import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { GameCard } from './components/GameCard';
import { MostSearchedSection } from './components/MostSearchedSection';
import { TopupModal } from './components/TopupModal';
import { FlashSaleSection } from './components/FlashSaleSection';
import { OrderTrackerModal } from './components/OrderTrackerModal';
import { AdminDashboard } from './components/AdminDashboard';
import { ReviewsSection } from './components/ReviewsSection';
import { TutorialSection } from './components/TutorialSection';
import { TransactionCheckView } from './components/TransactionCheckView';
import { RankingTopupView } from './components/RankingTopupView';
import { UserProfileView } from './components/UserProfileView';
import { GmailIntegrationModal } from './components/GmailIntegrationModal';
import { CartModal } from './components/CartModal';
import { LiveChatModal } from './components/LiveChatModal';
import { BottomNav, NavTab } from './components/BottomNav';
import { NineDotsMenuModal } from './components/NineDotsMenuModal';
import { RealCalculatorModal } from './components/RealCalculatorModal';
import { InfoPagesModal, InfoTab } from './components/InfoPagesModal';
import { Footer } from './components/Footer';
import { UsernameLoginModal } from './components/UsernameLoginModal';
import { ClerkAuthModal } from './components/ClerkAuthModal';
import { GoogleAuthModal } from './components/GoogleAuthModal';
import { useAppAuth } from './context/AuthContext';
import { LivePurchaseTicker } from './components/LivePurchaseTicker';
import { AnimatedBrandLogo } from './components/BrandLogo';
import { Game, GameCategory, Order, PromoBanner, SystemSettings, UserProfile, UserActivityLog, CartItem, FlashSaleConfig } from './types';
import { Review, INITIAL_REVIEWS } from './data/reviewsData';
import {
  INITIAL_GAMES,
  INITIAL_BANNERS,
  INITIAL_SETTINGS,
  INITIAL_FLASH_SALE,
  calculateSellPrice,
} from './data/initialData';
import { safeFetchJson } from './lib/safeFetch';
import { buildOrderMessage, buildCartMessage, generateWhatsAppUrl } from './lib/whatsapp';
import { Flame, Zap, Gamepad2, CheckCircle2, Filter } from 'lucide-react';

export default function App() {
  const [games, setGames] = useState<Game[]>(INITIAL_GAMES);
  const [banners, setBanners] = useState<PromoBanner[]>(INITIAL_BANNERS);
  const [settings, setSettings] = useState<SystemSettings>(INITIAL_SETTINGS);
  const [orders, setOrders] = useState<Order[]>([]);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [activityLogsList, setActivityLogsList] = useState<UserActivityLog[]>([]);
  const [flashSale, setFlashSale] = useState<FlashSaleConfig>(INITIAL_FLASH_SALE);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [onlineCount, setOnlineCount] = useState<number>(1);
  const [selectedInitialItemId, setSelectedInitialItemId] = useState<string | undefined>(undefined);

  const {
    isClerkModalOpen,
    clerkModalMode,
    openSignInModal,
    openSignUpModal,
    closeClerkModal,
    isGoogleModalOpen,
    openGoogleModal,
    closeGoogleModal,
    handleGoogleLoginSuccess,
    setUsername: setAuthUsername,
    updateUserPhone,
    updateUserAvatar,
    user: authContextUser,
  } = useAppAuth();

  // Username Login Modal & Chat States
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [loginModalPrompt, setLoginModalPrompt] = useState('Log Masuk Username TopupBalz');
  const [pendingGameForTopup, setPendingGameForTopup] = useState<Game | null>(null);

  const handleInitiateTopup = (game: Game, itemId?: string) => {
    setSelectedInitialItemId(itemId);
    if (!currentUser) {
      setPendingGameForTopup(game);
      openGoogleModal();
      showToast('Sila log masuk dengan akaun Google anda terlebih dahulu untuk buat topup!');
      return;
    }
    setSelectedGame(game);
  };

  // 9-Dots Menu Modal & Real Calculator States
  const [nineDotsOpen, setNineDotsOpen] = useState(false);
  const [calculatorOpen, setCalculatorOpen] = useState(false);
  const [infoModalOpen, setInfoModalOpen] = useState(false);
  const [infoModalTab, setInfoModalTab] = useState<InfoTab>('faq');

  const handleOpenInfoModal = (tab: InfoTab = 'faq') => {
    setInfoModalTab(tab);
    setInfoModalOpen(true);
  };

  // Restore current user from local storage
  useEffect(() => {
    const stored = localStorage.getItem('topupbalz_current_user');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (parsed && parsed.name) {
          setCurrentUser(parsed);
        }
      } catch (e) {}
    }
  }, []);

  const handleOpenLiveChatWithAuth = () => {
    if (!currentUser) {
      openGoogleModal();
      showToast('Sila log masuk dengan akaun Google anda dahulu sebelum memulakan Live Chat!');
    } else {
      setLiveChatOpen(true);
    }
  };

  // Troli Pembelian & Live Chat Admin States
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('topupbalz_cart');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  const [cartModalOpen, setCartModalOpen] = useState(false);
  const [liveChatOpen, setLiveChatOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('topupbalz_cart', JSON.stringify(cart));
    } catch (e) {}
  }, [cart]);

  // Real-time Active Online User Presence Heartbeat Ping
  useEffect(() => {
    let sessionId = sessionStorage.getItem('topupbalz_session_id');
    if (!sessionId) {
      sessionId = 'sess_' + Math.random().toString(36).substring(2, 10) + '_' + Date.now();
      sessionStorage.setItem('topupbalz_session_id', sessionId);
    }

    const sendPresencePing = async () => {
      try {
        const data = await safeFetchJson('/api/presence/ping', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId,
            userEmail: currentUser?.email,
            userName: currentUser?.name,
          }),
        });
        if (data && typeof data.onlineCount === 'number') {
          setOnlineCount(data.onlineCount);
        } else {
          const fallbackData = await safeFetchJson('/api/presence');
          if (fallbackData && typeof fallbackData.onlineCount === 'number') {
            setOnlineCount(fallbackData.onlineCount);
          }
        }
      } catch (err) {
        // Ignored
      }
    };

    sendPresencePing();
    const presenceInterval = setInterval(sendPresencePing, 8000); // Ping every 8s
    return () => clearInterval(presenceInterval);
  }, [currentUser]);

  // Active Tab: 'menu' (Default Store View)
  const [activeTab, setActiveTab] = useState<NavTab>('menu');

  // Theme State (Dark / Bright)
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try {
      const saved = localStorage.getItem('topupbalz_theme');
      return (saved === 'light' || saved === 'dark') ? saved : 'dark';
    } catch (e) {
      return 'dark';
    }
  });

  const toggleTheme = () => {
    setTheme((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      try {
        localStorage.setItem('topupbalz_theme', next);
      } catch (e) {}
      return next;
    });
  };

  // UI States
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<GameCategory>('all');
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [orderTrackerOpen, setOrderTrackerOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);

  // Auto-detect Admin route parameter (?admin=true or /admin)
  useEffect(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('admin') === 'true' || window.location.pathname.startsWith('/admin')) {
        setActiveTab('admin');
        setAdminOpen(true);
      }
    } catch (e) {}
  }, []);

  // Auto-sync selectedGame when games or price data updates from admin or live poll
  useEffect(() => {
    if (selectedGame) {
      const updated = games.find((g) => g.id === selectedGame.id);
      if (updated) {
        setSelectedGame(updated);
      }
    }
  }, [games]);

  // Auto-sync cart items when prices are updated by admin
  useEffect(() => {
    setCart((prevCart) => {
      let changed = false;
      const updatedCart = prevCart.map((item) => {
        const game = games.find((g) => g.id === item.gameId);
        if (game) {
          const gameItem = game.items.find((i) => i.id === item.itemId);
          if (gameItem && gameItem.sellPrice !== item.sellPrice) {
            changed = true;
            return { ...item, sellPrice: gameItem.sellPrice };
          }
        }
        return item;
      });
      return changed ? updatedCart : prevCart;
    });
  }, [games]);
  const [gmailModalOpen, setGmailModalOpen] = useState(false);
  const [gmailRecipient, setGmailRecipient] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Lock background body scroll when any modal is open
  const isAnyModalActive = Boolean(
    selectedGame ||
    orderTrackerOpen ||
    cartModalOpen ||
    liveChatOpen ||
    calculatorOpen ||
    loginModalOpen ||
    nineDotsOpen ||
    infoModalOpen ||
    gmailModalOpen ||
    isGoogleModalOpen ||
    isClerkModalOpen
  );

  useEffect(() => {
    if (isAnyModalActive) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isAnyModalActive]);

  const handleOpenGmailModal = (recipient?: string) => {
    setGmailRecipient(recipient || currentUser?.email || '');
    setGmailModalOpen(true);
  };

  // Live Online State Sync: Fetch data every 3 seconds for instant real-time synchronization
  useEffect(() => {
    const fetchServerData = async () => {
      try {
        const [gRes, bRes, sRes, oRes, rRes, uRes, fsRes] = await Promise.all([
          safeFetchJson('/api/games', undefined, { games: INITIAL_GAMES }),
          safeFetchJson('/api/banners', undefined, { banners: INITIAL_BANNERS }),
          safeFetchJson('/api/settings', undefined, { settings: INITIAL_SETTINGS }),
          safeFetchJson('/api/orders', undefined, { orders: [] }),
          safeFetchJson('/api/reviews', undefined, { reviews: INITIAL_REVIEWS }),
          safeFetchJson('/api/users', undefined, { users: [], activityLogs: [] }),
          safeFetchJson('/api/flash-sale', undefined, { flashSale: INITIAL_FLASH_SALE }),
        ]);

        if (gRes?.games && gRes.games.length > 0) setGames(gRes.games);
        if (bRes?.banners) setBanners(bRes.banners);
        if (sRes?.settings) setSettings(sRes.settings);
        if (oRes?.orders) setOrders(oRes.orders);
        if (rRes?.reviews) setReviews(rRes.reviews);
        if (fsRes?.flashSale) setFlashSale(fsRes.flashSale);
        if (uRes?.users) {
          setUsersList(uRes.users);
          // Keep active currentUser in sync with updated profile from server
          const storedUserJson = localStorage.getItem('topupbalz_current_user');
          let localUser = currentUser;
          if (!localUser && storedUserJson) {
            try { localUser = JSON.parse(storedUserJson); } catch (e) {}
          }
          if (localUser) {
            const updatedMe = uRes.users.find(
              (u: any) =>
                u.id === localUser.id ||
                (u.email && localUser.email && u.email.toLowerCase() === localUser.email.toLowerCase()) ||
                (u.name && localUser.name && u.name.toLowerCase() === localUser.name.toLowerCase())
            );
            if (updatedMe) {
              if (
                updatedMe.phoneNumber !== localUser.phoneNumber ||
                updatedMe.totalOrders !== localUser.totalOrders ||
                updatedMe.totalSpent !== localUser.totalSpent
              ) {
                setCurrentUser(updatedMe);
                localStorage.setItem('topupbalz_current_user', JSON.stringify(updatedMe));
              }
            }
          }
        }
        if (uRes?.activityLogs) setActivityLogsList(uRes.activityLogs);
      } catch (err) {
        console.error('Failed to load live server data:', err);
      }
    };

    fetchServerData();
    const interval = setInterval(fetchServerData, 3000); // Poll every 3s for live online sync
    return () => clearInterval(interval);
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleGoogleSignIn = async (googleAccountData?: { email: string; name: string; avatarUrl?: string }) => {
    try {
      const data = await safeFetchJson('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(googleAccountData || {
          email: 'user.topup@gmail.com',
          name: 'Pelanggan TopupBalz',
        }),
      });
      if (data?.user) {
        setCurrentUser(data.user);
        localStorage.setItem('topupbalz_current_user', JSON.stringify(data.user));
        if (data.users) setUsersList(data.users);
        showToast(`Selamat datang, ${data.user.name}! Akaun Google disahkan.`);
      }
    } catch (err) {
      console.error('Google Sign in failed:', err);
    }
  };

  const handleUpdatePhone = async (phone: string) => {
    const userToUpdate = currentUser || authContextUser || (() => {
      try {
        const stored = localStorage.getItem('topupbalz_current_user');
        return stored ? JSON.parse(stored) : null;
      } catch {
        return null;
      }
    })();

    if (!userToUpdate) return;
    const cleanPhone = phone.trim();

    try {
      const data = await safeFetchJson('/api/users/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: userToUpdate.id,
          id: userToUpdate.id,
          email: userToUpdate.email,
          name: userToUpdate.name,
          username: userToUpdate.username,
          phoneNumber: cleanPhone,
        }),
      });

      const updatedUser = data?.user || { ...userToUpdate, phoneNumber: cleanPhone };
      setCurrentUser(updatedUser);
      localStorage.setItem('topupbalz_current_user', JSON.stringify(updatedUser));
      if (updateUserPhone) updateUserPhone(cleanPhone);
      if (data?.users) setUsersList(data.users);
      if (data?.activityLogs) setActivityLogsList(data.activityLogs);
      showToast(cleanPhone ? `Nombor WhatsApp ${cleanPhone} berjaya disimpan!` : 'Nombor telefon dikemaskini!');
    } catch (err) {
      console.error('Failed to update phone:', err);
      const updatedUser = { ...userToUpdate, phoneNumber: cleanPhone };
      setCurrentUser(updatedUser);
      localStorage.setItem('topupbalz_current_user', JSON.stringify(updatedUser));
      if (updateUserPhone) updateUserPhone(cleanPhone);
      showToast(cleanPhone ? `Nombor WhatsApp ${cleanPhone} berjaya disimpan!` : 'Nombor telefon dikemaskini!');
    }
  };

  const handleUpdateAvatar = async (avatarUrl: string) => {
    if (!currentUser) return;
    try {
      const data = await safeFetchJson('/api/users/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          id: currentUser.id,
          email: currentUser.email,
          name: currentUser.name,
          username: currentUser.username,
          avatarUrl,
        }),
      });
      if (data?.user) {
        setCurrentUser(data.user);
        localStorage.setItem('topupbalz_current_user', JSON.stringify(data.user));
        if (data.users) setUsersList(data.users);
        if (data.activityLogs) setActivityLogsList(data.activityLogs);
        showToast('Gambar profil berjaya dikemaskini dari galeri!');
      }
    } catch (err) {
      console.error('Failed to update avatar:', err);
    }
  };

  // Filter games according to search query & selected category
  const filteredGames = useMemo(() => {
    return games.filter((game) => {
      // Search match
      const matchesSearch =
        game.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        game.slug.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      // Category match
      if (activeCategory === 'all') return true;
      if (activeCategory === 'popular') return game.isPopular;
      if (activeCategory === 'promo') return game.isDiscounted || game.items.some((i) => i.bonusTag);
      return game.category === activeCategory;
    });
  }, [games, searchQuery, activeCategory]);

  // Section groupings
  const popularGames = useMemo(() => games.filter((g) => g.isPopular), [games]);

  // Review submission
  const handleAddReview = async (newRev: Omit<Review, 'id' | 'date' | 'verified'>) => {
    try {
      const data = await safeFetchJson('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRev),
      });
      if (data?.reviews) {
        setReviews(data.reviews);
        showToast('Ulasan anda berjaya diterbitkan! Terima kasih.');
      } else {
        throw new Error('No reviews returned');
      }
    } catch (err) {
      const fallbackRev: Review = {
        ...newRev,
        id: 'rev-' + Date.now(),
        date: 'Baru sahaja',
        verified: true,
      };
      setReviews((prev) => [fallbackRev, ...prev]);
      showToast('Ulasan disimpan secara tempatan.');
    }
  };

  // Order Submission Handler
  const handleOrderSubmit = async (orderData: {
    gameId: string;
    gameName: string;
    itemId: string;
    itemName: string;
    basePrice: number;
    userId: string;
    serverId?: string;
    customerPhone?: string;
    paymentMethod: string;
    proofImageUrl?: string;
  }) => {
    try {
      const payload = {
        ...orderData,
        clientOrigin: typeof window !== 'undefined' ? window.location.origin : '',
        accountUserId: currentUser?.id,
        accountUsername: currentUser?.username || currentUser?.name,
      };

      const data = await safeFetchJson('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (data?.success && data?.order) {
        setOrders((prev) => [data.order, ...prev]);

        // Immediately update local currentUser state and storage for totalOrders & totalSpent
        if (currentUser) {
          const addedPrice = data.order.sellPrice || orderData.basePrice || 0;
          setCurrentUser((prev) => {
            if (!prev) return prev;
            const updated = {
              ...prev,
              totalOrders: (prev.totalOrders || 0) + 1,
              totalSpent: (prev.totalSpent || 0) + addedPrice,
            };
            localStorage.setItem('topupbalz_current_user', JSON.stringify(updated));
            return updated;
          });
        }

        showToast(`Pesanan #${data.order.id} berjaya dibuat! Sila buka WhatsApp.`);
        return {
          success: true,
          whatsappUrl: data.whatsappUrl,
          orderId: data.order.id,
          receiptUrl: data.receiptUrl,
          proofImageUrl: orderData.proofImageUrl,
        };
      } else {
        throw new Error(data?.error || 'Gagal menghantar order');
      }
    } catch (err: any) {
      // Local fallback if offline or server glitch
      const sellPrice = orderData.basePrice;
      const orderId = 'BZ-' + Math.floor(100000 + Math.random() * 900000);
      const matchedGame = games.find((g) => g.id === orderData.gameId || g.name === orderData.gameName);

      const textMessage = buildOrderMessage({
        orderId,
        gameName: orderData.gameName,
        itemName: orderData.itemName,
        price: sellPrice,
        userId: orderData.userId,
        serverId: orderData.serverId,
        customerPhone: orderData.customerPhone,
        paymentMethod: orderData.paymentMethod,
        gameCategory: matchedGame?.category || '',
        proofImageUrl: orderData.proofImageUrl,
      });

      const { waUrl: whatsappUrl } = generateWhatsAppUrl(textMessage, settings?.ownerWhatsApp);

      const fallbackOrder: any = {
        id: orderId,
        createdAt: new Date().toISOString(),
        gameId: orderData.gameId,
        gameName: orderData.gameName,
        itemId: orderData.itemId,
        itemName: orderData.itemName,
        basePrice: orderData.basePrice,
        sellPrice,
        userId: orderData.userId,
        serverId: orderData.serverId,
        customerPhone: orderData.customerPhone,
        paymentMethod: orderData.paymentMethod,
        proofImageUrl: orderData.proofImageUrl,
        status: 'pending',
        whatsappUrl,
        accountUserId: currentUser?.id,
        accountUsername: currentUser?.username || currentUser?.name,
      };

      setOrders((prev) => [fallbackOrder, ...prev]);

      if (currentUser) {
        setCurrentUser((prev) => {
          if (!prev) return prev;
          const updated = {
            ...prev,
            totalOrders: (prev.totalOrders || 0) + 1,
            totalSpent: (prev.totalSpent || 0) + sellPrice,
          };
          localStorage.setItem('topupbalz_current_user', JSON.stringify(updated));
          return updated;
        });
      }

      showToast(`Pesanan #${orderId} telah didaftarkan.`);

      return {
        success: true,
        whatsappUrl,
        orderId,
        proofImageUrl: orderData.proofImageUrl,
      };
    }
  };

  // Shopping Cart Handlers
  const handleAddToCart = (itemData: Omit<CartItem, 'id'>) => {
    if (!currentUser) {
      setLoginModalPrompt('Sila log masuk username anda terlebih dahulu untuk masukkan item ke troli!');
      setLoginModalOpen(true);
      return;
    }
    const newItem: CartItem = {
      ...itemData,
      id: 'cart_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    };
    setCart((prev) => [...prev, newItem]);
    showToast(`Item ${itemData.gameName} (${itemData.itemName}) dimasukkan ke Troli!`);
  };

  const handleUpdateCartQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((i) => (i.id === id ? { ...i, quantity: Math.max(1, i.quantity + delta) } : i))
        .filter((i) => i.quantity > 0)
    );
  };

  const handleRemoveCartItem = (id: string) => {
    setCart((prev) => prev.filter((i) => i.id !== id));
  };

  const handleUpdateCartUserId = (id: string, userId: string, serverId?: string) => {
    setCart((prev) =>
      prev.map((i) => (i.id === id ? { ...i, userId, serverId } : i))
    );
  };

  const handleClearCart = () => setCart([]);

  const handleSubmitCartOrders = async (payload: {
    items: CartItem[];
    paymentMethod: string;
    customerPhone?: string;
    proofImageUrl?: string;
  }) => {
    let lastOrderId = '';
    for (const item of payload.items) {
      for (let q = 0; q < item.quantity; q++) {
        const res = await handleOrderSubmit({
          gameId: item.gameId,
          gameName: item.gameName,
          itemId: item.itemId,
          itemName: item.itemName,
          basePrice: Math.max(0.5, item.sellPrice - 1.0),
          userId: item.userId,
          serverId: item.serverId,
          customerPhone: payload.customerPhone,
          paymentMethod: payload.paymentMethod,
          proofImageUrl: payload.proofImageUrl,
        });
        if (res?.orderId) lastOrderId = res.orderId;
      }
    }

    const totalAmount = payload.items.reduce((acc, i) => acc + i.sellPrice * i.quantity, 0);

    const waMsg = buildCartMessage({
      items: payload.items,
      totalAmount,
      paymentMethod: payload.paymentMethod,
      customerPhone: payload.customerPhone,
      ownerPhone: settings.ownerWhatsApp,
      proofImageUrl: payload.proofImageUrl,
    });

    const { waUrl } = generateWhatsAppUrl(waMsg, settings.ownerWhatsApp);

    return {
      success: true,
      whatsappUrl: waUrl,
      orderId: lastOrderId,
      proofImageUrl: payload.proofImageUrl,
    };
  };

  // Admin Actions
  const handleSaveGame = async (gameToSave: Game) => {
    try {
      const data = await safeFetchJson('/api/games', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(gameToSave),
      });
      if (data?.games) {
        setGames(data.games);
        showToast('Game & senarai harga berjaya dikemaskini online!');
      } else {
        throw new Error('Fallback required');
      }
    } catch (err) {
      setGames((prev) => {
        const idx = prev.findIndex((g) => g.id === gameToSave.id);
        if (idx >= 0) {
          const updated = [...prev];
          updated[idx] = gameToSave;
          return updated;
        }
        return [gameToSave, ...prev];
      });
      showToast('Game dikemaskini secara tempatan.');
    }
  };

  const handleDeleteGame = async (id: string) => {
    try {
      const data = await safeFetchJson(`/api/games/${id}`, { method: 'DELETE' });
      if (data?.games) {
        setGames(data.games);
        showToast('Game dipadamkan.');
      } else {
        setGames((prev) => prev.filter((g) => g.id !== id));
      }
    } catch (err) {
      setGames((prev) => prev.filter((g) => g.id !== id));
    }
  };

  const handleUpdateOrderStatus = async (id: string, status: Order['status'], notes?: string) => {
    try {
      const data = await safeFetchJson(`/api/orders/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, notes }),
      });
      if (data?.orders) {
        setOrders(data.orders);
        showToast(`Status pesanan #${id} ditukar ke ${status.toUpperCase()}.`);
      } else {
        setOrders((prev) =>
          prev.map((o) => (o.id === id ? { ...o, status, notes } : o))
        );
      }
    } catch (err) {
      setOrders((prev) =>
        prev.map((o) => (o.id === id ? { ...o, status, notes } : o))
      );
    }
  };

  const handleSaveBanner = async (banner: PromoBanner) => {
    try {
      const data = await safeFetchJson('/api/banners', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(banner),
      });
      if (data?.banners) {
        setBanners(data.banners);
        showToast('Banner berjaya disimpan!');
      } else {
        setBanners((prev) => [banner, ...prev]);
      }
    } catch (err) {
      setBanners((prev) => [banner, ...prev]);
    }
  };

  const handleDeleteBanner = async (id: string) => {
    try {
      const data = await safeFetchJson(`/api/banners/${id}`, { method: 'DELETE' });
      if (data?.banners) {
        setBanners(data.banners);
      } else {
        setBanners((prev) => prev.filter((b) => b.id !== id));
      }
    } catch (err) {
      setBanners((prev) => prev.filter((b) => b.id !== id));
    }
  };

  const handleSaveSettings = async (newSettings: SystemSettings) => {
    try {
      const data = await safeFetchJson('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings),
      });
      if (data?.settings) {
        setSettings(data.settings);
        showToast('Tetapan sistem berjaya disimpan.');
      } else {
        setSettings(newSettings);
      }
    } catch (err) {
      setSettings(newSettings);
    }
  };

  const handleSaveFlashSale = async (newFlashSale: FlashSaleConfig) => {
    try {
      const data = await safeFetchJson('/api/flash-sale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newFlashSale),
      });
      if (data?.flashSale) {
        setFlashSale(data.flashSale);
        showToast('Jualan Kilat berjaya dikemaskini secara langsung!');
      } else {
        setFlashSale(newFlashSale);
        showToast('Jualan Kilat disimpan secara tempatan.');
      }
    } catch (err) {
      setFlashSale(newFlashSale);
      showToast('Jualan Kilat disimpan secara tempatan.');
    }
  };

  const handleOrderSearch = async (queryId: string) => {
    const raw = (queryId || '').trim();
    const clean = raw.replace(/^#/, '').trim();
    const digits = raw.replace(/\D/g, '');

    try {
      const data = await safeFetchJson(`/api/orders/${encodeURIComponent(clean)}`);
      if (data?.orders) return data.orders;
      return [];
    } catch (err) {
      const cleanLower = clean.toLowerCase();
      // 1. Exact Order ID match (e.g. BZ-840080, #BZ-840080, TB-840080)
      const exactMatch = orders.filter((o) => {
        const oId = o.id.toLowerCase();
        const oIdClean = oId.replace(/^#/, '');
        return (
          oId === cleanLower ||
          oIdClean === cleanLower ||
          oIdClean.replace('-', '') === cleanLower.replace('-', '') ||
          `#${oIdClean}` === raw.toLowerCase()
        );
      });
      if (exactMatch.length > 0) return exactMatch;

      // 2. Numeric order ID match (e.g. '840080')
      if (digits.length >= 5) {
        const digitMatch = orders.filter((o) => o.id.replace(/\D/g, '') === digits);
        if (digitMatch.length > 0) return digitMatch;
      }

      // 3. Exact User ID match only if not searching with order prefix
      if (!cleanLower.startsWith('bz') && !cleanLower.startsWith('tb') && digits.length >= 3) {
        const userMatches = orders.filter(
          (o) => o.userId.toLowerCase() === cleanLower || o.userId.replace(/\D/g, '') === digits
        );
        if (userMatches.length > 0) return userMatches;
      }

      return [];
    }
  };

  const handleVerifyEmail = async (email: string, code: string) => {
    try {
      const data = await safeFetchJson('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otpCode: code }),
      });
      if (data?.user) {
        setCurrentUser(data.user);
        if (data.users) setUsersList(data.users);
        showToast('Tahniah! Email anda berjaya disahkan.');
      }
    } catch (err) {
      if (currentUser) {
        setCurrentUser({ ...currentUser, isEmailVerified: true });
        showToast('Email berjaya disahkan.');
      }
    }
  };

  return (
    <div className={`min-h-screen w-full flex flex-col font-sans transition-colors duration-200 relative pb-28 ${
      theme === 'light'
        ? 'text-slate-900 selection:bg-orange-500 selection:text-white'
        : 'text-slate-100 selection:bg-orange-500 selection:text-slate-950'
    }`}>
      {/* ⚡ ZERO-LAG STATIONARY BACKGROUND (100% 60-120 FPS, ZERO REPAINTS ON SCROLL) */}
      <div
        className={`fixed inset-0 pointer-events-none -z-10 transition-colors duration-300 ${
          theme === 'light' ? 'bg-canvas-light' : 'bg-canvas-dark'
        }`}
        aria-hidden="true"
      />
      
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-6 right-4 z-50 p-4 rounded-2xl bg-slate-900 border border-orange-500/60 text-white text-xs font-bold shadow-[0_0_25px_rgba(255,140,0,0.4)] flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Bar (Only in customer store view) */}
      {activeTab !== 'admin' && (
        <Header
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          onOpenOrderTracker={() => setOrderTrackerOpen(true)}
          onOpenAdmin={() => setActiveTab('admin')}
          onSelectGameClick={() => {
            const el = document.getElementById('semua-game-section');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onOpenGmail={() => handleOpenGmailModal()}
          onlineCount={onlineCount}
          cartCount={cart.reduce((a, b) => a + b.quantity, 0)}
          onOpenCart={() => setCartModalOpen(true)}
          onOpenLiveChat={handleOpenLiveChatWithAuth}
          theme={theme}
          onToggleTheme={toggleTheme}
          games={games}
        />
      )}

      {/* Main Content Area */}
      {activeTab === 'admin' ? (
        <div className="flex-1 w-full animate-fadeIn min-h-screen">
          <AdminDashboard
            games={games}
            orders={orders}
            banners={banners}
            settings={settings}
            users={usersList}
            activityLogs={activityLogsList}
            flashSale={flashSale}
            isEmbedded={true}
            onClose={() => setActiveTab('menu')}
            onSaveGame={handleSaveGame}
            onDeleteGame={handleDeleteGame}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onSaveBanner={handleSaveBanner}
            onDeleteBanner={handleDeleteBanner}
            onSaveSettings={handleSaveSettings}
            onSaveFlashSale={handleSaveFlashSale}
            onOpenGmailModal={handleOpenGmailModal}
          />
        </div>
      ) : (
        <main className="flex-1 max-w-7xl mx-auto w-full px-3 sm:px-6 lg:px-8 pt-20 sm:pt-24 pb-28 space-y-8 relative z-10 overflow-x-clip">
          {activeTab === 'menu' && (
            <div className="space-y-8 animate-fadeIn">
              {/* Promo Hero Banner */}
              <HeroBanner
                banners={banners}
                onSelectGame={(slugOrId) => {
                  const targetGame = games.find(
                    (g) => g.id === slugOrId || g.slug === slugOrId || g.name.toLowerCase().includes(slugOrId.toLowerCase())
                  );
                  if (targetGame) handleInitiateTopup(targetGame);
                }}
                onTopupNowClick={() => {
                  const el = document.getElementById('semua-game-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
              />

              {/* Jualan Kilat (Flash Sale) Section */}
              <FlashSaleSection
                flashSale={flashSale}
                games={games}
                theme={theme}
                onSelectItem={(game, itemId) => {
                  handleInitiateTopup(game, itemId);
                }}
              />

              {/* Paling Banyak Dicari (Auto-Scroll Section) */}
              <MostSearchedSection
                games={games}
                onSelectGame={(g) => handleInitiateTopup(g)}
                theme={theme}
              />

              {/* Semua Game Section (Underneath Paling Banyak Dicari) */}
              <div id="semua-game-section" className="space-y-3.5 pt-1 pb-4">
                
                {/* Header & Subtitle */}
                <div className="space-y-1 px-1">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-xl bg-orange-500/20 text-orange-500 border border-orange-500/30">
                      <Gamepad2 className="w-4 h-4" />
                    </span>
                    <h2 className={`text-base sm:text-lg font-black tracking-tight uppercase ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                      Semua Game
                    </h2>
                  </div>
                  <p className={`text-[11px] sm:text-xs font-medium ${theme === 'light' ? 'text-slate-600' : 'text-slate-400'}`}>
                    Pilih pelbagai game & item kegemaran anda untuk topup segera dengan proses pantas dan selamat.
                  </p>
                </div>

                {/* Search Bar Underneath Subtitle */}
                <div className="relative w-full">
                  <input
                    type="text"
                    placeholder="Cari game kegemaran anda (e.g. Mobile Legends, Free Fire, Roblox)..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`w-full rounded-2xl pl-10 pr-12 py-3 text-xs sm:text-sm font-semibold transition-all focus:outline-none ${
                      theme === 'light'
                        ? 'bg-white border border-slate-200 text-slate-900 placeholder-slate-400 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 shadow-sm'
                        : 'bg-[#0D1117] border border-slate-800 text-white placeholder-slate-500 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/30 shadow-md'
                    }`}
                  />
                  <Filter className={`w-4 h-4 absolute left-3.5 top-3.5 ${theme === 'light' ? 'text-slate-400' : 'text-slate-500'}`} />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className={`absolute right-2.5 top-2.5 text-[11px] px-2.5 py-1 rounded-xl font-bold transition-colors cursor-pointer ${
                        theme === 'light'
                          ? 'bg-slate-200 text-slate-700 hover:bg-orange-500 hover:text-white'
                          : 'bg-slate-800 text-slate-300 hover:bg-orange-500 hover:text-slate-950'
                      }`}
                    >
                      Padam
                    </button>
                  )}
                </div>

                {/* Game Cards Grid (Strict 3 columns like screenshot) */}
                {filteredGames.length === 0 ? (
                  <div className={`text-center py-12 border rounded-3xl space-y-3 ${
                    theme === 'light'
                      ? 'bg-white border-slate-200 text-slate-800'
                      : 'bg-[#0D1117] border border-slate-800 text-slate-300'
                  }`}>
                    <p className="font-bold text-sm">
                      {searchQuery ? `Tiada game sepadan dengan "${searchQuery}"` : 'Tiada Game Ditemui'}
                    </p>
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-md cursor-pointer transition-all"
                      >
                        Papar Semua Game
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-2 sm:gap-3.5">
                    {filteredGames.map((game) => (
                      <GameCard
                        key={game.id}
                        game={game}
                        onSelectGame={(g) => handleInitiateTopup(g)}
                        theme={theme}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'transactions' && (
            <TransactionCheckView
              orders={orders}
              games={games}
              ownerPhone={settings.ownerWhatsApp}
              onSelectGame={(g) => handleInitiateTopup(g)}
              onGoToProfile={() => setActiveTab('profile')}
              theme={theme}
            />
          )}

          {activeTab === 'ranking' && (
            <RankingTopupView
              orders={orders}
              usersList={usersList}
              currentUser={currentUser}
              onGoToProfile={() => setActiveTab('profile')}
              onSelectTopup={() => {
                setActiveTab('menu');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              theme={theme}
            />
          )}

          {activeTab === 'reviews' && (
            <ReviewsSection
              reviews={reviews}
              onAddReview={handleAddReview}
            />
          )}

          {activeTab === 'tutorials' && (
            <TutorialSection
              settings={settings}
            />
          )}

          {activeTab === 'profile' && (
            <UserProfileView
              currentUser={currentUser}
              orders={orders}
              theme={theme}
              onLoginSuccess={(usr) => {
                setCurrentUser(usr);
                localStorage.setItem('topupbalz_current_user', JSON.stringify(usr));
              }}
              onLogOut={() => {
                setCurrentUser(null);
                localStorage.removeItem('topupbalz_current_user');
              }}
              onUpdatePhone={handleUpdatePhone}
              onUpdateAvatar={handleUpdateAvatar}
              onVerifyEmail={handleVerifyEmail}
              onOpenGmailModal={handleOpenGmailModal}
              onOpenAdmin={() => setActiveTab('admin')}
            />
          )}
        </main>
      )}

      {/* Topup Modal */}
      {/* Topup Form Full-Screen Modal */}
      {selectedGame && (
        <TopupModal
          game={selectedGame}
          settings={settings}
          currentUser={currentUser}
          initialItemId={selectedInitialItemId}
          flashSaleItems={flashSale?.items || []}
          onRequestLogin={() => {
            setPendingGameForTopup(selectedGame);
            openGoogleModal();
            showToast('Sila log masuk akaun Google dahulu untuk meneruskan topup!');
          }}
          onClose={() => {
            setSelectedGame(null);
            setSelectedInitialItemId(undefined);
          }}
          onAddToCart={handleAddToCart}
          onSubmitOrder={handleOrderSubmit}
          theme={theme}
        />
      )}

      {/* Cart Modal */}
      <CartModal
        isOpen={cartModalOpen}
        onClose={() => setCartModalOpen(false)}
        cart={cart}
        currentUser={currentUser}
        onRequestLogin={() => {
          openGoogleModal();
          showToast('Sila log masuk akaun Google dahulu untuk checkout troli!');
        }}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onUpdateUserId={handleUpdateCartUserId}
        onClearCart={handleClearCart}
        settings={settings}
        onSubmitCartOrders={handleSubmitCartOrders}
        theme={theme}
      />

      {/* Live Chat Modal */}
      <LiveChatModal
        isOpen={liveChatOpen}
        onClose={() => setLiveChatOpen(false)}
        currentUser={currentUser}
        settings={settings}
        theme={theme}
      />

      {/* Order Tracker Modal */}
      {orderTrackerOpen && (
        <OrderTrackerModal
          isOpen={orderTrackerOpen}
          onClose={() => setOrderTrackerOpen(false)}
          onSearchOrder={handleOrderSearch}
          ownerPhone={settings.ownerWhatsApp}
          theme={theme}
        />
      )}

      {/* Real Fast Google Auth Modal */}
      <GoogleAuthModal
        isOpen={isGoogleModalOpen}
        onClose={closeGoogleModal}
        onSuccess={(authResultUser) => {
          handleGoogleLoginSuccess(authResultUser);
          const rawDefaultName = authResultUser.name || (authResultUser.email ? authResultUser.email.split('@')[0] : 'Gamer');
          const cleanUsername = authResultUser.username || (authResultUser.email ? authResultUser.email.split('@')[0] : 'Gamer');
          const newUser: UserProfile = {
            id: authResultUser.id || `usr-${Date.now()}`,
            name: authResultUser.name || rawDefaultName,
            username: cleanUsername,
            email: authResultUser.email,
            avatarUrl: authResultUser.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(rawDefaultName)}`,
            googleId: authResultUser.id || '',
            createdAt: authResultUser.createdAt || new Date().toISOString(),
            lastLoginAt: new Date().toISOString(),
            isOnline: true,
            isEmailVerified: authResultUser.isEmailVerified !== undefined ? authResultUser.isEmailVerified : true,
            totalOrders: authResultUser.totalOrders || 0,
            totalSpent: authResultUser.totalSpent || 0,
          };
          setCurrentUser(newUser);
          localStorage.setItem('topupbalz_current_user', JSON.stringify(newUser));
        }}
      />

      {/* Clerk In-App Auth Modal (Virtual Routing without 404) */}
      <ClerkAuthModal
        isOpen={isClerkModalOpen}
        onClose={closeClerkModal}
        initialMode={clerkModalMode}
        onLoginSuccess={(usr) => {
          setCurrentUser(usr);
          localStorage.setItem('topupbalz_current_user', JSON.stringify(usr));
        }}
      />



      {/* Username Login Modal */}
      <UsernameLoginModal
        isOpen={loginModalOpen}
        onClose={() => {
          setLoginModalOpen(false);
          setPendingGameForTopup(null);
        }}
        titlePrompt={loginModalPrompt}
        theme={theme}
        onLoginSuccess={(usr) => {
          setCurrentUser(usr);
          localStorage.setItem('topupbalz_current_user', JSON.stringify(usr));
          setLoginModalOpen(false);
          if (pendingGameForTopup) {
            setSelectedGame(pendingGameForTopup);
            setPendingGameForTopup(null);
            showToast(`Log masuk berjaya sebagai @${usr.username || usr.name}! Membuka borang topup...`);
          } else {
            showToast(`Selamat datang, @${usr.username || usr.name}!`);
          }
        }}
      />

      {/* 9 Dots Menu Modal */}
      <NineDotsMenuModal
        isOpen={nineDotsOpen}
        onClose={() => setNineDotsOpen(false)}
        setActiveTab={setActiveTab}
        onOpenOrderTracker={() => setOrderTrackerOpen(true)}
        onOpenCalculator={() => setCalculatorOpen(true)}
        onOpenInfoModal={handleOpenInfoModal}
        theme={theme}
      />

      {/* Real Calculator Modal */}
      <RealCalculatorModal
        isOpen={calculatorOpen}
        onClose={() => setCalculatorOpen(false)}
        theme={theme}
      />

      {/* Info Pages Modal (FAQ, Contact Us, Privacy Policy, TOS) */}
      <InfoPagesModal
        isOpen={infoModalOpen}
        onClose={() => setInfoModalOpen(false)}
        defaultTab={infoModalTab}
        ownerWhatsApp={settings.ownerWhatsApp}
        theme={theme}
      />

      {/* Gmail Integration Modal */}
      <GmailIntegrationModal
        isOpen={gmailModalOpen}
        onClose={() => setGmailModalOpen(false)}
        defaultRecipient={gmailRecipient}
        onSuccessToast={(msg) => showToast(msg)}
      />

      {/* Customer Only Components: Bottom Navigation, Ticker, & Footer */}
      {activeTab !== 'admin' && (
        <>
          <LivePurchaseTicker orders={orders} games={games} theme={theme} />
          <BottomNav
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            reviewCount={reviews.length}
            currentUser={currentUser}
            onOpenNineDots={() => setNineDotsOpen(true)}
            theme={theme}
          />
          <Footer
            onOpenAdmin={() => setActiveTab('admin')}
            onOpenOrderTracker={() => setOrderTrackerOpen(true)}
            ownerWhatsApp={settings.ownerWhatsApp}
            onOpenInfoModal={handleOpenInfoModal}
            theme={theme}
          />
        </>
      )}

    </div>
  );
}
