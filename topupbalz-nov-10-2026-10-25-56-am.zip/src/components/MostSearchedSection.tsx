import React, { useRef, useState, useEffect } from 'react';
import { Flame, ChevronLeft, ChevronRight } from 'lucide-react';
import { Game } from '../types';
import { GameCard } from './GameCard';

interface MostSearchedSectionProps {
  games: Game[];
  onSelectGame: (game: Game) => void;
  theme?: 'dark' | 'light';
}

export const MostSearchedSection: React.FC<MostSearchedSectionProps> = ({
  games,
  onSelectGame,
  theme = 'dark',
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);
  const isLight = theme === 'light';

  // Filter most searched games (or fallback to popular/all games if none marked)
  const mostSearchedGames = React.useMemo(() => {
    const explicit = games.filter((g) => g.isMostSearched);
    if (explicit.length > 0) return explicit;
    const popular = games.filter((g) => g.isPopular);
    if (popular.length > 0) return popular;
    return games.slice(0, 6);
  }, [games]);

  // Continuous auto-scroll effect
  useEffect(() => {
    const container = scrollRef.current;
    if (!container || isPaused || mostSearchedGames.length <= 3) return;

    let animationFrameId: number;
    const speed = 0.65; // Smooth scroll pixel per tick

    const step = () => {
      if (!isPaused && container) {
        container.scrollLeft += speed;
        // When reaching near the end, loop smoothly back
        if (container.scrollLeft >= container.scrollWidth - container.clientWidth - 1) {
          container.scrollLeft = 0;
        }
      }
      animationFrameId = requestAnimationFrame(step);
    };

    animationFrameId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPaused, mostSearchedGames.length]);

  if (mostSearchedGames.length === 0) return null;

  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -240, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: 240, behavior: 'smooth' });
    }
  };

  return (
    <section className="space-y-2.5 pt-2 pb-1">
      {/* Header Section */}
      <div className="flex items-center justify-between px-1">
        <div className="space-y-0.5">
          <div className="flex items-center gap-1.5">
            <span className="p-1 rounded-lg bg-orange-500/20 text-orange-500 border border-orange-500/30">
              <Flame className="w-4 h-4 fill-orange-500 animate-pulse" />
            </span>
            <h2 className={`text-base sm:text-lg font-black tracking-tight uppercase ${isLight ? 'text-slate-900' : 'text-white'}`}>
              Paling Banyak Dicari
            </h2>
          </div>
          <p className={`text-[11px] sm:text-xs font-medium ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
            Beberapa game yang paling banyak ditopup dan banyak di cari
          </p>
        </div>

        {/* Scroll Nav Buttons (Desktop / Quick Jump) */}
        {mostSearchedGames.length > 3 && (
          <div className="hidden sm:flex items-center gap-1">
            <button
              onClick={scrollLeft}
              className={`p-1.5 rounded-xl border transition-all cursor-pointer ${
                isLight
                  ? 'bg-white border-slate-200 text-slate-600 hover:text-orange-600 hover:border-orange-300 shadow-sm'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:border-orange-500/50'
              }`}
              title="Skrol Kiri"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={scrollRight}
              className={`p-1.5 rounded-xl border transition-all cursor-pointer ${
                isLight
                  ? 'bg-white border-slate-200 text-slate-600 hover:text-orange-600 hover:border-orange-300 shadow-sm'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:border-orange-500/50'
              }`}
              title="Skrol Kanan"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Auto-Scrolling Edge-to-Edge Container (No outer card box) */}
      <div
        className="relative w-full -mx-4 px-4 sm:mx-0 sm:px-0 py-1"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
      >
        <div
          ref={scrollRef}
          className="flex items-stretch gap-2.5 sm:gap-3 overflow-x-auto no-scrollbar scroll-smooth py-1"
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          {/* Double list to create seamless infinite auto-scroll illusion if more than 3 games */}
          {(mostSearchedGames.length > 3
            ? [...mostSearchedGames, ...mostSearchedGames]
            : mostSearchedGames
          ).map((game, index) => (
            <div
              key={`${game.id}-${index}`}
              className="w-[110px] sm:w-[130px] md:w-[150px] shrink-0"
            >
              <GameCard game={game} onSelectGame={onSelectGame} isCompact={true} theme={theme} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
