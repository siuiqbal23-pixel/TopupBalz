import React, { useState, useEffect, useRef } from 'react';
import { CheckCircle2, Gamepad2, Sparkles } from 'lucide-react';
import { Order, Game } from '../types';
import { INITIAL_GAMES } from '../data/initialData';

interface LivePurchaseTickerProps {
  orders?: Order[];
  games?: Game[];
  theme?: 'dark' | 'light';
}

export const LivePurchaseTicker: React.FC<LivePurchaseTickerProps> = ({ orders = [], games = [], theme = 'dark' }) => {
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [imageError, setImageError] = useState(false);
  const prevOrderCountRef = useRef(orders.length);
  const hasShownSessionNoticeRef = useRef(false);
  const isLight = theme === 'light';

  // Find game logo based on currentOrder
  const getGameLogo = (order: Order): string | null => {
    const allGames = (games && games.length > 0) ? games : INITIAL_GAMES;
    
    // 1. Match by gameId
    const foundById = allGames.find(g => g.id === order.gameId);
    if (foundById?.logoUrl) return foundById.logoUrl;

    // 2. Match by exact gameName or partial name
    const orderGameName = (order.gameName || '').toLowerCase().trim();
    if (orderGameName) {
      const foundByName = allGames.find(g => 
        g.name.toLowerCase().includes(orderGameName) ||
        orderGameName.includes(g.name.toLowerCase()) ||
        (g.slug && orderGameName.includes(g.slug.replace(/-/g, ' ')))
      );
      if (foundByName?.logoUrl) return foundByName.logoUrl;
    }

    return null;
  };

  // Helper time ago
  const formatTimeAgo = (dateString: string) => {
    if (!dateString) return 'Baru sahaja';
    const diffMs = Date.now() - new Date(dateString).getTime();
    const diffSec = Math.max(0, Math.floor(diffMs / 1000));
    if (diffSec < 10) return 'Baru sahaja';
    if (diffSec < 60) return `${diffSec}s lepas`;
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin}m lepas`;
    const diffHour = Math.floor(diffMin / 60);
    if (diffHour < 24) return `${diffHour}j lepas`;
    const diffDay = Math.floor(diffHour / 24);
    return `${diffDay}d lepas`;
  };

  // Helper to extract the strictly REAL username from the order
  const getRealBuyerUsername = (order: Order): string => {
    if (order.accountUsername && order.accountUsername.trim()) {
      return order.accountUsername.trim();
    }
    if (order.customerPhone && order.customerPhone.trim()) {
      const clean = order.customerPhone.replace(/\D/g, '');
      if (clean.length >= 6) {
        const prefix = clean.startsWith('60') ? '0' + clean.substring(2, 4) : clean.substring(0, 3);
        const suffix = clean.substring(clean.length - 2);
        return `${prefix}***${suffix}`;
      }
      return clean;
    }
    return 'Pelanggan';
  };

  // Show notification when entering the website - stays visible until the user taps on it
  useEffect(() => {
    if (!orders || orders.length === 0 || hasShownSessionNoticeRef.current) return;

    const alreadyShownInStorage = sessionStorage.getItem('topupbalz_entry_ticker_shown');
    if (alreadyShownInStorage) return;

    hasShownSessionNoticeRef.current = true;
    sessionStorage.setItem('topupbalz_entry_ticker_shown', 'true');

    // Show initial order after 1.2s delay; stays visible until tapped/dismissed by user
    const timer = setTimeout(() => {
      if (orders.length > 0) {
        setCurrentOrder(orders[0]);
        setImageError(false);
        setIsVisible(true);
      }
    }, 1200);

    return () => clearTimeout(timer);
  }, [orders]);

  // Real-time: If a brand new order is placed while on page, show it (stays visible until tapped)
  useEffect(() => {
    if (orders && orders.length > 0) {
      const latest = orders[0];
      if (orders.length > prevOrderCountRef.current) {
        setCurrentOrder(latest);
        setImageError(false);
        setIsVisible(true);
      }
    }
    prevOrderCountRef.current = orders ? orders.length : 0;
  }, [orders]);

  if (!currentOrder || !isVisible || !orders || orders.length === 0) return null;

  const realUsername = getRealBuyerUsername(currentOrder);
  const gameLogo = getGameLogo(currentOrder);

  return (
    <div
      onClick={() => setIsVisible(false)}
      role="button"
      tabIndex={0}
      title="Tekan di mana-mana pada kad ini untuk tutup notifikasi"
      className="fixed bottom-20 left-2.5 right-2.5 sm:bottom-6 sm:left-6 sm:right-auto sm:max-w-md z-50 animate-bounce-short transition-all duration-300 cursor-pointer active:scale-[0.98] group select-none"
    >
      <div className={`relative backdrop-blur-xl border p-3 sm:p-3.5 rounded-2xl overflow-hidden transition-all duration-300 shadow-2xl ${
        isLight
          ? 'bg-white/95 border-orange-400/80 text-slate-900 shadow-[0_10px_35px_rgba(249,115,22,0.2)] hover:border-orange-500 hover:shadow-[0_12px_40px_rgba(249,115,22,0.3)]'
          : 'bg-[#0D1117]/95 border-orange-500/40 shadow-[0_10px_35px_rgba(0,0,0,0.85)] text-white hover:border-orange-400 hover:shadow-[0_0_30px_rgba(249,115,22,0.2)]'
      }`}>
        {/* Glow accent line */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-500 via-amber-400 to-emerald-400" />

        <div className="flex items-start gap-3">
          {/* Game Logo Thumbnail (Gantikan Logo Hijau dengan Logo Game yang dibeli) */}
          <div className="relative shrink-0">
            {gameLogo && !imageError ? (
              <div className="w-11 h-11 rounded-xl overflow-hidden p-0.5 bg-gradient-to-br from-orange-500 to-amber-500 shadow-md group-hover:scale-105 transition-transform">
                <img
                  src={gameLogo}
                  alt={currentOrder.gameName}
                  onError={() => setImageError(true)}
                  className="w-full h-full object-cover rounded-[10px]"
                />
              </div>
            ) : (
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-orange-500 to-amber-600 p-0.5 shrink-0 shadow-md flex items-center justify-center group-hover:scale-105 transition-transform">
                <Gamepad2 className="w-6 h-6 text-slate-950 font-bold" />
              </div>
            )}
            <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-[#0D1117] flex items-center justify-center shadow-xs">
              <CheckCircle2 className="w-2.5 h-2.5 text-white stroke-[3]" />
            </span>
          </div>

          <div className="flex-1 min-w-0 space-y-1">
            {/* Header: Real Buyer Username + Time */}
            <div className="flex items-center justify-between gap-1.5">
              <div className="flex items-center gap-1.5 min-w-0">
                <span className={`text-xs font-black font-mono truncate ${
                  isLight ? 'text-slate-900' : 'text-white'
                }`}>
                  {realUsername}
                </span>
                <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase shrink-0 border ${
                  isLight
                    ? 'bg-orange-100 text-orange-800 border-orange-300'
                    : 'bg-orange-500/20 text-orange-400 border-orange-500/40'
                }`}>
                  Pembeli
                </span>
              </div>
              <span className={`text-[10px] font-mono flex items-center gap-1 shrink-0 font-bold ${
                isLight ? 'text-emerald-700' : 'text-emerald-400'
              }`}>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                {formatTimeAgo(currentOrder.createdAt)}
              </span>
            </div>

            {/* Real Product Purchased */}
            <p className={`text-[11px] font-medium truncate ${
              isLight ? 'text-slate-700' : 'text-slate-300'
            }`}>
              Membeli <strong className="text-orange-500 font-bold">{currentOrder.itemName}</strong>
            </p>

            {/* Bottom Row: Transaction Status & Price + Tap to dismiss hint */}
            <div className={`flex items-center justify-between text-[10px] pt-1.5 border-t ${
              isLight ? 'border-slate-200' : 'border-slate-800/80'
            }`}>
              <span className={`font-medium flex items-center gap-1 ${
                isLight ? 'text-slate-600' : 'text-slate-400'
              }`}>
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span className="truncate max-w-[110px] font-semibold">{currentOrder.gameName}</span>
              </span>
              <div className="flex items-center gap-2">
                <span className={`font-mono font-bold flex items-center gap-1 ${
                  isLight ? 'text-emerald-700' : 'text-emerald-400'
                }`}>
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  <span>RM {(currentOrder.sellPrice || 0).toFixed(2)}</span>
                </span>
                <span className="text-[9px] text-slate-400 group-hover:text-rose-400 transition-colors font-bold">
                  ✕
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

