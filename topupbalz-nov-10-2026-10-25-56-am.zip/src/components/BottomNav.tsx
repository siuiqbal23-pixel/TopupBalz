import React from 'react';
import { Home, ReceiptText, Trophy, User } from 'lucide-react';
import { UserProfile } from '../types';

export type NavTab = 'menu' | 'transactions' | 'ranking' | 'tutorials' | 'profile' | 'admin' | 'reviews';

interface BottomNavProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  reviewCount?: number;
  currentUser?: UserProfile | null;
  onOpenOrderTracker?: () => void;
  onOpenCart?: () => void;
  cartCount?: number;
  onOpenNineDots?: () => void;
  theme?: 'dark' | 'light';
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onOpenNineDots,
  theme = 'dark',
}) => {
  const isLight = theme === 'light';

  return (
    <nav
      className={`fixed bottom-0 left-0 right-0 z-50 transition-colors duration-200 rounded-t-[24px] sm:rounded-t-[30px] select-none ${
        isLight
          ? 'bg-white/95 border-t border-slate-200/90 shadow-[0_-4px_20px_rgba(0,0,0,0.08)]'
          : 'bg-[#0A0D16]/95 border-t border-orange-500/30 shadow-[0_-8px_30px_rgba(0,0,0,0.95)]'
      }`}
      style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 6px)' }}
    >
      <div className="max-w-md md:max-w-xl mx-auto grid grid-cols-5 gap-1 items-center relative pt-2 pb-2 sm:pb-3 px-2 sm:px-6">
        
        {/* Bar 1: 1. Home */}
        <button
          onClick={() => {
            setActiveTab('menu');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all duration-200 cursor-pointer ${
            activeTab === 'menu'
              ? isLight
                ? 'text-orange-600 font-black drop-shadow-sm'
                : 'text-orange-400 font-black drop-shadow-[0_0_12px_rgba(249,115,22,0.6)]'
              : isLight
              ? 'text-slate-500 hover:text-slate-800'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative mb-0.5">
            <Home className={`w-5 h-5 ${activeTab === 'menu' ? 'scale-110 text-orange-500' : ''} transition-transform`} />
            {activeTab === 'menu' && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-orange-500 animate-ping" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] leading-tight text-center font-bold tracking-tight">
            1. Home
          </span>
        </button>

        {/* Bar 2: Semak Transaksi */}
        <button
          onClick={() => {
            setActiveTab('transactions');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all duration-200 cursor-pointer ${
            activeTab === 'transactions'
              ? isLight
                ? 'text-orange-600 font-black drop-shadow-sm'
                : 'text-orange-400 font-black drop-shadow-[0_0_12px_rgba(249,115,22,0.6)]'
              : isLight
              ? 'text-slate-500 hover:text-slate-800'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative mb-0.5">
            <ReceiptText className={`w-5 h-5 ${activeTab === 'transactions' ? 'scale-110 text-orange-500' : ''} transition-transform`} />
            {activeTab === 'transactions' && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-orange-500 animate-ping" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] leading-tight text-center font-bold tracking-tight">
            2. Semak
          </span>
        </button>

        {/* Bar Tengah: Titik 9 Floating Button */}
        <div className="relative flex justify-center items-center h-full">
          <button
            onClick={() => {
              if (onOpenNineDots) {
                onOpenNineDots();
              } else {
                setActiveTab('menu');
              }
            }}
            className={`absolute -top-6 sm:-top-7 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gradient-to-tr from-orange-600 via-orange-500 to-amber-500 hover:from-orange-500 hover:to-amber-400 active:scale-95 text-white flex items-center justify-center shadow-[0_0_25px_rgba(249,115,22,0.7)] border-4 ${
              isLight ? 'border-[#F8FAFC]' : 'border-[#07090D]'
            } cursor-pointer transition-all z-20 group`}
            title="Menu Kategori & Aplikasi"
          >
            <svg className="w-5 h-5 sm:w-6 sm:h-6 text-white group-hover:scale-110 transition-transform" viewBox="0 0 24 24" fill="currentColor">
              <circle cx="5" cy="5" r="2.2" />
              <circle cx="12" cy="5" r="2.2" />
              <circle cx="19" cy="5" r="2.2" />
              <circle cx="5" cy="12" r="2.2" />
              <circle cx="12" cy="12" r="2.2" />
              <circle cx="19" cy="12" r="2.2" />
              <circle cx="5" cy="19" r="2.2" />
              <circle cx="12" cy="19" r="2.2" />
              <circle cx="19" cy="19" r="2.2" />
            </svg>
          </button>
        </div>

        {/* Bar 3: Ranking Topup */}
        <button
          onClick={() => {
            setActiveTab('ranking');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all duration-200 cursor-pointer ${
            activeTab === 'ranking'
              ? isLight
                ? 'text-amber-600 font-black drop-shadow-sm'
                : 'text-amber-400 font-black drop-shadow-[0_0_12px_rgba(249,115,22,0.6)]'
              : isLight
              ? 'text-slate-500 hover:text-slate-800'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative mb-0.5">
            <Trophy className={`w-5 h-5 ${activeTab === 'ranking' ? 'scale-110 text-amber-500' : ''} transition-transform`} />
            {activeTab === 'ranking' && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-500 animate-ping" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] leading-tight text-center font-bold tracking-tight">
            3. Ranking
          </span>
        </button>

        {/* Bar 4: 4. Profile */}
        <button
          onClick={() => {
            setActiveTab('profile');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all duration-200 cursor-pointer ${
            activeTab === 'profile'
              ? isLight
                ? 'text-orange-600 font-black drop-shadow-sm'
                : 'text-orange-400 font-black drop-shadow-[0_0_12px_rgba(249,115,22,0.6)]'
              : isLight
              ? 'text-slate-500 hover:text-slate-800'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative mb-0.5">
            {currentUser ? (
              <div className="relative">
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.name}
                  className="w-5 h-5 rounded-full object-cover border border-orange-400/60"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://api.dicebear.com/7.x/avataaars/svg?seed=User';
                  }}
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 border border-slate-950" />
              </div>
            ) : (
              <User className={`w-5 h-5 ${activeTab === 'profile' ? 'scale-110 text-orange-500' : ''} transition-transform`} />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] leading-tight text-center font-bold tracking-tight">
            4. Profile
          </span>
        </button>

      </div>
    </nav>
  );
};
