import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  AlertCircle,
  ShieldCheck,
  CheckCircle2,
  Zap,
  Check,
  LogIn,
  User,
  Mail,
  Lock,
  Eye,
  EyeOff,
  RefreshCw,
  ShieldAlert,
} from 'lucide-react';
import {
  signInWithPopup,
  GoogleAuthProvider,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendEmailVerification,
  reload,
} from 'firebase/auth';
import { auth } from '../lib/firebase';
import { UserProfile } from '../types';

interface GoogleAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserProfile) => void;
}

export const GoogleAuthModal: React.FC<GoogleAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [tab, setTab] = useState<'google' | 'signin' | 'signup' | 'verify'>('google');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Sign In inputs
  const [signInIdentifier, setSignInIdentifier] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  const [showSignInPassword, setShowSignInPassword] = useState(false);

  // Sign Up inputs
  const [signUpUsername, setSignUpUsername] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signUpConfirmPassword, setSignUpConfirmPassword] = useState('');
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);

  // Verification states
  const [verifyingEmail, setVerifyingEmail] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);
  const [isResending, setIsResending] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendCooldown > 0) {
      timer = setInterval(() => {
        setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [resendCooldown]);

  if (!isOpen) return null;

  // Google 1-Click Sign-In
  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const result = await signInWithPopup(auth, provider);
      const fbUser = result.user;

      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: fbUser.email,
          name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Gamer',
          avatarUrl: fbUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(fbUser.displayName || 'Gamer')}`,
          id: fbUser.uid,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setErrorMessage(data.error || 'Ralat semasa log masuk melalui Google.');
        return;
      }

      if (data.user) {
        const verifiedUser = { ...data.user, isEmailVerified: true };
        setSuccessMessage(`Selamat datang, ${verifiedUser.name || verifiedUser.email}!`);
        setTimeout(() => {
          onSuccess(verifiedUser);
          onClose();
        }, 500);
      }
    } catch (err: any) {
      console.error('Google popup auth error:', err);
      if (err.code === 'auth/unauthorized-domain') {
        setErrorMessage('Domain web ini belum dibenarkan di Firebase Auth.');
      } else if (err.code === 'auth/popup-blocked' || err.code === 'auth/cancelled-popup-request') {
        setErrorMessage('Tetingkap popup Google disekat. Sila benarkan popup pelayar web.');
      } else if (err.code === 'auth/popup-closed-by-user') {
        setErrorMessage('Tetingkap log masuk Google ditutup sebelum selesai.');
      } else {
        setErrorMessage(err.message || 'Log masuk Google gagal. Sila cuba lagi.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Sign In with Email/Username & Password
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    if (!signInIdentifier.trim() || !signInPassword) {
      setErrorMessage('Sila masukkan maklumat log masuk anda!');
      return;
    }

    setIsLoading(true);
    try {
      if (signInIdentifier.includes('@')) {
        try {
          await signInWithEmailAndPassword(auth, signInIdentifier.trim(), signInPassword);
        } catch (e) {}
      }

      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: signInIdentifier.trim(),
          password: signInPassword,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setErrorMessage(data.error || 'Gagal log masuk akaun.');
        return;
      }

      if (data.user) {
        let loggedUser = data.user;
        if (auth.currentUser?.emailVerified) {
          loggedUser.isEmailVerified = true;
        }

        if (!loggedUser.isEmailVerified && loggedUser.email) {
          setVerifyingEmail(loggedUser.email);
          setTab('verify');
          setErrorMessage('Emel akaun anda belum disahkan. Sila sahkan emel anda.');
          return;
        }

        setSuccessMessage(`Selamat kembali, @${loggedUser.username || loggedUser.name}!`);
        setTimeout(() => {
          onSuccess(loggedUser);
          onClose();
        }, 500);
      }
    } catch (err: any) {
      setErrorMessage('Ralat sambungan. Sila cuba lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  // Sign Up with Email, Username & Password
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const cleanUsername = signUpUsername.trim().replace(/^@+/, '');
    const cleanEmail = signUpEmail.trim().toLowerCase();

    if (!cleanUsername || cleanUsername.length < 3) {
      setErrorMessage('Username mestilah sekurang-kurangnya 3 aksara!');
      return;
    }
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setErrorMessage('Sila gunakan alamat emel yang sah!');
      return;
    }
    if (signUpPassword.length < 6) {
      setErrorMessage('Kata laluan mestilah sekurang-kurangnya 6 aksara!');
      return;
    }
    if (signUpPassword !== signUpConfirmPassword) {
      setErrorMessage('Kata laluan dan pengesahan tidak sepadan!');
      return;
    }

    setIsLoading(true);
    try {
      let fbUid = '';
      try {
        const cred = await createUserWithEmailAndPassword(auth, cleanEmail, signUpPassword);
        fbUid = cred.user.uid;
        await sendEmailVerification(cred.user);
      } catch (fbErr: any) {
        console.warn('Firebase register notice:', fbErr.message);
      }

      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: cleanUsername,
          email: cleanEmail,
          password: signUpPassword,
          confirmPassword: signUpConfirmPassword,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setErrorMessage(data.error || 'Pendaftaran akaun gagal.');
        return;
      }

      if (data.user) {
        const newUser: UserProfile = {
          ...data.user,
          id: fbUid || data.user.id,
          isEmailVerified: false,
        };

        setVerifyingEmail(cleanEmail);
        setSuccessMessage('Pendaftaran berjaya! Selamat datang.');
        setTimeout(() => {
          onSuccess(newUser);
          onClose();
        }, 400);
      }
    } catch (err: any) {
      setErrorMessage('Ralat pendaftaran: ' + (err.message || 'Sila cuba lagi.'));
    } finally {
      setIsLoading(false);
    }
  };

  // Check Email Verification Status
  const handleCheckVerification = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);
    try {
      let isVerified = false;
      if (auth.currentUser) {
        await reload(auth.currentUser);
        if (auth.currentUser.emailVerified) isVerified = true;
      }

      if (verifyingEmail) {
        const res = await fetch('/api/auth/set-verified', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: verifyingEmail }),
        });
        const data = await res.json();
        if (data.success && data.user) isVerified = true;
      }

      if (isVerified) {
        setSuccessMessage('🎉 Emel anda telah disahkan! Log masuk berjaya.');
        const stored = localStorage.getItem('topupbalz_current_user');
        const userObj = stored ? { ...JSON.parse(stored), isEmailVerified: true } : { email: verifyingEmail, isEmailVerified: true };
        setTimeout(() => {
          onSuccess(userObj as any);
          onClose();
        }, 800);
      } else {
        setErrorMessage('Emel belum dikesan disahkan. Sila klik pautan di inbox/spam atau masukkan kod OTP 6-digit.');
      }
    } catch (err: any) {
      setErrorMessage('Gagal menyemak pengesahan. Sila cuba lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  // Resend Email Verification Link & OTP
  const handleResend = async () => {
    if (resendCooldown > 0 || isResending) return;
    setIsResending(true);
    try {
      if (auth.currentUser) await sendEmailVerification(auth.currentUser);
      if (verifyingEmail) {
        await fetch('/api/auth/send-verification-otp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: verifyingEmail }),
        });
      }
      setResendCooldown(30);
      setSuccessMessage(`Emel pengesahan baharu telah dihantar ke ${verifyingEmail}!`);
    } catch (err: any) {
      setErrorMessage('Ralat menghantar emel: ' + err.message);
    } finally {
      setIsResending(false);
    }
  };

  // Verify OTP Code
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode.trim()) return;
    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: verifyingEmail, otpCode: otpCode.trim() }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setErrorMessage(data.error || 'Kod OTP tidak sah.');
        return;
      }
      if (data.user) {
        setSuccessMessage('🎉 Emel anda berjaya disahkan!');
        setTimeout(() => {
          onSuccess(data.user);
          onClose();
        }, 700);
      }
    } catch (err: any) {
      setErrorMessage('Ralat mengesahkan kod OTP.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[145] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#0D1117] border border-orange-500/40 rounded-3xl p-6 sm:p-7 space-y-5 shadow-[0_0_60px_rgba(255,140,0,0.25)] text-white overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow Accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-900 border border-slate-700 hover:border-orange-500 text-slate-400 hover:text-white flex items-center justify-center text-sm font-bold transition-all cursor-pointer z-10"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="text-center space-y-1.5 relative z-10 pt-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-orange-500/15 border border-orange-500/30 text-orange-300 text-[10px] font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>TopupBalz Authentication</span>
          </div>

          <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            {tab === 'verify'
              ? 'Pengesahan Emel'
              : tab === 'signup'
              ? 'Daftar Akaun Baru'
              : tab === 'signin'
              ? 'Log Masuk Emel'
              : 'Log Masuk Akaun'}
          </h3>
          <p className="text-xs text-slate-300 max-w-xs mx-auto leading-relaxed">
            {tab === 'verify'
              ? 'Sahkan emel anda untuk menjamin keselamatan akaun & pesanan.'
              : 'Pilih kaedah log masuk untuk meneruskan pesanan anda.'}
          </p>
        </div>

        {/* Tabs Bar */}
        {tab !== 'verify' && (
          <div className="p-1 rounded-2xl bg-[#121824] border border-slate-800 grid grid-cols-3 gap-1 relative z-10">
            <button
              type="button"
              onClick={() => {
                setTab('google');
                setErrorMessage(null);
              }}
              className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                tab === 'google'
                  ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 font-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Google</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setTab('signin');
                setErrorMessage(null);
              }}
              className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                tab === 'signin'
                  ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 font-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Sign In</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setTab('signup');
                setErrorMessage(null);
              }}
              className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                tab === 'signup'
                  ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 font-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Sign Up</span>
            </button>
          </div>
        )}

        {/* Success Alert */}
        {successMessage && (
          <div className="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/50 text-emerald-300 text-xs font-bold flex items-center gap-2.5 animate-fadeIn relative z-10">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="p-3 rounded-2xl bg-rose-500/15 border border-rose-500/50 text-rose-300 text-xs font-bold flex items-center gap-2.5 animate-shake relative z-10">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 1: GOOGLE 1-CLICK */}
        {/* ========================================================= */}
        {tab === 'google' && (
          <div className="space-y-4 relative z-10 animate-fadeIn">
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full py-3.5 px-6 rounded-2xl bg-white hover:bg-slate-100 active:scale-98 text-slate-900 font-black text-sm flex items-center justify-center gap-3 transition-all shadow-md cursor-pointer disabled:opacity-50 border-2 border-slate-200 group"
            >
              {isLoading ? (
                <div className="flex items-center gap-2 text-slate-800">
                  <RefreshCw className="w-4 h-4 animate-spin text-orange-500" />
                  <span>Menyambung ke Google...</span>
                </div>
              ) : (
                <>
                  <svg className="w-5 h-5 shrink-0 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Log Masuk Melalui Google</span>
                </>
              )}
            </button>

            <div className="p-3.5 rounded-2xl bg-[#121824] border border-slate-800/80 space-y-2 text-left">
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Pantas & emel disahkan automatik</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <Zap className="w-4 h-4 text-orange-400 shrink-0" />
                <span>Auto-sync pesanan & resit WhatsApp</span>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 2: SIGN IN */}
        {/* ========================================================= */}
        {tab === 'signin' && (
          <form onSubmit={handleSignIn} className="space-y-3.5 relative z-10 animate-fadeIn text-left">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Username atau Emel:</label>
              <div className="relative">
                <User className="w-4 h-4 text-orange-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={signInIdentifier}
                  onChange={(e) => setSignInIdentifier(e.target.value)}
                  placeholder="username atau nama@gmail.com"
                  className="w-full border rounded-xl pl-9 pr-3 py-2 text-xs font-mono bg-[#121824] border-slate-700 focus:border-orange-500 text-white focus:outline-none"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Kata Laluan:</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-orange-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showSignInPassword ? 'text' : 'password'}
                  required
                  value={signInPassword}
                  onChange={(e) => setSignInPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full border rounded-xl pl-9 pr-9 py-2 text-xs font-mono bg-[#121824] border-slate-700 focus:border-orange-500 text-white focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowSignInPassword(!showSignInPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showSignInPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all disabled:opacity-50"
            >
              {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <LogIn className="w-4 h-4" />}
              <span>{isLoading ? 'Memproses...' : 'Log Masuk (Sign In)'}</span>
            </button>
          </form>
        )}

        {/* ========================================================= */}
        {/* TAB 3: SIGN UP (Verifikasi Emel Diperlukan) */}
        {/* ========================================================= */}
        {tab === 'signup' && (
          <form onSubmit={handleSignUp} className="space-y-3 relative z-10 animate-fadeIn text-left">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Username:</label>
              <input
                type="text"
                required
                value={signUpUsername}
                onChange={(e) => setSignUpUsername(e.target.value.replace(/\s+/g, ''))}
                placeholder="cth: gamer_balzz"
                className="w-full border rounded-xl px-3 py-2 text-xs font-mono bg-[#121824] border-slate-700 focus:border-orange-500 text-white focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Alamat Emel:</label>
              <input
                type="email"
                required
                value={signUpEmail}
                onChange={(e) => setSignUpEmail(e.target.value)}
                placeholder="nama@gmail.com"
                className="w-full border rounded-xl px-3 py-2 text-xs font-mono bg-[#121824] border-slate-700 focus:border-orange-500 text-white focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-300">Kata Laluan:</label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={signUpPassword}
                  onChange={(e) => setSignUpPassword(e.target.value)}
                  placeholder="Min 6 aksara"
                  className="w-full border rounded-xl px-3 py-2 text-xs font-mono bg-[#121824] border-slate-700 focus:border-orange-500 text-white focus:outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-300">Sahkan Kata Laluan:</label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={signUpConfirmPassword}
                  onChange={(e) => setSignUpConfirmPassword(e.target.value)}
                  placeholder="Ulang kata laluan"
                  className="w-full border rounded-xl px-3 py-2 text-xs font-mono bg-[#121824] border-slate-700 focus:border-orange-500 text-white focus:outline-none"
                />
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
              <span>Emel wajib disahkan selepas mendaftar untuk keselamatan akaun.</span>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all disabled:opacity-50"
            >
              {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              <span>{isLoading ? 'Mendaftar...' : 'Daftar Akaun Sekarang'}</span>
            </button>
          </form>
        )}

        {/* ========================================================= */}
        {/* TAB 4: EMAIL VERIFICATION VIEW ("email kene verifikasi") */}
        {/* ========================================================= */}
        {tab === 'verify' && (
          <div className="space-y-4 relative z-10 animate-fadeIn text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/50 text-amber-400 flex items-center justify-center mx-auto">
              <Mail className="w-7 h-7 animate-bounce" />
            </div>

            <div className="space-y-1">
              <p className="text-xs text-slate-300">Pautan verifikasi telah dihantar ke:</p>
              <span className="font-mono font-bold text-orange-400 text-xs px-3 py-1 rounded-lg bg-orange-500/10 border border-orange-500/30 inline-block">
                {verifyingEmail}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-[#121824] border border-slate-800 text-[11px] text-slate-300 text-left space-y-1.5">
              <p className="font-bold text-amber-400">Langkah Pengesahan:</p>
              <p>1. Buka peti emel anda (semak Inbox atau folder Spam).</p>
              <p>2. Klik pautan pengesahan dari Firebase / TopupBalz.</p>
              <p>3. Tekan butang "Semak Status" di bawah.</p>
            </div>

            <div className="space-y-2">
              <button
                type="button"
                onClick={handleCheckVerification}
                disabled={isLoading}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all disabled:opacity-50"
              >
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                <span>Saya Dah Klik Pautan (Semak Status)</span>
              </button>

              <button
                type="button"
                onClick={handleResend}
                disabled={resendCooldown > 0 || isResending}
                className="w-full py-2 rounded-xl border border-slate-700 text-xs font-bold text-slate-300 hover:text-white cursor-pointer disabled:opacity-50"
              >
                {resendCooldown > 0 ? `Hantar Semula (${resendCooldown}s)` : 'Hantar Semula Pautan'}
              </button>
            </div>

            {/* OTP Input Alternative */}
            <form onSubmit={handleVerifyOtp} className="pt-2 border-t border-slate-800 flex gap-2">
              <input
                type="text"
                maxLength={6}
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                placeholder="Kod OTP 6-Digit"
                className="flex-1 border rounded-xl px-3 py-2 text-center text-xs font-mono bg-[#121824] border-slate-700 text-white focus:outline-none focus:border-orange-500"
              />
              <button
                type="submit"
                disabled={isLoading || !otpCode.trim()}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-orange-500 hover:text-slate-950 text-white text-xs font-bold border border-slate-700 cursor-pointer disabled:opacity-50"
              >
                Sahkan
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
