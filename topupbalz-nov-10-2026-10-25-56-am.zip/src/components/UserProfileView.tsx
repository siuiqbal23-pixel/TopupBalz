import React, { useState, useEffect, useRef } from 'react';
import {
  User,
  LogIn,
  LogOut,
  ShieldCheck,
  Smartphone,
  ShoppingBag,
  Clock,
  CheckCircle2,
  Copy,
  Check,
  Sparkles,
  ChevronRight,
  Zap,
  Edit2,
  Save,
  Globe,
  Mail,
  Lock,
  ExternalLink,
  KeyRound,
  ShieldAlert,
  AlertCircle,
  Camera,
  Image as ImageIcon,
  UploadCloud,
  RefreshCw,
  X,
  Eye,
  EyeOff,
  Send,
  HelpCircle,
  Key,
  Shield,
  ArrowRight,
} from 'lucide-react';
import {
  signInWithPopup,
  GoogleAuthProvider,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signOut,
  reload,
} from 'firebase/auth';
import { auth } from '../lib/firebase';
import { UserProfile, Order } from '../types';
import { useAppAuth } from '../context/AuthContext';
import { ADMIN_USERNAME, ADMIN_PIN_CODE } from '../lib/clerkConfig';

const AVATAR_PRESETS = [
  { id: 'mecha', name: 'TB Mecha', url: 'https://api.dicebear.com/7.x/bottts/svg?seed=TopupBalzMecha' },
  { id: 'cyber', name: 'Cyber Neon', url: 'https://api.dicebear.com/7.x/bottts/svg?seed=CyberNeon' },
  { id: 'gamer', name: 'Gamer Legend', url: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=250&auto=format&fit=crop&q=80' },
  { id: 'anime', name: 'Anime Warrior', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=250&auto=format&fit=crop&q=80' },
  { id: 'gold', name: 'VIP Gold', url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=250&auto=format&fit=crop&q=80' },
  { id: 'diamond', name: 'Diamond King', url: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=250&auto=format&fit=crop&q=80' },
];

const compressAndCropImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const size = Math.min(img.width, img.height);
        const targetSize = 400;
        canvas.width = targetSize;
        canvas.height = targetSize;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }
        // Center crop to square
        const sx = (img.width - size) / 2;
        const sy = (img.height - size) / 2;
        ctx.drawImage(img, sx, sy, size, size, 0, 0, targetSize, targetSize);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => reject(new Error('Gagal memproses gambar'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Gagal membaca fail'));
    reader.readAsDataURL(file);
  });
};

interface UserProfileViewProps {
  currentUser: UserProfile | null;
  orders: Order[];
  onLoginSuccess: (user: UserProfile) => void;
  onLogOut: () => void;
  onUpdatePhone: (phone: string) => Promise<void>;
  onUpdateAvatar?: (avatarUrl: string) => Promise<void> | void;
  onVerifyEmail?: (email: string, code: string) => Promise<void>;
  onOpenGmailModal?: (email?: string) => void;
  onOpenAdmin?: () => void;
  theme?: 'dark' | 'light';
}

export const UserProfileView: React.FC<UserProfileViewProps> = ({
  currentUser: propUser,
  orders,
  onLoginSuccess,
  onLogOut,
  onUpdatePhone,
  onUpdateAvatar,
  onVerifyEmail,
  onOpenGmailModal,
  onOpenAdmin,
  theme = 'dark',
}) => {
  const isLight = theme === 'light';
  const {
    isClerkConfigured,
    isSignedIn: isClerkSignedIn,
    user: authUser,
    isAdmin,
    adminPinVerified,
    verifyAdminPin,
    setUsername: setAuthUsername,
    updateUserAvatar: setAuthAvatar,
    updateUserPhone,
    openSignInModal,
    openSignUpModal,
    openGoogleModal,
    logout: clerkLogout,
  } = useAppAuth();

  // Active user priority
  const activeUser = authUser || propUser;

  // Authentication Mode Tab: 'signin' | 'signup'
  const [authTab, setAuthTab] = useState<'signin' | 'signup'>('signin');

  // Sign In form states
  const [signInIdent, setSignInIdent] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  const [signInAdminPin, setSignInAdminPin] = useState('');
  const [showSignInPassword, setShowSignInPassword] = useState(false);

  // Sign Up form states
  const [signUpUsername, setSignUpUsername] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signUpConfirmPassword, setSignUpConfirmPassword] = useState('');
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);

  // Common Auth Notification states
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSuccessMessage, setAuthSuccessMessage] = useState<string | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Email Verification modal & process states
  const [verificationModalOpen, setVerificationModalOpen] = useState(false);
  const [verifyingEmail, setVerifyingEmail] = useState('');
  const [otpCodeInput, setOtpCodeInput] = useState('');
  const [isCheckingVerification, setIsCheckingVerification] = useState(false);
  const [isResendingEmail, setIsResendingEmail] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const [verificationFeedback, setVerificationFeedback] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  // Forgot password modal
  const [forgotPasswordOpen, setForgotPasswordOpen] = useState(false);
  const [forgotEmailInput, setForgotEmailInput] = useState('');
  const [forgotFeedback, setForgotFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSendingReset, setIsSendingReset] = useState(false);

  // Profile edit states
  const [editingPhone, setEditingPhone] = useState(false);
  const [phoneInput, setPhoneInput] = useState(activeUser?.phoneNumber || '');
  const [phoneSuccessMsg, setPhoneSuccessMsg] = useState<string | null>(null);
  // Avatar Modal States
  const [avatarModalOpen, setAvatarModalOpen] = useState(false);
  const [selectedAvatarPreview, setSelectedAvatarPreview] = useState<string | null>(null);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [avatarSuccessMessage, setAvatarSuccessMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // PIN prompt modal for accessing Admin
  const [pinPromptOpen, setPinPromptOpen] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  useEffect(() => {
    if (activeUser?.phoneNumber) {
      setPhoneInput(activeUser.phoneNumber);
    }
    if (activeUser?.email) {
      setVerifyingEmail(activeUser.email);
    }
  }, [activeUser?.phoneNumber, activeUser?.email]);

  // Resend cooldown timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendCooldown > 0) {
      timer = setInterval(() => {
        setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [resendCooldown]);

  const cleanSignInIdent = signInIdent.trim().replace(/^@+/, '');
  const isTargetingAdminOnSignIn =
    cleanSignInIdent.toLowerCase() === 'siuiqbal23' ||
    cleanSignInIdent.toLowerCase() === ADMIN_USERNAME.toLowerCase() ||
    cleanSignInIdent.toLowerCase() === 'balzltdsdn' ||
    cleanSignInIdent.toLowerCase() === 'balzz';

  // ==========================================
  // 1. GOOGLE 1-CLICK SIGN IN ("Log Google")
  // ==========================================
  const handleGoogleSignIn = async () => {
    setIsAuthLoading(true);
    setAuthError(null);
    setAuthSuccessMessage(null);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const result = await signInWithPopup(auth, provider);
      const fbUser = result.user;

      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: fbUser.email,
          name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Gamer',
          avatarUrl: fbUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(fbUser.displayName || 'Gamer')}`,
          id: fbUser.uid,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setAuthError(data.error || 'Ralat semasa log masuk melalui Google.');
        return;
      }

      if (data.user) {
        // Google accounts have verified email automatically
        const userObj: UserProfile = {
          ...data.user,
          isEmailVerified: true,
        };
        localStorage.setItem('topupbalz_current_user', JSON.stringify(userObj));
        onLoginSuccess(userObj);
        setAuthSuccessMessage(`Selamat datang, ${userObj.name || userObj.email}!`);
      }
    } catch (err: any) {
      console.error('Google popup auth error:', err);
      if (err.code === 'auth/unauthorized-domain') {
        setAuthError('Domain web ini belum dibenarkan di Firebase Auth Authorized Domains.');
      } else if (err.code === 'auth/popup-blocked' || err.code === 'auth/cancelled-popup-request') {
        setAuthError('Tetingkap popup Google disekat oleh pelayar web. Sila benarkan popup (Allow popups).');
      } else if (err.code === 'auth/popup-closed-by-user') {
        setAuthError('Tetingkap log masuk Google ditutup sebelum selesai.');
      } else {
        setAuthError(err.message || 'Log masuk Google gagal. Sila cuba lagi.');
      }
    } finally {
      setIsAuthLoading(false);
    }
  };

  // ==========================================
  // 2. SIGN IN (Email / Username & Password)
  // ==========================================
  const handlePerformSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMessage(null);

    if (!signInIdent.trim()) {
      setAuthError('Sila masukkan username atau alamat emel anda!');
      return;
    }
    if (!signInPassword) {
      setAuthError('Sila masukkan kata laluan anda!');
      return;
    }

    if (isTargetingAdminOnSignIn) {
      if (!signInAdminPin.trim() || signInAdminPin.trim() !== ADMIN_PIN_CODE) {
        setAuthError('PIN keselamatan admin tidak sah. Sila semak semula.');
        return;
      }
    }

    setIsAuthLoading(true);
    try {
      // Also attempt Firebase auth if email is provided
      if (signInIdent.includes('@')) {
        try {
          await signInWithEmailAndPassword(auth, signInIdent.trim(), signInPassword);
        } catch (fbErr: any) {
          console.warn('Firebase sign in note:', fbErr.message);
        }
      }

      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: signInIdent.trim(),
          password: signInPassword,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setAuthError(data.error || 'Gagal log masuk. Sila semak maklumat anda.');
        return;
      }

      if (data.user) {
        let loggedInUser: UserProfile = data.user;

        // Check Firebase current user status if email verified
        if (auth.currentUser?.emailVerified) {
          loggedInUser.isEmailVerified = true;
        }

        localStorage.setItem('topupbalz_current_user', JSON.stringify(loggedInUser));
        if (isTargetingAdminOnSignIn) {
          verifyAdminPin(ADMIN_PIN_CODE);
        } else {
          localStorage.removeItem('topupbalz_admin_pin_verified');
        }

        onLoginSuccess(loggedInUser);
        setAuthSuccessMessage(`Selamat kembali, @${loggedInUser.username || loggedInUser.name}!`);

        // If email is not verified, open verification prompt immediately!
        if (!loggedInUser.isEmailVerified && loggedInUser.email) {
          setVerifyingEmail(loggedInUser.email);
          setVerificationModalOpen(true);
        }
      }
    } catch (err: any) {
      setAuthError('Ralat sambungan pelayan. Sila cuba sebentar lagi.');
    } finally {
      setIsAuthLoading(false);
    }
  };

  // ==========================================
  // 3. SIGN UP (Register with Email & Password)
  // ==========================================
  const handlePerformSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMessage(null);

    const cleanUsername = signUpUsername.trim().replace(/^@+/, '');
    const cleanEmail = signUpEmail.trim().toLowerCase();

    if (!cleanUsername || cleanUsername.length < 3) {
      setAuthError('Username mestilah sekurang-kurangnya 3 aksara!');
      return;
    }
    if (!/^[a-zA-Z0-9_]+$/.test(cleanUsername)) {
      setAuthError('Username hanya boleh mengandungi huruf, nombor dan garis bawah (_).');
      return;
    }
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setAuthError('Sila masukkan alamat emel yang sah (cth: nama@gmail.com)!');
      return;
    }
    if (signUpPassword.length < 6) {
      setAuthError('Kata laluan mestilah sekurang-kurangnya 6 aksara!');
      return;
    }
    if (signUpPassword !== signUpConfirmPassword) {
      setAuthError('Pengesahan kata laluan tidak sepadan!');
      return;
    }

    setIsAuthLoading(true);
    try {
      // 1. Create Firebase Auth user and send Firebase email verification
      let firebaseUid = '';
      try {
        const userCred = await createUserWithEmailAndPassword(auth, cleanEmail, signUpPassword);
        firebaseUid = userCred.user.uid;
        // Send email verification link from Firebase
        await sendEmailVerification(userCred.user);
      } catch (fbErr: any) {
        console.warn('Firebase createUser notice:', fbErr.message);
        // If email already in use on Firebase, proceed or alert
        if (fbErr.code === 'auth/email-already-in-use') {
          // If already in firebase, try signIn to send verification
          try {
            const signed = await signInWithEmailAndPassword(auth, cleanEmail, signUpPassword);
            await sendEmailVerification(signed.user);
          } catch (e) {}
        }
      }

      // 2. Call server /api/auth/register (stores with isEmailVerified: false)
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: cleanUsername,
          email: cleanEmail,
          password: signUpPassword,
          confirmPassword: signUpConfirmPassword,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setAuthError(data.error || 'Pendaftaran akaun gagal.');
        return;
      }

      if (data.user) {
        const newUser: UserProfile = {
          ...data.user,
          id: firebaseUid || data.user.id,
          isEmailVerified: false, // Mandatory verification required!
        };

        localStorage.setItem('topupbalz_current_user', JSON.stringify(newUser));
        onLoginSuccess(newUser);

        // Verification happens when logged in via profile banner as requested
        setVerifyingEmail(cleanEmail);
        setAuthSuccessMessage('Akaun berjaya didaftarkan! Selamat datang ke TopupBalz.');
      }
    } catch (err: any) {
      setAuthError('Ralat semasa pendaftaran akaun. Sila cuba lagi.');
    } finally {
      setIsAuthLoading(false);
    }
  };

  // ==========================================
  // 4. CHECK EMAIL VERIFICATION STATUS
  // ==========================================
  const handleCheckEmailVerification = async () => {
    setIsCheckingVerification(true);
    setVerificationFeedback(null);
    try {
      let isVerified = false;

      // Check with Firebase Auth reload
      if (auth.currentUser) {
        await reload(auth.currentUser);
        if (auth.currentUser.emailVerified) {
          isVerified = true;
        }
      }

      // Check with server
      const targetEmail = verifyingEmail || activeUser?.email;
      if (targetEmail) {
        const res = await fetch('/api/auth/set-verified', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: targetEmail,
            userId: activeUser?.id,
          }),
        });
        const data = await res.json();
        if (data.success && data.user) {
          isVerified = true;
        }
      }

      if (isVerified && activeUser) {
        const updated: UserProfile = { ...activeUser, isEmailVerified: true };
        localStorage.setItem('topupbalz_current_user', JSON.stringify(updated));
        onLoginSuccess(updated);
        setVerificationFeedback({
          type: 'success',
          text: '🎉 Tahniah! Emel anda telah berjaya disahkan. Akaun anda kini aktif sepenuhnya!',
        });
        setTimeout(() => {
          setVerificationModalOpen(false);
        }, 1500);
      } else {
        setVerificationFeedback({
          type: 'info',
          text: 'Emel belum dikesan disahkan. Sila buka peti emel anda (semak Inbox atau folder Spam) dan klik pautan pengesahan, atau gunakan Kod OTP di bawah.',
        });
      }
    } catch (err: any) {
      setVerificationFeedback({
        type: 'error',
        text: 'Gagal menyemak status pengesahan. Sila cuba sebentar lagi.',
      });
    } finally {
      setIsCheckingVerification(false);
    }
  };

  // ==========================================
  // 5. RESEND EMAIL VERIFICATION LINK & OTP
  // ==========================================
  const handleResendEmailVerification = async () => {
    if (resendCooldown > 0 || isResendingEmail) return;
    setIsResendingEmail(true);
    setVerificationFeedback(null);
    const targetEmail = verifyingEmail || activeUser?.email;

    try {
      // 1. Firebase send verification link
      if (auth.currentUser) {
        await sendEmailVerification(auth.currentUser);
      }

      // 2. Server send verification OTP
      if (targetEmail) {
        await fetch('/api/auth/send-verification-otp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: targetEmail }),
        });
      }

      setResendCooldown(30);
      setVerificationFeedback({
        type: 'success',
        text: `Emel pengesahan baharu telah dihantar ke ${targetEmail}! Sila semak inbox atau folder Spam.`,
      });
    } catch (err: any) {
      setVerificationFeedback({
        type: 'error',
        text: 'Ralat menghantar emel pengesahan: ' + (err.message || 'Sila cuba lagi.'),
      });
    } finally {
      setIsResendingEmail(false);
    }
  };

  // ==========================================
  // 6. VERIFY WITH 6-DIGIT OTP CODE
  // ==========================================
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanOtp = otpCodeInput.trim();
    if (!cleanOtp) {
      setVerificationFeedback({ type: 'error', text: 'Sila masukkan kod OTP 6-digit!' });
      return;
    }

    const targetEmail = verifyingEmail || activeUser?.email;
    if (!targetEmail) return;

    setIsCheckingVerification(true);
    try {
      const res = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: targetEmail, otpCode: cleanOtp }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setVerificationFeedback({
          type: 'error',
          text: data.error || 'Kod OTP tidak sah. Sila semak semula!',
        });
        return;
      }

      if (data.user && activeUser) {
        const updated: UserProfile = { ...activeUser, isEmailVerified: true };
        localStorage.setItem('topupbalz_current_user', JSON.stringify(updated));
        onLoginSuccess(updated);
        setVerificationFeedback({
          type: 'success',
          text: '🎉 Tahniah! Emel anda telah disahkan melalui Kod OTP!',
        });
        setTimeout(() => {
          setVerificationModalOpen(false);
          setOtpCodeInput('');
        }, 1200);
      }
    } catch (err: any) {
      setVerificationFeedback({ type: 'error', text: 'Ralat semasa mengesahkan kod OTP.' });
    } finally {
      setIsCheckingVerification(false);
    }
  };

  // ==========================================
  // 7. SEND PASSWORD RESET EMAIL
  // ==========================================
  const handleSendPasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmailInput.trim()) return;
    setIsSendingReset(true);
    setForgotFeedback(null);
    try {
      await sendPasswordResetEmail(auth, forgotEmailInput.trim());
      setForgotFeedback({
        type: 'success',
        text: `Pautan reset kata laluan telah dihantar ke ${forgotEmailInput.trim()}. Sila semak peti masuk anda.`,
      });
    } catch (err: any) {
      setForgotFeedback({
        type: 'error',
        text: 'Gagal menghantar reset kata laluan: ' + (err.message || 'Sila cuba lagi.'),
      });
    } finally {
      setIsSendingReset(false);
    }
  };

  // Dedicated Robust Log Out Handler
  const handlePerformLogout = async (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    setIsAuthLoading(true);
    try {
      await signOut(auth);
    } catch (e) {}

    try {
      if (clerkLogout) {
        await clerkLogout();
      }
    } catch (err) {
      console.warn('Clerk signOut error:', err);
    }

    localStorage.removeItem('topupbalz_current_user');
    localStorage.removeItem('topupbalz_admin_pin_verified');
    localStorage.removeItem('clerk-db-jwt');
    sessionStorage.clear();

    setSignInIdent('');
    setSignInPassword('');
    setSignInAdminPin('');
    setAuthError(null);
    setPinPromptOpen(false);
    setVerificationModalOpen(false);

    onLogOut();
    setIsAuthLoading(false);
  };

  // Handle Admin Button Click
  const handleAdminButtonClick = () => {
    const currentUsername = (activeUser?.username || activeUser?.name || '').replace(/^@+/, '').trim().toLowerCase();
    const currentEmail = (activeUser?.email || '').trim().toLowerCase();
    const isAdminUser =
      currentUsername === 'balzbalz' ||
      currentUsername === 'siuiqbal23' ||
      currentEmail === 'siuiqbal23@gmail.com' ||
      currentUsername === ADMIN_USERNAME.toLowerCase() ||
      currentUsername === 'balzltdsdn' ||
      currentUsername === 'balzz';

    if (!isAdminUser) {
      setAuthError('Akaun anda bukan pentadbir.');
      return;
    }

    if (!adminPinVerified) {
      setPinPromptOpen(true);
      setPinError(null);
      return;
    }

    onOpenAdmin?.();
  };

  // Submit Admin PIN Verification
  const handleVerifyPinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === ADMIN_PIN_CODE) {
      verifyAdminPin(pinInput.trim());
      setPinPromptOpen(false);
      setPinInput('');
      onOpenAdmin?.();
    } else {
      setPinError('PIN keselamatan tidak sah. Sila cuba lagi.');
    }
  };

  // Filter user's specific orders
  const userOrders = activeUser
    ? orders.filter((o) => {
        const accUserId = (o as any).accountUserId;
        const accUsername = (o as any).accountUsername;
        const uName = activeUser.username || activeUser.name;
        return (
          (accUserId && accUserId === activeUser.id) ||
          (accUsername && (accUsername === uName || accUsername === `@${uName}`)) ||
          o.userId === activeUser.id ||
          o.userId === uName ||
          (activeUser.phoneNumber && o.customerPhone && o.customerPhone.replace(/\D/g, '') === activeUser.phoneNumber.replace(/\D/g, '')) ||
          (activeUser.email && o.notes?.includes(activeUser.email))
        );
      })
    : [];

  const totalOrdersCount = Math.max(activeUser?.totalOrders || 0, userOrders.length);
  const totalSpentAmount = Math.max(
    activeUser?.totalSpent || 0,
    userOrders.reduce((sum, ord) => sum + (ord.sellPrice || ord.basePrice || 0), 0)
  );

  const cleanActiveUsername = (activeUser?.username || activeUser?.name || '').replace(/^@+/, '').trim().toLowerCase();
  const activeUserEmail = (activeUser?.email || '').trim().toLowerCase();
  const isCurrentlyAdminUser =
    (cleanActiveUsername === 'balzbalz' ||
    cleanActiveUsername === 'siuiqbal23' ||
    activeUserEmail === 'siuiqbal23@gmail.com' ||
    cleanActiveUsername === ADMIN_USERNAME.toLowerCase() ||
    cleanActiveUsername === 'balzltdsdn' ||
    cleanActiveUsername === 'balzz') && adminPinVerified;

  const handleSavePhone = async () => {
    const cleanPhone = phoneInput.trim();
    setIsSubmitting(true);
    try {
      await onUpdatePhone(cleanPhone);
      if (activeUser) {
        const updated = { ...activeUser, phoneNumber: cleanPhone };
        if (updateUserPhone) updateUserPhone(cleanPhone);
        localStorage.setItem('topupbalz_current_user', JSON.stringify(updated));
        onLoginSuccess(updated);
      }
      setPhoneSuccessMsg('Nombor telefon berjaya disimpan!');
      setTimeout(() => setPhoneSuccessMsg(null), 3500);
      setEditingPhone(false);
    } catch (e) {
      console.error('Error saving phone number:', e);
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  // Handle Gallery Photo Selection
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Sila pilih fail imej (PNG, JPG, JPEG, WEBP)!');
      return;
    }

    try {
      setIsUploadingAvatar(true);
      const compressed = await compressAndCropImage(file);
      setSelectedAvatarPreview(compressed);
    } catch (err) {
      console.error('Error compressing image:', err);
    } finally {
      setIsUploadingAvatar(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Handle Save New Avatar
  const handleSaveAvatar = async () => {
    if (!selectedAvatarPreview || !activeUser) return;
    setIsUploadingAvatar(true);
    try {
      if (onUpdateAvatar) {
        await onUpdateAvatar(selectedAvatarPreview);
      }
      setAuthAvatar(selectedAvatarPreview);
      const updated = { ...activeUser, avatarUrl: selectedAvatarPreview };
      localStorage.setItem('topupbalz_current_user', JSON.stringify(updated));
      onLoginSuccess(updated);

      setAvatarSuccessMessage('Gambar profil berjaya dikemaskini dari galeri!');
      setTimeout(() => {
        setAvatarModalOpen(false);
        setSelectedAvatarPreview(null);
        setAvatarSuccessMessage(null);
      }, 1000);
    } catch (err) {
      console.error('Failed to save avatar:', err);
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8 animate-fadeIn">
      
      {/* 📸 MODAL PILIH GAMBAR DARI GALERI / TUKAR AVATAR */}
      {avatarModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className={`border rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-6 animate-scaleIn relative overflow-hidden ${
            isLight
              ? 'bg-white border-orange-200 shadow-2xl text-slate-900'
              : 'bg-[#0D1117] border-orange-500/50 shadow-[0_0_50px_rgba(255,140,0,0.3)] text-white'
          }`}>
            <div className="absolute top-0 right-0 p-4">
              <button
                type="button"
                onClick={() => {
                  setAvatarModalOpen(false);
                  setSelectedAvatarPreview(null);
                }}
                className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                  isLight
                    ? 'bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-600'
                    : 'bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-orange-500/20 border border-orange-500/50 text-orange-500 flex items-center justify-center shrink-0">
                <Camera className="w-6 h-6" />
              </div>
              <div>
                <h3 className={`text-lg font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>Tukar Gambar Profil</h3>
                <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Pilih gambar dari galeri telefon / komputer anda</p>
              </div>
            </div>

            {avatarSuccessMessage && (
              <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 text-emerald-600 dark:text-emerald-300 text-xs font-bold flex items-center gap-2 animate-fadeIn">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
                <span>{avatarSuccessMessage}</span>
              </div>
            )}

            {/* HIDDEN FILE INPUT TRIGGER */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />

            {/* PREVIEW CONTAINER */}
            <div className={`flex flex-col items-center justify-center p-5 rounded-2xl border border-dashed space-y-4 ${
              isLight
                ? 'bg-slate-50 border-orange-300'
                : 'bg-[#121824] border-orange-500/40'
            }`}>
              <div className="relative">
                <img
                  src={selectedAvatarPreview || activeUser?.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(activeUser?.username || activeUser?.name || 'gamer')}`}
                  alt="Pratonton Avatar"
                  className={`w-28 h-28 sm:w-32 sm:h-32 rounded-3xl object-cover border-4 border-orange-500 shadow-xl ${
                    isLight ? 'bg-white' : 'bg-[#0D1117]'
                  }`}
                />
                {selectedAvatarPreview && (
                  <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black uppercase whitespace-nowrap shadow-md">
                    Pratonton
                  </span>
                )}
              </div>

              <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploadingAvatar}
                  className="py-3 px-4 rounded-xl bg-orange-500 hover:bg-orange-400 text-slate-950 font-black text-xs uppercase flex items-center justify-center gap-2 transition-all shadow-[0_0_20px_rgba(255,140,0,0.3)] cursor-pointer"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>{isUploadingAvatar ? 'Memproses...' : 'Pilih Dari Galeri'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveAvatar}
                  disabled={isUploadingAvatar || !selectedAvatarPreview}
                  className={`py-3 px-4 rounded-xl font-black text-xs uppercase flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    selectedAvatarPreview
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                      : isLight
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  {isUploadingAvatar ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  <span>Simpan Gambar</span>
                </button>
              </div>
            </div>

            {/* PRESET AVATARS SELECTION */}
            <div className="space-y-2.5">
              <span className={`text-[11px] font-bold uppercase tracking-wider block ${
                isLight ? 'text-slate-600' : 'text-slate-400'
              }`}>
                Atau Pilih Avatar Gaming Khas:
              </span>
              <div className="grid grid-cols-6 gap-2">
                {AVATAR_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setSelectedAvatarPreview(preset.url)}
                    className={`p-1 rounded-xl border-2 transition-all cursor-pointer overflow-hidden ${
                      selectedAvatarPreview === preset.url
                        ? 'border-orange-500 bg-orange-500/20 scale-105 shadow-[0_0_15px_rgba(255,140,0,0.4)]'
                        : isLight
                        ? 'border-slate-200 hover:border-orange-300 bg-slate-100'
                        : 'border-slate-800 hover:border-slate-600 bg-slate-900/60'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.name}
                      className="w-full h-10 sm:h-12 rounded-lg object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 🔐 MODAL PIN VERIFICATION FOR ADMIN */}
      {pinPromptOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className={`border rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-6 animate-scaleIn ${
            isLight
              ? 'bg-white border-orange-300 shadow-2xl text-slate-900'
              : 'bg-[#0D1117] border-orange-500/50 shadow-[0_0_50px_rgba(255,140,0,0.25)] text-white'
          }`}>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-orange-500/20 border border-orange-500/50 text-orange-500 flex items-center justify-center shrink-0">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <h3 className={`text-lg font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>Pengesahan PIN Keselamatan</h3>
                <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Sila masukkan PIN untuk membuka Pusat Kawalan</p>
              </div>
            </div>

            {pinError && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-600 dark:text-rose-300 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{pinError}</span>
              </div>
            )}

            <form onSubmit={handleVerifyPinSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className={`text-xs font-bold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  PIN 6-Digit:
                </label>
                <input
                  type="password"
                  maxLength={6}
                  autoFocus
                  required
                  value={pinInput}
                  onChange={(e) => {
                    setPinInput(e.target.value.replace(/\D/g, ''));
                    setPinError(null);
                  }}
                  placeholder="••••••"
                  className={`w-full border rounded-2xl px-4 py-3 text-center text-xl font-mono font-black tracking-widest focus:outline-none ${
                    isLight
                      ? 'bg-slate-50 border-orange-300 focus:border-orange-500 text-slate-900'
                      : 'bg-[#121824] border-orange-500/50 focus:border-orange-400 text-white'
                  }`}
                />
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setPinPromptOpen(false);
                    setPinInput('');
                    setPinError(null);
                  }}
                  className={`flex-1 py-3 rounded-2xl font-bold text-xs cursor-pointer transition-colors ${
                    isLight
                      ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase shadow-[0_0_20px_rgba(255,140,0,0.4)] cursor-pointer transition-all"
                >
                  Sahkan & Buka
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 📧 MODAL PENGESAHAN EMEL (EMAIL VERIFICATION) */}
      {verificationModalOpen && (
        <div className="fixed inset-0 z-[150] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className={`border rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 animate-scaleIn relative overflow-hidden ${
            isLight
              ? 'bg-white border-amber-300 shadow-2xl text-slate-900'
              : 'bg-[#0D1117] border-amber-500/50 shadow-[0_0_50px_rgba(245,158,11,0.25)] text-white'
          }`}>
            <div className="absolute top-0 right-0 p-4">
              <button
                type="button"
                onClick={() => setVerificationModalOpen(false)}
                className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                  isLight
                    ? 'bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-600'
                    : 'bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-center space-y-2 pt-2">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/50 text-amber-500 flex items-center justify-center mx-auto shadow-inner">
                <Mail className="w-8 h-8 animate-bounce" />
              </div>
              <h3 className={`text-xl font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Pengesahan Emel Diperlukan
              </h3>
              <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                Pautan pengesahan telah dihantar ke alamat emel:
              </p>
              <div className="inline-block px-3.5 py-1.5 rounded-xl bg-orange-500/15 border border-orange-500/40 text-orange-500 font-mono font-bold text-xs">
                {verifyingEmail || activeUser?.email || 'emel_anda@gmail.com'}
              </div>
            </div>

            {verificationFeedback && (
              <div className={`p-3.5 rounded-2xl border text-xs font-bold flex items-center gap-2.5 animate-fadeIn ${
                verificationFeedback.type === 'success'
                  ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-600 dark:text-emerald-300'
                  : verificationFeedback.type === 'error'
                  ? 'bg-rose-500/15 border-rose-500/50 text-rose-600 dark:text-rose-300'
                  : 'bg-blue-500/15 border-blue-500/50 text-blue-600 dark:text-blue-300'
              }`}>
                {verificationFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{verificationFeedback.text}</span>
              </div>
            )}

            {/* Step-by-Step Instructions */}
            <div className={`p-4 rounded-2xl border space-y-2.5 text-xs text-left ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
            }`}>
              <span className="font-black text-orange-500 uppercase tracking-wider text-[11px] block">
                Langkah-Langkah Pengesahan:
              </span>
              <div className="flex items-start gap-2 text-[11px] text-slate-300">
                <span className="w-4 h-4 rounded-full bg-orange-500/20 text-orange-400 font-bold flex items-center justify-center shrink-0">1</span>
                <span>Buka peti masuk emel anda (semak Inbox atau folder <strong>Spam/Junk</strong>).</span>
              </div>
              <div className="flex items-start gap-2 text-[11px] text-slate-300">
                <span className="w-4 h-4 rounded-full bg-orange-500/20 text-orange-400 font-bold flex items-center justify-center shrink-0">2</span>
                <span>Klik pautan pengesahan dari <strong>TopupBalz / Firebase</strong>.</span>
              </div>
              <div className="flex items-start gap-2 text-[11px] text-slate-300">
                <span className="w-4 h-4 rounded-full bg-orange-500/20 text-orange-400 font-bold flex items-center justify-center shrink-0">3</span>
                <span>Tekan butang <strong>"Semak Status Pengesahan"</strong> di bawah.</span>
              </div>
            </div>

            {/* Check Button & Resend Button */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={handleCheckEmailVerification}
                disabled={isCheckingVerification}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg cursor-pointer transition-all disabled:opacity-50"
              >
                {isCheckingVerification ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <ShieldCheck className="w-4 h-4" />
                )}
                <span>{isCheckingVerification ? 'Menyemak Status...' : 'Saya Sudah Klik Pautan (Semak Status)'}</span>
              </button>

              <button
                type="button"
                onClick={handleResendEmailVerification}
                disabled={resendCooldown > 0 || isResendingEmail}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold border transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                  resendCooldown > 0
                    ? 'opacity-60 cursor-not-allowed border-slate-700 text-slate-500'
                    : isLight
                    ? 'border-slate-300 hover:bg-slate-100 text-slate-700'
                    : 'border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isResendingEmail ? 'animate-spin' : ''}`} />
                <span>
                  {resendCooldown > 0
                    ? `Hantar Semula Emel (${resendCooldown}s)`
                    : isResendingEmail
                    ? 'Sedang Menghantar...'
                    : 'Hantar Semula Pautan Pengesahan'}
                </span>
              </button>
            </div>

            {/* Alternative OTP Section */}
            <div className="pt-2 border-t border-slate-800/80">
              <form onSubmit={handleVerifyOtp} className="space-y-2 text-left">
                <span className="text-[11px] font-bold text-slate-400 block">
                  Atau masukkan Kod OTP 6-Digit:
                </span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    maxLength={6}
                    value={otpCodeInput}
                    onChange={(e) => setOtpCodeInput(e.target.value.replace(/\D/g, ''))}
                    placeholder="cth: 123456"
                    className={`flex-1 border rounded-xl px-3 py-2 text-center text-sm font-mono tracking-widest focus:outline-none ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 focus:border-orange-500 text-slate-900'
                        : 'bg-[#121824] border-slate-700 focus:border-orange-500 text-white'
                    }`}
                  />
                  <button
                    type="submit"
                    disabled={isCheckingVerification || !otpCodeInput.trim()}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-orange-500 hover:text-slate-950 text-white text-xs font-bold border border-slate-700 transition-all cursor-pointer disabled:opacity-50"
                  >
                    Sahkan Kod
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* 🔐 MODAL LUPA KATA LALUAN */}
      {forgotPasswordOpen && (
        <div className="fixed inset-0 z-[150] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className={`border rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 animate-scaleIn relative overflow-hidden ${
            isLight
              ? 'bg-white border-orange-200 shadow-2xl text-slate-900'
              : 'bg-[#0D1117] border-orange-500/50 shadow-[0_0_50px_rgba(255,140,0,0.25)] text-white'
          }`}>
            <div className="absolute top-0 right-0 p-4">
              <button
                type="button"
                onClick={() => setForgotPasswordOpen(false)}
                className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                  isLight
                    ? 'bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-600'
                    : 'bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-orange-500/20 border border-orange-500/50 text-orange-500 flex items-center justify-center shrink-0">
                <Key className="w-6 h-6" />
              </div>
              <div>
                <h3 className={`text-lg font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>
                  Lupa Kata Laluan
                </h3>
                <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Masukkan alamat emel anda untuk reset kata laluan
                </p>
              </div>
            </div>

            {forgotFeedback && (
              <div className={`p-3 rounded-xl border text-xs font-bold flex items-center gap-2 ${
                forgotFeedback.type === 'success'
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400'
                  : 'bg-rose-500/15 border-rose-500/40 text-rose-400'
              }`}>
                {forgotFeedback.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" /> : <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />}
                <span>{forgotFeedback.text}</span>
              </div>
            )}

            <form onSubmit={handleSendPasswordReset} className="space-y-4">
              <div className="space-y-1.5 text-left">
                <label className={`text-xs font-bold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  Alamat Emel Berdaftar:
                </label>
                <input
                  type="email"
                  required
                  value={forgotEmailInput}
                  onChange={(e) => setForgotEmailInput(e.target.value)}
                  placeholder="nama@gmail.com"
                  className={`w-full border rounded-xl px-4 py-2.5 text-xs font-mono focus:outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 focus:border-orange-500 text-slate-900'
                      : 'bg-[#121824] border-slate-700 focus:border-orange-500 text-white'
                  }`}
                />
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setForgotPasswordOpen(false)}
                  className={`flex-1 py-3 rounded-2xl font-bold text-xs cursor-pointer transition-colors ${
                    isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSendingReset}
                  className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase shadow-md cursor-pointer transition-all disabled:opacity-50"
                >
                  {isSendingReset ? 'Menghantar...' : 'Hantar Pautan Reset'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 🚀 NOT LOGGED IN VIEW - GOOGLE LOGIN + SIGN IN + SIGN UP + EMAIL VERIFICATION */}
      {!activeUser ? (
        <div className={`border rounded-3xl p-6 sm:p-8 space-y-6 relative overflow-hidden max-w-xl mx-auto shadow-2xl ${
          isLight
            ? 'bg-white border-orange-200 shadow-xl text-slate-900'
            : 'bg-[#0D1117] border-orange-500/30 shadow-[0_0_50px_rgba(255,140,0,0.18)] text-white'
        }`}>
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Header */}
          <div className="text-center space-y-2 relative z-10">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-orange-500/20 via-amber-500/20 to-orange-500/10 border border-orange-500/40 text-orange-500 flex items-center justify-center mx-auto shadow-inner">
              <User className="w-8 h-8" />
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-600 dark:text-orange-300 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Akaun & Profil TopupBalz</span>
            </div>

            <h2 className={`text-2xl sm:text-3xl font-black tracking-tight ${isLight ? 'text-slate-900' : 'text-white'}`}>
              Selamat Datang ke TopupBalz
            </h2>
            <p className={`text-xs sm:text-sm max-w-md mx-auto leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
              Log masuk melalui Google atau gunakan emel anda untuk menyimpan rekod topup, kumpul mata ganjaran & urus profil.
            </p>
          </div>

          {/* Notifications / Alerts */}
          {authSuccessMessage && (
            <div className="p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/50 text-emerald-600 dark:text-emerald-300 text-xs font-bold flex items-center gap-2.5 animate-fadeIn relative z-10">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
              <span>{authSuccessMessage}</span>
            </div>
          )}

          {authError && (
            <div className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-500/50 text-rose-600 dark:text-rose-300 text-xs font-bold flex items-center gap-2.5 animate-shake relative z-10">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{authError}</span>
            </div>
          )}

          {/* 🌟 1. GOOGLE 1-CLICK LOGIN BUTTON ("Log Google") */}
          <div className="space-y-3 relative z-10">
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isAuthLoading}
              className="w-full py-3.5 px-6 rounded-2xl bg-white hover:bg-slate-100 active:scale-98 text-slate-900 font-black text-sm flex items-center justify-center gap-3 transition-all shadow-md cursor-pointer disabled:opacity-50 border-2 border-slate-200 group"
            >
              {isAuthLoading ? (
                <div className="flex items-center gap-2 text-slate-800">
                  <RefreshCw className="w-4 h-4 animate-spin text-orange-500" />
                  <span>Menyambung akaun...</span>
                </div>
              ) : (
                <>
                  <svg className="w-5 h-5 shrink-0 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Log Masuk Melalui Google (1-Klik Pantas)</span>
                </>
              )}
            </button>
            <p className="text-[11px] text-center text-emerald-600 dark:text-emerald-400 font-bold flex items-center justify-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Akaun Google disahkan secara automatik tanpa verifikasi manual</span>
            </p>
          </div>

          {/* DIVIDER */}
          <div className="relative flex items-center justify-center my-4">
            <div className={`w-full border-t ${isLight ? 'border-slate-200' : 'border-slate-800'}`} />
            <span className={`absolute px-4 text-[11px] font-bold uppercase tracking-wider ${
              isLight ? 'bg-white text-slate-400' : 'bg-[#0D1117] text-slate-500'
            }`}>
              atau guna emel & kata laluan
            </span>
          </div>

          {/* TAB SWITCHER: SIGN IN vs SIGN UP */}
          <div className={`p-1 rounded-2xl grid grid-cols-2 gap-1 border ${
            isLight ? 'bg-slate-100 border-slate-200' : 'bg-[#121824] border-slate-800'
          }`}>
            <button
              type="button"
              onClick={() => {
                setAuthTab('signin');
                setAuthError(null);
              }}
              className={`py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
                authTab === 'signin'
                  ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 shadow-md'
                  : isLight
                  ? 'text-slate-600 hover:text-slate-900'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <LogIn className="w-4 h-4" />
              <span>Log Masuk (Sign In)</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setAuthTab('signup');
                setAuthError(null);
              }}
              className={`py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
                authTab === 'signup'
                  ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 shadow-md'
                  : isLight
                  ? 'text-slate-600 hover:text-slate-900'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Daftar Akaun (Sign Up)</span>
            </button>
          </div>

          {/* ========================================================= */}
          {/* 🔑 SIGN IN FORM */}
          {/* ========================================================= */}
          {authTab === 'signin' && (
            <form onSubmit={handlePerformSignIn} className="space-y-4 animate-fadeIn">
              <div className="space-y-1.5 text-left">
                <label className={`text-xs font-bold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  Username atau Alamat Emel:
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-orange-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={signInIdent}
                    onChange={(e) => setSignInIdent(e.target.value)}
                    placeholder="cth: balzz atau gamer@gmail.com"
                    className={`w-full border rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono focus:outline-none ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 focus:border-orange-500 text-slate-900'
                        : 'bg-[#121824] border-slate-700 focus:border-orange-500 text-white'
                    }`}
                  />
                </div>
              </div>

              {/* Admin PIN if Balzz */}
              {isTargetingAdminOnSignIn && (
                <div className="space-y-1.5 text-left animate-fadeIn">
                  <label className="text-xs font-bold text-orange-500 flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4" />
                    <span>PIN Keselamatan Pentadbir (6-Digit):</span>
                  </label>
                  <input
                    type="password"
                    maxLength={6}
                    required
                    value={signInAdminPin}
                    onChange={(e) => setSignInAdminPin(e.target.value.replace(/\D/g, ''))}
                    placeholder="••••••"
                    className={`w-full border rounded-xl px-4 py-2.5 text-center text-sm font-mono tracking-widest focus:outline-none ${
                      isLight
                        ? 'bg-white border-orange-300 text-slate-900 focus:border-orange-500'
                        : 'bg-[#0D1117] border-orange-500 text-white focus:border-amber-400'
                    }`}
                  />
                </div>
              )}

              <div className="space-y-1.5 text-left">
                <div className="flex items-center justify-between">
                  <label className={`text-xs font-bold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                    Kata Laluan:
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setForgotEmailInput(signInIdent.includes('@') ? signInIdent : '');
                      setForgotPasswordOpen(true);
                      setForgotFeedback(null);
                    }}
                    className="text-[11px] text-orange-500 hover:underline cursor-pointer"
                  >
                    Lupa kata laluan?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-orange-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showSignInPassword ? 'text' : 'password'}
                    required
                    value={signInPassword}
                    onChange={(e) => setSignInPassword(e.target.value)}
                    placeholder="••••••••"
                    className={`w-full border rounded-xl pl-10 pr-10 py-2.5 text-xs font-mono focus:outline-none ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 focus:border-orange-500 text-slate-900'
                        : 'bg-[#121824] border-slate-700 focus:border-orange-500 text-white'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowSignInPassword(!showSignInPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showSignInPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isAuthLoading}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
              >
                {isAuthLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <LogIn className="w-4 h-4" />}
                <span>{isAuthLoading ? 'Memproses...' : 'Log Masuk (Sign In)'}</span>
              </button>
            </form>
          )}

          {/* ========================================================= */}
          {/* 📝 SIGN UP FORM (Daftar Akaun + Verifikasi Emel Wajib) */}
          {/* ========================================================= */}
          {authTab === 'signup' && (
            <form onSubmit={handlePerformSignUp} className="space-y-4 animate-fadeIn">
              <div className="space-y-1.5 text-left">
                <label className={`text-xs font-bold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  Nama Username Pilihan:
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-orange-500 font-mono font-bold">@</span>
                  <input
                    type="text"
                    required
                    value={signUpUsername}
                    onChange={(e) => setSignUpUsername(e.target.value.replace(/\s+/g, ''))}
                    placeholder="cth: gamer_balzz"
                    className={`w-full border rounded-xl pl-8 pr-4 py-2.5 text-xs font-mono focus:outline-none ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 focus:border-orange-500 text-slate-900'
                        : 'bg-[#121824] border-slate-700 focus:border-orange-500 text-white'
                    }`}
                  />
                </div>
              </div>

              <div className="space-y-1.5 text-left">
                <label className={`text-xs font-bold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  Alamat Emel:
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-orange-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={signUpEmail}
                    onChange={(e) => setSignUpEmail(e.target.value)}
                    placeholder="nama@gmail.com"
                    className={`w-full border rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono focus:outline-none ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 focus:border-orange-500 text-slate-900'
                        : 'bg-[#121824] border-slate-700 focus:border-orange-500 text-white'
                    }`}
                  />
                </div>
              </div>

              <div className="space-y-1.5 text-left">
                <label className={`text-xs font-bold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  Kata Laluan (Minimum 6 aksara):
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-orange-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showSignUpPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={signUpPassword}
                    onChange={(e) => setSignUpPassword(e.target.value)}
                    placeholder="••••••••"
                    className={`w-full border rounded-xl pl-10 pr-10 py-2.5 text-xs font-mono focus:outline-none ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 focus:border-orange-500 text-slate-900'
                        : 'bg-[#121824] border-slate-700 focus:border-orange-500 text-white'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowSignUpPassword(!showSignUpPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showSignUpPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1.5 text-left">
                <label className={`text-xs font-bold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  Sahkan Kata Laluan:
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-orange-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={signUpConfirmPassword}
                    onChange={(e) => setSignUpConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className={`w-full border rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono focus:outline-none ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 focus:border-orange-500 text-slate-900'
                        : 'bg-[#121824] border-slate-700 focus:border-orange-500 text-white'
                    }`}
                  />
                </div>
              </div>

              {/* VERIFICATION NOTICE BANNER */}
              <div className={`p-3.5 rounded-2xl border flex items-start gap-3 text-left ${
                isLight ? 'bg-amber-50 border-amber-300 text-amber-900' : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
              }`}>
                <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <p className="text-xs font-black">Pengesahan Emel di Profil</p>
                  <p className="text-[11px] leading-relaxed opacity-90">
                    Daftar dan masuk terus ke akaun anda. Anda boleh membuat pengesahan emel bila-bila masa di menu profil anda.
                  </p>
                </div>
              </div>

              <button
                type="submit"
                disabled={isAuthLoading}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
              >
                {isAuthLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>{isAuthLoading ? 'Mendaftar...' : 'Daftar Akaun Sekarang'}</span>
              </button>
            </form>
          )}

          {/* Guarantee Badges */}
          <div className={`pt-4 border-t grid grid-cols-2 gap-3 text-left ${isLight ? 'border-slate-200' : 'border-slate-800/80'}`}>
            <div className={`flex items-center gap-2 p-2.5 rounded-xl border ${
              isLight ? 'bg-slate-50 border-slate-200 text-slate-700' : 'bg-slate-900/60 border-slate-800 text-slate-300'
            }`}>
              <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
              <span className="text-[11px] font-medium">Akaun Selamat & Dilindungi</span>
            </div>
            <div className={`flex items-center gap-2 p-2.5 rounded-xl border ${
              isLight ? 'bg-slate-50 border-slate-200 text-slate-700' : 'bg-slate-900/60 border-slate-800 text-slate-300'
            }`}>
              <Zap className="w-4 h-4 text-orange-500 shrink-0" />
              <span className="text-[11px] font-medium">Auto-Sync Resit & Pesanan</span>
            </div>
          </div>
        </div>
      ) : (
        /* 🎮 LOGGED IN USER PROFILE */
        <div className="space-y-6">

          {/* ⚠️ PROMINENT EMAIL VERIFICATION ALERT (IF EMAIL IS NOT YET VERIFIED) */}
          {!activeUser.isEmailVerified && (
            <div className={`p-5 rounded-3xl border-2 flex flex-col sm:flex-row items-center justify-between gap-4 animate-pulse shadow-xl ${
              isLight
                ? 'bg-amber-50 border-amber-400 text-amber-950 shadow-amber-200/50'
                : 'bg-gradient-to-r from-amber-950/80 via-[#261608] to-[#120B03] border-amber-500/80 text-amber-200 shadow-[0_0_30px_rgba(245,158,11,0.25)]'
            }`}>
              <div className="flex items-center gap-3.5 text-center sm:text-left">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/50 text-amber-400 flex items-center justify-center shrink-0">
                  <ShieldAlert className="w-7 h-7 text-amber-400" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500 text-slate-950">
                      Perhatian
                    </span>
                    <h4 className="text-sm font-black">Emel Anda Belum Disahkan!</h4>
                  </div>
                  <p className="text-xs leading-relaxed max-w-xl opacity-90">
                    Sila sahkan alamat emel <strong>{activeUser.email || 'anda'}</strong> untuk melindungi akaun dan mengelakkan sebarang sekatan pesanan.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setVerifyingEmail(activeUser.email || '');
                  setVerificationModalOpen(true);
                  setVerificationFeedback(null);
                }}
                className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-transform hover:scale-105 active:scale-95 shrink-0"
              >
                <Mail className="w-4 h-4" />
                <span>Sahkan Emel Sekarang</span>
              </button>
            </div>
          )}

          {/* 👑 ADMIN ACCESS BAR (ONLY SHOWN IF ACTUALLY AUTHORIZED & PIN VERIFIED) */}
          {isCurrentlyAdminUser && onOpenAdmin && (
            <div className={`p-6 rounded-3xl border-2 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-5 animate-fadeIn ${
              isLight
                ? 'bg-gradient-to-r from-orange-100 via-amber-50 to-orange-100 border-orange-300 shadow-lg text-slate-900'
                : 'bg-gradient-to-r from-orange-950/90 via-[#181124] to-slate-900 border-orange-500/70 shadow-[0_0_40px_rgba(255,140,0,0.4)] text-white'
            }`}>
              <div className="flex items-center gap-4 text-center sm:text-left">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-lg ${
                  isLight ? 'bg-orange-500/15 border border-orange-300 text-orange-600' : 'bg-orange-500/20 border border-orange-500/50 text-orange-400'
                }`}>
                  <ShieldCheck className="w-8 h-8 animate-pulse" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                    <span className="px-3 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-orange-500 text-slate-950 shadow-[0_0_10px_rgba(255,140,0,0.5)]">
                      ★ Akses Pentadbir Disahkan
                    </span>
                  </div>
                  <h3 className={`text-lg font-black tracking-tight ${isLight ? 'text-slate-900' : 'text-white'}`}>Pusat Kawalan Kedai TopupBalz</h3>
                  <p className={`text-xs max-w-lg leading-relaxed ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                    Urus senarai game, kemaskini harga jualan, semak pesanan masuk & tukar banner promosi secara langsung.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleAdminButtonClick}
                className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-2xl shadow-[0_0_25px_rgba(255,140,0,0.5)] hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
              >
                <Lock className="w-4 h-4" />
                <span>Buka Panel Admin</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* MAIN PROFILE CARD */}
          <div className={`border rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl relative overflow-hidden ${
            isLight
              ? 'bg-white border-slate-200 shadow-xl'
              : 'bg-[#0D1117] border-orange-500/30 shadow-xl'
          }`}>
            <div className={`flex flex-col sm:flex-row items-center justify-between gap-6 pb-6 border-b ${
              isLight ? 'border-slate-200' : 'border-slate-800/80'
            }`}>
              <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
                {/* INTERACTIVE AVATAR WITH GALLERY PICKER TRIGGER */}
                <div
                  onClick={() => {
                    setSelectedAvatarPreview(activeUser.avatarUrl || null);
                    setAvatarModalOpen(true);
                  }}
                  className="relative group cursor-pointer transition-transform hover:scale-105"
                  title="Klik untuk tukar gambar dari galeri"
                >
                  <img
                    src={activeUser.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(activeUser.username || activeUser.name)}`}
                    alt={activeUser.name}
                    referrerPolicy="no-referrer"
                    className={`w-20 h-20 sm:w-22 sm:h-22 rounded-2xl border-2 object-cover shadow-lg ${
                      isLight ? 'border-orange-400 bg-slate-100' : 'border-orange-500/70 bg-[#121824]'
                    }`}
                  />
                  <div className="absolute inset-0 bg-black/50 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[10px] font-bold gap-1">
                    <Camera className="w-5 h-5 text-orange-400" />
                    <span>Tukar</span>
                  </div>
                  <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-lg bg-orange-500 border-2 text-slate-950 flex items-center justify-center shadow-md ${
                    isLight ? 'border-white' : 'border-[#0D1117]'
                  }`}>
                    <Camera className="w-3.5 h-3.5" />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                    <h2 className={`text-xl sm:text-2xl font-black tracking-tight ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      {activeUser.name || 'Pengguna TopupBalz'}
                    </h2>
                    {isCurrentlyAdminUser && (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-orange-500 text-slate-950">
                        Admin
                      </span>
                    )}
                  </div>

                  <p className="text-xs font-mono text-orange-500 font-bold flex items-center justify-center sm:justify-start gap-1">
                    <span>@{cleanActiveUsername || 'gamer'}</span>
                  </p>

                  <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap text-xs">
                    <span className={`font-mono text-[11px] ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                      {activeUser.email || 'Tiada Emel'}
                    </span>
                    {activeUser.isEmailVerified ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                        <CheckCircle2 className="w-3 h-3" /> Emel Disahkan
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setVerifyingEmail(activeUser.email || '');
                          setVerificationModalOpen(true);
                          setVerificationFeedback(null);
                        }}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-500 hover:bg-amber-500/25 border border-amber-500/40 cursor-pointer"
                      >
                        <ShieldAlert className="w-3 h-3" /> Sahkan Emel
                      </button>
                    )}
                  </div>

                  <p className={`text-[11px] font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                    ID: {activeUser.id}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2.5 w-full sm:w-auto flex-wrap">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedAvatarPreview(activeUser.avatarUrl || null);
                    setAvatarModalOpen(true);
                  }}
                  className={`flex-1 sm:flex-none px-3.5 py-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    isLight
                      ? 'bg-orange-50 border-orange-300 text-orange-700 hover:bg-orange-100'
                      : 'bg-orange-500/15 border-orange-500/40 hover:bg-orange-500/25 text-orange-300 hover:text-orange-200'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Pilih Galeri</span>
                </button>

                <button
                  type="button"
                  onClick={handlePerformLogout}
                  disabled={isSubmitting}
                  className={`flex-1 sm:flex-none px-3.5 py-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    isLight
                      ? 'bg-rose-50 border-rose-200 hover:bg-rose-100 text-rose-700'
                      : 'bg-rose-500/15 border-rose-500/40 hover:bg-rose-500/25 text-rose-300 hover:text-rose-200'
                  }`}
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Log Keluar</span>
                </button>
              </div>
            </div>

            {/* DETAILS & STATS */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className={`p-4 rounded-2xl border space-y-1 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
              }`}>
                <span className={`text-[11px] block font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Jumlah Pesanan</span>
                <span className={`text-xl font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>{totalOrdersCount}</span>
              </div>
              <div className={`p-4 rounded-2xl border space-y-1 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
              }`}>
                <span className={`text-[11px] block font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Jumlah Belanja</span>
                <span className="text-xl font-black text-orange-500">RM {totalSpentAmount.toFixed(2)}</span>
              </div>
              <div className={`p-4 rounded-2xl border space-y-1 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
              }`}>
                <span className={`text-[11px] block font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Status Emel & Akaun</span>
                {activeUser.isEmailVerified ? (
                  <span className="text-xs font-bold text-emerald-500 dark:text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Emel Sah
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setVerifyingEmail(activeUser.email || '');
                      setVerificationModalOpen(true);
                      setVerificationFeedback(null);
                    }}
                    className="text-xs font-bold text-amber-500 hover:text-amber-400 flex items-center gap-1 cursor-pointer underline text-left"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" /> Belum Disahkan
                  </button>
                )}
              </div>
              <div className={`p-4 rounded-2xl border space-y-1 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
              }`}>
                <span className={`text-[11px] block font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Tarikh Daftar</span>
                <span className={`text-xs font-mono ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  {new Date(activeUser.createdAt).toLocaleDateString('ms-MY')}
                </span>
              </div>
            </div>

            {/* PHONE NUMBER SETTINGS */}
            <div className={`p-4 rounded-2xl border space-y-3 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800/80'
            }`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/30 text-orange-500 flex items-center justify-center shrink-0">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className={`text-xs font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>Nombor WhatsApp / Telefon</h4>
                    <p className="text-[11px] font-mono font-medium">
                      {activeUser.phoneNumber ? (
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold tracking-wide">{activeUser.phoneNumber}</span>
                      ) : (
                        <span className={isLight ? 'text-slate-500' : 'text-slate-400'}>Belum didaftarkan (untuk resit automatik)</span>
                      )}
                    </p>
                  </div>
                </div>

                {editingPhone ? (
                  <div className="flex items-center gap-2 flex-wrap">
                    <input
                      type="tel"
                      value={phoneInput}
                      onChange={(e) => setPhoneInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleSavePhone();
                        }
                      }}
                      autoFocus
                      placeholder="cth: 01112345678"
                      className={`border rounded-xl px-3 py-2 text-xs font-mono focus:outline-none shadow-inner ${
                        isLight
                          ? 'bg-white border-orange-300 text-slate-900 focus:border-orange-500'
                          : 'bg-[#0D1117] border-orange-500/60 focus:border-orange-400 text-white'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={handleSavePhone}
                      disabled={isSubmitting}
                      className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-md transition-all active:scale-95 disabled:opacity-50"
                    >
                      {isSubmitting ? 'Menyimpan...' : 'Simpan'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingPhone(false)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
                        isLight ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      Batal
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setPhoneInput(activeUser.phoneNumber || '');
                      setEditingPhone(true);
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer shadow-sm active:scale-95 shrink-0 ${
                      isLight
                        ? 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300 hover:border-orange-400'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700/80 hover:border-orange-500/40'
                    }`}
                  >
                    {activeUser.phoneNumber ? 'Tukar Nombor' : 'Tambah Nombor'}
                  </button>
                )}
              </div>

              {phoneSuccessMsg && (
                <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-600 dark:text-emerald-300 text-xs font-bold flex items-center gap-2 animate-fadeIn">
                  <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>{phoneSuccessMsg}</span>
                </div>
              )}
            </div>

          </div>

          {/* USER ORDERS HISTORY */}
          <div className={`border rounded-3xl p-6 sm:p-8 space-y-4 shadow-xl ${
            isLight
              ? 'bg-white border-slate-200 shadow-xl'
              : 'bg-[#0D1117] border-slate-800 shadow-xl'
          }`}>
            <div className={`flex items-center justify-between pb-4 border-b ${
              isLight ? 'border-slate-200' : 'border-slate-800'
            }`}>
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-orange-500" />
                <h3 className={`text-base font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>Sejarah Pesanan Anda</h3>
              </div>
              <span className={`text-xs font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>{userOrders.length} Pesanan</span>
            </div>

            {userOrders.length === 0 ? (
              <div className="py-10 text-center space-y-2">
                <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Tiada rekod pesanan lagi.</p>
                <p className={`text-[11px] font-mono ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>Pesanan topup anda akan dipaparkan di sini secara automatik.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {userOrders.map((ord) => (
                  <div
                    key={ord.id}
                    className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      isLight
                        ? 'bg-slate-50 border-slate-200 hover:border-orange-300'
                        : 'bg-[#121824] border-slate-800 hover:border-orange-500/40'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>{ord.gameTitle || 'Topup Game'}</span>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                          isLight
                            ? 'bg-slate-200 text-slate-700 border-slate-300'
                            : 'bg-slate-800 text-slate-300 border-slate-700'
                        }`}>
                          {ord.itemPackage || ord.packageName || 'Pakej'}
                        </span>
                      </div>
                      <p className={`text-[11px] font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                        ID: {ord.id} • {new Date(ord.createdAt).toLocaleDateString('en-GB', { timeZone: 'Asia/Kuala_Lumpur' })} {new Date(ord.createdAt).toLocaleTimeString('en-US', { timeZone: 'Asia/Kuala_Lumpur', hour: '2-digit', minute: '2-digit', hour12: true })}
                      </p>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-4">
                      <span className="text-xs font-mono font-bold text-orange-500">
                        RM {(ord.sellPrice || ord.basePrice || 0).toFixed(2)}
                      </span>
                      <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                        ord.status === 'completed'
                          ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/40'
                          : ord.status === 'processing'
                          ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/40'
                          : isLight
                          ? 'bg-slate-200 text-slate-600 border-slate-300'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}>
                        {ord.status === 'completed' ? 'Selesai' : ord.status === 'processing' ? 'Diproses' : 'Menunggu'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
};
