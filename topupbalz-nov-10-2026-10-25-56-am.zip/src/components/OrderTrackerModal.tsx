import React, { useState } from 'react';
import { X, Search, Clock, CheckCircle2, AlertCircle, MessageCircle, RefreshCw, Copy, Check, ShieldCheck, Gamepad2, FileText } from 'lucide-react';
import { Order } from '../types';
import { maskGameUserId, maskServerId } from '../lib/masking';

interface OrderTrackerModalProps {
  isOpen?: boolean;
  onClose: () => void;
  onSearchOrder: (id: string) => Promise<Order[]>;
  ownerPhone?: string;
  theme?: 'dark' | 'light';
}

export const OrderTrackerModal: React.FC<OrderTrackerModalProps> = ({
  isOpen = true,
  onClose,
  onSearchOrder,
  ownerPhone = '',
  theme = 'dark',
}) => {
  if (!isOpen) return null;
  const isLight = theme === 'light';

  const [searchQuery, setSearchQuery] = useState('');
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchQuery.trim();
    if (!q) return;
    setLoading(true);
    try {
      const res = await onSearchOrder(q);
      setOrders(res);
    } catch (err) {
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (id: string) => {
    const formatted = id.startsWith('#') ? id : `#${id}`;
    navigator.clipboard.writeText(formatted);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'completed':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-black bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/40 flex items-center gap-1.5 shadow-sm">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>SELESAI</span>
          </span>
        );
      case 'processing':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-black bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/40 flex items-center gap-1.5 shadow-sm">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>SEDANG DIPROSES</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-black bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/40 flex items-center gap-1.5 shadow-sm">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>DIBATALKAN</span>
          </span>
        );
      default:
        return (
          <span className="px-3 py-1 rounded-full text-xs font-black bg-orange-500/20 text-orange-600 dark:text-orange-400 border border-orange-500/40 flex items-center gap-1.5 shadow-sm">
            <Clock className="w-3.5 h-3.5" />
            <span>MENUNGGU</span>
          </span>
        );
    }
  };

  return (
    <div className={`fixed inset-0 z-50 overflow-y-auto backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fadeIn ${
      isLight ? 'bg-slate-900/50' : 'bg-black/85'
    }`}>
      <div className={`relative w-full max-w-lg rounded-3xl overflow-hidden my-auto border shadow-2xl transition-colors duration-300 ${
        isLight
          ? 'bg-white border-slate-200 text-slate-900 shadow-2xl'
          : 'bg-[#0D1117] border-slate-800 text-white shadow-[0_0_50px_rgba(0,0,0,0.9)]'
      }`}>
        
        {/* Top Accent Line */}
        <div className="h-1 w-full bg-gradient-to-r from-orange-500 via-amber-400 to-orange-600" />

        {/* Header */}
        <div className={`p-5 border-b flex items-center justify-between transition-colors ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-orange-500/20 border border-orange-500/40 flex items-center justify-center text-orange-500">
              <Search className="w-4 h-4" />
            </div>
            <div>
              <h3 className={`text-base sm:text-lg font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Semak Status Pesanan
              </h3>
              <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Sistem Semakan Privasi &amp; Status Pantas
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Tutup Semakan Pesanan"
            className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors cursor-pointer border ${
              isLight
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-200'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white border-slate-700'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5">
          {/* Search Form */}
          <form onSubmit={handleSearch} className="space-y-2">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Contoh: #BZ-840080 atau 840080"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`w-full rounded-xl px-4 py-3 text-sm font-mono tracking-wide focus:outline-none transition-colors border ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400 focus:border-orange-500 focus:ring-1 focus:ring-orange-500'
                      : 'bg-[#121824] border-slate-700 focus:border-orange-500 text-white placeholder:text-slate-500'
                  }`}
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="px-5 py-3 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition-all shadow-[0_0_15px_rgba(249,115,22,0.4)] cursor-pointer disabled:opacity-50 shrink-0 active:scale-95"
              >
                {loading ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                ) : (
                  'Cari'
                )}
              </button>
            </div>
            <p className={`text-[11px] flex items-center gap-1 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Masukkan ID pesanan lengkap (#BZ-XXXXXX) untuk semak status tepat.</span>
            </p>
          </form>

          {/* Search Results Display */}
          {orders !== null && (
            <div className="space-y-4 max-h-[420px] overflow-y-auto pr-1">
              {orders.length === 0 ? (
                <div className={`p-6 border rounded-2xl text-center space-y-2 ${
                  isLight ? 'bg-slate-50 border-slate-200 text-slate-700' : 'bg-[#121824] border-slate-800 text-slate-300'
                }`}>
                  <AlertCircle className="w-8 h-8 text-amber-500 mx-auto" />
                  <p className="text-sm font-bold">Tiada Pesanan Dijumpai</p>
                  <p className="text-xs text-slate-500">
                    Sila pastikan format ID pesanan betul (Contoh: #BZ-123456 atau nombor telefon anda).
                  </p>
                </div>
              ) : (
                orders.map((ord) => (
                  <div
                    key={ord.id}
                    className={`p-4 rounded-2xl border space-y-3 transition-colors ${
                      isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-mono font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                          #{ord.id}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopy(ord.id)}
                          className="p-1 text-slate-400 hover:text-orange-500 cursor-pointer transition-colors"
                          title="Salin ID"
                        >
                          {copiedId === ord.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      {getStatusBadge(ord.status)}
                    </div>

                    <div className={`space-y-1.5 text-xs border-t pt-2.5 ${isLight ? 'border-slate-200 text-slate-600' : 'border-slate-800 text-slate-300'}`}>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Game / Pakej:</span>
                        <span className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>{ord.gameName} - {ord.itemName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">User ID / Server:</span>
                        <span className={`font-mono font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                          {maskGameUserId(ord.userId)} {ord.serverId ? `(${maskServerId(ord.serverId)})` : ''}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Jumlah Bayaran:</span>
                        <span className="font-mono font-bold text-orange-600 dark:text-orange-400">RM {ord.price.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Tarikh:</span>
                        <span>{new Date(ord.createdAt).toLocaleString('ms-MY')}</span>
                      </div>
                    </div>

                    {ownerPhone && (
                      <a
                        href={`https://wa.me/${ownerPhone}?text=${encodeURIComponent(`Salam Admin, saya nak semak status pesanan #${ord.id} bagi ${ord.gameName}`)}`}
                        target="_blank"
                        rel="noreferrer"
                        className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Hubungi Admin WhatsApp</span>
                      </a>
                    )}
                  </div>
                ))
              )}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
