import React, { useRef, useEffect, useState } from 'react';
import { Game } from '../types';

// The User's exact Google Flow MP4 animation link
export const USER_ANIMATION_VIDEO_URL = 'https://files.catbox.moe/a8737w.mp4';
export const CUSTOM_USER_LOGO_URL = 'https://i.ibb.co/PZQjWszz/Copilot-20260823-220345.png';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showText?: boolean;
  theme?: 'light' | 'dark';
  games?: Game[];
}

/**
 * TopupBalz Official Emblem (Orange Lightning 'B')
 */
export const TopupBalzIcon: React.FC<{ className?: string }> = ({ className = 'w-10 h-10' }) => {
  return (
    <svg
      viewBox="0 0 200 240"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="balzOrangeGradSolo" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFA000" />
          <stop offset="30%" stopColor="#FF6D00" />
          <stop offset="100%" stopColor="#FF3D00" />
        </linearGradient>
      </defs>
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M48 15 L135 15 C175 15 195 34 188 68 C182 93 165 108 138 115 C172 125 186 149 180 186 C172 224 142 234 94 234 L52 234 L10 242 L68 150 L26 150 L48 15 Z 
           M82 52 L124 52 C140 52 148 60 146 72 C144 84 134 92 118 92 L70 92 L82 52 Z 
           M88 134 L124 134 C140 134 148 142 146 156 C144 170 132 180 114 180 L76 180 L88 134 Z"
        fill="url(#balzOrangeGradSolo)"
      />
    </svg>
  );
};

/**
 * AnimatedBrandLogo:
 * Plays the user's exact Google Flow video animation (https://files.catbox.moe/bl2p2j.mp4)
 * with seamless looping, autoplay, ambient glow and crisp visual presentation.
 */
export const AnimatedBrandLogo: React.FC<BrandLogoProps> = ({
  size = 'lg',
  className = '',
  theme = 'dark',
}) => {
  const isLight = theme === 'light';
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch(() => {
        // Autoplay may be deferred by browser until interaction
      });
    }
  }, []);

  // Sizing styles
  const heightClasses = {
    sm: 'h-9 sm:h-10 max-w-[170px]',
    md: 'h-11 sm:h-12 max-w-[220px]',
    lg: 'h-12 sm:h-14 md:h-16 max-w-[280px] sm:max-w-[340px] md:max-w-[420px]',
    xl: 'h-16 sm:h-20 max-w-[380px] sm:max-w-[480px]',
  }[size];

  return (
    <div
      className={`relative flex items-center justify-center select-none group cursor-pointer overflow-visible ${className}`}
    >
      {/* Ambient Flame Glow behind video */}
      <div
        className="absolute -inset-1 rounded-xl blur-lg opacity-60 pointer-events-none transition-all duration-300 group-hover:opacity-90"
        style={{
          background: isLight
            ? 'radial-gradient(ellipse, rgba(255, 140, 0, 0.4) 0%, rgba(255, 80, 0, 0.15) 60%, transparent 80%)'
            : 'radial-gradient(ellipse, rgba(255, 109, 0, 0.6) 0%, rgba(255, 50, 0, 0.25) 60%, transparent 80%)',
        }}
      />

      {!hasError ? (
        /* The Real Google Flow MP4 Animation */
        <video
          ref={videoRef}
          src={USER_ANIMATION_VIDEO_URL}
          autoPlay
          loop
          muted
          playsInline
          preload="auto"
          onError={() => setHasError(true)}
          className={`relative z-10 w-auto object-contain rounded-lg transition-transform duration-300 group-hover:scale-105 ${heightClasses}`}
          style={{
            mixBlendMode: isLight ? 'multiply' : 'screen',
            filter: isLight
              ? 'contrast(1.08) brightness(0.95)'
              : 'drop-shadow(0 0 10px rgba(255, 109, 0, 0.55)) brightness(1.05)',
          }}
        />
      ) : (
        /* Fallback SVG in case video fails */
        <div className="relative z-10 flex items-center gap-2">
          <TopupBalzIcon className="w-10 h-10 animate-flame-aura" />
          <span className="text-xl font-black font-mono italic text-orange-500">
            TOPUP<span className="text-white">BALZ</span>
          </span>
        </div>
      )}
    </div>
  );
};
