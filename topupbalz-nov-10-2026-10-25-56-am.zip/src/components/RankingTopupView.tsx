import React, { useState, useMemo } from 'react';
import { Trophy, Search, CheckCircle2, Gamepad2, Sparkles, X } from 'lucide-react';
import { Order, UserProfile } from '../types';
import { maskPhoneNumber } from '../lib/masking';

interface RankingTopupViewProps {
  orders: Order[];
  usersList?: UserProfile[];
  currentUser?: UserProfile | null;
  onGoToProfile?: () => void;
  onSelectTopup?: () => void;
  theme?: 'dark' | 'light';
}

export interface RankItem {
  id: string;
  rank: number;
  username: string;
  avatarUrl: string;
  orderCount: number;
  totalSpent: number;
  tier?: string;
  isCurrentUser?: boolean;
  isOnline?: boolean;
  isVerified?: boolean;
  memberSince?: string;
}

export const RankingTopupView: React.FC<RankingTopupViewProps> = ({
  orders = [],
  usersList = [],
  currentUser,
  onSelectTopup,
  theme = 'dark',
}) => {
  const isLight = theme === 'light';
  const [searchQuery, setSearchQuery] = useState('');

  // Helper to identify and hide admin accounts from public ranking
  const isAdminAccount = (username?: string, email?: string, name?: string, phone?: string): boolean => {
    const cleanU = (username || '').replace(/^@+/, '').trim().toLowerCase();
    const cleanE = (email || '').trim().toLowerCase();
    const cleanN = (name || '').replace(/^@+/, '').trim().toLowerCase();
    const cleanP = (phone || '').replace(/\D/g, '');

    const adminNames = ['balzltdsdn', 'siuiqbal23', 'balzz', 'admin', 'topupbalz', 'dbalz0309', 'iqbalz'];
    
    if (adminNames.includes(cleanU) || adminNames.includes(cleanN)) return true;
    if (cleanU.startsWith('balzltd') || cleanN.startsWith('balzltd') || cleanU.startsWith('balzz')) return true;
    if (cleanE === 'siuiqbal23@gmail.com' || cleanE.startsWith('siuiqbal23') || cleanE.includes('balzltd')) return true;
    if (cleanP === '0145975056' || cleanP === '60145975056') return true;
    
    return false;
  };

  // Compute 100% REAL and AUTHENTIC rankings strictly from registered users and actual orders (Admin accounts strictly hidden)
  const rankings: RankItem[] = useMemo(() => {
    const userRankMap = new Map<string, {
      id: string;
      username: string;
      avatarUrl: string;
      orderCount: number;
      totalSpent: number;
      isCurrentUser: boolean;
      isOnline: boolean;
      isVerified: boolean;
      memberSince?: string;
    }>();

    // 1. Process all real registered users in usersList (Excluding Admin accounts)
    usersList.forEach((u: any) => {
      // Exclude admin accounts from ranking
      if (isAdminAccount(u.username, u.email, u.name, u.phoneNumber) || u.role === 'admin' || u.isAdmin) {
        return;
      }

      const userKey = u.id || u.email || u.name;
      const cleanPhone = (u.phoneNumber || '').replace(/\D/g, '');
      const cleanUsername = (u.username || u.name || '').replace(/^@+/, '').trim().toLowerCase();
      const cleanEmail = (u.email || '').toLowerCase().trim();

      // Find all real orders associated with this user
      const matchingOrders = orders.filter((o: any) => {
        const orderAccountUserId = o.accountUserId;
        const orderAccountUsername = (o.accountUsername || '').replace(/^@+/, '').trim().toLowerCase();
        const orderUserId = (o.userId || '').replace(/^@+/, '').trim().toLowerCase();
        const orderPhone = (o.customerPhone || '').replace(/\D/g, '');

        return (
          (orderAccountUserId && orderAccountUserId === u.id) ||
          (cleanUsername && orderAccountUsername && orderAccountUsername === cleanUsername) ||
          (cleanUsername && orderUserId && orderUserId === cleanUsername) ||
          (cleanPhone && orderPhone && orderPhone === cleanPhone) ||
          (u.id && orderUserId && orderUserId === u.id)
        );
      });

      // Calculate real total order count and real RM spent
      const orderCountFromOrders = matchingOrders.length;
      const totalSpentFromOrders = matchingOrders.reduce(
        (sum, ord) => sum + (Number(ord.sellPrice) || Number(ord.basePrice) || 0),
        0
      );

      const actualOrderCount = Math.max(u.totalOrders || 0, orderCountFromOrders);
      const actualTotalSpent = Math.max(u.totalSpent || 0, totalSpentFromOrders);

      const isCurrent = Boolean(
        currentUser &&
          (currentUser.id === u.id ||
            (currentUser.email && u.email && currentUser.email.toLowerCase() === u.email.toLowerCase()) ||
            (currentUser.name && u.name && currentUser.name.toLowerCase() === u.name.toLowerCase()) ||
            (currentUser.username && u.username && currentUser.username.toLowerCase() === u.username.toLowerCase()))
      );

      const displayName = u.username
        ? u.username.replace(/^@+/, '')
        : u.name
        ? u.name.replace(/^@+/, '')
        : u.email
        ? u.email.split('@')[0]
        : 'Gamer';

      const avatar = u.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(displayName)}`;

      // Only genuinely online if it is the active user or last activity was within the last 2 minutes
      const hasRecentActivity = Boolean(
        u.lastLoginAt && Date.now() - new Date(u.lastLoginAt).getTime() < 2 * 60 * 1000
      );
      const isReallyOnline = Boolean(isCurrent || (u.isOnline && hasRecentActivity));

      userRankMap.set(userKey, {
        id: u.id,
        username: displayName,
        avatarUrl: avatar,
        orderCount: actualOrderCount,
        totalSpent: actualTotalSpent,
        isCurrentUser: isCurrent,
        isOnline: isReallyOnline,
        isVerified: u.isEmailVerified !== false,
        memberSince: u.createdAt,
      });
    });

    // 2. Ensure current logged-in user is included IF NOT an admin
    if (currentUser && !isAdminAccount(currentUser.username, currentUser.email, currentUser.name, currentUser.phoneNumber) && !(currentUser as any).isAdmin) {
      const curKey = currentUser.id || currentUser.email || currentUser.name;
      if (!userRankMap.has(curKey)) {
        const cleanPhone = (currentUser.phoneNumber || '').replace(/\D/g, '');
        const cleanUsername = (currentUser.username || currentUser.name || '').replace(/^@+/, '').trim().toLowerCase();

        const matchingOrders = orders.filter((o: any) => {
          const orderAccountUserId = o.accountUserId;
          const orderAccountUsername = (o.accountUsername || '').replace(/^@+/, '').trim().toLowerCase();
          const orderUserId = (o.userId || '').replace(/^@+/, '').trim().toLowerCase();
          const orderPhone = (o.customerPhone || '').replace(/\D/g, '');

          return (
            (orderAccountUserId && orderAccountUserId === currentUser.id) ||
            (cleanUsername && orderAccountUsername && orderAccountUsername === cleanUsername) ||
            (cleanUsername && orderUserId && orderUserId === cleanUsername) ||
            (cleanPhone && orderPhone && orderPhone === cleanPhone) ||
            (currentUser.id && orderUserId && orderUserId === currentUser.id)
          );
        });

        const actualOrderCount = Math.max(currentUser.totalOrders || 0, matchingOrders.length);
        const actualTotalSpent = Math.max(
          currentUser.totalSpent || 0,
          matchingOrders.reduce((sum, ord) => sum + (Number(ord.sellPrice) || Number(ord.basePrice) || 0), 0)
        );

        const displayName = currentUser.username
          ? currentUser.username.replace(/^@+/, '')
          : currentUser.name
          ? currentUser.name.replace(/^@+/, '')
          : 'Gamer';

        const avatar = currentUser.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(displayName)}`;

        userRankMap.set(curKey, {
          id: currentUser.id,
          username: displayName,
          avatarUrl: avatar,
          orderCount: actualOrderCount,
          totalSpent: actualTotalSpent,
          isCurrentUser: true,
          isOnline: true,
          isVerified: currentUser.isEmailVerified !== false,
          memberSince: currentUser.createdAt,
        });
      }
    }

    // 3. Process guest orders (customers who checked out directly with real transactions)
    orders.forEach((o: any) => {
      const orderPhone = (o.customerPhone || '').replace(/\D/g, '');
      const orderUserId = (o.userId || '').trim();
      const accountUserId = o.accountUserId;
      const accountUsername = o.accountUsername;

      // Skip orders created by or associated with admin
      if (isAdminAccount(accountUsername, undefined, orderUserId, orderPhone)) {
        return;
      }

      // Check if already captured in registered users
      const alreadyCaptured = Array.from(userRankMap.values()).some((u) => {
        return (
          (accountUserId && u.id === accountUserId) ||
          (u.username && orderUserId && u.username.toLowerCase() === orderUserId.toLowerCase())
        );
      });

      if (!alreadyCaptured && (orderPhone || orderUserId)) {
        const guestKey = `guest-${orderPhone || orderUserId}`;
        const price = Number(o.sellPrice) || Number(o.basePrice) || 0;

        if (!userRankMap.has(guestKey)) {
          const guestName = orderPhone
            ? `Pelanggan (${maskPhoneNumber(orderPhone)})`
            : `ID ${orderUserId}`;

          userRankMap.set(guestKey, {
            id: guestKey,
            username: guestName,
            avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(guestKey)}`,
            orderCount: 1,
            totalSpent: price,
            isCurrentUser: false,
            isOnline: false,
            isVerified: true,
            memberSince: o.createdAt,
          });
        } else {
          const existing = userRankMap.get(guestKey)!;
          existing.orderCount += 1;
          existing.totalSpent += price;
        }
      }
    });

    // 4. Sort strictly descending by totalSpent, then by orderCount & ensure no admin leaked
    const allRealSpenders = Array.from(userRankMap.values()).filter(
      (item) => !isAdminAccount(item.username)
    );
    allRealSpenders.sort((a, b) => {
      if (b.totalSpent !== a.totalSpent) {
        return b.totalSpent - a.totalSpent;
      }
      return b.orderCount - a.orderCount;
    });

    // 5. Assign true ranks and tiers based on real statistics
    return allRealSpenders.map((item, index) => {
      const rank = index + 1;
      let tier = '⭐ Verified Gamer';

      if (item.totalSpent >= 500) {
        tier = '👑 Supreme Sultan';
      } else if (item.totalSpent >= 200) {
        tier = '🔥 Imperial Titan';
      } else if (item.totalSpent >= 100) {
        tier = '⚡ Grand Mythic';
      } else if (item.totalSpent >= 30) {
        tier = '💎 Elite Diamond';
      } else if (item.totalSpent > 0) {
        tier = '✨ Active Spender';
      } else {
        tier = '🎮 Ahli Baru';
      }

      return {
        id: item.id,
        rank,
        username: item.username,
        avatarUrl: item.avatarUrl,
        orderCount: item.orderCount,
        totalSpent: item.totalSpent,
        tier,
        isCurrentUser: item.isCurrentUser,
        isOnline: item.isOnline,
        isVerified: item.isVerified,
        memberSince: item.memberSince,
      };
    });
  }, [orders, usersList, currentUser]);

  // Filter rankings based on search query
  const filteredRankings = useMemo(() => {
    const q = searchQuery.trim().toLowerCase().replace(/^@+/, '');
    if (!q) return rankings;
    return rankings.filter(
      (r) =>
        r.username.toLowerCase().includes(q) ||
        r.tier.toLowerCase().includes(q) ||
        String(r.rank) === q
    );
  }, [searchQuery, rankings]);

  return (
    <div className={`space-y-4 max-w-5xl mx-auto animate-fadeIn pb-20 pt-2 px-1 sm:px-2 ${
      isLight ? 'text-slate-900' : 'text-slate-100'
    }`}>
      
      {/* Search Bar on Top of the Table List */}
      <div className="relative flex items-center">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Cari nama / username gamer..."
          className={`w-full font-semibold text-sm sm:text-base rounded-2xl py-3.5 pl-4 pr-12 border transition-all focus:outline-none focus:ring-2 focus:ring-orange-500 ${
            isLight
              ? 'bg-white text-slate-900 placeholder:text-slate-400 border-slate-300 shadow-sm'
              : 'bg-[#120803] text-white placeholder:text-slate-500 border-orange-500/40 shadow-[0_0_20px_rgba(249,115,22,0.15)]'
          }`}
        />
        {searchQuery ? (
          <button
            onClick={() => setSearchQuery('')}
            className={`absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-xl transition cursor-pointer ${
              isLight ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' : 'bg-orange-950 text-orange-300 hover:text-white'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        ) : (
          <div className={`absolute right-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-xl border flex items-center justify-center pointer-events-none ${
            isLight ? 'bg-orange-50 border-orange-200 text-orange-600' : 'bg-orange-500/20 border-orange-500/30 text-orange-400'
          }`}>
            <Search className="w-4 h-4" />
          </div>
        )}
      </div>

      {/* Full Ranking Table */}
      <div className={`rounded-2xl sm:rounded-3xl overflow-hidden border shadow-xl ${
        isLight
          ? 'bg-white border-slate-200 shadow-lg'
          : 'border-orange-500/40 bg-[#0C0602] shadow-[0_10px_35px_rgba(0,0,0,0.9)]'
      }`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            
            {/* Table Header */}
            <thead>
              <tr className={`border-b text-xs sm:text-sm font-extrabold uppercase tracking-wider ${
                isLight
                  ? 'bg-slate-100 border-slate-200 text-slate-800'
                  : 'bg-[#180A02] border-orange-500/40 text-orange-200'
              }`}>
                <th className={`py-3.5 px-3 sm:px-6 border-r text-center w-16 sm:w-24 shrink-0 ${isLight ? 'border-slate-200' : 'border-orange-900/40'}`}>
                  RANK
                </th>
                <th className={`py-3.5 px-3 sm:px-6 border-r min-w-[170px] sm:min-w-[220px] ${isLight ? 'border-slate-200' : 'border-orange-900/40'}`}>
                  PENGGUNA / GAMER
                </th>
                <th className={`py-3.5 px-3 sm:px-6 border-r min-w-[110px] sm:min-w-[150px] text-center ${isLight ? 'border-slate-200' : 'border-orange-900/40'}`}>
                  PESANAN
                </th>
                <th className="py-3.5 px-3 sm:px-6 min-w-[110px] sm:min-w-[150px] text-right">
                  JUMLAH BELANJA
                </th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className={`divide-y text-xs sm:text-sm font-medium ${isLight ? 'divide-slate-200' : 'divide-orange-950/60'}`}>
              {filteredRankings.length === 0 ? (
                <tr>
                  <td colSpan={4} className={`py-12 text-center ${isLight ? 'text-slate-500 bg-slate-50' : 'text-slate-400 bg-[#0A0502]'}`}>
                    <div className="max-w-md mx-auto space-y-3 px-4">
                      <Trophy className="w-10 h-10 text-orange-500 mx-auto opacity-60" />
                      <p className={`font-bold text-base ${isLight ? 'text-slate-900' : 'text-white'}`}>Tiada Rekod Ditemui</p>
                      <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                        {searchQuery
                          ? `Tiada pengguna sepadan dengan carian "${searchQuery}".`
                          : 'Belum ada rekod transaksi. Jadilah orang pertama membuat topup!'}
                      </p>
                      {searchQuery && (
                        <button
                          onClick={() => setSearchQuery('')}
                          className="mt-2 px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                        >
                          Papar Semua
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filteredRankings.map((item) => {
                  let rankBadge = (
                    <div className={`w-8 h-8 rounded-full border font-mono font-black text-xs flex items-center justify-center mx-auto ${
                      isLight
                        ? 'bg-slate-100 border-slate-300 text-slate-700'
                        : 'bg-slate-900/80 border-slate-700/60 text-slate-300'
                    }`}>
                      #{item.rank}
                    </div>
                  );

                  if (item.rank === 1) {
                    rankBadge = (
                      <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 text-slate-950 font-black text-xs sm:text-sm shadow-[0_0_15px_rgba(245,158,11,0.8)] flex items-center justify-center mx-auto">
                        1👑
                      </div>
                    );
                  } else if (item.rank === 2) {
                    rankBadge = (
                      <div className="w-9 h-9 rounded-full bg-slate-300 text-slate-950 font-black text-xs sm:text-sm shadow-md flex items-center justify-center mx-auto">
                        2🥈
                      </div>
                    );
                  } else if (item.rank === 3) {
                    rankBadge = (
                      <div className="w-9 h-9 rounded-full bg-amber-700 text-amber-100 font-black text-xs sm:text-sm shadow-md flex items-center justify-center mx-auto">
                        3🥉
                      </div>
                    );
                  } else if (item.rank <= 5) {
                    rankBadge = (
                      <div className={`w-8 h-8 rounded-xl border font-mono font-black text-xs flex items-center justify-center mx-auto ${
                        isLight
                          ? 'bg-orange-50 text-orange-700 border-orange-200'
                          : 'bg-orange-500/20 text-orange-400 border-orange-500/40'
                      }`}>
                        #{item.rank}
                      </div>
                    );
                  }

                  return (
                    <tr
                      key={`${item.id}-${item.username}-${item.rank}`}
                      className={`transition-colors duration-150 ${
                        item.isCurrentUser
                          ? isLight ? 'bg-orange-50 text-slate-900 border-l-4 border-l-orange-500' : 'bg-[#261204] text-white border-l-4 border-l-orange-500'
                          : isLight
                          ? item.rank % 2 === 0
                          ? 'bg-white hover:bg-orange-50/50'
                          : 'bg-slate-50/50 hover:bg-orange-50/50'
                          : item.rank % 2 === 0
                          ? 'bg-[#0E0702] hover:bg-[#1A0D04]'
                          : 'bg-[#0A0501] hover:bg-[#1A0D04]'
                      }`}
                    >
                      {/* Column 1: Rank Badge */}
                      <td className={`py-3.5 px-2 sm:px-6 border-r text-center shrink-0 ${isLight ? 'border-slate-200' : 'border-orange-950/60'}`}>
                        {rankBadge}
                      </td>

                      {/* Column 2: Gamer Info */}
                      <td className={`py-3.5 px-3 sm:px-6 border-r ${isLight ? 'border-slate-200' : 'border-orange-950/60'}`}>
                        <div className="flex items-center gap-2.5 sm:gap-3">
                          
                          {/* Avatar container with strict dimensions & shrink-0 */}
                          <div className="relative w-9 h-9 sm:w-10 sm:h-10 min-w-[36px] sm:min-w-[40px] shrink-0">
                            <img
                              src={item.avatarUrl}
                              alt={item.username}
                              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full object-cover border shadow-sm ${
                                isLight ? 'border-orange-300 bg-slate-100' : 'border-orange-500/50 bg-[#1A0C04]'
                              }`}
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(item.username)}`;
                              }}
                            />
                            {item.isOnline ? (
                              <span
                                className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 border border-white dark:border-black rounded-full shadow-sm animate-pulse"
                                title="Online Sekarang 🟢"
                              />
                            ) : (
                              <span
                                className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-slate-400 dark:bg-slate-600 border border-white dark:border-black rounded-full shadow-sm"
                                title="Offline ⚫"
                              />
                            )}
                          </div>

                          {/* Details */}
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center flex-wrap gap-1.5">
                              <span className={`font-extrabold text-xs sm:text-sm truncate max-w-[140px] sm:max-w-[200px] ${
                                isLight ? 'text-slate-900' : 'text-white'
                              }`}>
                                @{item.username}
                              </span>
                              {item.isCurrentUser && (
                                <span className="px-1.5 py-0.5 rounded bg-orange-500 text-white dark:text-black text-[9px] font-black uppercase tracking-wider shrink-0 shadow-sm">
                                  Akaun Anda
                                </span>
                              )}
                              {item.isVerified && (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" title="Disahkan" />
                              )}
                            </div>
                          </div>

                        </div>
                      </td>

                      {/* Column 3: Jumlah Pesanan */}
                      <td className={`py-3.5 px-2 sm:px-6 border-r text-center font-mono ${isLight ? 'border-slate-200' : 'border-orange-950/60'}`}>
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl border font-bold text-xs sm:text-sm ${
                          isLight
                            ? 'bg-slate-100 border-slate-200 text-slate-800'
                            : 'bg-black/60 border-orange-900/60 text-slate-200'
                        }`}>
                          <Gamepad2 className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                          <span>{item.orderCount}</span>
                        </span>
                      </td>

                      {/* Column 4: Jumlah Belanja */}
                      <td className="py-3.5 px-3 sm:px-6 text-right font-mono">
                        <span className="text-orange-600 dark:text-amber-400 font-black text-xs sm:text-sm tracking-wide">
                          RM {item.totalSpent.toFixed(2)}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer info note */}
        <div className={`p-3.5 border-t flex flex-col sm:flex-row items-center justify-between gap-2.5 text-xs ${
          isLight
            ? 'bg-slate-50 border-slate-200 text-slate-600'
            : 'bg-[#140A03] border-orange-900/50 text-orange-300/80'
        }`}>
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
            <span className="text-[11px] sm:text-xs">Data kedudukan dikemas kini automatik berdasarkan rekod transaksi akaun.</span>
          </div>
          {onSelectTopup && (
            <button
              onClick={onSelectTopup}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white font-black text-xs shadow-md transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
            >
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>Topup Sekarang ➔</span>
            </button>
          )}
        </div>

      </div>

    </div>
  );
};
