import React from 'react';
import { ShieldCheck, Zap, MessageCircle, Heart, CheckCircle2, Lock, HelpCircle, FileText, PhoneCall, ExternalLink, Award } from 'lucide-react';
import { TopupBalzIcon } from './BrandLogo';

interface FooterProps {
  onOpenAdmin: () => void;
  onOpenOrderTracker: () => void;
  ownerWhatsApp: string;
  onOpenInfoModal?: (tab: 'faq' | 'contact' | 'privacy' | 'terms') => void;
  theme?: 'dark' | 'light';
}

export const Footer: React.FC<FooterProps> = ({
  onOpenAdmin,
  onOpenOrderTracker,
  ownerWhatsApp,
  onOpenInfoModal,
  theme = 'dark',
}) => {
  const cleanPhone = (ownerWhatsApp || '').replace(/\D/g, '');
  const isLight = theme === 'light';

  return (
    <footer
      className={`border-t pt-14 pb-36 sm:pb-40 text-xs transition-colors duration-300 ${
        isLight
          ? 'bg-slate-100/95 border-slate-200 text-slate-600'
          : 'bg-[#06080D] border-slate-800/80 text-slate-400'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Top Badges Strip: Authenticity, Instant Delivery, SSL 256-Bit */}
        <div className={`p-4 sm:p-5 rounded-2xl border grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 ${
          isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#0B0F17] border-slate-800/90 shadow-md'
        }`}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className={`font-bold text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>
                100% Rasmi & Sah
              </p>
              <p className="text-[11px] text-slate-400">
                Semua topup terus ke ID akaun rasmi
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-500 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <p className={`font-bold text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Penghantaran Segera 24/7
              </p>
              <p className="text-[11px] text-slate-400">
                Proses pantas 10 hingga 30 saat
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-500 flex items-center justify-center shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <p className={`font-bold text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Enkripsi SSL 256-Bit
              </p>
              <p className="text-[11px] text-slate-400">
                Data peribadi & transaksi dilindungi
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 text-purple-400 flex items-center justify-center shrink-0">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <p className={`font-bold text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Jaminan Harga Terbaik
              </p>
              <p className="text-[11px] text-slate-400">
                Paling murah & berpatutan di Malaysia
              </p>
            </div>
          </div>
        </div>

        {/* Main 4-Column Footer Navigation */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-10">
          
          {/* Col 1: Corporate Profile */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="relative">
                <TopupBalzIcon className="w-10 h-10 object-contain drop-shadow-[0_2px_12px_rgba(249,115,22,0.5)] animate-logo-float" />
              </div>
              <div>
                <span className={`text-xl font-black tracking-tight font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
                  TOPUP<span className="text-orange-500">BALZ</span>
                </span>
                <span className="ml-1.5 px-1.5 py-0.5 text-[9px] font-black uppercase rounded bg-orange-500/20 text-orange-400 border border-orange-500/40">
                  MALAYSIA
                </span>
              </div>
            </div>

            <p className={`leading-relaxed text-xs ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
              <strong>TopupBalz Malaysia</strong> ialah platform pasaran digital dan gedung tambah nilai permainan video atas talian terkemuka di Malaysia. Kami menyediakan kemudahan tambah nilai diamond, token, credits, dan baucar game secara automatik dan pantas dengan jaminan keselamatan 100%.
            </p>

            <div className="space-y-1.5 pt-1 text-xs">
              <p className={`font-semibold flex items-center gap-2 ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Waktu Operasi: <strong>24 Jam (Isnin – Ahad)</strong></span>
              </p>
              <p className="text-slate-400 text-[11px]">
                Sistem pesanan & pemprosesan berjalan automatik tanpa henti.
              </p>
            </div>
          </div>

          {/* Col 2: Pilihan Game Popular */}
          <div className="md:col-span-2 space-y-3">
            <p className={`font-extrabold text-xs uppercase tracking-wider font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
              Game Popular
            </p>
            <ul className={`space-y-2 text-xs ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
              <li>
                <button
                  type="button"
                  onClick={() => window.scrollTo({ top: 300, behavior: 'smooth' })}
                  className="hover:text-orange-500 transition-colors text-left cursor-pointer"
                >
                  Mobile Legends: Bang Bang
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => window.scrollTo({ top: 300, behavior: 'smooth' })}
                  className="hover:text-orange-500 transition-colors text-left cursor-pointer"
                >
                  Free Fire (Garena)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => window.scrollTo({ top: 300, behavior: 'smooth' })}
                  className="hover:text-orange-500 transition-colors text-left cursor-pointer"
                >
                  PUBG Mobile (UC)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => window.scrollTo({ top: 300, behavior: 'smooth' })}
                  className="hover:text-orange-500 transition-colors text-left cursor-pointer"
                >
                  Roblox (Robux Gift Card)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => window.scrollTo({ top: 300, behavior: 'smooth' })}
                  className="hover:text-orange-500 transition-colors text-left cursor-pointer"
                >
                  Honor of Kings (Tokens)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => window.scrollTo({ top: 300, behavior: 'smooth' })}
                  className="hover:text-orange-500 transition-colors text-left cursor-pointer"
                >
                  Genshin Impact (Genesis)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => window.scrollTo({ top: 300, behavior: 'smooth' })}
                  className="hover:text-orange-500 transition-colors text-left cursor-pointer"
                >
                  Call of Duty: Mobile (CP)
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Khidmat Pelanggan & Bantuan */}
          <div className="md:col-span-3 space-y-3">
            <p className={`font-extrabold text-xs uppercase tracking-wider font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
              Bantuan &amp; Sokongan
            </p>
            <ul className={`space-y-2 text-xs ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
              <li>
                <button
                  type="button"
                  onClick={onOpenOrderTracker}
                  className="hover:text-orange-500 transition-colors flex items-center gap-1.5 cursor-pointer text-left font-semibold text-orange-400"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Semak Status Pesanan</span>
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal?.('faq')}
                  className="hover:text-orange-500 transition-colors flex items-center gap-1.5 cursor-pointer text-left"
                >
                  <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
                  <span>Soalan Lazim (FAQ)</span>
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal?.('contact')}
                  className="hover:text-orange-500 transition-colors flex items-center gap-1.5 cursor-pointer text-left"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-slate-400" />
                  <span>Hubungi Khidmat Pelanggan</span>
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal?.('privacy')}
                  className="hover:text-orange-500 transition-colors flex items-center gap-1.5 cursor-pointer text-left"
                >
                  <Lock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Dasar Privasi &amp; Data (PDPA)</span>
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal?.('terms')}
                  className="hover:text-orange-500 transition-colors flex items-center gap-1.5 cursor-pointer text-left"
                >
                  <FileText className="w-3.5 h-3.5 text-slate-400" />
                  <span>Terma &amp; Syarat Penggunaan</span>
                </button>
              </li>
              <li>
                <a
                  href={`https://wa.me/${cleanPhone.length ? cleanPhone : '60145975056'}?text=Hi%20Admin%20TopupBalz`}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5 cursor-pointer text-left"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-500" />
                  <span>WhatsApp Rasmi Admin</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Kaedah Pembayaran Rasmi & Marquee */}
          <div className="md:col-span-3 space-y-3">
            <p className={`font-extrabold text-xs uppercase tracking-wider font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
              Kaedah Pembayaran Rasmi
            </p>
            <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
              Sokongan pembayaran lengkap, selamat dan disahkan melalui Touch 'n Go eWallet, DuitNow QR serta Perbankan Internet FPX.
            </p>

            {/* Payment Logos Grid */}
            <div className={`p-3 rounded-2xl border space-y-2.5 ${
              isLight ? 'bg-white border-slate-200' : 'bg-[#0B0F17] border-slate-800'
            }`}>
              <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-bold">
                <div className={`p-1.5 rounded-lg border ${
                  isLight ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-blue-950/40 border-blue-800/60 text-blue-300'
                }`}>
                  TNG eWallet
                </div>
                <div className={`p-1.5 rounded-lg border ${
                  isLight ? 'bg-pink-50 border-pink-200 text-pink-700' : 'bg-pink-950/40 border-pink-800/60 text-pink-300'
                }`}>
                  DuitNow QR
                </div>
                <div className={`p-1.5 rounded-lg border ${
                  isLight ? 'bg-amber-50 border-amber-200 text-amber-800' : 'bg-amber-950/40 border-amber-800/60 text-amber-300'
                }`}>
                  FPX Banking
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-[9px] font-semibold text-slate-400">
                <span className="p-1 rounded bg-slate-900/60 border border-slate-800">Maybank</span>
                <span className="p-1 rounded bg-slate-900/60 border border-slate-800">CIMB</span>
                <span className="p-1 rounded bg-slate-900/60 border border-slate-800">Bank Islam</span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1 text-[11px] text-slate-400">
              <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Semua transaksi disulitkan 256-Bit SSL</span>
            </div>
          </div>

        </div>

      </div>

      {/* Floating WhatsApp Quick Contact Button */}
      <a
        href={`https://wa.me/${cleanPhone.length ? cleanPhone : '60145975056'}?text=Assalamualaikum%20admin%20TopupBalz,%20saya%20perlukan%20bantuan.`}
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-24 right-3 sm:bottom-28 sm:right-6 z-30 p-2.5 sm:px-4 sm:py-3 rounded-full bg-[#25D366] hover:bg-[#20ba5a] text-slate-950 font-black text-xs shadow-[0_0_25px_rgba(37,211,102,0.6)] hover:shadow-[0_0_40px_rgba(37,211,102,0.9)] hover:scale-105 active:scale-95 transition-all duration-300 flex items-center gap-2 cursor-pointer border-2 border-white/80"
        title="Hubungi Admin via WhatsApp"
      >
        <div className="relative flex items-center justify-center">
          <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 fill-slate-950 text-[#25D366]" />
          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-300 animate-ping" />
        </div>
        <span className="font-extrabold text-slate-950 text-[11px] sm:text-xs tracking-tight hidden xs:inline sm:inline">
          WhatsApp Admin
        </span>
      </a>

    </footer>
  );
};
