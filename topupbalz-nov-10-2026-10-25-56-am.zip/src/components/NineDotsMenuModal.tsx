import React from 'react';
import { X, ShoppingCart, RotateCcw, Star, BookOpen, Calculator, Trophy, HelpCircle, Flame } from 'lucide-react';
import { NavTab } from './BottomNav';

interface NineDotsMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  setActiveTab: (tab: NavTab) => void;
  onOpenOrderTracker: () => void;
  onOpenCalculator: () => void;
  onOpenInfoModal?: (tab?: 'faq' | 'contact' | 'privacy' | 'terms') => void;
  theme?: 'dark' | 'light';
}

export const NineDotsMenuModal: React.FC<NineDotsMenuModalProps> = ({
  isOpen,
  onClose,
  setActiveTab,
  onOpenCalculator,
  onOpenInfoModal,
  theme = 'dark',
}) => {
  if (!isOpen) return null;
  const isLight = theme === 'light';

  const menuItems = [
    {
      id: 'store',
      label: 'Kedai Akaun / Topup',
      icon: ShoppingCart,
      color: isLight ? 'text-orange-600' : 'text-orange-400',
      bgColor: isLight ? 'bg-orange-100 border-orange-200' : 'bg-orange-500/15 border-orange-500/30',
      action: () => {
        setActiveTab('menu');
        onClose();
        const el = document.getElementById('semua-game-section') || document.getElementById('game-categories');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      },
    },
    {
      id: 'tracker',
      label: 'Semak Transaksi',
      icon: RotateCcw,
      color: isLight ? 'text-amber-600' : 'text-amber-400',
      bgColor: isLight ? 'bg-amber-100 border-amber-200' : 'bg-amber-500/15 border-amber-500/30',
      action: () => {
        setActiveTab('transactions');
        onClose();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
    },
    {
      id: 'ranking',
      label: 'Ranking Topup',
      icon: Trophy,
      color: isLight ? 'text-yellow-600' : 'text-yellow-400',
      bgColor: isLight ? 'bg-yellow-100 border-yellow-200' : 'bg-yellow-500/15 border-yellow-500/30',
      action: () => {
        setActiveTab('ranking');
        onClose();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
    },
    {
      id: 'tutorials',
      label: 'Tutorial & Panduan',
      icon: BookOpen,
      color: isLight ? 'text-emerald-600' : 'text-emerald-400',
      bgColor: isLight ? 'bg-emerald-100 border-emerald-200' : 'bg-emerald-500/15 border-emerald-500/30',
      action: () => {
        setActiveTab('tutorials');
        onClose();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
    },
    {
      id: 'reviews',
      label: 'Semua Ulasan',
      icon: Star,
      color: isLight ? 'text-amber-500' : 'text-amber-300',
      bgColor: isLight ? 'bg-amber-100 border-amber-200' : 'bg-amber-500/15 border-amber-500/30',
      action: () => {
        setActiveTab('reviews');
        onClose();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
    },
    {
      id: 'calculator',
      label: 'Kalkulator Winrate',
      icon: Calculator,
      color: isLight ? 'text-rose-600' : 'text-rose-400',
      bgColor: isLight ? 'bg-rose-100 border-rose-200' : 'bg-rose-500/15 border-rose-500/30',
      action: () => {
        onClose();
        onOpenCalculator();
      },
    },
    {
      id: 'faq',
      label: 'Soalan Lazim (FAQ)',
      icon: HelpCircle,
      color: isLight ? 'text-cyan-600' : 'text-cyan-400',
      bgColor: isLight ? 'bg-cyan-100 border-cyan-200' : 'bg-cyan-500/15 border-cyan-500/30',
      action: () => {
        onClose();
        if (onOpenInfoModal) onOpenInfoModal('faq');
      },
    },
  ];

  return (
    <div className={`fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-md animate-fadeIn ${
      isLight ? 'bg-slate-900/50' : 'bg-[#050201]/90'
    }`}>
      
      {/* Modal Card Box matching theme */}
      <div className={`relative w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-5 sm:p-7 overflow-hidden space-y-6 max-h-[85vh] overflow-y-auto transition-colors duration-300 ${
        isLight
          ? 'bg-white border-t sm:border border-orange-200 shadow-[0_20px_60px_rgba(0,0,0,0.15)] text-slate-900'
          : 'bg-[#0D0602] border-t sm:border border-orange-500/40 shadow-[0_0_60px_rgba(249,115,22,0.35)] text-white'
      }`}>
        
        {/* Modal Header */}
        <div className={`flex items-center justify-between pb-3 border-b ${
          isLight ? 'border-orange-100' : 'border-orange-900/50'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-md ${
              isLight
                ? 'bg-orange-100 border border-orange-300 text-orange-600'
                : 'bg-orange-500/20 border border-orange-500/40 text-orange-400 shadow-[0_0_15px_rgba(249,115,22,0.3)]'
            }`}>
              <Flame className="w-5 h-5 text-orange-500 animate-pulse" />
            </div>
            <div>
              <h2 className={`text-base font-black tracking-widest uppercase ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}>
                MENU UTAMA
              </h2>
              <p className={`text-[11px] font-medium ${
                isLight ? 'text-orange-700' : 'text-orange-300/70'
              }`}>
                Navigasi Pantas & Perkhidmatan TopupBalz
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Tutup Menu"
            className={`p-2.5 rounded-full transition-all cursor-pointer border ${
              isLight
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 border-slate-200'
                : 'bg-[#1A0A02] hover:bg-[#261004] text-slate-400 hover:text-white border-orange-900/50'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Grid Menu Tiles */}
        <div className="grid grid-cols-3 gap-3 sm:gap-4">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={item.action}
                className={`flex flex-col items-center justify-center text-center p-3 sm:p-4 rounded-2xl border transition-all duration-200 group cursor-pointer aspect-square ${
                  isLight
                    ? 'bg-slate-50 hover:bg-orange-50/80 border-slate-200 hover:border-orange-300 shadow-sm hover:shadow-md hover:-translate-y-0.5 active:scale-95'
                    : 'bg-[#140802] hover:bg-[#200D04] border-orange-900/50 hover:border-orange-500/60 shadow-lg hover:shadow-orange-500/20 hover:-translate-y-0.5 active:scale-95'
                }`}
              >
                <div className={`p-3 rounded-2xl mb-2 transition-transform group-hover:scale-110 border ${item.bgColor}`}>
                  <Icon className={`w-6 h-6 sm:w-7 sm:h-7 ${item.color}`} />
                </div>
                <span className={`text-[11px] sm:text-xs font-bold leading-tight line-clamp-2 ${
                  isLight
                    ? 'text-slate-700 group-hover:text-orange-950'
                    : 'text-slate-200 group-hover:text-white'
                }`}>
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Quick Footer hint */}
        <div className={`pt-2 border-t text-center ${
          isLight ? 'border-orange-100' : 'border-orange-950/80'
        }`}>
          <p className={`text-[10px] font-mono ${
            isLight ? 'text-orange-700' : 'text-orange-400/60'
          }`}>
            ⚡ TopupBalz Gaming Services & Real-time Live Portal
          </p>
        </div>

      </div>
    </div>
  );
};
