import React, { useState } from 'react';
import { X, HelpCircle, PhoneCall, ShieldCheck, FileText, MessageSquare, Mail, MapPin, Send } from 'lucide-react';

export type InfoTab = 'faq' | 'contact' | 'privacy' | 'terms';

interface InfoPagesModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: InfoTab;
  ownerWhatsApp?: string;
  theme?: 'dark' | 'light';
}

export const InfoPagesModal: React.FC<InfoPagesModalProps> = ({
  isOpen,
  onClose,
  defaultTab = 'faq',
  ownerWhatsApp = '60145975056',
  theme = 'dark',
}) => {
  const [activeTab, setActiveTab] = useState<InfoTab>(defaultTab);
  const [contactSubject, setContactSubject] = useState('');
  const [contactMessage, setContactMessage] = useState('');

  if (!isOpen) return null;
  const isLight = theme === 'light';

  const handleSendContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactMessage.trim()) return;
    const msg = `*PERTANYAAN / MAKLUMAT PELANGGAN*\n\n*Tajuk:* ${contactSubject || 'Pertanyaan Umum'}\n*Mesej:* ${contactMessage}`;
    window.open(`https://wa.me/${ownerWhatsApp}?text=${encodeURIComponent(msg)}`, '_blank');
    setContactMessage('');
    setContactSubject('');
  };

  const faqs = [
    {
      q: 'Berapa lamakah proses topup mengambil masa?',
      a: 'Kebiasaannya dalam masa 1 hingga 15 minit selepas bayaran dan resit disahkan oleh sistem/admin.',
    },
    {
      q: 'Adakah topup di TopupBalz selamat & sah?',
      a: '100% Sah & Selamat! Semua transaksi dibuat terus melalui kaedah rasmi tanpa risiko akaun di-ban.',
    },
    {
      q: 'Apa perlu dibuat jika tersalah masukkan User ID?',
      a: 'Sila hubungi Admin WhatsApp segera dengan menyertakan No. Pesanan (#BZ-XXXXXX) sebelum pesanan diproses.',
    },
    {
      q: 'Apakah kaedah pembayaran yang disokong?',
      a: 'Kami menerima Touch \'n Go eWallet, FPX Online Banking (Semua bank utama Malaysia), dan DuitNow QR.',
    },
  ];

  return (
    <div className={`fixed inset-0 z-[100] overflow-y-auto backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fadeIn ${
      isLight ? 'bg-slate-900/50' : 'bg-black/80'
    }`}>
      <div className={`relative w-full max-w-3xl rounded-3xl overflow-hidden my-auto border shadow-2xl transition-colors duration-300 ${
        isLight
          ? 'bg-white border-orange-200 text-slate-900 shadow-2xl'
          : 'bg-[#0D1117] border-orange-500/30 text-white shadow-[0_0_50px_rgba(255,140,0,0.3)]'
      }`}>
        
        {/* Header Bar */}
        <div className={`p-4 sm:p-5 border-b flex items-center justify-between transition-colors ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-orange-500/20 text-orange-500 rounded-xl border border-orange-500/30">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className={`text-base sm:text-lg font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Pusat Maklumat & Bantuan TopupBalz
              </h3>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                FAQ, Hubungi Kami, Polisi Privasi & Terma Perkhidmatan
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Tutup Maklumat"
            className={`w-9 h-9 rounded-full flex items-center justify-center transition-all cursor-pointer border ${
              isLight
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-200'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border-slate-800'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className={`px-4 pt-3 border-b flex items-center gap-2 overflow-x-auto no-scrollbar transition-colors ${
          isLight ? 'bg-slate-100 border-slate-200' : 'bg-[#090B10] border-slate-800/80'
        }`}>
          <button
            onClick={() => setActiveTab('faq')}
            className={`px-4 py-2.5 rounded-t-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border-b-2 whitespace-nowrap ${
              activeTab === 'faq'
                ? isLight
                  ? 'bg-white text-orange-600 border-orange-500 font-black shadow-sm'
                  : 'bg-[#0D1117] text-orange-400 border-orange-500 font-black'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 border-transparent'
                : 'text-slate-400 hover:text-white border-transparent'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>Soalan Lazim (FAQ)</span>
          </button>

          <button
            onClick={() => setActiveTab('contact')}
            className={`px-4 py-2.5 rounded-t-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border-b-2 whitespace-nowrap ${
              activeTab === 'contact'
                ? isLight
                  ? 'bg-white text-orange-600 border-orange-500 font-black shadow-sm'
                  : 'bg-[#0D1117] text-orange-400 border-orange-500 font-black'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 border-transparent'
                : 'text-slate-400 hover:text-white border-transparent'
            }`}
          >
            <PhoneCall className="w-4 h-4" />
            <span>Hubungi Kami</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`px-4 py-2.5 rounded-t-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border-b-2 whitespace-nowrap ${
              activeTab === 'privacy'
                ? isLight
                  ? 'bg-white text-orange-600 border-orange-500 font-black shadow-sm'
                  : 'bg-[#0D1117] text-orange-400 border-orange-500 font-black'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 border-transparent'
                : 'text-slate-400 hover:text-white border-transparent'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Polisi Privasi</span>
          </button>

          <button
            onClick={() => setActiveTab('terms')}
            className={`px-4 py-2.5 rounded-t-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border-b-2 whitespace-nowrap ${
              activeTab === 'terms'
                ? isLight
                  ? 'bg-white text-orange-600 border-orange-500 font-black shadow-sm'
                  : 'bg-[#0D1117] text-orange-400 border-orange-500 font-black'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 border-transparent'
                : 'text-slate-400 hover:text-white border-transparent'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Terma &amp; Syarat</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-5 sm:p-6 max-h-[60vh] overflow-y-auto space-y-4">
          {activeTab === 'faq' && (
            <div className="space-y-3">
              {faqs.map((f, i) => (
                <div key={i} className={`p-4 rounded-2xl border transition-colors ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
                }`}>
                  <h4 className={`text-xs sm:text-sm font-bold flex items-center gap-2 ${
                    isLight ? 'text-slate-900' : 'text-orange-400'
                  }`}>
                    <HelpCircle className="w-4 h-4 text-orange-500 shrink-0" />
                    <span>{f.q}</span>
                  </h4>
                  <p className={`text-xs mt-2 pl-6 leading-relaxed ${
                    isLight ? 'text-slate-600' : 'text-slate-300'
                  }`}>
                    {f.a}
                  </p>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'contact' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-3">
                <div className={`p-4 rounded-2xl border space-y-2 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
                }`}>
                  <div className="flex items-center gap-2 text-orange-500 font-bold text-xs">
                    <MessageSquare className="w-4 h-4" />
                    <span>WhatsApp Rasmi Admin</span>
                  </div>
                  <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                    Perkhidmatan Bantuan Pantas 24/7
                  </p>
                  <a
                    href={`https://wa.me/${ownerWhatsApp}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow-sm"
                  >
                    <span>Hubungi +{ownerWhatsApp}</span>
                  </a>
                </div>

                <div className={`p-4 rounded-2xl border space-y-2 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
                }`}>
                  <div className="flex items-center gap-2 text-orange-500 font-bold text-xs">
                    <MapPin className="w-4 h-4" />
                    <span>Lokasi Operasi</span>
                  </div>
                  <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                    Kuala Lumpur &amp; Seluruh Malaysia (Perkhidmatan Digital Sepenuhnya)
                  </p>
                </div>
              </div>

              <form onSubmit={handleSendContact} className={`p-4 rounded-2xl border space-y-3 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
              }`}>
                <h4 className={`text-xs font-black uppercase ${isLight ? 'text-slate-900' : 'text-white'}`}>
                  Hantar Mesej Terus ke WhatsApp
                </h4>
                <div>
                  <label className={`block text-[11px] font-bold mb-1 ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                    Tajuk / Topik Pertanyaan
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: Masalah Pembayaran FPX"
                    value={contactSubject}
                    onChange={(e) => setContactSubject(e.target.value)}
                    className={`w-full rounded-xl px-3 py-2 text-xs focus:outline-none ${
                      isLight
                        ? 'bg-white border border-slate-300 text-slate-900'
                        : 'bg-[#0D1117] border border-slate-700 text-white'
                    }`}
                  />
                </div>
                <div>
                  <label className={`block text-[11px] font-bold mb-1 ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                    Mesej Anda
                  </label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Tuliskan soalan atau maklumat berkaitan..."
                    value={contactMessage}
                    onChange={(e) => setContactMessage(e.target.value)}
                    className={`w-full rounded-xl px-3 py-2 text-xs focus:outline-none resize-none ${
                      isLight
                        ? 'bg-white border border-slate-300 text-slate-900'
                        : 'bg-[#0D1117] border border-slate-700 text-white'
                    }`}
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Kirim ke WhatsApp</span>
                </button>
              </form>
            </div>
          )}

          {activeTab === 'privacy' && (
            <div className={`p-4 rounded-2xl border text-xs leading-relaxed space-y-3 ${
              isLight ? 'bg-slate-50 border-slate-200 text-slate-700' : 'bg-[#121824] border-slate-800 text-slate-300'
            }`}>
              <h4 className={`text-sm font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>Polisi Privasi TopupBalz</h4>
              <p>Kami menghormati dan melindungi privasi setiap maklumat pengguna kami. Segala maklumat seperti Nombor Telefon, User ID Game, dan Bukti Bayaran hanya digunakan semata-mata untuk tujuan pemprosesan pesanan dan rekod transaksi yang sah.</p>
              <p>Maklumat anda tidak akan sesekali dijual, dikongsi, atau diedarkan kepada mana-mana pihak ketiga yang tidak berkaitan.</p>
            </div>
          )}

          {activeTab === 'terms' && (
            <div className={`p-4 rounded-2xl border text-xs leading-relaxed space-y-3 ${
              isLight ? 'bg-slate-50 border-slate-200 text-slate-700' : 'bg-[#121824] border-slate-800 text-slate-300'
            }`}>
              <h4 className={`text-sm font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>Terma &amp; Syarat Perkhidmatan</h4>
              <ul className="list-disc pl-5 space-y-1.5">
                <li>Pengguna bertanggungjawab memastikan User ID dan Server ID yang dimasukkan adalah tepat sebelum bayaran dibuat.</li>
                <li>Pesanan yang telah selesai diproses dengan maklumat yang betul tidak boleh dipulangkan (non-refundable).</li>
                <li>Sebarang resit palsu atau percubaan manipulasi bukti bayaran akan mengakibatkan nombor dan akaun anda disenaraihitamkan serta-merta.</li>
              </ul>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
