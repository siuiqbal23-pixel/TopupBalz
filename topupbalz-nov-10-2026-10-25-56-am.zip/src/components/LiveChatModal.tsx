import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Video,
  Phone,
  MoreVertical,
  Smile,
  Paperclip,
  Mic,
  Send,
  Image as ImageIcon,
  Camera,
  MapPin,
  User,
  FileText,
  Headphones,
  BarChart2,
  CheckCheck,
  Lock,
  Search,
  Trash2,
  BellOff,
  Clock,
  Sparkles,
  Info,
  X
} from 'lucide-react';
import { ChatMessage, SystemSettings } from '../types';
import { safeFetchJson } from '../lib/safeFetch';

interface LiveChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName?: string;
  currentUser?: any;
  settings?: SystemSettings;
  theme?: 'dark' | 'light';
}

export const LiveChatModal: React.FC<LiveChatModalProps> = ({
  isOpen,
  onClose,
  userName = 'Pelanggan',
  currentUser,
  settings,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [sending, setSending] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showEncryptionModal, setShowEncryptionModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [wallpaperTheme, setWallpaperTheme] = useState<'blue-doodle' | 'navy-solid' | 'midnight'>('blue-doodle');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const attachMenuRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getEffectiveUserName = () => {
    if (currentUser?.username || currentUser?.name) return currentUser.username || currentUser.name;
    if (userName && userName !== 'Pelanggan') return userName;
    try {
      const stored = localStorage.getItem('topupbalz_current_user');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && (parsed.username || parsed.name)) {
          return parsed.username || parsed.name;
        }
      }
    } catch (e) {}
    return userName || 'Pelanggan';
  };

  const getSessionId = () => {
    let sId = sessionStorage.getItem('topupbalz_session_id');
    if (!sId) {
      sId = 'sess_' + Math.random().toString(36).substring(2, 10) + '_' + Date.now();
      sessionStorage.setItem('topupbalz_session_id', sId);
    }
    return sId;
  };

  const fetchMessages = async () => {
    try {
      const sId = getSessionId();
      const name = getEffectiveUserName();
      const data = await safeFetchJson(
        `/api/chat/messages?sessionId=${encodeURIComponent(sId)}&userName=${encodeURIComponent(name)}`
      );
      if (data && Array.isArray(data.messages)) {
        setMessages(data.messages);
      }
    } catch (e) {
      console.error('Error fetching chat messages:', e);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchMessages();
      const interval = setInterval(fetchMessages, 3000);
      return () => clearInterval(interval);
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, showAttachMenu]);

  // Handle click outside for dropdown & attach menu matching script.js
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (dropdownRef.current && !dropdownRef.current.contains(target) && !target.closest('.dropdown-trigger')) {
        setShowDropdown(false);
      }
      if (attachMenuRef.current && !attachMenuRef.current.contains(target) && !target.closest('.attach-trigger')) {
        setShowAttachMenu(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isOpen]);

  // Voice recording simulation timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isRecording) {
      timer = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      setRecordingSeconds(0);
    }
    return () => clearInterval(timer);
  }, [isRecording]);

  const handleSendMessage = async (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const text = (customText || inputText).trim();
    if (!text || sending) return;

    const sId = getSessionId();
    const senderName = getEffectiveUserName();

    const tempMessage: ChatMessage = {
      id: 'temp_' + Date.now(),
      sessionId: sId,
      sender: 'user',
      senderName,
      message: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, tempMessage]);
    if (!customText) setInputText('');
    setSending(true);
    setShowAttachMenu(false);
    setShowEmojiPicker(false);

    try {
      await fetch('/api/chat/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: sId,
          sender: 'user',
          senderName,
          message: text,
        }),
      });
      fetchMessages();
    } catch (err) {
      console.error('Failed to send message:', err);
    } finally {
      setSending(false);
    }
  };

  const handleMicClick = () => {
    if (!isRecording) {
      setIsRecording(true);
    } else {
      setIsRecording(false);
      const seconds = recordingSeconds || 3;
      handleSendMessage(undefined, `🎤 Mesej Suara (0:0${seconds < 10 ? '0' + seconds : seconds})`);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleSendMessage(undefined, `📸 [Lampiran Fail]: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`);
      setShowAttachMenu(false);
    }
  };

  const handleClearChat = () => {
    if (window.confirm('Adakah anda pasti ingin mengosongkan paparan perbualan chat ini?')) {
      setMessages([]);
      setShowDropdown(false);
    }
  };

  if (!isOpen) return null;

  const filteredMessages = searchQuery.trim()
    ? messages.filter((m) => m.message.toLowerCase().includes(searchQuery.toLowerCase()))
    : messages;

  return (
    <div
      className="fixed inset-0 z-[150] bg-black/85 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-4 animate-fadeIn"
      id="chatCloneApp"
    >
      <div className="relative w-full max-w-md h-[96vh] sm:h-[680px] bg-[#0A0F1D] text-white flex flex-col overflow-hidden sm:rounded-2xl border border-blue-900/60 shadow-[0_10px_40px_rgba(30,58,138,0.35)]">
        
        {/* Hidden File Input for Galeri / Dokumen */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          className="hidden"
          accept="image/*,.pdf,.doc,.docx"
        />

        {/* ============================================================ */}
        {/* HEADER (Following DzarelDeveloper / CHATCLONE Style in BLUE) */}
        {/* ============================================================ */}
        <div
          className="header"
          style={{
            backgroundColor: '#172554', // Deep Blue Header
            padding: '10px 12px',
            display: 'flex',
            alignItems: 'center',
            borderBottom: '1px solid #1E3A8A',
            position: 'relative',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.3)',
          }}
        >
          {/* Back Icon */}
          <button
            onClick={onClose}
            className="back-icon"
            style={{
              color: 'white',
              fontSize: '22px',
              cursor: 'pointer',
              marginRight: '8px',
              background: 'none',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              padding: 0,
            }}
            title="Kembali"
          >
            <ArrowLeft className="w-5 h-5 text-blue-200 hover:text-white transition-colors" />
          </button>

          {/* Profile Picture */}
          <div
            className="profile-pic relative"
            style={{
              width: '42px',
              height: '42px',
              borderRadius: '50%',
              backgroundColor: '#1E3A8A',
              backgroundImage: `url('https://raw.githubusercontent.com/DzarelDeveloper/CHATCLONE-V1/main/Profile.jpg')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              marginRight: '12px',
              border: '2px solid #3B82F6',
              flexShrink: 0,
            }}
            onClick={() => setShowContactModal(true)}
          >
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-[#172554] rounded-full" />
          </div>

          {/* User Info */}
          <div
            className="user-info cursor-pointer select-none"
            style={{ flexGrow: 1, minWidth: 0 }}
            onClick={() => setShowContactModal(true)}
          >
            <p
              className="username font-semibold truncate flex items-center gap-1.5"
              style={{ fontSize: '0.98em', margin: 0, color: '#FFFFFF' }}
            >
              <span>Mimin TopupBalz</span>
              <span className="inline-block px-1.5 py-0.2 text-[9px] font-bold bg-blue-600 text-blue-100 rounded">
                OFFICIAL
              </span>
            </p>
            <p
              className="status font-medium flex items-center gap-1.5"
              style={{ fontSize: '0.72em', color: '#4ADE80', margin: '2px 0 0' }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Online • Sedia Membantu 24 Jam</span>
            </p>
          </div>

          {/* Header Icons */}
          <div className="header-icons" style={{ display: 'flex', alignItems: 'center' }}>
            {/* Video Call */}
            <button
              onClick={() =>
                alert('Panggilan Video TopupBalz diaktifkan semasa sesi bantuan teknikal eksklusif.')
              }
              className="header-icon p-1.5 hover:bg-blue-800/60 rounded-full transition-colors"
              style={{
                color: 'white',
                fontSize: '18px',
                cursor: 'pointer',
                marginLeft: '10px',
                background: 'none',
                border: 'none',
              }}
              title="Panggilan Video"
            >
              <Video className="w-5 h-5 text-blue-200 hover:text-white" />
            </button>

            {/* Voice Phone Call */}
            <a
              href={`https://wa.me/${(settings?.ownerWhatsApp || '601120926330').replace(/\D/g, '')}`}
              target="_blank"
              rel="noreferrer"
              className="header-icon p-1.5 hover:bg-blue-800/60 rounded-full transition-colors flex items-center"
              style={{
                color: 'white',
                fontSize: '18px',
                cursor: 'pointer',
                marginLeft: '8px',
                textDecoration: 'none',
              }}
              title="Panggilan / WhatsApp Admin"
            >
              <Phone className="w-4.5 h-4.5 text-blue-200 hover:text-white" />
            </a>

            {/* Dropdown 3-Dots */}
            <button
              onClick={() => setShowDropdown(!showDropdown)}
              className="header-icon dropdown-trigger p-1.5 hover:bg-blue-800/60 rounded-full transition-colors"
              style={{
                color: 'white',
                fontSize: '18px',
                cursor: 'pointer',
                marginLeft: '8px',
                background: 'none',
                border: 'none',
              }}
              title="Pilihan Tambahan"
            >
              <MoreVertical className="w-5 h-5 text-blue-200 hover:text-white" />
            </button>
          </div>

          {/* ============================================================ */}
          {/* DROPDOWN MENU (Following style.css / index.html) */}
          {/* ============================================================ */}
          {showDropdown && (
            <div
              ref={dropdownRef}
              id="dropdownMenu"
              className="dropdown-menu active"
              style={{
                display: 'block',
                position: 'absolute',
                top: '52px',
                right: '10px',
                backgroundColor: '#1E293B', // Deep Blue-Gray
                boxShadow: '0 8px 24px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(59, 130, 246, 0.3)',
                zIndex: 50,
                borderRadius: '8px',
                overflow: 'hidden',
                minWidth: '200px',
              }}
            >
              <button
                onClick={() => {
                  setShowDropdown(false);
                  setShowContactModal(true);
                }}
                className="w-full text-left px-4 py-2.5 text-xs text-blue-100 hover:bg-blue-700/50 hover:text-white flex items-center gap-2 border-b border-slate-700/60 transition-colors"
              >
                <User className="w-3.5 h-3.5 text-blue-400" />
                <span>Lihat Kontak</span>
              </button>

              <button
                onClick={() => {
                  setShowDropdown(false);
                  setIsSearching(!isSearching);
                }}
                className="w-full text-left px-4 py-2.5 text-xs text-blue-100 hover:bg-blue-700/50 hover:text-white flex items-center gap-2 border-b border-slate-700/60 transition-colors"
              >
                <Search className="w-3.5 h-3.5 text-blue-400" />
                <span>Cari Mesej</span>
              </button>

              <button
                onClick={() => {
                  setShowDropdown(false);
                  fileInputRef.current?.click();
                }}
                className="w-full text-left px-4 py-2.5 text-xs text-blue-100 hover:bg-blue-700/50 hover:text-white flex items-center gap-2 border-b border-slate-700/60 transition-colors"
              >
                <FileText className="w-3.5 h-3.5 text-blue-400" />
                <span>Media, tautan, dan dok</span>
              </button>

              <button
                onClick={() => {
                  setShowDropdown(false);
                  alert('Notifikasi chat ini telah dibisukan.');
                }}
                className="w-full text-left px-4 py-2.5 text-xs text-blue-100 hover:bg-blue-700/50 hover:text-white flex items-center gap-2 border-b border-slate-700/60 transition-colors"
              >
                <BellOff className="w-3.5 h-3.5 text-blue-400" />
                <span>Bisukan notifikasi</span>
              </button>

              <button
                onClick={() => {
                  setShowDropdown(false);
                  setShowEncryptionModal(true);
                }}
                className="w-full text-left px-4 py-2.5 text-xs text-blue-100 hover:bg-blue-700/50 hover:text-white flex items-center gap-2 border-b border-slate-700/60 transition-colors"
              >
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                <span>Pesan Sementara</span>
              </button>

              <button
                onClick={() => {
                  setShowDropdown(false);
                  setWallpaperTheme((prev) =>
                    prev === 'blue-doodle' ? 'navy-solid' : prev === 'navy-solid' ? 'midnight' : 'blue-doodle'
                  );
                }}
                className="w-full text-left px-4 py-2.5 text-xs text-blue-100 hover:bg-blue-700/50 hover:text-white flex items-center gap-2 border-b border-slate-700/60 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                <span>Wallpaper (Tukar Tema)</span>
              </button>

              <button
                onClick={handleClearChat}
                className="w-full text-left px-4 py-2.5 text-xs text-red-300 hover:bg-red-950/60 hover:text-red-200 flex items-center gap-2 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
                <span>Kosongkan Chat</span>
              </button>
            </div>
          )}
        </div>

        {/* Search Bar if Active */}
        {isSearching && (
          <div className="bg-[#111C38] px-3 py-2 border-b border-blue-900/60 flex items-center gap-2">
            <Search className="w-4 h-4 text-blue-400 shrink-0" />
            <input
              type="text"
              placeholder="Cari dalam chat..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-xs text-white placeholder-blue-300/50 focus:outline-none flex-1"
              autoFocus
            />
            <button
              onClick={() => {
                setIsSearching(false);
                setSearchQuery('');
              }}
              className="text-blue-300 hover:text-white p-1 text-xs"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Quick Suggestion Chips */}
        <div className="bg-[#0D1527] px-3 py-1.5 border-b border-blue-950 flex items-center gap-2 overflow-x-auto text-[11px] shrink-0 no-scrollbar">
          <span className="text-[10px] text-blue-400 font-bold shrink-0">Pantaskan:</span>
          <button
            onClick={() => handleSendMessage(undefined, 'Hai Admin Mimin, boleh tolong semak status pesanan topup saya?')}
            className="px-2.5 py-0.5 rounded-full bg-blue-900/50 hover:bg-blue-800 text-blue-200 border border-blue-700/50 whitespace-nowrap text-[10px] transition-colors"
          >
            🔍 Semak Pesanan
          </button>
          <button
            onClick={() => handleSendMessage(undefined, 'Admin, game apa yang paling jimat dan ada promosi kilat hari ini?')}
            className="px-2.5 py-0.5 rounded-full bg-blue-900/50 hover:bg-blue-800 text-blue-200 border border-blue-700/50 whitespace-nowrap text-[10px] transition-colors"
          >
            🔥 Promo Terkini
          </button>
          <button
            onClick={() => handleSendMessage(undefined, 'Saya perlukan bantuan mengenai cara pembayaran manual & resit.')}
            className="px-2.5 py-0.5 rounded-full bg-blue-900/50 hover:bg-blue-800 text-blue-200 border border-blue-700/50 whitespace-nowrap text-[10px] transition-colors"
          >
            💳 Resit / Bayaran
          </button>
        </div>

        {/* ============================================================ */}
        {/* CHAT CONTAINER (With Blue / WhatsApp-style Wallpaper) */}
        {/* ============================================================ */}
        <div
          className={`chat-container flex-1 overflow-y-auto p-3 flex flex-col relative transition-all ${
            wallpaperTheme === 'blue-doodle'
              ? 'bg-[#0B1120] bg-[radial-gradient(#1E3A8A_1.2px,transparent_1.2px)] [background-size:20px_20px]'
              : wallpaperTheme === 'navy-solid'
              ? 'bg-[#070D1E]'
              : 'bg-[#030712]'
          }`}
          style={{
            flexGrow: 1,
            overflowY: 'auto',
            padding: '12px 10px',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          {/* Encryption Notice Banner */}
          <div
            className="encryption-message cursor-pointer"
            onClick={() => setShowEncryptionModal(true)}
            style={{
              backgroundColor: '#1E293B',
              color: '#94A3B8',
              borderRadius: '10px',
              padding: '8px 12px',
              marginBottom: '12px',
              fontSize: '0.72em',
              display: 'flex',
              alignItems: 'center',
              textAlign: 'center',
              lineHeight: 1.4,
              border: '1px solid rgba(59, 130, 246, 0.25)',
              boxShadow: '0 2px 6px rgba(0,0,0,0.2)',
            }}
          >
            <Lock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span style={{ marginLeft: '8px' }}>
              🔒 Pesan dan panggilan dienkripsi secara end-to-end. Tidak seorang pun di luar chat ini, termasuk WhatsApp atau pihak ketiga, yang dapat membaca atau mendengarkannya. Ketuk untuk info selengkapnya.
            </span>
          </div>

          {/* Timestamp Divider */}
          <div
            className="timestamp"
            style={{
              textAlign: 'center',
              color: '#60A5FA',
              fontSize: '0.72em',
              margin: '8px 0 14px',
              fontWeight: 600,
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
            }}
          >
            <span className="px-3 py-1 bg-[#1E293B]/80 rounded-full border border-blue-900/50 shadow-sm">
              Hari ini
            </span>
          </div>

          {/* Messages Loop */}
          {filteredMessages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`message ${isUser ? 'sent' : 'received'} group`}
                style={{
                  margin: '6px 0',
                  maxWidth: '78%',
                  padding: '8px 12px',
                  borderRadius: '10px',
                  display: 'inline-block',
                  position: 'relative',
                  wordWrap: 'break-word',
                  alignSelf: isUser ? 'flex-end' : 'flex-start',
                  backgroundColor: isUser ? '#1D4ED8' : '#1E293B', // User: Vibrant Blue (#1D4ED8), Received: Deep Navy-Slate (#1E293B)
                  color: '#FFFFFF',
                  borderTopRightRadius: isUser ? '0' : '10px',
                  borderTopLeftRadius: isUser ? '10px' : '0',
                  border: isUser ? '1px solid #2563EB' : '1px solid #334155',
                  boxShadow: '0 2px 6px rgba(0, 0, 0, 0.25)',
                }}
              >
                {!isUser && (
                  <div className="text-[10px] font-bold text-blue-300 mb-0.5 flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5 text-blue-400" />
                    <span>{msg.senderName || 'Mimin TopupBalz'}</span>
                  </div>
                )}

                <p className="text-xs leading-relaxed whitespace-pre-wrap select-text">{msg.message}</p>

                <div
                  className="time"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'flex-end',
                    gap: '4px',
                    fontSize: '0.68em',
                    color: isUser ? '#BFDBFE' : '#94A3B8',
                    marginTop: '4px',
                    marginLeft: '8px',
                  }}
                >
                  <span>{msg.timestamp || '22:21'}</span>
                  {isUser && <CheckCheck className="w-3 h-3 text-cyan-300 inline" />}
                </div>
              </div>
            );
          })}

          <div ref={messagesEndRef} />
        </div>

        {/* ============================================================ */}
        {/* ATTACHMENT MENU (Following DzarelDeveloper / CHATCLONE Style) */}
        {/* ============================================================ */}
        {showAttachMenu && (
          <div
            ref={attachMenuRef}
            id="attachMenu"
            className="attach-menu animate-fadeIn"
            style={{
              display: 'block',
              position: 'absolute',
              bottom: '68px',
              left: '12px',
              right: '12px',
              backgroundColor: '#1E293B', // Deep Blue-Gray
              padding: '16px 12px 12px',
              borderRadius: '16px',
              boxShadow: '0 10px 30px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(59, 130, 246, 0.4)',
              zIndex: 40,
            }}
          >
            {/* Row 1: Galeri, Kamera, Lokasi */}
            <div
              className="attach-row"
              style={{
                display: 'flex',
                justifyContent: 'space-around',
                marginBottom: '16px',
              }}
            >
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="attach-item group hover:scale-105 transition-transform"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  color: '#fff',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                }}
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-white shadow-md mb-1.5 group-hover:shadow-purple-500/50">
                  <ImageIcon className="w-6 h-6" />
                </div>
                <span style={{ fontSize: '11px', color: '#E2E8F0', fontWeight: 500 }}>Galeri</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="attach-item group hover:scale-105 transition-transform"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  color: '#fff',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                }}
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-pink-600 to-rose-500 flex items-center justify-center text-white shadow-md mb-1.5 group-hover:shadow-pink-500/50">
                  <Camera className="w-6 h-6" />
                </div>
                <span style={{ fontSize: '11px', color: '#E2E8F0', fontWeight: 500 }}>Kamera</span>
              </button>

              <button
                type="button"
                onClick={() => handleSendMessage(undefined, '📍 [Lokasi]: Malaysia / Pelayan Serantau Asia Tenggara (MY/SG)')}
                className="attach-item group hover:scale-105 transition-transform"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  color: '#fff',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                }}
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md mb-1.5 group-hover:shadow-emerald-500/50">
                  <MapPin className="w-6 h-6" />
                </div>
                <span style={{ fontSize: '11px', color: '#E2E8F0', fontWeight: 500 }}>Lokasi</span>
              </button>
            </div>

            {/* Row 2: Kontak, Dokumen, Audio, Polling */}
            <div
              className="attach-row"
              style={{
                display: 'flex',
                justifyContent: 'space-around',
                marginBottom: '4px',
              }}
            >
              <button
                type="button"
                onClick={() => {
                  setShowContactModal(true);
                  setShowAttachMenu(false);
                }}
                className="attach-item group hover:scale-105 transition-transform"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  color: '#fff',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                }}
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center text-white shadow-md mb-1.5 group-hover:shadow-blue-500/50">
                  <User className="w-6 h-6" />
                </div>
                <span style={{ fontSize: '11px', color: '#E2E8F0', fontWeight: 500 }}>Kontak</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="attach-item group hover:scale-105 transition-transform"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  color: '#fff',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                }}
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-md mb-1.5 group-hover:shadow-indigo-500/50">
                  <FileText className="w-6 h-6" />
                </div>
                <span style={{ fontSize: '11px', color: '#E2E8F0', fontWeight: 500 }}>Dokumen</span>
              </button>

              <button
                type="button"
                onClick={handleMicClick}
                className="attach-item group hover:scale-105 transition-transform"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  color: '#fff',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                }}
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-600 to-orange-500 flex items-center justify-center text-white shadow-md mb-1.5 group-hover:shadow-amber-500/50">
                  <Headphones className="w-6 h-6" />
                </div>
                <span style={{ fontSize: '11px', color: '#E2E8F0', fontWeight: 500 }}>Audio</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleSendMessage(
                    undefined,
                    '📊 [Polling]: Bagaimana kualiti perkhidmatan TopupBalz? (1: Sangat Pantas, 2: Jimat & Terbaik, 3: Perlu Diperbaiki)'
                  )
                }
                className="attach-item group hover:scale-105 transition-transform"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  color: '#fff',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                }}
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-teal-600 to-cyan-600 flex items-center justify-center text-white shadow-md mb-1.5 group-hover:shadow-teal-500/50">
                  <BarChart2 className="w-6 h-6" />
                </div>
                <span style={{ fontSize: '11px', color: '#E2E8F0', fontWeight: 500 }}>Polling</span>
              </button>
            </div>
          </div>
        )}

        {/* Quick Emoji Picker Popover */}
        {showEmojiPicker && (
          <div className="bg-[#1E293B] border-t border-blue-900/60 p-2.5 flex items-center justify-between gap-1 overflow-x-auto text-lg shrink-0">
            {['👋', '🎮', '💎', '🔥', '👍', '💳', '⭐', '⚡', '❤️', '🙏', '😊', '✅'].map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => {
                  setInputText((prev) => prev + emoji);
                  setShowEmojiPicker(false);
                }}
                className="p-1.5 hover:bg-blue-800/60 rounded-lg hover:scale-125 transition-transform text-base"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}

        {/* ============================================================ */}
        {/* FOOTER (Following DzarelDeveloper / CHATCLONE in BLUE) */}
        {/* ============================================================ */}
        <form
          onSubmit={handleSendMessage}
          className="footer"
          style={{
            backgroundColor: '#172554', // Deep Blue matching header
            padding: '8px 10px',
            display: 'flex',
            alignItems: 'center',
            borderTop: '1px solid #1E3A8A',
            position: 'relative',
          }}
        >
          {/* Smile Emoji Icon */}
          <button
            type="button"
            onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            className="icon p-1 hover:bg-blue-800/60 rounded-full transition-colors cursor-pointer"
            style={{
              color: '#93C5FD',
              fontSize: '18px',
              margin: '0 4px',
              background: 'none',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
            }}
            title="Pilih Emoji"
          >
            <Smile className="w-5 h-5 text-blue-200 hover:text-white" />
          </button>

          {/* Text Input */}
          <div className="flex-1 relative flex items-center">
            <input
              type="text"
              placeholder={isRecording ? `Sedang merakam suara (${recordingSeconds}s)...` : 'Ketik pesan'}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              disabled={isRecording}
              style={{
                width: '100%',
                flexGrow: 1,
                padding: '9px 38px 9px 14px',
                borderRadius: '20px',
                border: 'none',
                backgroundColor: '#0F172A', // Dark Slate Blue Input Box
                color: '#fff',
                fontSize: '0.88em',
                outline: 'none',
                boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.5)',
              }}
            />

            {/* Paperclip Icon inside input bar */}
            <button
              type="button"
              onClick={() => {
                setShowAttachMenu(!showAttachMenu);
                setShowEmojiPicker(false);
              }}
              className="attach-trigger absolute right-2.5 p-1 hover:bg-blue-800/60 rounded-full transition-colors cursor-pointer"
              style={{
                color: '#93C5FD',
                background: 'none',
                border: 'none',
                display: 'flex',
                alignItems: 'center',
              }}
              title="Lampirkan Fail"
            >
              <Paperclip
                className={`w-4 h-4 transition-transform ${showAttachMenu ? 'rotate-45 text-white' : 'text-blue-200'}`}
              />
            </button>
          </div>

          {/* Action Button: Microphone or Send (VIBRANT BLUE #2563EB) */}
          <button
            type={inputText.trim() ? 'submit' : 'button'}
            onClick={!inputText.trim() ? handleMicClick : undefined}
            disabled={sending}
            aria-label={inputText.trim() ? 'Hantar Mesej' : 'Rakam Suara'}
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              backgroundColor: isRecording ? '#DC2626' : '#2563EB', // Blue Button (#2563EB) or Red if recording
              color: '#fff',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 0,
              marginLeft: '8px',
              border: 'none',
              boxShadow: '0 2px 8px rgba(37, 99, 235, 0.4)',
              transition: 'all 0.2s ease',
              flexShrink: 0,
            }}
          >
            {inputText.trim() ? (
              <Send className="w-4.5 h-4.5 text-white transform -rotate-12 translate-x-0.5" />
            ) : (
              <Mic className={`w-4.5 h-4.5 text-white ${isRecording ? 'animate-bounce' : ''}`} />
            )}
          </button>
        </form>

        {/* ============================================================ */}
        {/* MODAL: LIHAT KONTAK / ADMIN INFO */}
        {/* ============================================================ */}
        {showContactModal && (
          <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
            <div className="w-full max-w-xs bg-[#1E293B] rounded-2xl border border-blue-600/50 p-5 text-center shadow-2xl">
              <div
                className="w-20 h-20 rounded-full mx-auto mb-3 border-2 border-blue-400"
                style={{
                  backgroundImage: `url('https://raw.githubusercontent.com/DzarelDeveloper/CHATCLONE-V1/main/Profile.jpg')`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                }}
              />
              <h4 className="font-bold text-base text-white">Mimin TopupBalz</h4>
              <p className="text-xs text-emerald-400 font-medium mt-0.5">Online • Customer Care Specialist</p>

              <div className="mt-4 p-3 rounded-xl bg-blue-950/60 border border-blue-800/40 text-left text-xs space-y-2">
                <div className="flex justify-between">
                  <span className="text-blue-300">WhatsApp:</span>
                  <span className="font-mono text-white font-bold">{settings?.ownerWhatsApp || '+60 11-2092 6330'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-300">Status:</span>
                  <span className="text-emerald-400 font-bold">Terverifikasi</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-300">Waktu Operasi:</span>
                  <span className="text-white">24 Jam Setiap Hari</span>
                </div>
              </div>

              <div className="mt-5 flex gap-2">
                <a
                  href={`https://wa.me/${(settings?.ownerWhatsApp || '601120926330').replace(/\D/g, '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
                <button
                  onClick={() => setShowContactModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs transition-colors"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* MODAL: INFO ENKRIPSI END-TO-END */}
        {/* ============================================================ */}
        {showEncryptionModal && (
          <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
            <div className="w-full max-w-xs bg-[#1E293B] rounded-2xl border border-blue-600/50 p-5 text-center shadow-2xl">
              <div className="w-12 h-12 rounded-full bg-blue-600/30 border border-blue-400 flex items-center justify-center mx-auto mb-3 text-amber-300">
                <Lock className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-base text-white">Enkripsi End-to-End</h4>
              <p className="text-xs text-blue-200 mt-2 leading-relaxed">
                Setiap mesej dan perbualan antara anda dan pegawai rasmi TopupBalz diproses secara selamat. Maklumat pesanan, ID akaun game, serta bukti bayaran anda dirahsiakan sepenuhnya.
              </p>
              <button
                onClick={() => setShowEncryptionModal(false)}
                className="mt-4 w-full py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors"
              >
                Faham
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
