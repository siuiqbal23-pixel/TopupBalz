import React, { useState } from 'react';
import { X, Calculator, Delete, RotateCcw } from 'lucide-react';

interface RealCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme?: 'dark' | 'light';
}

export const RealCalculatorModal: React.FC<RealCalculatorModalProps> = ({
  isOpen,
  onClose,
  theme = 'dark',
}) => {
  const [displayValue, setDisplayValue] = useState<string>('0');
  const [equation, setEquation] = useState<string>('');
  const [isNewInput, setIsNewInput] = useState<boolean>(true);

  if (!isOpen) return null;
  const isLight = theme === 'light';

  // Handle digit press (0-9)
  const handleDigit = (digit: string) => {
    if (displayValue === '0' || isNewInput) {
      setDisplayValue(digit);
      setIsNewInput(false);
    } else {
      if (displayValue.replace(/,/g, '').length < 12) {
        setDisplayValue(displayValue + digit);
      }
    }
  };

  // Handle decimal point
  const handleDecimal = () => {
    if (isNewInput) {
      setDisplayValue('0.');
      setIsNewInput(false);
    } else if (!displayValue.includes('.')) {
      setDisplayValue(displayValue + '.');
    }
  };

  // Handle operator (+, -, ×, ÷)
  const handleOperator = (op: string) => {
    const currentNum = parseFloat(displayValue);
    if (isNaN(currentNum)) return;

    if (equation && !isNewInput) {
      const evaluated = evaluateEquation(`${equation} ${displayValue}`);
      setEquation(`${evaluated} ${op}`);
      setDisplayValue(String(evaluated));
    } else {
      setEquation(`${displayValue} ${op}`);
    }
    setIsNewInput(true);
  };

  // Handle Percentage
  const handlePercentage = () => {
    const currentNum = parseFloat(displayValue);
    if (isNaN(currentNum)) return;
    const res = currentNum / 100;
    setDisplayValue(String(res));
    setIsNewInput(true);
  };

  // Handle Toggle Sign (+/-)
  const handleToggleSign = () => {
    const currentNum = parseFloat(displayValue);
    if (isNaN(currentNum)) return;
    setDisplayValue(String(currentNum * -1));
  };

  // Handle Clear (C / AC)
  const handleClear = () => {
    setDisplayValue('0');
    setEquation('');
    setIsNewInput(true);
  };

  // Handle Backspace (Del)
  const handleDelete = () => {
    if (isNewInput) return;
    if (displayValue.length > 1) {
      setDisplayValue(displayValue.slice(0, -1));
    } else {
      setDisplayValue('0');
      setIsNewInput(true);
    }
  };

  // Mathematical evaluation function
  const evaluateEquation = (expr: string): number => {
    try {
      const sanitized = expr
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/[^0-9+\-*/.]/g, '');

      const tokens = sanitized.match(/(\d+\.?\d*|[+\-*/])/g);
      if (!tokens) return 0;

      let result = parseFloat(tokens[0]);
      let currentOp = '';

      for (let i = 1; i < tokens.length; i++) {
        const token = tokens[i];
        if (['+', '-', '*', '/'].includes(token)) {
          currentOp = token;
        } else {
          const nextNum = parseFloat(token);
          if (currentOp === '+') result += nextNum;
          else if (currentOp === '-') result -= nextNum;
          else if (currentOp === '*') result *= nextNum;
          else if (currentOp === '/') {
            if (nextNum === 0) return 0;
            result /= nextNum;
          }
        }
      }
      return Math.round(result * 100000000) / 100000000;
    } catch {
      return 0;
    }
  };

  // Handle Equals (=)
  const handleEquals = () => {
    if (!equation) return;
    const fullExpr = `${equation} ${displayValue}`;
    const result = evaluateEquation(fullExpr);

    setEquation(`${fullExpr} =`);
    setDisplayValue(String(result));
    setIsNewInput(true);
  };

  const formatDisplay = (val: string) => {
    if (val === 'Error') return 'Error';
    if (val.endsWith('.')) return val;
    const parts = val.split('.');
    const integerPart = parts[0];
    const decimalPart = parts.length > 1 ? '.' + parts[1] : '';

    if (!isNaN(Number(integerPart))) {
      return Number(integerPart).toLocaleString('en-US') + decimalPart;
    }
    return val;
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-md animate-fadeIn ${
      isLight ? 'bg-slate-900/50' : 'bg-[#030611]/85'
    }`}>
      <div className={`relative w-full max-w-xs sm:max-w-sm rounded-3xl border shadow-2xl overflow-hidden flex flex-col transition-colors ${
        isLight
          ? 'bg-white border-slate-200 text-slate-900 shadow-2xl'
          : 'bg-[#0a0f24] border-blue-500/30 text-white shadow-[0_0_50px_rgba(37,99,235,0.3)]'
      }`}>
        
        {/* Modal Header */}
        <div className={`flex items-center justify-between px-5 py-3.5 border-b transition-colors ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#060a1d] border-blue-900/50'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl border ${
              isLight
                ? 'bg-orange-100 border-orange-200 text-orange-600'
                : 'bg-blue-600/20 border-blue-500/30 text-blue-400'
            }`}>
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className={`text-sm font-black tracking-wide uppercase ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}>
                Kalkulator
              </h3>
              <p className={`text-[10px] font-medium ${
                isLight ? 'text-slate-500' : 'text-blue-300/70'
              }`}>
                Standard Tool
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Tutup Kalkulator"
            className={`p-2 rounded-full transition-all cursor-pointer border ${
              isLight
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-200'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border-slate-800'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Digital Screen */}
        <div className={`p-5 border-b text-right space-y-1 transition-colors ${
          isLight
            ? 'bg-slate-100 border-slate-200 text-slate-900'
            : 'bg-gradient-to-b from-[#050814] to-[#0d1433] border-blue-900/40 text-white'
        }`}>
          <div className={`h-6 text-xs font-mono overflow-x-auto whitespace-nowrap tracking-wider ${
            isLight ? 'text-slate-500' : 'text-blue-400/80'
          }`}>
            {equation || '\u00A0'}
          </div>
          <div className={`text-3xl sm:text-4xl font-mono font-black tracking-tight truncate ${
            isLight ? 'text-slate-900' : 'text-white'
          }`}>
            {formatDisplay(displayValue)}
          </div>
        </div>

        {/* Keypad Grid */}
        <div className={`p-4 grid grid-cols-4 gap-2 sm:gap-2.5 transition-colors ${
          isLight ? 'bg-white' : 'bg-[#080d21]'
        }`}>
          {/* Row 1 */}
          <button
            onClick={handleClear}
            className={`py-3.5 rounded-2xl font-black text-sm transition-all cursor-pointer ${
              isLight
                ? 'bg-red-50 hover:bg-red-100 text-red-600 border border-red-200'
                : 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30'
            }`}
          >
            AC
          </button>
          <button
            onClick={handleDelete}
            className={`py-3.5 rounded-2xl font-black text-sm transition-all cursor-pointer flex items-center justify-center ${
              isLight
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300 border border-slate-700'
            }`}
          >
            <Delete className="w-4 h-4" />
          </button>
          <button
            onClick={handlePercentage}
            className={`py-3.5 rounded-2xl font-black text-sm transition-all cursor-pointer ${
              isLight
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300 border border-slate-700'
            }`}
          >
            %
          </button>
          <button
            onClick={() => handleOperator('÷')}
            className={`py-3.5 rounded-2xl font-black text-base transition-all cursor-pointer ${
              isLight
                ? 'bg-orange-100 hover:bg-orange-200 text-orange-700 border border-orange-200'
                : 'bg-blue-600/30 hover:bg-blue-600/40 text-blue-400 border border-blue-500/40'
            }`}
          >
            ÷
          </button>

          {/* Row 2 */}
          {['7', '8', '9'].map((d) => (
            <button
              key={d}
              onClick={() => handleDigit(d)}
              className={`py-3.5 rounded-2xl font-bold text-base transition-all cursor-pointer ${
                isLight
                  ? 'bg-slate-50 hover:bg-slate-100 text-slate-800 border border-slate-200 shadow-sm'
                  : 'bg-[#111833] hover:bg-[#182247] text-white border border-slate-800/80 shadow-md'
              }`}
            >
              {d}
            </button>
          ))}
          <button
            onClick={() => handleOperator('×')}
            className={`py-3.5 rounded-2xl font-black text-base transition-all cursor-pointer ${
              isLight
                ? 'bg-orange-100 hover:bg-orange-200 text-orange-700 border border-orange-200'
                : 'bg-blue-600/30 hover:bg-blue-600/40 text-blue-400 border border-blue-500/40'
            }`}
          >
            ×
          </button>

          {/* Row 3 */}
          {['4', '5', '6'].map((d) => (
            <button
              key={d}
              onClick={() => handleDigit(d)}
              className={`py-3.5 rounded-2xl font-bold text-base transition-all cursor-pointer ${
                isLight
                  ? 'bg-slate-50 hover:bg-slate-100 text-slate-800 border border-slate-200 shadow-sm'
                  : 'bg-[#111833] hover:bg-[#182247] text-white border border-slate-800/80 shadow-md'
              }`}
            >
              {d}
            </button>
          ))}
          <button
            onClick={() => handleOperator('-')}
            className={`py-3.5 rounded-2xl font-black text-base transition-all cursor-pointer ${
              isLight
                ? 'bg-orange-100 hover:bg-orange-200 text-orange-700 border border-orange-200'
                : 'bg-blue-600/30 hover:bg-blue-600/40 text-blue-400 border border-blue-500/40'
            }`}
          >
            -
          </button>

          {/* Row 4 */}
          {['1', '2', '3'].map((d) => (
            <button
              key={d}
              onClick={() => handleDigit(d)}
              className={`py-3.5 rounded-2xl font-bold text-base transition-all cursor-pointer ${
                isLight
                  ? 'bg-slate-50 hover:bg-slate-100 text-slate-800 border border-slate-200 shadow-sm'
                  : 'bg-[#111833] hover:bg-[#182247] text-white border border-slate-800/80 shadow-md'
              }`}
            >
              {d}
            </button>
          ))}
          <button
            onClick={() => handleOperator('+')}
            className={`py-3.5 rounded-2xl font-black text-base transition-all cursor-pointer ${
              isLight
                ? 'bg-orange-100 hover:bg-orange-200 text-orange-700 border border-orange-200'
                : 'bg-blue-600/30 hover:bg-blue-600/40 text-blue-400 border border-blue-500/40'
            }`}
          >
            +
          </button>

          {/* Row 5 */}
          <button
            onClick={handleToggleSign}
            className={`py-3.5 rounded-2xl font-bold text-sm transition-all cursor-pointer ${
              isLight
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300 border border-slate-700'
            }`}
          >
            +/-
          </button>
          <button
            onClick={() => handleDigit('0')}
            className={`py-3.5 rounded-2xl font-bold text-base transition-all cursor-pointer ${
              isLight
                ? 'bg-slate-50 hover:bg-slate-100 text-slate-800 border border-slate-200 shadow-sm'
                : 'bg-[#111833] hover:bg-[#182247] text-white border border-slate-800/80 shadow-md'
            }`}
          >
            0
          </button>
          <button
            onClick={handleDecimal}
            className={`py-3.5 rounded-2xl font-bold text-base transition-all cursor-pointer ${
              isLight
                ? 'bg-slate-50 hover:bg-slate-100 text-slate-800 border border-slate-200 shadow-sm'
                : 'bg-[#111833] hover:bg-[#182247] text-white border border-slate-800/80 shadow-md'
            }`}
          >
            .
          </button>
          <button
            onClick={handleEquals}
            className="py-3.5 rounded-2xl font-black text-base bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-slate-950 shadow-md transition-all cursor-pointer"
          >
            =
          </button>
        </div>

      </div>
    </div>
  );
};
