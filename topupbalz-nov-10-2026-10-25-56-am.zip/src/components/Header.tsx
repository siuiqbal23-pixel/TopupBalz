import React, { useState } from 'react';
import { 
  X, 
  ShoppingBag, 
  Mail, 
  ShoppingCart, 
  Headphones, 
  MoreVertical, 
  ChevronRight,
  CheckCircle2,
  Sun,
  Moon,
  Bot,
  Sparkles
} from 'lucide-react';
import { Game, GameCategory } from '../types';
import { AnimatedBrandLogo } from './BrandLogo';

interface HeaderProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  activeCategory: GameCategory;
  setActiveCategory: (cat: GameCategory) => void;
  onOpenOrderTracker: () => void;
  onOpenAdmin: () => void;
  onSelectGameClick: () => void;
  onOpenGmail?: () => void;
  onlineCount?: number;
  cartCount?: number;
  onOpenCart?: () => void;
  onOpenLiveChat?: () => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
  games?: Game[];
}

export const Header: React.FC<HeaderProps> = ({
  searchQuery,
  setSearchQuery,
  activeCategory,
  setActiveCategory,
  onOpenOrderTracker,
  onOpenAdmin,
  onSelectGameClick,
  onOpenGmail,
  onlineCount = 1,
  cartCount = 0,
  onOpenCart,
  onOpenLiveChat,
  theme = 'dark',
  onToggleTheme,
  games = [],
}) => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const isLight = theme === 'light';

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 w-full backdrop-blur-xl transition-all duration-300 ${
          isLight
            ? 'bg-white/95 border-b border-orange-200 shadow-[0_2px_15px_rgba(255,140,0,0.08)]'
            : 'bg-[#090B10]/95 border-b border-orange-500/20 shadow-[0_4px_25px_rgba(0,0,0,0.85)]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20 gap-2 sm:gap-3 py-1.5">
            
            {/* Logo TopupBalz with Dynamic Orbiting Game Badges & Real Logos */}
            <div 
              onClick={() => {
                setActiveCategory('all');
                setSearchQuery('');
              }}
              className="flex items-center cursor-pointer group min-w-0 select-none py-1"
            >
              {/* Custom Esports Logo Banner with Live Game Badges */}
              <AnimatedBrandLogo size="lg" theme={theme} showText={false} games={games} />
            </div>

            {/* Right: Theme Toggle (Dark / Bright) + Three Dots (Menu) */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              
              {/* Ai Topupbalz Direct Header Button */}
              {onOpenLiveChat && (
                <button
                  onClick={onOpenLiveChat}
                  className={`relative p-1.5 sm:px-2.5 sm:py-2 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer border select-none ${
                    isLight
                      ? 'bg-orange-50 hover:bg-orange-100 text-orange-700 border-orange-200 shadow-sm'
                      : 'bg-orange-950/60 hover:bg-orange-900/80 text-amber-300 border-orange-500/40 shadow-sm'
                  }`}
                  title="Ai Topupbalz - Tanya apa sahaja tentang web TopupBalz"
                  aria-label="Ai Topupbalz"
                >
                  <Bot className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-orange-500 animate-pulse" />
                  <span className="hidden xs:inline text-[10px] sm:text-xs font-black font-mono tracking-wider">
                    AI CHAT
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                </button>
              )}

              {/* Dark / Bright Single Toggle Button */}
              {onToggleTheme && (
                <button
                  onClick={onToggleTheme}
                  className={`relative p-1.5 sm:px-2.5 sm:py-2 rounded-xl transition-all duration-300 flex items-center gap-1.5 cursor-pointer border select-none ${
                    isLight
                      ? 'bg-orange-50 text-orange-600 border-orange-200 hover:bg-orange-100 hover:border-orange-300 shadow-sm'
                      : 'bg-[#0D1117] text-amber-300 border-slate-800 hover:border-amber-400/50 hover:bg-slate-900 shadow-sm'
                  }`}
                  title={isLight ? 'Tukar ke Mod Gelap (Dark)' : 'Tukar ke Mod Terang (Bright)'}
                  aria-label="Tukar Tema Dark / Bright"
                >
                  {isLight ? (
                    <Sun className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-orange-500 fill-orange-400 animate-pulse" />
                  ) : (
                    <Moon className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-amber-300 fill-amber-300/30" />
                  )}
                  <span className="hidden xs:inline text-[10px] sm:text-xs font-black font-mono tracking-wider">
                    {isLight ? 'BRIGHT' : 'DARK'}
                  </span>
                </button>
              )}

              {/* Three Dots (Titik Tiga) Button */}
              <button
                onClick={() => setDrawerOpen(true)}
                className={`relative p-1.5 sm:px-3 sm:py-2 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer border ${
                  drawerOpen
                    ? 'bg-orange-500 text-slate-950 border-orange-400 shadow-[0_0_15px_rgba(255,140,0,0.8)] font-black'
                    : isLight
                    ? 'bg-slate-100 text-slate-800 hover:text-slate-950 border-slate-200 hover:border-orange-400 hover:bg-orange-50 shadow-sm'
                    : 'bg-[#0D1117] text-slate-200 hover:text-white border-slate-800 hover:border-orange-500/50 hover:bg-slate-900 shadow-sm'
                }`}
                title="Buka Menu Dari Kiri"
                aria-label="Menu Utama"
              >
                <MoreVertical className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500" />
                <span className="hidden sm:inline text-[11px] sm:text-xs font-black font-mono tracking-wider">MENU</span>

                {/* Cart Badge if items in cart */}
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-4.5 h-4.5 rounded-full bg-orange-500 text-slate-950 font-mono font-black text-[9px] flex items-center justify-center border-2 border-[#090B10] shadow-[0_0_10px_rgba(255,140,0,0.9)] animate-bounce">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Left Slide-Over Sidebar Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          
          {/* Backdrop Blur Overlay */}
          <div 
            onClick={() => setDrawerOpen(false)}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity animate-fadeIn"
          />

          {/* Left Sliding Menu Panel */}
          <div
            className={`relative w-72 sm:w-80 max-w-[85vw] h-full border-r flex flex-col justify-between z-10 animate-slideRight overflow-y-auto transition-colors ${
              isLight
                ? 'bg-white border-orange-200 shadow-[10px_0_40px_rgba(0,0,0,0.15)] text-slate-900'
                : 'bg-[#0D1117] border-orange-500/30 shadow-[10px_0_50px_rgba(0,0,0,0.95)] text-slate-100'
            }`}
          >
            
            {/* Top Section: Header of Drawer */}
            <div className="p-4 sm:p-5 space-y-4">
              
              {/* Drawer Top Row: Logo & Close Button */}
              <div className={`flex items-center justify-between pb-3.5 border-b ${isLight ? 'border-slate-200' : 'border-slate-800'}`}>
                <div className="flex items-center gap-2.5">
                  <AnimatedBrandLogo size="sm" showText={false} games={games} theme={theme} />
                  <div>
                    <span className={`text-base font-black font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      TOPUP<span className="text-orange-500">BALZ</span>
                    </span>
                    <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono font-extrabold tracking-wide">
                        ● SISTEM ONLINE 24/7
                      </span>
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-emerald-500/15 border border-emerald-500/30 rounded-full text-[9px] font-black text-emerald-600 dark:text-emerald-300 font-mono">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        {onlineCount} ONLINE
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setDrawerOpen(false)}
                  className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                    isLight
                      ? 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                      : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                  title="Tutup Menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Vertical Menu Items List */}
              <div className="space-y-2.5 pt-1">
                
                {/* 1. Troli Belian */}
                {onOpenCart && (
                  <button
                    onClick={() => {
                      onOpenCart();
                      setDrawerOpen(false);
                    }}
                    className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between group transition-all cursor-pointer shadow-md ${
                      isLight
                        ? 'bg-orange-50/80 hover:bg-orange-100/80 border-orange-200'
                        : 'bg-gradient-to-r from-orange-500/20 via-amber-500/15 to-slate-900/40 hover:from-orange-500/30 border-orange-500/40'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-500 flex items-center justify-center border border-orange-500/30 group-hover:scale-110 transition-transform">
                        <ShoppingCart className="w-5 h-5" />
                      </div>
                      <div>
                        <div className={`text-xs sm:text-sm font-black font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>Troli Belian</div>
                        <div className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-300'} font-medium`}>Semak item sebelum bayar</div>
                      </div>
                    </div>

                    {cartCount > 0 ? (
                      <span className="px-2.5 py-1 rounded-full bg-orange-500 text-slate-950 font-mono font-black text-xs shadow-md animate-pulse">
                        {cartCount} Item
                      </span>
                    ) : (
                      <span className={`text-[11px] font-mono font-bold ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>0 Item</span>
                    )}
                  </button>
                )}

                {/* 2. Ai Topupbalz Assistant 24/7 */}
                {onOpenLiveChat && (
                  <button
                    onClick={() => {
                      onOpenLiveChat();
                      setDrawerOpen(false);
                    }}
                    className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between group transition-all cursor-pointer shadow-md ${
                      isLight
                        ? 'bg-gradient-to-r from-orange-50 to-amber-50 hover:from-orange-100 border-orange-200'
                        : 'bg-gradient-to-r from-orange-950/50 via-amber-950/40 to-slate-900/60 hover:from-orange-900/70 border-orange-500/40'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center border border-orange-500/40 group-hover:scale-110 transition-transform">
                        <Bot className="w-5 h-5 text-orange-400" />
                      </div>
                      <div>
                        <div className={`text-xs sm:text-sm font-black font-mono flex items-center gap-1.5 ${isLight ? 'text-slate-900' : 'text-white'}`}>
                          <span>Ai Topupbalz</span>
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-orange-500 text-slate-950">AI BOT</span>
                          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                        </div>
                        <div className={`text-[11px] font-medium ${isLight ? 'text-orange-800' : 'text-amber-200'}`}>Tanya soalan tentang web & topup</div>
                      </div>
                    </div>

                    <ChevronRight className="w-5 h-5 text-orange-400 group-hover:translate-x-1 transition-transform" />
                  </button>
                )}

                {/* 3. Semak Status Pesanan (Order Tracker) */}
                <button
                  onClick={() => {
                    onOpenOrderTracker();
                    setDrawerOpen(false);
                  }}
                  className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between group transition-all cursor-pointer shadow-md ${
                    isLight
                      ? 'bg-slate-50 hover:bg-blue-50/70 border-slate-200 hover:border-blue-300'
                      : 'bg-slate-900/90 hover:bg-slate-800/90 border-slate-800 hover:border-blue-500/40'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-500 flex items-center justify-center border border-blue-500/30 group-hover:scale-110 transition-transform">
                      <ShoppingBag className="w-5 h-5" />
                    </div>
                    <div>
                      <div className={`text-xs sm:text-sm font-black font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>Semak Status Pesanan</div>
                      <div className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-slate-300'}`}>Jejak topup dengan Order ID</div>
                    </div>
                  </div>

                  <ChevronRight className="w-5 h-5 text-slate-400 group-hover:translate-x-1 transition-transform" />
                </button>

                {/* 4. Pusat Gmail Notifikasi API */}
                {onOpenGmail && (
                  <button
                    onClick={() => {
                      onOpenGmail();
                      setDrawerOpen(false);
                    }}
                    className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between text-xs font-bold transition-all cursor-pointer shadow-sm ${
                      isLight
                        ? 'bg-red-50 hover:bg-red-100/70 border-red-200 text-red-700'
                        : 'bg-red-500/10 hover:bg-red-500/20 border-red-500/30 text-red-300'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Mail className="w-4 h-4 text-red-500 shrink-0" />
                      <span>Pusat Notifikasi Gmail</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-red-500" />
                  </button>
                )}

              </div>
            </div>

            {/* Bottom Section: Security & System Badge */}
            <div className={`p-4 border-t space-y-2.5 ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#07090D] border-slate-800/90'}`}>
              <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-300 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Bayaran Sah Touch 'n Go eWallet QR</span>
              </div>
              <div className="text-center pt-1">
                <p className={`text-xs font-black font-mono tracking-wide ${isLight ? 'text-slate-900' : 'text-white'}`}>
                  © 2026 TOPUPBALZ (M) SDN. BHD.
                </p>
                <p className={`text-[11px] font-semibold mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Sistem Automatik 24 Jam • Selamat & Pantas
                </p>
              </div>
            </div>

          </div>

        </div>
      )}
    </>
  );
};
