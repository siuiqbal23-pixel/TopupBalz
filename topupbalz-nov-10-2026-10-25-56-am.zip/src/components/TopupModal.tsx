import React, { useState, useEffect } from 'react';
import {
  X,
  Zap,
  ShieldCheck,
  QrCode,
  Upload,
  CheckCircle2,
  HelpCircle,
  MessageCircle,
  Sparkles,
  ArrowLeft,
  ChevronRight,
  Info,
  Copy,
  Check,
  Image as ImageIcon,
  UserCheck,
  Search,
  RefreshCw,
  Printer,
  FileText,
  Server,
  Send,
  Bot,
  LogIn,
  ShoppingCart,
  Shield,
  AlertTriangle,
  Share2,
  ExternalLink,
} from 'lucide-react';
import { Game, GameItem, SystemSettings, CartItem, UserProfile, FlashSaleItem } from '../types';
import { TngQrCodeCard } from './TngQrCodeCard';
import { compressImage } from '../lib/imageCompressor';
import { shareOrderWithReceipt } from '../lib/whatsapp';
import { maskOrderId, maskGameUserId, maskServerId } from '../lib/masking';

interface TopupModalProps {
  game: Game | null;
  settings: SystemSettings;
  currentUser?: UserProfile | null;
  initialItemId?: string;
  flashSaleItems?: FlashSaleItem[];
  onRequestLogin?: () => void;
  onClose: () => void;
  onAddToCart?: (cartItem: Omit<CartItem, 'id'>) => void;
  onSubmitOrder: (orderData: {
    gameId: string;
    gameName: string;
    itemId: string;
    itemName: string;
    basePrice: number;
    sellPrice?: number;
    userId: string;
    serverId?: string;
    customerPhone?: string;
    paymentMethod: string;
    proofImageUrl?: string;
  }) => Promise<{ success: boolean; whatsappUrl?: string; orderId?: string; receiptUrl?: string; proofImageUrl?: string }>;
  theme?: 'dark' | 'light';
}

export const TopupModal: React.FC<TopupModalProps> = ({
  game,
  settings,
  currentUser,
  initialItemId,
  flashSaleItems = [],
  onRequestLogin,
  onClose,
  onAddToCart,
  onSubmitOrder,
  theme = 'dark',
}) => {
  if (!game) return null;
  const isLight = theme === 'light';

  const [selectedItem, setSelectedItem] = useState<GameItem | null>(() => {
    if (initialItemId && game.items) {
      const matched = game.items.find((i) => i.id === initialItemId);
      if (matched) return matched;
    }
    return game.items && game.items.length > 0 ? game.items[0] : null;
  });

  useEffect(() => {
    if (initialItemId && game.items) {
      const matched = game.items.find((i) => i.id === initialItemId);
      if (matched) setSelectedItem(matched);
    }
  }, [initialItemId, game]);

  const [userId, setUserId] = useState('');
  const [serverId, setServerId] = useState(
    game.serverOptions && game.serverOptions.length > 0 ? game.serverOptions[0] : ''
  );
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'tng' | 'fpx' | 'duitnow'>('tng');
  const [proofImage, setProofImage] = useState<string | null>(null);
  const [showIdGuide, setShowIdGuide] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderComplete, setOrderComplete] = useState<{
    whatsappUrl: string;
    orderId: string;
    receiptUrl?: string;
    proofImageUrl?: string;
  } | null>(null);
  const [copiedAccount, setCopiedAccount] = useState(false);
  const [honeypot, setHoneypot] = useState('');
  const [spamError, setSpamError] = useState('');
  const [formError, setFormError] = useState('');
  const [addedToCartToast, setAddedToCartToast] = useState(false);
  const [showMaintenanceModal, setShowMaintenanceModal] = useState(false);

  // Auto-sync customerPhone from currentUser if available
  useEffect(() => {
    if (currentUser?.phoneNumber && !customerPhone) {
      setCustomerPhone(currentUser.phoneNumber);
    }
  }, [currentUser]);

  // Account Verification States
  const [isVerifyingAccount, setIsVerifyingAccount] = useState(false);
  const [verifiedAccount, setVerifiedAccount] = useState<{
    nickname: string;
    region: string;
    status: string;
  } | null>(null);

  const getFlashSaleForItem = (itemId?: string) => {
    if (!itemId) return null;
    return flashSaleItems.find(
      (fs) =>
        (fs.gameId === game.id || fs.gameId === game.slug) &&
        fs.itemId === itemId &&
        fs.isActive &&
        (fs.maxQuota <= 0 || fs.soldCount < fs.maxQuota)
    );
  };

  const currentFlashSale = getFlashSaleForItem(selectedItem?.id);
  const effectivePrice = currentFlashSale ? currentFlashSale.flashPrice : (selectedItem?.sellPrice || 0);

  const handleVerifyAccount = () => {
    if (!userId.trim()) {
      setFormError('Sila masukkan User ID terlebih dahulu sebelum menyemak.');
      return;
    }
    setFormError('');
    setIsVerifyingAccount(true);

    setTimeout(() => {
      setIsVerifyingAccount(false);
      const cleanId = userId.trim();
      const mockNicknames = [
        'BalzProGamer',
        'CyberKnight',
        'ShadowHunter_MY',
        'VortexElite',
        'MythicKing',
        'ApexLegend_99',
        'PhoenixLord',
      ];
      const selectedNick = mockNicknames[Math.abs(cleanId.split('').reduce((a, b) => a + b.charCodeAt(0), 0)) % mockNicknames.length];

      setVerifiedAccount({
        nickname: selectedNick,
        region: 'Malaysia (MY)',
        status: 'Aktif & Sah',
      });
    }, 900);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFormError('Sila pilih fail imej yang sah (JPG, PNG, JPEG).');
      return;
    }

    try {
      const compressed = await compressImage(file);
      setProofImage(compressed);
      setFormError('');
    } catch (err) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProofImage(reader.result as string);
        setFormError('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCopyAccountName = () => {
    navigator.clipboard.writeText(settings.tngAccountName);
    setCopiedAccount(true);
    setTimeout(() => setCopiedAccount(false), 2000);
  };

  const handleAddToCartClick = () => {
    // Check if store is closed/maintenance
    if (settings.isStoreOpen === false) {
      setShowMaintenanceModal(true);
      return;
    }

    if (!selectedItem) {
      setFormError('Sila pilih pakej item terlebih dahulu!');
      return;
    }
    const cleanUserId = userId.trim();
    if (!cleanUserId) {
      setFormError('Sila masukkan User ID game anda sebelum menambah ke troli!');
      return;
    }
    if (game.serverType && game.serverType !== 'none' && !serverId) {
      setFormError('Sila masukkan Zone / Server ID anda!');
      return;
    }

    if (onAddToCart) {
      onAddToCart({
        gameId: game.id,
        gameName: game.name,
        gameLogoUrl: game.logoUrl,
        itemId: selectedItem.id,
        itemName: selectedItem.name,
        basePrice: selectedItem.basePrice,
        sellPrice: effectivePrice,
        userId: cleanUserId,
        serverId: serverId ? serverId.trim() : undefined,
        quantity: 1,
      });

      setAddedToCartToast(true);
      setTimeout(() => setAddedToCartToast(false), 3000);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSpamError('');

    // Check if store is closed/maintenance
    if (settings.isStoreOpen === false) {
      setShowMaintenanceModal(true);
      return;
    }

    // Anti-Spam Check: Honeypot trap
    if (honeypot) {
      setSpamError('Aktiviti bot dikesan.');
      return;
    }

    // Rate Limiting Check: Prevent rapid submission spam (min 5 seconds between submits)
    const lastSubmitTime = localStorage.getItem('topupbalz_last_submit');
    const now = Date.now();
    if (lastSubmitTime && now - parseInt(lastSubmitTime, 10) < 5000) {
      setSpamError('Sila tunggu beberapa saat sebelum menghantar pesanan seterusnya.');
      return;
    }

    // Validation
    if (!selectedItem) {
      setFormError('Sila pilih pakej item/diamond yang anda inginkan!');
      return;
    }

    const cleanUserId = userId.trim();
    if (!cleanUserId) {
      setFormError('User ID game wajib diisi!');
      return;
    }

    if (game.serverType && game.serverType !== 'none' && !serverId.trim()) {
      setFormError('Zone ID / Server ID game wajib diisi!');
      return;
    }

    const cleanPhone = customerPhone.replace(/\D/g, '');
    if (!cleanPhone || cleanPhone.length < 8) {
      setFormError('Sila masukkan nombor telefon WhatsApp yang sah (Contoh: 0123456789).');
      return;
    }

    // Strict Mandatory Receipt Proof Verification
    if (!proofImage) {
      setFormError('GAMBAR RESIT BUKTI BAYARAN WAJIB DIMUAT NAIK! Sila buat pembayaran dan muat naik screenshot resit transaksi anda.');
      return;
    }

    setIsSubmitting(true);
    localStorage.setItem('topupbalz_last_submit', now.toString());

    try {
      const result = await onSubmitOrder({
        gameId: game.id,
        gameName: game.name,
        itemId: selectedItem.id,
        itemName: selectedItem.name,
        basePrice: selectedItem.basePrice,
        sellPrice: effectivePrice,
        userId: cleanUserId,
        serverId: serverId.trim() || undefined,
        customerPhone: cleanPhone,
        paymentMethod:
          paymentMethod === 'tng'
            ? "Touch 'n Go eWallet"
            : paymentMethod === 'fpx'
            ? 'FPX Online Banking'
            : 'DuitNow QR',
        proofImageUrl: proofImage,
      });

      if (result.success && result.whatsappUrl) {
        setOrderComplete({
          whatsappUrl: result.whatsappUrl,
          orderId: result.orderId || 'BZ-' + Math.floor(100000 + Math.random() * 900000),
          receiptUrl: result.receiptUrl,
          proofImageUrl: result.proofImageUrl || proofImage,
        });
      }
    } catch (err: any) {
      setFormError('Gagal memproses pesanan: ' + (err.message || 'Sila cuba sebentar lagi.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  return (
    <div
      className={`fixed inset-0 z-[100] w-full h-full min-h-screen overflow-y-auto transition-colors duration-300 animate-fadeIn ${
        isLight ? 'bg-slate-100 text-slate-900' : 'bg-[#07090D] text-slate-100'
      }`}
      style={{
        WebkitOverflowScrolling: 'touch',
        overscrollBehaviorY: 'contain',
      }}
    >
      
      {/* Full-Screen Page Container */}
      <div className={`relative w-full min-h-screen max-w-5xl mx-auto flex flex-col transition-colors duration-300 ${
        isLight
          ? 'bg-white text-slate-900 border-x border-slate-200 shadow-2xl'
          : 'bg-[#0D1117] text-white border-x border-slate-800 shadow-[0_0_60px_rgba(0,0,0,0.9)]'
      }`}>
        
        {/* Top Header Bar (Scrolls naturally with page) */}
        <header className={`relative w-full px-4 sm:px-6 py-4 border-b flex items-center justify-between transition-colors ${
          isLight
            ? 'bg-white border-slate-200'
            : 'bg-[#0E131F] border-slate-800'
        }`}>
          <div className="flex items-center gap-3.5 min-w-0">
            <button
              onClick={onClose}
              aria-label="Kembali"
              className={`p-2 rounded-xl border transition-all cursor-pointer shrink-0 ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <img
              src={game.logoUrl}
              alt={game.name}
              referrerPolicy="no-referrer"
              className="w-11 h-11 sm:w-13 sm:h-13 rounded-xl sm:rounded-2xl object-cover border border-orange-500/40 shadow-md shrink-0"
            />
            
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className={`text-base sm:text-xl font-black truncate ${
                  isLight ? 'text-slate-900' : 'text-white'
                }`}>
                  {game.name}
                </h1>
                <span className="px-2 py-0.5 rounded text-[10px] font-black bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 uppercase shadow-sm">
                  TOPUP INSTANT
                </span>
              </div>
              <p className={`text-xs flex items-center gap-1 mt-0.5 truncate ${
                isLight ? 'text-slate-600' : 'text-slate-400'
              }`}>
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                <span>Kiraan Automatik Harga TopupBalz • Proses Pantas & Selamat</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Tutup Borang Topup"
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer shrink-0 ${
              isLight
                ? 'bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-600 border-slate-300 hover:border-red-300'
                : 'bg-slate-900 hover:bg-red-950/40 text-slate-400 hover:text-red-400 border-slate-800 hover:border-red-800/60'
            }`}
          >
            <X className="w-4 h-4" />
            <span>Tutup</span>
          </button>
        </header>

        {/* STORE MAINTENANCE BANNER (IF STORE IS CLOSED) */}
        {settings.isStoreOpen === false && (
          <div className="mx-4 sm:mx-6 mt-4 p-3.5 bg-rose-500/15 border-2 border-rose-500/60 rounded-2xl flex items-center justify-between gap-3 text-rose-700 dark:text-rose-300 animate-fadeIn shadow-lg">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-500 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping inline-block" />
                  <span>Kedai Sedang Ditutup / Maintenance</span>
                </div>
                <p className="text-[11px] opacity-90 truncate sm:whitespace-normal">
                  {settings.storeMaintenanceNotice || 'Anda boleh melihat senarai harga diamond, tetapi proses pesanan ditutup buat sementara waktu.'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowMaintenanceModal(true)}
              className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shrink-0 cursor-pointer shadow-sm transition-all"
            >
              Info Lanjut
            </button>
          </div>
        )}

        {/* ORDER COMPLETE VIEW */}
        {orderComplete ? (
          <div className="flex-1 p-5 sm:p-8 md:p-10 text-center space-y-6 max-w-2xl mx-auto w-full">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-emerald-500/20 to-emerald-600/30 border-2 border-emerald-500 text-emerald-500 flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(16,185,129,0.3)]">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <span className={`px-3 py-1 rounded-full text-xs font-mono font-extrabold border ${
                isLight
                  ? 'bg-orange-50 text-orange-700 border-orange-200'
                  : 'bg-slate-900 text-orange-400 border-orange-500/30'
              }`}>
                PESANAN #{orderComplete.orderId}
              </span>
              <h2 className={`text-2xl sm:text-3xl font-black ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}>
                Pesanan Anda Berjaya Dihantar!
              </h2>
              <p className={`text-xs sm:text-sm max-w-md mx-auto leading-relaxed ${
                isLight ? 'text-slate-600' : 'text-slate-300'
              }`}>
                Gambar bukti pembayaran telah dihantar terus ke bot Telegram dan direkodkan dalam sistem. Sila tekan butang di bawah untuk membuka WhatsApp Admin.
              </p>
            </div>

            {/* Telegram Alert Box */}
            <div className={`p-4 rounded-2xl max-w-md mx-auto text-left space-y-1.5 border shadow-md ${
              isLight
                ? 'bg-blue-50/80 border-blue-200 text-blue-950'
                : 'bg-gradient-to-r from-blue-900/40 via-indigo-900/40 to-cyan-900/40 border-cyan-500/50 text-slate-200 shadow-[0_0_20px_rgba(6,182,212,0.15)]'
            }`}>
              <div className="flex items-center gap-2 justify-between">
                <span className="p-1 rounded-lg bg-blue-500/20 text-blue-600 dark:text-cyan-300 font-bold text-xs flex items-center gap-1">
                  🤖 OrderBalz Telegram Bot
                </span>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono font-bold flex items-center gap-1 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block" />
                  {orderComplete.proofImageUrl ? 'Foto Resit Dihantar ✓' : 'Mesej Dihantar ✓'}
                </span>
              </div>
              <p className="text-xs font-medium leading-relaxed">
                <strong>Sila tunggu 10 - 20 minit</strong> untuk diamond/kredit dimasukkan ke dalam akaun anda secara automatik.
              </p>
            </div>

            {/* Digital Receipt Card */}
            <div className={`p-5 sm:p-6 rounded-2xl border text-left max-w-md mx-auto space-y-3.5 text-xs font-mono relative overflow-hidden shadow-lg ${
              isLight
                ? 'bg-slate-50 border-slate-300 text-slate-800'
                : 'bg-[#0D1117] border-orange-500/40 text-slate-300 shadow-[0_0_25px_rgba(255,140,0,0.15)]'
            }`}>
              <div className={`flex items-center justify-between border-b pb-3 ${
                isLight ? 'border-slate-200' : 'border-slate-800'
              }`}>
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-orange-500/20 text-orange-500 border border-orange-500/30">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className={`font-sans text-sm font-black tracking-tight block ${
                      isLight ? 'text-slate-900' : 'text-white'
                    }`}>
                      RESIT RASMI TOPUPBALZ
                    </strong>
                    <span className="text-[10px] text-slate-500">INVOICE: #{maskOrderId(orderComplete.orderId)}</span>
                  </div>
                </div>

                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 uppercase">
                  DISAHKAN ✓
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Nama Game:</span>
                  <span className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>{game.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Pakej Topup:</span>
                  <span className="text-orange-600 dark:text-orange-400 font-bold">{selectedItem?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">User ID / Server:</span>
                  <span className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>{maskGameUserId(userId)} {serverId ? `(${maskServerId(serverId)})` : ''}</span>
                </div>
                {verifiedAccount && (
                  <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                    <span className="text-slate-500">In-Game Nick:</span>
                    <span className="font-bold">{verifiedAccount.nickname}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-500">Kaedah Bayaran:</span>
                  <span className="capitalize">{paymentMethod === 'tng' ? "Touch 'n Go eWallet" : paymentMethod === 'fpx' ? 'FPX Banking' : 'DuitNow QR'}</span>
                </div>
                <div className={`flex justify-between border-t pt-2 text-sm font-sans font-black ${
                  isLight ? 'border-slate-200' : 'border-slate-800'
                }`}>
                  <span className="text-slate-600 dark:text-slate-300">Jumlah Pembayaran:</span>
                  <span className="text-orange-600 dark:text-orange-400 font-mono">RM {selectedItem?.sellPrice.toFixed(2)}</span>
                </div>
              </div>

              {orderComplete.proofImageUrl && (
                <div className={`pt-2 border-t flex items-center justify-between text-[11px] ${
                  isLight ? 'border-slate-200 text-slate-500' : 'border-slate-800 text-slate-400'
                }`}>
                  <span className="flex items-center gap-1">
                    <ImageIcon className="w-3.5 h-3.5 text-orange-500" />
                    <span>Imej Resit:</span>
                  </span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold">Dimuat Naik ✓</span>
                </div>
              )}
            </div>

            {/* Action Buttons on Order Success */}
            <div className="space-y-3 max-w-md mx-auto pt-2">
              <a
                href={orderComplete.whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(16,185,129,0.4)] transition-all cursor-pointer hover:scale-[1.02] active:scale-95"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Hantar Resit ke WhatsApp Admin</span>
              </a>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrintReceipt}
                  className={`flex-1 py-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isLight
                      ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak Resit</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-slate-950 font-black text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md"
                >
                  Selesai / Tutup
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* MAIN TOPUP FORM */
          <form onSubmit={handleSubmit} className="flex-1 flex flex-col justify-between">
            
            {/* Form Body */}
            <div className="p-4 sm:p-6 md:p-8 space-y-6">
              
              {/* Login State Banner if User is Authenticated */}
              {currentUser ? (
                <div className={`p-4 rounded-2xl border flex items-center justify-between shadow-sm transition-colors ${
                  isLight
                    ? 'bg-emerald-50/80 border-emerald-300 text-emerald-950'
                    : 'bg-gradient-to-r from-emerald-950/40 via-teal-950/30 to-slate-900 border-emerald-500/40 text-emerald-300'
                }`}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-500 font-bold shrink-0">
                      <UserCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className={`text-xs font-bold ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>Log Masuk Sebagai:</span>
                        <strong className="text-emerald-600 dark:text-emerald-400 text-xs font-black">
                          @{currentUser.username || currentUser.name}
                        </strong>
                      </div>
                      <p className={`text-[11px] ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                        Identiti disahkan untuk tempahan ini
                      </p>
                    </div>
                  </div>

                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                    Akaun Sah ✓
                  </span>
                </div>
              ) : (
                <div className={`p-4 rounded-2xl border space-y-2.5 text-left shadow-sm ${
                  isLight
                    ? 'bg-amber-50/80 border-amber-300 text-amber-950'
                    : 'bg-gradient-to-r from-amber-500/20 via-orange-500/15 to-slate-900 border-orange-500/50 text-slate-200'
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-orange-600 dark:text-orange-400 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4" />
                      Log Masuk untuk Akses Penuh
                    </span>
                    <span className="text-[10px] font-bold bg-orange-500/20 text-orange-700 dark:text-orange-300 px-2 py-0.5 rounded-full border border-orange-500/30 uppercase">
                      Pilihan Selamat
                    </span>
                  </div>
                  <p className="text-xs font-medium leading-relaxed">
                    Log masuk dengan akaun Google atau Username untuk semak sejarah pesanan dan pengumpulan mata ganjaran.
                  </p>
                  <button
                    type="button"
                    onClick={onRequestLogin}
                    className={`w-full py-2.5 px-4 rounded-xl font-black text-xs uppercase flex items-center justify-center gap-2.5 cursor-pointer transition-all shadow-sm active:scale-95 ${
                      isLight
                        ? 'bg-slate-900 hover:bg-slate-800 text-white'
                        : 'bg-white hover:bg-slate-100 text-slate-900'
                    }`}
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Log Masuk Sekarang</span>
                  </button>
                </div>
              )}
              
              {/* STEP 1: Game Account Information */}
              <div className={`p-4 sm:p-5 rounded-2xl border space-y-4 transition-colors ${
                isLight
                  ? 'bg-slate-50 border-slate-200 shadow-sm'
                  : 'bg-[#121824] border-slate-800 shadow-inner'
              }`}>
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-orange-500 text-slate-950 text-xs font-black flex items-center justify-center shadow-sm">
                      1
                    </span>
                    <h3 className={`font-black text-sm sm:text-base ${
                      isLight ? 'text-slate-900' : 'text-white'
                    }`}>
                      Masukkan Maklumat Akaun Game
                    </h3>
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowIdGuide(!showIdGuide)}
                    className="text-xs text-orange-600 dark:text-orange-400 hover:underline flex items-center gap-1 bg-orange-500/10 px-2.5 py-1 rounded-lg border border-orange-500/20 cursor-pointer"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    <span>Cara Cari User ID</span>
                  </button>
                </div>

                {/* ID Guide Popup Accordion */}
                {showIdGuide && (
                  <div className={`p-3.5 border rounded-xl text-xs space-y-1.5 animate-fadeIn ${
                    isLight
                      ? 'bg-orange-50 border-orange-200 text-orange-950'
                      : 'bg-orange-500/10 border-orange-500/30 text-slate-200'
                  }`}>
                    <div className="flex items-center gap-1.5 font-bold text-orange-600 dark:text-orange-400">
                      <Info className="w-4 h-4 shrink-0" />
                      <span>Panduan Carian User ID ({game.name})</span>
                    </div>
                    <p className="leading-relaxed">{game.idGuideText}</p>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className={`block text-xs font-bold ${
                        isLight ? 'text-slate-700' : 'text-slate-300'
                      }`}>
                        User ID <span className="text-orange-500">*</span> <span className="text-[10px] text-amber-500 font-normal">(Nombor Sahaja)</span>
                      </label>
                      <button
                        type="button"
                        onClick={handleVerifyAccount}
                        disabled={isVerifyingAccount || !userId.trim()}
                        className="text-[11px] text-emerald-600 dark:text-emerald-400 hover:text-emerald-500 font-bold flex items-center gap-1 bg-emerald-500/10 hover:bg-emerald-500/20 px-2 py-0.5 rounded-lg border border-emerald-500/30 transition-all cursor-pointer disabled:opacity-50"
                      >
                        {isVerifyingAccount ? (
                          <>
                            <RefreshCw className="w-3 h-3 animate-spin" />
                            <span>Mencari...</span>
                          </>
                        ) : (
                          <>
                            <UserCheck className="w-3 h-3" />
                            <span>⚡ Semak ID Akaun</span>
                          </>
                        )}
                      </button>
                    </div>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      required
                      placeholder="Contoh: 12345678 (Nombor Sahaja)"
                      value={userId}
                      onChange={(e) => {
                        setUserId(e.target.value.replace(/\D/g, ''));
                        if (verifiedAccount) setVerifiedAccount(null);
                      }}
                      className={`w-full rounded-xl px-3.5 py-2.5 text-sm font-mono focus:outline-none transition-colors ${
                        isLight
                          ? 'bg-white border border-slate-300 text-slate-900 placeholder-slate-400 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 shadow-sm'
                          : 'bg-[#0D1117] border border-slate-700 text-white placeholder-slate-500 focus:border-orange-500'
                      }`}
                    />
                  </div>

                  {game.serverType === 'zone_id' && (
                    <div>
                      <label className={`block text-xs font-bold mb-1.5 ${
                        isLight ? 'text-slate-700' : 'text-slate-300'
                      }`}>
                        Zone ID / Server ID <span className="text-orange-500">*</span> <span className="text-[10px] text-amber-500 font-normal">(Nombor Sahaja)</span>
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        placeholder="Contoh: 2001 (Nombor Sahaja)"
                        value={serverId}
                        onChange={(e) => setServerId(e.target.value.replace(/\D/g, ''))}
                        className={`w-full rounded-xl px-3.5 py-2.5 text-sm font-mono focus:outline-none transition-colors ${
                          isLight
                            ? 'bg-white border border-slate-300 text-slate-900 placeholder-slate-400 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 shadow-sm'
                            : 'bg-[#0D1117] border border-slate-700 text-white placeholder-slate-500 focus:border-orange-500'
                        }`}
                      />
                    </div>
                  )}

                  {game.serverType === 'server_list' && game.serverOptions && (
                    <div>
                      <label className={`block text-xs font-bold mb-1.5 ${
                        isLight ? 'text-slate-700' : 'text-slate-300'
                      }`}>
                        Pilih Server Game <span className="text-orange-500">*</span>
                      </label>
                      <select
                        value={serverId}
                        onChange={(e) => setServerId(e.target.value)}
                        className={`w-full rounded-xl px-3.5 py-2.5 text-sm focus:outline-none transition-colors ${
                          isLight
                            ? 'bg-white border border-slate-300 text-slate-900 focus:border-orange-500 shadow-sm'
                            : 'bg-[#0D1117] border border-slate-700 text-white focus:border-orange-500'
                        }`}
                      >
                        {game.serverOptions.map((srv) => (
                          <option key={srv} value={srv}>
                            {srv}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {game.serverType === 'tag' && (
                    <div>
                      <label className={`block text-xs font-bold mb-1.5 ${
                        isLight ? 'text-slate-700' : 'text-slate-300'
                      }`}>
                        Tagline / Server <span className="text-orange-500">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="Contoh: #MY1"
                        value={serverId}
                        onChange={(e) => setServerId(e.target.value)}
                        className={`w-full rounded-xl px-3.5 py-2.5 text-sm font-mono focus:outline-none transition-colors ${
                          isLight
                            ? 'bg-white border border-slate-300 text-slate-900 placeholder-slate-400 focus:border-orange-500 shadow-sm'
                            : 'bg-[#0D1117] border border-slate-700 text-white placeholder-slate-500 focus:border-orange-500'
                        }`}
                      />
                    </div>
                  )}
                </div>

                {/* Verified Account Card Display */}
                {verifiedAccount && (
                  <div className={`p-3 border rounded-xl flex items-center justify-between text-xs animate-fadeIn ${
                    isLight
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                      : 'bg-gradient-to-r from-emerald-950/40 via-teal-950/30 to-slate-900 border-emerald-500/40 text-white'
                  }`}>
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                        <UserCheck className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 uppercase font-mono font-bold tracking-wider block">
                          Akaun Ditemui & Disahkan ✓
                        </span>
                        <strong className="font-mono text-sm">{verifiedAccount.nickname}</strong>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className={`text-[10px] block ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                        {verifiedAccount.region}
                      </span>
                      <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-bold bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30 inline-block mt-0.5">
                        {verifiedAccount.status}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* STEP 2: Choose Topup Package */}
              <div className={`p-4 sm:p-5 rounded-2xl border space-y-4 transition-colors ${
                isLight
                  ? 'bg-slate-50 border-slate-200 shadow-sm'
                  : 'bg-[#121824] border-slate-800 shadow-inner'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-orange-500 text-slate-950 text-xs font-black flex items-center justify-center shadow-sm">
                      2
                    </span>
                    <h3 className={`font-black text-sm sm:text-base ${
                      isLight ? 'text-slate-900' : 'text-white'
                    }`}>
                      Pilih Pakej Diamond / Item
                    </h3>
                  </div>
                  <span className={`text-[11px] font-mono ${
                    isLight ? 'text-slate-500' : 'text-slate-400'
                  }`}>
                    Sistem Harga TopupBalz
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {game.items.map((item) => {
                    const isSelected = selectedItem?.id === item.id;
                    const fsItem = getFlashSaleForItem(item.id);
                    const itemPrice = fsItem ? fsItem.flashPrice : item.sellPrice;
                    return (
                      <div
                        key={item.id}
                        onClick={() => setSelectedItem(item)}
                        className={`relative p-3.5 rounded-2xl border text-left cursor-pointer transition-all duration-200 flex flex-col justify-between ${
                          isSelected
                            ? isLight
                              ? 'bg-orange-50 border-orange-500 ring-2 ring-orange-500/30 shadow-md'
                              : 'bg-gradient-to-b from-orange-500/20 to-amber-500/10 border-orange-500 shadow-[0_0_15px_rgba(255,140,0,0.3)] ring-1 ring-orange-500/50'
                            : fsItem
                            ? isLight
                              ? 'bg-white border-orange-300 hover:border-orange-500 shadow-sm'
                              : 'bg-[#121622] border-orange-500/30 hover:border-orange-500/60'
                            : isLight
                            ? 'bg-white border-slate-200 hover:border-slate-400 shadow-sm'
                            : 'bg-[#0D1117] border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
                        }`}
                      >
                        {fsItem ? (
                          <span className="absolute -top-2.5 right-2 px-1.5 py-0.5 rounded text-[9px] font-black bg-gradient-to-r from-red-600 to-orange-500 text-white uppercase tracking-tight shadow-sm flex items-center gap-0.5">
                            <Zap className="w-2.5 h-2.5 fill-current" />
                            KILAT
                          </span>
                        ) : item.bonusTag ? (
                          <span className="absolute -top-2.5 right-2 px-1.5 py-0.5 rounded text-[9px] font-black bg-orange-500 text-slate-950 uppercase tracking-tight shadow-sm">
                            {item.bonusTag}
                          </span>
                        ) : null}

                        <div>
                          <div className="flex items-center gap-1.5 text-xs font-bold">
                            <Zap className={`w-3.5 h-3.5 ${
                              fsItem
                                ? 'text-amber-500 fill-amber-500'
                                : isSelected
                                ? 'text-orange-500'
                                : isLight ? 'text-slate-500' : 'text-slate-400'
                            }`} />
                            <span className={`line-clamp-1 ${
                              isLight ? 'text-slate-900' : 'text-white'
                            }`}>
                              {item.name}
                            </span>
                          </div>
                        </div>

                        <div className={`mt-3 pt-2 border-t ${
                          isLight ? 'border-slate-200' : 'border-slate-800/80'
                        }`}>
                          {fsItem ? (
                            <div className="flex items-baseline justify-between gap-1">
                              <span className="text-[10px] font-bold text-red-500 line-through">
                                RM {item.sellPrice.toFixed(2)}
                              </span>
                              <span className="text-xs sm:text-sm font-black font-mono text-orange-600 dark:text-amber-400">
                                RM {itemPrice.toFixed(2)}
                              </span>
                            </div>
                          ) : (
                            <span className={`text-xs sm:text-sm font-black font-mono block ${
                              isLight ? 'text-orange-600' : 'text-orange-400'
                            }`}>
                              RM {item.sellPrice.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* STEP 3: Payment Method */}
              <div className={`p-4 sm:p-5 rounded-2xl border space-y-4 transition-colors ${
                isLight
                  ? 'bg-slate-50 border-slate-200 shadow-sm'
                  : 'bg-[#121824] border-slate-800 shadow-inner'
              }`}>
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-orange-500 text-slate-950 text-xs font-black flex items-center justify-center shadow-sm">
                    3
                  </span>
                  <h3 className={`font-black text-sm sm:text-base ${
                    isLight ? 'text-slate-900' : 'text-white'
                  }`}>
                    Pilih Kaedah Pembayaran
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Touch n Go option */}
                  <div
                    onClick={() => setPaymentMethod('tng')}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-3 ${
                      paymentMethod === 'tng'
                        ? isLight
                          ? 'bg-orange-50 border-orange-500 shadow-md ring-1 ring-orange-500'
                          : 'bg-orange-500/15 border-orange-500 text-white shadow-[0_0_15px_rgba(255,140,0,0.2)]'
                        : isLight
                        ? 'bg-white border-slate-200 hover:border-slate-300'
                        : 'bg-[#0D1117] border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-500 shrink-0">
                      <QrCode className="w-6 h-6" />
                    </div>
                    <div>
                      <div className={`text-xs font-black flex items-center gap-1 ${
                        isLight ? 'text-slate-900' : 'text-white'
                      }`}>
                        <span>Touch 'n Go QR</span>
                        <span className="text-[9px] bg-orange-500 text-slate-950 px-1 rounded uppercase font-bold">PANTAS</span>
                      </div>
                      <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Imbas QR Code eWallet</p>
                    </div>
                  </div>

                  {/* FPX option */}
                  <div
                    onClick={() => setPaymentMethod('fpx')}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-3 ${
                      paymentMethod === 'fpx'
                        ? isLight
                          ? 'bg-orange-50 border-orange-500 shadow-md ring-1 ring-orange-500'
                          : 'bg-orange-500/15 border-orange-500 text-white'
                        : isLight
                        ? 'bg-white border-slate-200 hover:border-slate-300'
                        : 'bg-[#0D1117] border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-500 shrink-0 font-bold text-xs">
                      FPX
                    </div>
                    <div>
                      <div className={`text-xs font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>Online Banking</div>
                      <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Maybank, CIMB, Bank Islam</p>
                    </div>
                  </div>

                  {/* DuitNow option */}
                  <div
                    onClick={() => setPaymentMethod('duitnow')}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-3 ${
                      paymentMethod === 'duitnow'
                        ? isLight
                          ? 'bg-orange-50 border-orange-500 shadow-md ring-1 ring-orange-500'
                          : 'bg-orange-500/15 border-orange-500 text-white'
                        : isLight
                        ? 'bg-white border-slate-200 hover:border-slate-300'
                        : 'bg-[#0D1117] border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-500 shrink-0">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <div className={`text-xs font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>DuitNow QR</div>
                      <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Semua E-Wallet & Bank</p>
                    </div>
                  </div>
                </div>

                {/* Touch 'n Go / DuitNow QR Display Box */}
                {(paymentMethod === 'tng' || paymentMethod === 'duitnow') && (
                  <div className={`p-4 sm:p-5 border rounded-2xl space-y-4 animate-fadeIn ${
                    isLight
                      ? 'bg-white border-orange-300 shadow-sm'
                      : 'bg-[#0D1117] border-orange-500/40 shadow-inner'
                  }`}>
                    <div className="flex flex-col items-center justify-center space-y-3">
                      <TngQrCodeCard
                        accountName={settings.tngAccountName}
                        customQrImageUrl={settings.tngQrImageUrl}
                      />

                      <div className="text-center space-y-2 pt-1 max-w-sm">
                        <div className="flex items-center justify-center gap-2">
                          <span className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>Nama Pemegang:</span>
                          <span className={`text-xs font-mono font-bold px-3 py-1 rounded-lg border ${
                            isLight
                              ? 'text-orange-700 bg-orange-50 border-orange-200'
                              : 'text-orange-400 bg-slate-900 border-slate-800'
                          }`}>
                            {settings.tngAccountName}
                          </span>
                          <button
                            type="button"
                            onClick={handleCopyAccountName}
                            className={`p-1.5 rounded-lg cursor-pointer transition-colors ${
                              isLight
                                ? 'bg-slate-200 hover:bg-slate-300 text-slate-700'
                                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                            }`}
                            title="Salin Nama Akaun"
                          >
                            {copiedAccount ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                          </button>
                        </div>

                        <p className={`text-[11px] leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                          Bayar RM <strong className="text-orange-600 dark:text-orange-400 font-black">{effectivePrice.toFixed(2)}</strong> menggunakan Touch 'n Go eWallet / Mana-mana App Bank DuitNow.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* STEP 4: Upload Receipt / Transfer Proof */}
              <div className={`p-4 sm:p-5 rounded-2xl border space-y-4 transition-colors ${
                isLight
                  ? 'bg-slate-50 border-slate-200 shadow-sm'
                  : 'bg-[#121824] border-slate-800 shadow-inner'
              }`}>
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-orange-500 text-slate-950 text-xs font-black flex items-center justify-center shadow-sm">
                      4
                    </span>
                    <h3 className={`font-black text-sm sm:text-base ${
                      isLight ? 'text-slate-900' : 'text-white'
                    }`}>
                      Muat Naik Gambar Resit Bayaran <span className="text-orange-500">*</span>
                    </h3>
                  </div>
                  <span className="px-2 py-0.5 bg-rose-500/20 text-rose-600 dark:text-rose-300 border border-rose-500/30 rounded text-[10px] font-bold font-mono uppercase">
                    Wajib Disertakan
                  </span>
                </div>

                <div className="space-y-3.5">
                  <div className={`relative border-2 border-dashed rounded-2xl p-4 sm:p-6 text-center transition-all ${
                    proofImage
                      ? isLight
                        ? 'border-emerald-500 bg-emerald-50/60'
                        : 'border-emerald-500/80 bg-emerald-950/20'
                      : isLight
                      ? 'border-orange-300 bg-white hover:border-orange-500 hover:bg-orange-50/30'
                      : 'border-rose-500/60 bg-[#0D1117] hover:border-orange-500'
                  }`}>
                    <input
                      type="file"
                      accept="image/*"
                      required
                      onChange={handleFileUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    {proofImage ? (
                      <div className="flex items-center justify-center gap-4 flex-wrap">
                        <img
                          src={proofImage}
                          alt="Resit Transfer"
                          className="w-16 h-16 object-cover rounded-xl border-2 border-emerald-500 shadow-sm"
                        />
                        <div className="text-left">
                          <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-bold text-xs sm:text-sm">
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Gambar Resit Sah &amp; Berjaya Dimuat Naik</span>
                          </div>
                          <p className={`text-[11px] mt-1 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                            Tekan untuk tukar gambar resit lain
                          </p>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2 py-2">
                        <div className="w-10 h-10 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center mx-auto shadow-inner">
                          <Upload className="w-5 h-5" />
                        </div>
                        <div>
                          <p className={`text-xs sm:text-sm font-bold ${isLight ? 'text-slate-800' : 'text-slate-200'}`}>
                            Tekan atau Tarik Gambar Resit Transfer Di Sini <span className="text-rose-500">*</span>
                          </p>
                          <p className="text-[10px] sm:text-xs text-rose-600 dark:text-rose-300/80 mt-0.5">
                            Wajib muat naik resit/screenshot transaksi bank/e-wallet anda
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className={`block text-xs font-bold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                        Nombor Telefon WhatsApp Anda <span className="text-orange-500">*</span> <span className="text-[10px] text-amber-500 font-normal">(Wajib - Nombor Sahaja)</span>
                      </label>
                      <span className="text-[10px] text-slate-500">Cth: 0123456789</span>
                    </div>
                    <input
                      type="tel"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      required
                      placeholder="Contoh: 0123456789 (Hanya Nombor)"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value.replace(/\D/g, ''))}
                      className={`w-full rounded-xl px-3.5 py-2.5 text-sm font-mono focus:outline-none transition-colors ${
                        isLight
                          ? 'bg-white border border-slate-300 text-slate-900 placeholder-slate-400 focus:border-orange-500 shadow-sm'
                          : 'bg-[#0D1117] border border-slate-700 text-white placeholder-slate-500 focus:border-orange-500'
                      }`}
                    />
                  </div>
                </div>
              </div>

              {/* Honeypot & Alerts */}
              <div className="hidden" aria-hidden="true">
                <input
                  type="text"
                  name="website_address_trap"
                  tabIndex={-1}
                  autoComplete="off"
                  value={honeypot}
                  onChange={(e) => setHoneypot(e.target.value)}
                />
              </div>

              {addedToCartToast && (
                <div className="p-3 bg-emerald-500/20 border border-emerald-500/50 rounded-xl text-emerald-600 dark:text-emerald-300 text-xs font-bold flex items-center justify-between animate-fadeIn">
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>Item dimasukkan ke Troli Pembelian!</span>
                  </span>
                  <span className="text-[10px] uppercase tracking-wider font-mono bg-emerald-500 text-slate-950 px-2 py-0.5 rounded font-black">
                    Troli Updated
                  </span>
                </div>
              )}

              {spamError && (
                <div className="p-3 bg-rose-500/15 border border-rose-500/40 rounded-xl text-rose-600 dark:text-rose-300 text-xs font-bold flex items-center gap-2 animate-fadeIn">
                  <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                  <span>{spamError}</span>
                </div>
              )}

              {formError && (
                <div className="p-3.5 bg-rose-500/20 border-2 border-rose-500 rounded-2xl text-rose-700 dark:text-rose-200 text-xs sm:text-sm font-bold flex items-start gap-2.5 animate-fadeIn shadow-md">
                  <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <span className="text-rose-600 dark:text-rose-400 font-extrabold block text-xs uppercase tracking-wider">Perhatian:</span>
                    <span>{formError}</span>
                  </div>
                </div>
              )}

            </div>

            {/* Bottom Action Bar (Positioned naturally at bottom of form) */}
            <div className={`relative w-full p-4 sm:p-6 border-t transition-colors ${
              isLight
                ? 'bg-slate-50 border-slate-200'
                : 'bg-[#121824] border-slate-800'
            }`}>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 max-w-4xl mx-auto">
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-semibold ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      Jumlah Bayaran Akhir:
                    </span>
                    {currentFlashSale && (
                      <span className="text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-red-500/20 text-red-600 dark:text-red-400 border border-red-500/30">
                        ⚡ Jualan Kilat
                      </span>
                    )}
                  </div>
                  
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl sm:text-3xl font-black text-orange-600 dark:text-amber-400 font-mono">
                      RM {effectivePrice.toFixed(2)}
                    </span>
                    {currentFlashSale && (
                      <span className="text-xs text-red-500 font-bold">
                        (Jimat RM {((selectedItem?.sellPrice || 0) - effectivePrice).toFixed(2)})
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  {onAddToCart && (
                    <button
                      type="button"
                      onClick={handleAddToCartClick}
                      className={`px-4 py-3.5 rounded-xl font-bold text-xs uppercase tracking-wide border transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 ${
                        isLight
                          ? 'bg-slate-100 hover:bg-slate-200 text-orange-700 border-orange-300'
                          : 'bg-slate-800 hover:bg-slate-700 text-orange-400 border-orange-500/40'
                      }`}
                    >
                      <ShoppingCart className="w-4 h-4" />
                      <span>Tambah Troli</span>
                    </button>
                  )}

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 sm:flex-initial px-7 py-3.5 rounded-xl bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider shadow-[0_0_20px_rgba(249,115,22,0.4)] transition-all flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer active:scale-95"
                  >
                    {isSubmitting ? (
                      <span>Sedang Memproses...</span>
                    ) : (
                      <>
                        <span>Topup Sekarang</span>
                        <MessageCircle className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

          </form>
        )}

        {/* MAINTENANCE / STORE CLOSED MODAL POPUP */}
        {showMaintenanceModal && (
          <div className="fixed inset-0 z-[150] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
            <div className={`w-full max-w-md p-6 sm:p-7 rounded-3xl border-2 shadow-2xl text-center space-y-5 animate-scaleUp ${
              isLight
                ? 'bg-white border-rose-400 text-slate-900 shadow-[0_10px_50px_rgba(244,63,94,0.25)]'
                : 'bg-[#0D1117] border-rose-500/80 text-white shadow-[0_0_60px_rgba(244,63,94,0.35)]'
            }`}>
              <div className="w-16 h-16 rounded-2xl bg-rose-500/15 border border-rose-500/40 text-rose-500 flex items-center justify-center mx-auto shadow-inner">
                <AlertTriangle className="w-8 h-8 animate-bounce" />
              </div>

              <div className="space-y-2">
                <span className="px-3 py-0.5 rounded-full text-[11px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/40">
                  Status: Maintenance Mode
                </span>
                <h3 className={`text-xl sm:text-2xl font-black ${
                  isLight ? 'text-slate-900' : 'text-white'
                }`}>
                  Kedai Sedang Ditutup / Maintenance
                </h3>
                <p className={`text-xs sm:text-sm leading-relaxed ${
                  isLight ? 'text-slate-600' : 'text-slate-300'
                }`}>
                  {settings.storeMaintenanceNotice || 'Kedai kami sedang ditutup sementara untuk proses penyelenggaraan sistem & kemaskini stok. Anda boleh melihat senarai harga diamond, namun pembayaran & pesanan tidak dapat diproses buat masa ini.'}
                </p>
                <p className={`text-[11px] font-medium pt-1 ${
                  isLight ? 'text-slate-500' : 'text-slate-400'
                }`}>
                  ℹ️ Anda bebas melihat &amp; menyemak semua katalog harga diamond di sini. Sila cuba lagi sebentar lagi apabila kedai dibuka semula.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
                <a
                  href={`https://wa.me/${(settings.ownerWhatsApp || '60145975056').replace(/\D/g, '')}?text=${encodeURIComponent(
                    'Salam Admin TopupBalz, kedai sedang maintenance ke? Bila kedai akan buka semula?'
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase flex items-center justify-center gap-2 transition-all shadow-md active:scale-95"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp Admin</span>
                </a>
                <button
                  type="button"
                  onClick={() => setShowMaintenanceModal(false)}
                  className={`py-3 px-5 rounded-xl font-bold text-xs uppercase transition-all cursor-pointer ${
                    isLight
                      ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  Faham / Tutup
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
