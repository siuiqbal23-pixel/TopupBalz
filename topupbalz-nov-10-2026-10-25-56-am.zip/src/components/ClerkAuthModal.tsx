import React, { useState } from 'react';
import { SignIn, SignUp } from '@clerk/clerk-react';
import { X, Sparkles, User, Lock, AlertCircle, ArrowRight, Check } from 'lucide-react';
import { ADMIN_USERNAME, ADMIN_PIN_CODE } from '../lib/clerkConfig';
import { UserProfile } from '../types';

interface ClerkAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'signin' | 'signup';
  onLoginSuccess?: (user: UserProfile) => void;
}

export const ClerkAuthModal: React.FC<ClerkAuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'signin',
  onLoginSuccess,
}) => {
  const [mode, setMode] = useState<'signin' | 'signup'>(initialMode);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[140] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn overflow-y-auto">
      <div className="relative w-full max-w-md bg-[#0D1117] border border-orange-500/40 rounded-3xl p-5 sm:p-7 shadow-[0_0_60px_rgba(255,140,0,0.25)] my-auto text-white">
        
        {/* Glow Accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-900 border border-slate-700 hover:border-orange-500 text-slate-400 hover:text-white flex items-center justify-center text-sm font-bold transition-all cursor-pointer z-20"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="text-center space-y-1.5 mb-5 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/15 border border-orange-500/30 text-orange-400 text-[11px] font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>TopupBalz Authentication</span>
          </div>
          <h3 className="text-xl font-black text-white">
            {mode === 'signin' ? 'Log Masuk Akaun' : 'Daftar Akaun Baru'}
          </h3>
          <p className="text-xs text-slate-400">
            {mode === 'signin'
              ? 'Log masuk dengan Google atau emel untuk akses pantas'
              : 'Daftar akaun TopupBalz percuma hari ini'}
          </p>
        </div>

        {/* Clerk In-App Embedded Component with virtual routing (no 404 redirection) */}
        <div className="clerk-inapp-container flex flex-col items-center justify-center relative z-10 w-full space-y-4">
          {mode === 'signin' ? (
            <SignIn
              routing="virtual"
              fallbackRedirectUrl={typeof window !== 'undefined' ? window.location.origin : '/'}
              signUpFallbackRedirectUrl={typeof window !== 'undefined' ? window.location.origin : '/'}
              appearance={{
                layout: {
                  socialButtonsPlacement: 'top',
                  showOptionalFields: false,
                },
                variables: {
                  colorPrimary: '#f97316',
                  colorBackground: '#0D1117',
                  colorText: '#ffffff',
                  colorTextSecondary: '#94a3b8',
                  colorInputBackground: '#121824',
                  colorInputText: '#ffffff',
                },
                elements: {
                  card: 'bg-transparent border-0 shadow-none p-0 w-full',
                  header: 'hidden',
                  footer: 'hidden',
                  formButtonPrimary:
                    'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 font-black hover:from-orange-400 hover:to-amber-400 rounded-xl text-xs uppercase py-3 shadow-[0_0_20px_rgba(255,140,0,0.3)] transition-all',
                  socialButtonsBlockButton:
                    'bg-slate-900 border border-slate-700 hover:border-orange-500/60 text-white rounded-xl py-3 text-xs font-bold transition-all shadow-sm',
                  formFieldInput:
                    'bg-[#121824] border border-slate-700 focus:border-orange-500 text-white rounded-xl py-2.5 px-3 text-xs font-mono',
                  formFieldLabel: 'text-slate-300 text-xs font-bold',
                  dividerLine: 'bg-slate-800',
                  dividerText: 'text-slate-500 text-[11px] font-mono',
                },
              }}
            />
          ) : (
            <SignUp
              routing="virtual"
              fallbackRedirectUrl={typeof window !== 'undefined' ? window.location.origin : '/'}
              signInFallbackRedirectUrl={typeof window !== 'undefined' ? window.location.origin : '/'}
              appearance={{
                layout: {
                  socialButtonsPlacement: 'top',
                  showOptionalFields: false,
                },
                variables: {
                  colorPrimary: '#f97316',
                  colorBackground: '#0D1117',
                  colorText: '#ffffff',
                  colorTextSecondary: '#94a3b8',
                  colorInputBackground: '#121824',
                  colorInputText: '#ffffff',
                },
                elements: {
                  card: 'bg-transparent border-0 shadow-none p-0 w-full',
                  header: 'hidden',
                  footer: 'hidden',
                  formButtonPrimary:
                    'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 font-black hover:from-orange-400 hover:to-amber-400 rounded-xl text-xs uppercase py-3 shadow-[0_0_20px_rgba(255,140,0,0.3)] transition-all',
                  socialButtonsBlockButton:
                    'bg-slate-900 border border-slate-700 hover:border-orange-500/60 text-white rounded-xl py-3 text-xs font-bold transition-all shadow-sm',
                  formFieldInput:
                    'bg-[#121824] border border-slate-700 focus:border-orange-500 text-white rounded-xl py-2.5 px-3 text-xs font-mono',
                  formFieldLabel: 'text-slate-300 text-xs font-bold',
                  dividerLine: 'bg-slate-800',
                  dividerText: 'text-slate-500 text-[11px] font-mono',
                },
              }}
            />
          )}
        </div>

        {/* Mode Toggle Footer */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 text-center text-xs text-slate-400 relative z-10">
          {mode === 'signin' ? (
            <p>
              Belum mempunyai akaun?{' '}
              <button
                type="button"
                onClick={() => setMode('signup')}
                className="text-orange-400 hover:text-orange-300 font-bold underline cursor-pointer ml-1"
              >
                Daftar sekarang
              </button>
            </p>
          ) : (
            <p>
              Sudah mempunyai akaun?{' '}
              <button
                type="button"
                onClick={() => setMode('signin')}
                className="text-orange-400 hover:text-orange-300 font-bold underline cursor-pointer ml-1"
              >
                Log Masuk di sini
              </button>
            </p>
          )}
        </div>

      </div>
    </div>
  );
};
