import React, { useState } from 'react';
import {
  X,
  Lock,
  Gamepad2,
  ShoppingBag,
  Sliders,
  Settings,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Check,
  Clock,
  AlertCircle,
  Eye,
  MessageCircle,
  Save,
  RefreshCw,
  HelpCircle,
  QrCode,
  DollarSign,
  Send,
  Zap,
  Upload,
  Image as ImageIcon,
  Users,
  Activity,
  UserCheck,
  Search,
  ExternalLink,
  MoreVertical,
  ChevronDown,
  Mail,
  Sparkles,
  ArrowLeft,
  Camera,
  LayoutGrid,
  Home,
  Smartphone,
  Receipt,
} from 'lucide-react';
import { GambarTfGenerator } from './GambarTfGenerator';
import { Game, GameItem, Order, PromoBanner, SystemSettings, UserProfile, UserActivityLog, FlashSaleConfig, FlashSaleItem } from '../types';
import { INITIAL_FLASH_SALE } from '../data/initialData';
import { safeFetchJson } from '../lib/safeFetch';
import { compressImage } from '../lib/imageCompressor';
import { useAppAuth } from '../context/AuthContext';
import { ADMIN_USERNAME, ADMIN_PIN_CODE } from '../lib/clerkConfig';


interface AdminDashboardProps {
  games: Game[];
  orders: Order[];
  banners: PromoBanner[];
  settings: SystemSettings;
  users?: UserProfile[];
  activityLogs?: UserActivityLog[];
  flashSale?: FlashSaleConfig;
  isEmbedded?: boolean;
  onClose: () => void;
  onSaveGame: (game: Game) => Promise<void>;
  onDeleteGame: (id: string) => Promise<void>;
  onUpdateOrderStatus: (id: string, status: Order['status'], notes?: string) => Promise<void>;
  onSaveBanner: (banner: PromoBanner) => Promise<void>;
  onDeleteBanner: (id: string) => Promise<void>;
  onSaveSettings: (settings: SystemSettings) => Promise<void>;
  onSaveFlashSale?: (config: FlashSaleConfig) => Promise<void>;
  onOpenGmailModal?: (recipient?: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  games,
  orders,
  banners,
  settings,
  users = [],
  activityLogs = [],
  flashSale,
  isEmbedded = false,
  onClose,
  onSaveGame,
  onDeleteGame,
  onUpdateOrderStatus,
  onSaveBanner,
  onDeleteBanner,
  onSaveSettings,
  onSaveFlashSale,
  onOpenGmailModal,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(isEmbedded ? true : false);
  const [pinError, setPinError] = useState(false);
  const [activeTab, setActiveTab] = useState<'hub' | 'games' | 'orders' | 'banners' | 'settings' | 'users' | 'chat' | 'flash_sale' | 'gambar_tf'>('hub');
  const [showThreeDotsMenu, setShowThreeDotsMenu] = useState(false);
  const [userSearch, setUserSearch] = useState('');

  // Flash Sale Admin States
  const [localFlashSale, setLocalFlashSale] = useState<FlashSaleConfig>(
    flashSale || (JSON.parse(JSON.stringify(INITIAL_FLASH_SALE)) as FlashSaleConfig)
  );
  const [isSavingFlashSale, setIsSavingFlashSale] = useState(false);
  const [flashSaleMsg, setFlashSaleMsg] = useState<{ text: string; isError?: boolean } | null>(null);
  const [editingFlashItem, setEditingFlashItem] = useState<FlashSaleItem | null>(null);
  const [selectedGameForNewItem, setSelectedGameForNewItem] = useState<string>(games[0]?.id || '');
  const [selectedPackageForNewItem, setSelectedPackageForNewItem] = useState<string>('');
  const [newFlashPrice, setNewFlashPrice] = useState<string>('');
  const [newMaxQuota, setNewMaxQuota] = useState<string>('20');
  const [durationHours, setDurationHours] = useState<string>('24');
  const [durationMinutes, setDurationMinutes] = useState<string>('0');
  const [durationSeconds, setDurationSeconds] = useState<string>('0');
  const isInitialDurationLoaded = React.useRef(false);

  // Sync flashSale from props (only once on mount or when explicit prop changes, so typing and background edits are never reset by 3s polling)
  const isInitialFlashSaleLoaded = React.useRef(false);
  React.useEffect(() => {
    if (flashSale && !isInitialFlashSaleLoaded.current) {
      isInitialFlashSaleLoaded.current = true;
      setLocalFlashSale(flashSale);
      if (flashSale.endTime) {
        const diff = new Date(flashSale.endTime).getTime() - Date.now();
        if (diff > 0) {
          const totalSec = Math.floor(diff / 1000);
          const h = Math.floor(totalSec / 3600);
          const m = Math.floor((totalSec % 3600) / 60);
          const s = totalSec % 60;
          setDurationHours(String(h));
          setDurationMinutes(String(m));
          setDurationSeconds(String(s));
        }
      }
    }
  }, [flashSale]);

  // User Management & Banning States
  const [localUsers, setLocalUsers] = useState<UserProfile[]>(users);
  const [bannedUsersList, setBannedUsersList] = useState<any[]>([]);
  const [copiedAllEmails, setCopiedAllEmails] = useState(false);
  const [deleteConfirmUser, setDeleteConfirmUser] = useState<UserProfile | null>(null);
  const [previewAvatarUser, setPreviewAvatarUser] = useState<UserProfile | null>(null);
  const [deleteReason, setDeleteReason] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [userActionMessage, setUserActionMessage] = useState<{ text: string; isError?: boolean } | null>(null);

  // Sync users from props when updated
  React.useEffect(() => {
    if (users && users.length > 0) {
      setLocalUsers(users);
    }
  }, [users]);

  const fetchUsersAndBanned = async () => {
    try {
      const data = await safeFetchJson('/api/users');
      if (data) {
        if (Array.isArray(data.users)) setLocalUsers(data.users);
        if (Array.isArray(data.bannedUsers)) setBannedUsersList(data.bannedUsers);
      }
    } catch (err) {
      console.error('Error fetching users and banned list:', err);
    }
  };

  React.useEffect(() => {
    fetchUsersAndBanned();
  }, []);

  const handleDeleteAndBanUser = async () => {
    if (!deleteConfirmUser) return;
    setIsDeleting(true);
    setUserActionMessage(null);
    try {
      const res = await fetch('/api/users/delete-and-ban', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: deleteConfirmUser.id,
          email: deleteConfirmUser.email,
          username: deleteConfirmUser.username || deleteConfirmUser.name,
          reason: deleteReason || 'Akaun dipadam & disekat oleh Admin.',
        }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setUserActionMessage({ text: data.error || 'Gagal memadam akaun.', isError: true });
        return;
      }

      setUserActionMessage({ text: data.message || 'Akaun berjaya dipadam & disekat!', isError: false });
      setDeleteConfirmUser(null);
      setDeleteReason('');
      if (Array.isArray(data.users)) setLocalUsers(data.users);
      if (Array.isArray(data.bannedUsers)) setBannedUsersList(data.bannedUsers);
    } catch (err: any) {
      setUserActionMessage({ text: 'Ralat pelayan memadam akaun.', isError: true });
    } finally {
      setIsDeleting(false);
    }
  };

  const handleUnbanUser = async (id: string, email: string) => {
    try {
      const res = await fetch('/api/users/unban', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, email }),
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.bannedUsers)) {
        setBannedUsersList(data.bannedUsers);
        setUserActionMessage({ text: 'Sekatan akaun berjaya dibuka!', isError: false });
      }
    } catch (err) {
      console.error('Unban error:', err);
    }
  };

  const handleCopyAllEmails = () => {
    const emails = localUsers
      .map((u) => u.email)
      .filter((e): e is string => Boolean(e && e.includes('@')));
    if (emails.length === 0) {
      alert('Tiada emel untuk disalin.');
      return;
    }
    navigator.clipboard.writeText(emails.join(', '));
    setCopiedAllEmails(true);
    setTimeout(() => setCopiedAllEmails(false), 3000);
  };

  // Live Chat Admin States
  const [chatSessions, setChatSessions] = useState<Array<{
    sessionId: string;
    senderName: string;
    lastMessage: string;
    lastTime: string;
    unreadCount: number;
    messages: Array<{
      id: string;
      sessionId: string;
      sender: 'user' | 'admin';
      senderName: string;
      message: string;
      timestamp: string;
      read: boolean;
    }>;
  }>>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);
  const [adminReplyText, setAdminReplyText] = useState('');
  const [sendingReply, setSendingReply] = useState(false);

  const fetchAdminChats = async () => {
    try {
      const data = await safeFetchJson('/api/chat/messages?admin=true');
      if (data && Array.isArray(data.sessions)) {
        setChatSessions(data.sessions);
      }
    } catch (e) {
      console.error('Error fetching admin chats:', e);
    }
  };

  React.useEffect(() => {
    fetchAdminChats();
    const interval = setInterval(fetchAdminChats, 2500);
    return () => clearInterval(interval);
  }, [selectedSessionId]);

  const handleSendReply = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedSessionId || !adminReplyText.trim() || sendingReply) return;

    setSendingReply(true);
    try {
      const data = await safeFetchJson('/api/chat/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: selectedSessionId,
          sender: 'admin',
          senderName: 'Admin TopupBalz 🟢 24/7',
          message: adminReplyText.trim(),
        }),
      });
      if (data && data.success) {
        setAdminReplyText('');
        fetchAdminChats();
      }
    } catch (err) {
      console.error('Error sending admin reply:', err);
    } finally {
      setSendingReply(false);
    }
  };

  // Edit states
  const [editingGame, setEditingGame] = useState<Game | null>(null);
  const [gameToDelete, setGameToDelete] = useState<Game | null>(null);
  const [isDeletingGame, setIsDeletingGame] = useState(false);
  const [viewingProof, setViewingProof] = useState<string | null>(null);
  const [editingBanner, setEditingBanner] = useState<PromoBanner | null>(null);
  const [localSettings, setLocalSettings] = useState<SystemSettings>({ ...settings });
  const [orderStatusFilter, setOrderStatusFilter] = useState<'all' | Order['status']>('all');
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [gameSearchQuery, setGameSearchQuery] = useState('');
  const [gameCategoryFilter, setGameCategoryFilter] = useState<'all' | 'mobile' | 'pc' | 'voucher'>('all');
  const [chatSearchQuery, setChatSearchQuery] = useState('');

  // Telegram Channel Detection & Testing States
  const [isDetectingTg, setIsDetectingTg] = useState(false);
  const [isTestingTg, setIsTestingTg] = useState(false);
  const [tgTestResult, setTgTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [detectedTgChannels, setDetectedTgChannels] = useState<Array<{ id: string | number; title: string; type: string; username?: string }>>([]);

  // Flash Sale Handler Functions
  const persistFlashSale = async (updatedConfig: FlashSaleConfig, successMessage?: string) => {
    setLocalFlashSale(updatedConfig);
    try {
      if (onSaveFlashSale) {
        await onSaveFlashSale(updatedConfig);
      } else {
        const res = await safeFetchJson('/api/flash-sale', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updatedConfig),
        });
        if (res?.flashSale) {
          setLocalFlashSale(res.flashSale);
        }
      }
      if (successMessage) {
        setFlashSaleMsg({ text: successMessage, isError: false });
      }
    } catch (err: any) {
      console.error('Error saving flash sale:', err);
      setFlashSaleMsg({ text: '❌ Ralat menyimpan: ' + err.message, isError: true });
    }
  };

  const handleSaveFlashSaleConfig = async () => {
    setIsSavingFlashSale(true);
    setFlashSaleMsg(null);
    try {
      const h = Math.max(0, parseInt(durationHours || '0', 10) || 0);
      const m = Math.max(0, parseInt(durationMinutes || '0', 10) || 0);
      const s = Math.max(0, parseInt(durationSeconds || '0', 10) || 0);
      const totalMs = (h * 3600 + m * 60 + s) * 1000;
      const updatedConfig: FlashSaleConfig = {
        ...localFlashSale,
        endTime: totalMs > 0 ? new Date(Date.now() + totalMs).toISOString() : (localFlashSale.endTime || new Date(Date.now() + 24 * 3600 * 1000).toISOString()),
      };
      await persistFlashSale(updatedConfig, '✅ Tetapan Jualan Kilat berjaya disimpan & dikemaskini secara langsung!');
    } finally {
      setIsSavingFlashSale(false);
    }
  };

  const handleToggleFlashItemActive = (itemId: string) => {
    const updated: FlashSaleConfig = {
      ...localFlashSale,
      items: localFlashSale.items.map((it) => (it.id === itemId ? { ...it, isActive: !it.isActive } : it)),
    };
    persistFlashSale(updated, 'Status item dikemaskini');
  };

  const handleDeleteFlashItem = (itemId: string) => {
    const updated: FlashSaleConfig = {
      ...localFlashSale,
      items: localFlashSale.items.filter((it) => it.id !== itemId),
    };
    persistFlashSale(updated, '🗑️ Item berjaya dipadam dari jualan kilat!');
  };

  const handleAddNewFlashItem = () => {
    const targetGame = games.find((g) => g.id === selectedGameForNewItem) || games[0];
    if (!targetGame) return;

    const targetItem = targetGame.items.find((i) => i.id === selectedPackageForNewItem) || targetGame.items[0];
    if (!targetItem) return;

    const originalPrice = targetItem.sellPrice || targetItem.basePrice || 10;
    const flashPrice = Number(newFlashPrice) > 0 ? Number(newFlashPrice) : Math.max(0.5, Number((originalPrice * 0.85).toFixed(2)));
    const quota = Number(newMaxQuota) > 0 ? Number(newMaxQuota) : 20;

    const newItem: FlashSaleItem = {
      id: 'fs-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      gameId: targetGame.id,
      gameName: targetGame.name,
      gameLogoUrl: targetGame.logoUrl,
      itemId: targetItem.id,
      itemName: targetItem.name,
      originalPrice: Number(originalPrice.toFixed(2)),
      flashPrice: Number(flashPrice.toFixed(2)),
      savings: Number(Math.max(0, originalPrice - flashPrice).toFixed(2)),
      maxQuota: quota,
      soldCount: 0,
      isActive: true,
    };

    // Remove any existing flash sale for same exact game & item to prevent duplicates
    const filteredExisting = (localFlashSale.items || []).filter(
      (it) => !(it.gameId === targetGame.id && it.itemId === targetItem.id)
    );

    // Calculate end time if not currently set or if already expired
    let currentEndTime = localFlashSale.endTime;
    const isEndTimeValid = currentEndTime && new Date(currentEndTime).getTime() > Date.now();
    if (!isEndTimeValid) {
      const h = Math.max(0, parseInt(durationHours || '0', 10) || 0);
      const m = Math.max(0, parseInt(durationMinutes || '0', 10) || 0);
      const s = Math.max(0, parseInt(durationSeconds || '0', 10) || 0);
      const totalMs = (h * 3600 + m * 60 + s) * 1000;
      currentEndTime = new Date(Date.now() + (totalMs > 0 ? totalMs : 24 * 3600 * 1000)).toISOString();
    }

    const updated: FlashSaleConfig = {
      ...localFlashSale,
      isEnabled: true,
      endTime: currentEndTime,
      items: [newItem, ...filteredExisting],
    };

    setNewFlashPrice('');
    persistFlashSale(updated, `✅ Item "${newItem.itemName}" (${newItem.gameName}) berjaya ditambah ke jualan kilat!`);
  };

  // Supabase Database States
  const [supabaseStatus, setSupabaseStatus] = useState<{ connected: boolean; url: string; message?: string; tables?: any } | null>(null);
  const [isSyncingSupabase, setIsSyncingSupabase] = useState(false);
  const [supabaseSyncMsg, setSupabaseSyncMsg] = useState<{ success: boolean; text: string } | null>(null);
  const [copiedSupabaseSql, setCopiedSupabaseSql] = useState(false);

  const fetchSupabaseStatus = async () => {
    try {
      const data = await safeFetchJson('/api/supabase/status');
      if (data) setSupabaseStatus(data);
    } catch (e) {}
  };

  React.useEffect(() => {
    fetchSupabaseStatus();
  }, []);

  const handleSyncToSupabase = async () => {
    setIsSyncingSupabase(true);
    setSupabaseSyncMsg(null);
    try {
      const res = await fetch('/api/supabase/sync-all', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setSupabaseSyncMsg({
          success: true,
          text: `✓ ${data.message} (${data.synced?.games || 0} game, ${data.synced?.orders || 0} order, ${data.synced?.users || 0} user)`,
        });
        fetchSupabaseStatus();
      } else {
        setSupabaseSyncMsg({
          success: false,
          text: `Ralat sync: ${data.error || 'Sila pastikan skrip SQL telah dijalankan di Supabase'}`,
        });
      }
    } catch (err: any) {
      setSupabaseSyncMsg({
        success: false,
        text: `Ralat sambungan: ${err.message}`,
      });
    } finally {
      setIsSyncingSupabase(false);
    }
  };

  const handleCopySupabaseSql = async () => {
    try {
      const res = await fetch('/api/supabase/schema.sql');
      const text = await res.text();
      await navigator.clipboard.writeText(text);
      setCopiedSupabaseSql(true);
      setTimeout(() => setCopiedSupabaseSql(false), 3000);
    } catch (err) {
      alert('Sila salin fail supabase_schema.sql secara manual.');
    }
  };

  const handleDetectChannels = async () => {
    setIsDetectingTg(true);
    setTgTestResult(null);
    try {
      const res = await fetch('/api/telegram/detect-channel');
      const data = await res.json();
      if (data.detectedChannels && data.detectedChannels.length > 0) {
        setDetectedTgChannels(data.detectedChannels);
        const first = data.detectedChannels[0];
        const chosenId = first.username ? `@${first.username}` : String(first.id);
        setLocalSettings((prev) => ({ ...prev, telegramChannelId: chosenId }));
        setTgTestResult({
          success: true,
          message: `Berjaya mengesan ${data.detectedChannels.length} channel/grup! Saluran "${first.title}" (${chosenId}) telah dipilih dan dimasukkan secara automatik.`
        });
      } else {
        setTgTestResult({
          success: false,
          message: 'Tiada channel dikesan dalam log bot terkini. Sila hantar 1 mesej/post di dalam channel Telegram anda (atau pastikan @OrderBalz_bot dijadikan Admin), kemudian tekan butang ini semula.'
        });
      }
    } catch (e: any) {
      setTgTestResult({
        success: false,
        message: 'Gagal mengesan channel: ' + e.message
      });
    } finally {
      setIsDetectingTg(false);
    }
  };

  const handleTestChannel = async (target: string) => {
    if (!target || !target.trim()) {
      setTgTestResult({
        success: false,
        message: 'Sila masukkan Channel ID atau @username terlebih dahulu sebelum menguji.'
      });
      return;
    }
    setIsTestingTg(true);
    setTgTestResult(null);
    try {
      const res = await fetch('/api/telegram/test-channel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target }),
      });
      const data = await res.json();
      if (data.success) {
        setTgTestResult({
          success: true,
          message: data.message || 'Mesej ujian berjaya dihantar ke channel!'
        });
        const updated = { ...localSettings, telegramChannelId: target };
        setLocalSettings(updated);
        await onSaveSettings(updated);
      } else {
        setTgTestResult({
          success: false,
          message: data.error || 'Gagal menghantar ke channel.'
        });
      }
    } catch (e: any) {
      setTgTestResult({
        success: false,
        message: 'Ralat sambungan: ' + e.message
      });
    } finally {
      setIsTestingTg(false);
    }
  };

  const handleToggleStoreStatus = async () => {
    const isCurrentlyOpen = localSettings.isStoreOpen !== false;
    const nextState = !isCurrentlyOpen;
    const updated: SystemSettings = {
      ...localSettings,
      isStoreOpen: nextState,
    };
    setLocalSettings(updated);
    try {
      await onSaveSettings(updated);
    } catch (e) {
      console.error('Error toggling store status:', e);
    }
  };

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === ADMIN_PIN_CODE || pinInput.trim() === 'admin') {
      setIsUnlocked(true);
      setPinError(false);
    } else {
      setPinError(true);
    }
  };

  // If locked, show PIN prompt
  if (!isUnlocked) {
    return (
      <div className={isEmbedded ? "w-full my-4 bg-[#0D1117] border border-orange-500/40 rounded-3xl p-6 sm:p-8 space-y-6 text-center shadow-2xl" : "fixed inset-0 z-50 bg-black/90 backdrop-blur-lg flex items-center justify-center p-4 animate-fadeIn"}>
        <div className="w-full max-w-md bg-[#0D1117] border border-orange-500/40 rounded-3xl p-6 sm:p-8 space-y-6 text-center shadow-[0_0_50px_rgba(255,140,0,0.3)] mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-orange-500/10 border border-orange-500/40 text-orange-400 flex items-center justify-center mx-auto shadow-inner">
            <Lock className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-2xl font-black text-white">Pusat Kawalan Pentadbir</h2>
            <p className="text-xs text-slate-400 mt-1">Sila sahkan PIN keselamatan untuk membuka panel</p>
          </div>

          <form onSubmit={handleUnlock} className="space-y-4">
            <input
              type="password"
              placeholder="••••••"
              maxLength={6}
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
              className="w-full bg-[#121824] border border-slate-700 text-center font-mono text-xl tracking-widest text-white py-3 rounded-xl focus:outline-none focus:border-orange-500"
            />
            {pinError && (
              <p className="text-xs text-rose-400 font-bold">PIN keselamatan tidak sah. Sila semak semula.</p>
            )}

            <div className="flex gap-2">
              <button
                type="submit"
                className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 font-black text-xs uppercase rounded-xl shadow-lg cursor-pointer hover:from-orange-400 hover:to-amber-400"
              >
                Buka Panel Admin
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  // Filtered orders & games
  const filteredOrders = orders.filter((o) => {
    const matchesStatus = orderStatusFilter === 'all' || o.status === orderStatusFilter;
    const matchesSearch =
      !orderSearchQuery.trim() ||
      o.id.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
      o.gameName.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
      (o.userId && o.userId.toLowerCase().includes(orderSearchQuery.toLowerCase())) ||
      (o.whatsapp && o.whatsapp.includes(orderSearchQuery)) ||
      (o.items && o.items.some((i) => i.name.toLowerCase().includes(orderSearchQuery.toLowerCase())));
    return matchesStatus && matchesSearch;
  });

  const filteredGames = games.filter((g) => {
    const matchesCategory = gameCategoryFilter === 'all' || g.category === gameCategoryFilter;
    const matchesSearch =
      !gameSearchQuery.trim() ||
      g.name.toLowerCase().includes(gameSearchQuery.toLowerCase()) ||
      g.slug.toLowerCase().includes(gameSearchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className={isEmbedded ? "w-full min-h-screen bg-[#07090D] animate-fadeIn" : "fixed inset-0 z-50 overflow-hidden bg-[#07090D] flex flex-col animate-fadeIn"}>
      <div className="relative w-full h-full bg-[#0D1117] flex flex-col overflow-hidden">
        
        {/* Unified Clean Full-Screen Header Bar */}
        <header className="sticky top-0 z-30 bg-[#090C12]/95 backdrop-blur-xl px-3 sm:px-5 py-2.5 sm:py-3 border-b border-orange-500/30 flex items-center justify-between gap-3 shrink-0 shadow-lg">
          {activeTab === 'hub' ? (
            /* HUB TOP BAR: Back to Store + Title + Quick Actions */
            <>
              <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3.5 py-2 rounded-xl bg-orange-500 hover:bg-orange-400 text-slate-950 font-black text-xs flex items-center gap-2 transition-all shadow-[0_0_15px_rgba(255,140,0,0.4)] cursor-pointer shrink-0 active:scale-95"
                  title="Kembali ke Laman Kedai Utama"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Kembali ke Kedai</span>
                </button>

                <div className="hidden xs:flex items-center gap-2 min-w-0">
                  <span className="text-sm font-black text-white tracking-tight truncate">
                    Pusat Kawalan Admin
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 shrink-0">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Live
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {/* STORE STATUS TOGGLE BUTTON (ON / OFF) */}
                <button
                  type="button"
                  onClick={handleToggleStoreStatus}
                  className={`px-3 py-1.5 sm:py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all shadow-md cursor-pointer active:scale-95 border ${
                    localSettings.isStoreOpen !== false
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.4)]'
                      : 'bg-rose-600 hover:bg-rose-500 text-white border-rose-400 shadow-[0_0_15px_rgba(225,29,72,0.4)]'
                  }`}
                  title={localSettings.isStoreOpen !== false ? "Status: Kedai Buka (Pelanggan boleh order). Klik untuk tutup/maintenance." : "Status: Kedai Tutup (Maintenance). Klik untuk buka."}
                >
                  <span className={`w-2 h-2 rounded-full ${localSettings.isStoreOpen !== false ? 'bg-slate-950 animate-pulse' : 'bg-white animate-ping'}`} />
                  <span>{localSettings.isStoreOpen !== false ? 'KEDAI: ON' : 'KEDAI: OFF'}</span>
                </button>

                {onOpenGmailModal && (
                  <button
                    type="button"
                    onClick={() => onOpenGmailModal()}
                    className="px-3 py-1.5 sm:py-2 bg-red-500/15 hover:bg-red-500/25 text-red-300 border border-red-500/40 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                    title="Semak Emel & Resit via Gmail"
                  >
                    <Mail className="w-3.5 h-3.5 text-red-400" />
                    <span className="hidden sm:inline">Gmail Sync</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setEditingGame({
                      id: 'g_' + Date.now(),
                      name: '',
                      slug: '',
                      category: 'mobile',
                      serverType: 'none',
                      logoUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
                      idGuideText: 'Sila masukkan User ID anda.',
                      items: [
                        { id: 'item_1', name: '86 Diamonds', basePrice: 5.00, sellPrice: 6.00 },
                        { id: 'item_2', name: '172 Diamonds', basePrice: 10.00, sellPrice: 12.00 },
                        { id: 'item_3', name: '257 Diamonds', basePrice: 15.00, sellPrice: 18.00 },
                        { id: 'item_4', name: '706 Diamonds', basePrice: 40.00, sellPrice: 48.00 },
                      ]
                    });
                  }}
                  className="px-3 py-1.5 sm:py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span className="hidden xs:inline">Tambah Game</span>
                </button>
              </div>
            </>
          ) : (
            /* SUB-SECTION TOP BAR: Back to Hub + Section Title + Sub-actions */
            <>
              <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                <button
                  type="button"
                  onClick={() => setActiveTab('hub')}
                  className="px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 sm:gap-2 transition-all shadow-[0_0_15px_rgba(255,140,0,0.35)] cursor-pointer shrink-0 active:scale-95"
                  title="Kembali ke Menu Utama Admin"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Menu Utama</span>
                </button>

                <div className="min-w-0 flex items-center gap-2">
                  <span className="text-slate-600 font-mono hidden sm:inline">/</span>
                  <h2 className="text-xs sm:text-sm md:text-base font-black text-white truncate flex items-center gap-1.5 sm:gap-2">
                    {activeTab === 'games' && (
                      <>
                        <Gamepad2 className="w-4 h-4 text-orange-400 shrink-0" />
                        <span>Katalog &amp; Harga Game</span>
                        <span className="px-2 py-0.5 rounded-md bg-orange-500/20 text-orange-400 text-[10px] font-mono border border-orange-500/30">
                          {games.length}
                        </span>
                      </>
                    )}
                    {activeTab === 'orders' && (
                      <>
                        <ShoppingBag className="w-4 h-4 text-amber-400 shrink-0" />
                        <span>Pengurusan Pesanan &amp; Resit</span>
                        <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-400 text-[10px] font-mono border border-amber-500/30">
                          {orders.length}
                        </span>
                      </>
                    )}
                    {activeTab === 'chat' && (
                      <>
                        <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Live Chat Pelanggan 24/7</span>
                        <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10px] font-mono border border-emerald-500/30">
                          {chatSessions.length}
                        </span>
                      </>
                    )}
                    {activeTab === 'banners' && (
                      <>
                        <Sliders className="w-4 h-4 text-purple-400 shrink-0" />
                        <span>Banner &amp; Promosi Slider</span>
                        <span className="px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-400 text-[10px] font-mono border border-purple-500/30">
                          {banners.length}
                        </span>
                      </>
                    )}
                    {activeTab === 'settings' && (
                      <>
                        <Settings className="w-4 h-4 text-blue-400 shrink-0" />
                        <span>Tetapan Kedai &amp; QR Kod</span>
                      </>
                    )}
                    {activeTab === 'users' && (
                      <>
                        <Users className="w-4 h-4 text-cyan-400 shrink-0" />
                        <span>Pengguna &amp; Keselamatan</span>
                        <span className="px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-400 text-[10px] font-mono border border-cyan-500/30">
                          {users.length}
                        </span>
                      </>
                    )}
                    {activeTab === 'flash_sale' && (
                      <>
                        <Zap className="w-4 h-4 text-amber-400 fill-amber-400 shrink-0" />
                        <span>Kawalan Jualan Kilat (Flash Sale)</span>
                      </>
                    )}
                    {activeTab === 'gambar_tf' && (
                      <>
                        <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Gambar Tf (Generator Resit Penghantaran)</span>
                        <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10px] font-mono border border-emerald-500/30">
                          BalzLtd
                        </span>
                      </>
                    )}
                  </h2>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {/* STORE STATUS TOGGLE BUTTON (ON / OFF) */}
                <button
                  type="button"
                  onClick={handleToggleStoreStatus}
                  className={`px-3 py-1.5 sm:py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all shadow-md cursor-pointer active:scale-95 border ${
                    localSettings.isStoreOpen !== false
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.4)]'
                      : 'bg-rose-600 hover:bg-rose-500 text-white border-rose-400 shadow-[0_0_15px_rgba(225,29,72,0.4)]'
                  }`}
                  title={localSettings.isStoreOpen !== false ? "Status: Kedai Buka (Pelanggan boleh order). Klik untuk tutup/maintenance." : "Status: Kedai Tutup (Maintenance). Klik untuk buka."}
                >
                  <span className={`w-2 h-2 rounded-full ${localSettings.isStoreOpen !== false ? 'bg-slate-950 animate-pulse' : 'bg-white animate-ping'}`} />
                  <span>{localSettings.isStoreOpen !== false ? 'KEDAI: ON' : 'KEDAI: OFF'}</span>
                </button>

                {activeTab === 'games' && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingGame({
                        id: 'g_' + Date.now(),
                        name: '',
                        slug: '',
                        category: 'mobile',
                        serverType: 'none',
                        logoUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
                        idGuideText: 'Sila masukkan User ID anda.',
                        items: [
                          { id: 'item_1', name: '86 Diamonds', basePrice: 5.00, sellPrice: 6.00 },
                          { id: 'item_2', name: '172 Diamonds', basePrice: 10.00, sellPrice: 12.00 },
                          { id: 'item_3', name: '257 Diamonds', basePrice: 15.00, sellPrice: 18.00 },
                          { id: 'item_4', name: '706 Diamonds', basePrice: 40.00, sellPrice: 48.00 },
                        ]
                      });
                    }}
                    className="px-3 py-1.5 sm:px-3.5 sm:py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span className="hidden xs:inline">Tambah Game</span>
                  </button>
                )}
                {activeTab === 'banners' && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingBanner({
                        id: 'banner_' + Date.now(),
                        title: '',
                        image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
                        active: true,
                        tag: 'PROMO',
                        subtitle: ''
                      });
                    }}
                    className="px-3 py-1.5 sm:px-3.5 sm:py-2 bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-black text-xs rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span className="hidden xs:inline">Tambah Banner</span>
                  </button>
                )}
              </div>
            </>
          )}
        </header>

        {/* Full-Screen Tab Contents Area */}
        <div className="p-3.5 sm:p-6 overflow-y-auto flex-1 space-y-6">

          {/* TAB 0: ADMIN COMMAND HUB (PUSAT PILIHAN MENU ADMIN - SEPERTI PILIHAN TOPUP) */}
          {/* TAB 0: ADMIN COMMAND HUB (PUSAT PILIHAN MENU ADMIN - AESTHETIC & TERATUR) */}
          {activeTab === 'hub' && (
            <div className="space-y-6 animate-fadeIn pb-12">
              {/* Header Hero Banner with Glowing Accents */}
              <div className="relative overflow-hidden p-5 sm:p-7 rounded-3xl bg-gradient-to-br from-[#131A29] via-[#0E1422] to-[#080B12] border border-orange-500/30 shadow-[0_10px_40px_rgba(0,0,0,0.6)]">
                <div className="absolute top-0 right-0 -mt-10 -mr-10 w-72 h-72 bg-gradient-to-br from-orange-500/15 to-amber-500/5 rounded-full blur-3xl pointer-events-none" />
                <div className="absolute bottom-0 left-1/3 -mb-12 w-60 h-60 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
                
                <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-3 py-1 rounded-full text-[11px] font-black uppercase tracking-wider bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-sm flex items-center gap-1.5">
                        <Sparkles className="w-3 h-3 text-orange-400" />
                        Pusat Kawalan TopupBalz
                      </span>
                      <span className={`px-3 py-1 rounded-full text-[11px] font-mono font-black border flex items-center gap-1.5 ${
                        localSettings.isStoreOpen !== false
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 shadow-[0_0_12px_rgba(16,185,129,0.25)]'
                          : 'bg-rose-500/15 text-rose-300 border-rose-500/40'
                      }`}>
                        <span className={`w-2 h-2 rounded-full ${localSettings.isStoreOpen !== false ? 'bg-emerald-400 animate-ping' : 'bg-rose-400'}`} />
                        {localSettings.isStoreOpen !== false ? 'Kedai Sedang Dibuka' : 'Kedai Ditutup (Maintenance)'}
                      </span>
                    </div>

                    <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                      Pusat Pengurusan <span className="bg-gradient-to-r from-orange-400 via-amber-300 to-yellow-400 bg-clip-text text-transparent">TopupBalz</span>
                    </h2>
                    <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                      Pilih mana-mana modul di bawah untuk menguruskan harga game, pesanan pembeli, live chat, promosi jualan kilat, dan bukti transfer secara teratur.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => setActiveTab('games')}
                      className="px-4 py-2.5 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-2xl shadow-lg shadow-orange-500/20 flex items-center gap-2 cursor-pointer transition-all active:scale-95"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                      <span>+ Tambah Game</span>
                    </button>
                    {onOpenGmailModal && (
                      <button
                        type="button"
                        onClick={() => onOpenGmailModal()}
                        className="px-4 py-2.5 bg-[#161F30] hover:bg-[#1E2B42] text-slate-200 hover:text-white font-bold text-xs rounded-2xl border border-slate-700/80 flex items-center gap-2 cursor-pointer transition-all active:scale-95"
                      >
                        <Mail className="w-4 h-4 text-cyan-400" />
                        <span>Semak Resit Emel</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Quick High-Level Statistics Strip */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                {/* 1. Total Gross Sales */}
                <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-[#141C2B] to-[#0D121D] border border-emerald-500/30 shadow-md flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0 shadow-inner">
                    <DollarSign className="w-5 h-5 font-black" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[10px] sm:text-[11px] font-bold text-slate-400 uppercase tracking-wider truncate">
                      Jumlah Jualan
                    </p>
                    <p className="text-lg sm:text-xl font-black text-emerald-400 font-mono truncate">
                      RM {orders.filter(o => o.status === 'completed').reduce((sum, o) => sum + (o.sellPrice || 0), 0).toFixed(2)}
                    </p>
                  </div>
                </div>

                {/* 2. Pending & Processing Orders */}
                <div 
                  onClick={() => setActiveTab('orders')}
                  className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-[#141C2B] to-[#0D121D] border border-amber-500/30 shadow-md flex items-center gap-3.5 cursor-pointer hover:border-amber-400 transition-colors"
                >
                  <div className="w-11 h-11 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0 shadow-inner">
                    <ShoppingBag className="w-5 h-5 font-black" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[10px] sm:text-[11px] font-bold text-slate-400 uppercase tracking-wider truncate">
                      Perlu Diproses
                    </p>
                    <p className="text-lg sm:text-xl font-black text-amber-400 font-mono truncate flex items-center gap-1.5">
                      <span>{orders.filter(o => o.status === 'pending' || o.status === 'processing').length}</span>
                      <span className="text-[10px] font-bold text-slate-400">pesanan</span>
                    </p>
                  </div>
                </div>

                {/* 3. Total Users */}
                <div 
                  onClick={() => setActiveTab('users')}
                  className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-[#141C2B] to-[#0D121D] border border-cyan-500/30 shadow-md flex items-center gap-3.5 cursor-pointer hover:border-cyan-400 transition-colors"
                >
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/15 border border-cyan-500/40 text-cyan-400 flex items-center justify-center shrink-0 shadow-inner">
                    <Users className="w-5 h-5 font-black" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[10px] sm:text-[11px] font-bold text-slate-400 uppercase tracking-wider truncate">
                      Pengguna Berdaftar
                    </p>
                    <p className="text-lg sm:text-xl font-black text-cyan-400 font-mono truncate">
                      {users.length} Akaun
                    </p>
                  </div>
                </div>

                {/* 4. Live Chat Unread */}
                <div 
                  onClick={() => setActiveTab('chat')}
                  className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-[#141C2B] to-[#0D121D] border border-purple-500/30 shadow-md flex items-center gap-3.5 cursor-pointer hover:border-purple-400 transition-colors"
                >
                  <div className="w-11 h-11 rounded-xl bg-purple-500/15 border border-purple-500/40 text-purple-400 flex items-center justify-center shrink-0 shadow-inner">
                    <MessageCircle className="w-5 h-5 font-black" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[10px] sm:text-[11px] font-bold text-slate-400 uppercase tracking-wider truncate">
                      Live Chat 24/7
                    </p>
                    <p className="text-lg sm:text-xl font-black text-purple-300 font-mono truncate">
                      {chatSessions.length} Chat
                    </p>
                  </div>
                </div>
              </div>

              {/* Visual Selection Grid (Aesthetic Module Cards) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
                
                {/* 1. Pengurusan Game & Harga */}
                <div
                  onClick={() => setActiveTab('games')}
                  className="group relative bg-gradient-to-b from-[#151D2C] to-[#0D121D] border-2 border-slate-800/90 hover:border-orange-500/80 rounded-3xl p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(255,140,0,0.22)] hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-orange-500 to-amber-400 text-slate-950 flex items-center justify-center shadow-lg shadow-orange-500/30 group-hover:scale-110 transition-transform">
                        <Gamepad2 className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono bg-orange-500/20 text-orange-400 border border-orange-500/40">
                        {games.length} Game Aktif
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-white group-hover:text-orange-400 transition-colors">
                        Senarai &amp; Harga Game
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        Urus poster logo, nama game, kategori, format ID akaun, serta pakej harga jualan &amp; modal.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-slate-300 text-[10px] font-mono border border-slate-800">
                        🎮 Poster Grid
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-emerald-400 text-[10px] font-mono border border-slate-800">
                        💰 Untung Bersih
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-black text-orange-400">
                    <span>Urus Game Sekarang</span>
                    <span className="group-hover:translate-x-1 transition-transform">➔</span>
                  </div>
                </div>

                {/* 2. Pengurusan Pesanan & Resit */}
                <div
                  onClick={() => setActiveTab('orders')}
                  className="group relative bg-gradient-to-b from-[#151D2C] to-[#0D121D] border-2 border-slate-800/90 hover:border-amber-500/80 rounded-3xl p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(245,158,11,0.22)] hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-500/30 group-hover:scale-110 transition-transform">
                        <ShoppingBag className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                        {orders.filter(o => o.status === 'pending' || o.status === 'processing').length} Menunggu
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-white group-hover:text-amber-400 transition-colors">
                        Pengurusan Pesanan &amp; Resit
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        Semak bukti bayaran resit pelanggan, sahkan transaksi topup dan tukar status pesanan.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-slate-300 text-[10px] font-mono border border-slate-800">
                        📦 {orders.length} Transaksi
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-cyan-400 text-[10px] font-mono border border-slate-800">
                        📑 Semak Resit
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-black text-amber-400">
                    <span>Semak Pesanan</span>
                    <span className="group-hover:translate-x-1 transition-transform">➔</span>
                  </div>
                </div>

                {/* 3. Live Chat Pelanggan 24/7 */}
                <div
                  onClick={() => setActiveTab('chat')}
                  className="group relative bg-gradient-to-b from-[#151D2C] to-[#0D121D] border-2 border-slate-800/90 hover:border-emerald-500/80 rounded-3xl p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(16,185,129,0.22)] hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/30 group-hover:scale-110 transition-transform">
                        <MessageCircle className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        {chatSessions.reduce((acc, s) => acc + s.unreadCount, 0) > 0 ? `${chatSessions.reduce((acc, s) => acc + s.unreadCount, 0)} Mesej Baru` : `${chatSessions.length} Perbualan`}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-white group-hover:text-emerald-400 transition-colors">
                        Live Chat &amp; Bantuan 24/7
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        Balas pertanyaan pelanggan secara langsung dengan templat balasan pantas &amp; semakan chat ID.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-emerald-400 text-[10px] font-mono border border-slate-800">
                        ⚡ Balas Pantas
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-slate-300 text-[10px] font-mono border border-slate-800">
                        💬 Realtime Sync
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-black text-emerald-400">
                    <span>Buka Live Chat</span>
                    <span className="group-hover:translate-x-1 transition-transform">➔</span>
                  </div>
                </div>

                {/* 4. Banner & Promosi Laman Utama */}
                <div
                  onClick={() => setActiveTab('banners')}
                  className="group relative bg-gradient-to-b from-[#151D2C] to-[#0D121D] border-2 border-slate-800/90 hover:border-purple-500/80 rounded-3xl p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(168,85,247,0.22)] hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-500 to-indigo-500 text-white flex items-center justify-center shadow-lg shadow-purple-500/30 group-hover:scale-110 transition-transform">
                        <Sliders className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono bg-purple-500/20 text-purple-300 border border-purple-500/40">
                        {banners.length} Slaid Aktif
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-white group-hover:text-purple-400 transition-colors">
                        Banner &amp; Promosi Slider
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        Tukar gambar slaid depan dari galeri telefon/PC atau pilih templat preset poster rasmi game.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-purple-300 text-[10px] font-mono border border-slate-800">
                        🖼️ Muat Naik Galeri
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-slate-300 text-[10px] font-mono border border-slate-800">
                        🎯 Auto-Slide Depan
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-black text-purple-400">
                    <span>Urus Banner Promo</span>
                    <span className="group-hover:translate-x-1 transition-transform">➔</span>
                  </div>
                </div>

                {/* 5. Jualan Kilat (Flash Sale) */}
                <div
                  onClick={() => setActiveTab('flash_sale')}
                  className="group relative bg-gradient-to-b from-[#151D2C] to-[#0D121D] border-2 border-slate-800/90 hover:border-amber-500/80 rounded-3xl p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(249,115,22,0.22)] hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-red-500 text-slate-950 flex items-center justify-center shadow-lg shadow-orange-500/30 group-hover:scale-110 transition-transform">
                        <Zap className="w-6 h-6 fill-current animate-pulse" />
                      </div>
                      <span className={`px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono ${
                        localFlashSale?.isEnabled 
                          ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40' 
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}>
                        {localFlashSale?.isEnabled ? '🔥 Live Aktif' : '⏸️ Tidak Aktif'}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-white group-hover:text-orange-400 transition-colors">
                        Jualan Kilat (Flash Sale)
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        Kawal countdown timer, diskaun harga promosi, serta tetapkan had kuota maksimum pembeli.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-amber-300 text-[10px] font-mono border border-slate-800">
                        ⚡ {localFlashSale?.items?.length || 0} Pakej Diskaun
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-slate-300 text-[10px] font-mono border border-slate-800">
                        ⏱️ Countdown Timer
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-black text-amber-400">
                    <span>Tetapan Flash Sale</span>
                    <span className="group-hover:translate-x-1 transition-transform">➔</span>
                  </div>
                </div>

                {/* 6. Pengurusan Pengguna & Akaun */}
                <div
                  onClick={() => setActiveTab('users')}
                  className="group relative bg-gradient-to-b from-[#151D2C] to-[#0D121D] border-2 border-slate-800/90 hover:border-cyan-500/80 rounded-3xl p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(6,182,212,0.22)] hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-teal-400 text-slate-950 flex items-center justify-center shadow-lg shadow-cyan-500/30 group-hover:scale-110 transition-transform">
                        <Users className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                        {users.length} Akaun
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-white group-hover:text-cyan-400 transition-colors">
                        Pengguna &amp; Keselamatan
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        Lihat profil pembeli, sejarah perbelanjaan, sekat akaun scammer &amp; salin emel berdaftar.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-cyan-300 text-[10px] font-mono border border-slate-800">
                        👤 Profil Pembeli
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-rose-400 text-[10px] font-mono border border-slate-800">
                        🚫 Sekat Scammer
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-black text-cyan-400">
                    <span>Urus Pengguna</span>
                    <span className="group-hover:translate-x-1 transition-transform">➔</span>
                  </div>
                </div>

                {/* 7. Tetapan Kedai & QR DuitNow / TNG */}
                <div
                  onClick={() => setActiveTab('settings')}
                  className="group relative bg-gradient-to-b from-[#151D2C] to-[#0D121D] border-2 border-slate-800/90 hover:border-blue-500/80 rounded-3xl p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(59,130,246,0.22)] hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-500 to-cyan-500 text-white flex items-center justify-center shadow-lg shadow-blue-500/30 group-hover:scale-110 transition-transform">
                        <Settings className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono bg-blue-500/20 text-blue-300 border border-blue-500/40">
                        QR TNG Sedia
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-white group-hover:text-blue-400 transition-colors">
                        Tetapan Kedai &amp; QR Kod
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        Muat naik gambar QR DuitNow/Touch 'n Go dari galeri, nombor WhatsApp owner &amp; bot Telegram.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-blue-300 text-[10px] font-mono border border-slate-800">
                        📱 Touch 'n Go &amp; DuitNow
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-slate-300 text-[10px] font-mono border border-slate-800">
                        📢 Telegram Bot
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-black text-blue-400">
                    <span>Kemaskini Tetapan</span>
                    <span className="group-hover:translate-x-1 transition-transform">➔</span>
                  </div>
                </div>

                {/* 8. Integrasi Gmail Auto-Sync */}
                <div
                  onClick={() => onOpenGmailModal ? onOpenGmailModal() : setActiveTab('settings')}
                  className="group relative bg-gradient-to-b from-[#151D2C] to-[#0D121D] border-2 border-slate-800/90 hover:border-rose-500/80 rounded-3xl p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(244,63,94,0.22)] hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-500 to-red-500 text-white flex items-center justify-center shadow-lg shadow-rose-500/30 group-hover:scale-110 transition-transform">
                        <Mail className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono bg-rose-500/20 text-rose-300 border border-rose-500/40">
                        Auto-Sync Resit
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-white group-hover:text-rose-400 transition-colors">
                        Integrasi Emel &amp; Resit Bank
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        Sambungkan Gmail untuk mengesan resit rasmi bank secara automatik bagi mengelakkan penipuan.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-rose-300 text-[10px] font-mono border border-slate-800">
                        📧 Gmail Sync
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-emerald-400 text-[10px] font-mono border border-slate-800">
                        🛡️ Anti-Scam
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-black text-rose-400">
                    <span>Buka Integrasi Emel</span>
                    <span className="group-hover:translate-x-1 transition-transform">➔</span>
                  </div>
                </div>

                {/* 9. Generator Gambar Tf (Bukti Resit Penghantaran Duit) */}
                <div
                  onClick={() => setActiveTab('gambar_tf')}
                  className="group relative bg-gradient-to-b from-[#151D2C] to-[#0D121D] border-2 border-emerald-500/50 hover:border-emerald-400 rounded-3xl p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(16,185,129,0.3)] hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/30 group-hover:scale-110 transition-transform">
                        <Smartphone className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        📸 Penjana Resit
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-white group-hover:text-emerald-400 transition-colors flex items-center gap-1.5">
                        <span>Gambar Tf</span>
                        <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono">BARU</span>
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        Jana gambar bukti transfer (Touch 'n Go eWallet) dengan harga boleh diedit, penerima BalzLtd &amp; waktu Malaysia.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-emerald-400 text-[10px] font-mono border border-slate-800">
                        💵 Edit RM Suka Hati
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900/90 text-cyan-300 text-[10px] font-mono border border-slate-800">
                        ⚡ BalzLtd
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-black text-emerald-400">
                    <span>Buka Gambar Tf</span>
                    <span className="group-hover:translate-x-1 transition-transform">➔</span>
                  </div>
                </div>

              </div>
            </div>
          )}
          
          {/* TAB 1: GAMES & PRICING */}
          {activeTab === 'games' && (
            <div className="space-y-6">
              
              {/* Formula Highlight Banner */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-orange-500/15 via-amber-500/10 to-orange-500/15 border border-orange-500/40 text-xs text-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
                <div className="space-y-0.5">
                  <span className="font-bold text-orange-400 block uppercase font-mono">
                    ⚙️ PENGURUSAN PRODUK & HARGA JUALAN
                  </span>
                  <p className="text-xs text-slate-300">
                    Kawal senarai game, kategori, input format ID akaun, dan margin keuntungan terus dari sini.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    setEditingGame({
                      id: 'g_' + Date.now(),
                      name: '',
                      slug: '',
                      category: 'mobile',
                      serverType: 'none',
                      logoUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
                      idGuideText: 'Sila masukkan User ID anda.',
                      items: [
                        { id: 'item_1', name: '86 Diamonds', basePrice: 5.00, sellPrice: 6.00 },
                      ],
                    })
                  }
                  className="w-full sm:w-auto px-4 py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase rounded-xl shadow-md flex items-center justify-center gap-1.5 shrink-0 cursor-pointer transition-transform active:scale-95"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Tambah Game Baru</span>
                </button>
              </div>

              {/* Games Search & Category Bar */}
              <div className="bg-[#121824] p-3 rounded-2xl border border-slate-800/90 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 shadow-sm">
                <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-0.5">
                  {(
                    [
                      { id: 'all', label: 'Semua Kategori', count: games.length },
                      { id: 'mobile', label: '🎮 Mobile', count: games.filter((g) => g.category === 'mobile').length },
                      { id: 'pc', label: '💻 PC Game', count: games.filter((g) => g.category === 'pc').length },
                      { id: 'voucher', label: '🎟️ Voucher', count: games.filter((g) => g.category === 'voucher').length },
                    ] as const
                  ).map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setGameCategoryFilter(cat.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                        gameCategoryFilter === cat.id
                          ? 'bg-orange-500 text-slate-950 font-black shadow-md'
                          : 'bg-slate-900/90 text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      <span>{cat.label}</span>
                      <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${
                        gameCategoryFilter === cat.id ? 'bg-slate-950/30 text-slate-950' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {cat.count}
                      </span>
                    </button>
                  ))}
                </div>

                <div className="relative w-full md:w-64 shrink-0">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={gameSearchQuery}
                    onChange={(e) => setGameSearchQuery(e.target.value)}
                    placeholder="Cari nama game..."
                    className="w-full bg-[#0D1117] border border-slate-700/80 rounded-xl pl-9 pr-8 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                  />
                  {gameSearchQuery && (
                    <button
                      onClick={() => setGameSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Game Editor - Dedicated Full Screen Mode */}
              {editingGame && (
                <div className="fixed inset-0 z-[120] bg-[#070A12] text-white flex flex-col overflow-hidden animate-fadeIn">
                  {/* Top Sticky Header Bar */}
                  <header className="sticky top-0 z-30 bg-[#0C101A]/95 backdrop-blur-md border-b border-slate-800/90 px-4 sm:px-6 py-3 flex items-center justify-between gap-3 sm:gap-4 shadow-xl shrink-0">
                    <div className="flex items-center gap-3 min-w-0">
                      <button
                        type="button"
                        onClick={() => setEditingGame(null)}
                        className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer shrink-0"
                      >
                        <ArrowLeft className="w-4 h-4" />
                        <span className="hidden sm:inline">Kembali</span>
                      </button>

                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl overflow-hidden bg-slate-900 border border-orange-500/50 shrink-0">
                          <img
                            src={editingGame.logoUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=200&q=80'}
                            alt={editingGame.name}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=200&q=80';
                            }}
                          />
                        </div>
                        <div className="min-w-0">
                          <h2 className="font-extrabold text-white text-sm sm:text-base truncate flex items-center gap-2">
                            <span>{editingGame.name || 'Game Baru Tanpa Nama'}</span>
                            <span className="text-[10px] font-mono uppercase bg-orange-500/20 text-orange-400 border border-orange-500/30 px-2 py-0.5 rounded-md hidden xs:inline">
                              {editingGame.category}
                            </span>
                          </h2>
                          <p className="text-[10px] sm:text-xs text-slate-400 truncate">
                            {editingGame.items.length} Pakej Topup • Skrin Penuh Editor (Full Screen)
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                      {/* Delete Button */}
                      {editingGame.id && games.some((g) => g.id === editingGame.id) && (
                        <button
                          type="button"
                          onClick={() => {
                            setGameToDelete(editingGame);
                            setEditingGame(null);
                          }}
                          className="p-2 sm:px-3 sm:py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                          title="Padam Game Ini"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span className="hidden md:inline">Padam Game</span>
                        </button>
                      )}

                      {/* Save Button */}
                      <button
                        type="button"
                        onClick={async () => {
                          let finalLogoUrl = editingGame.logoUrl;
                          if (finalLogoUrl && finalLogoUrl.startsWith('data:image/')) {
                            finalLogoUrl = await compressImage(finalLogoUrl, 800, 0.75);
                          }
                          const sanitizedGame: Game = {
                            ...editingGame,
                            name: editingGame.name || 'Game Baru',
                            slug: editingGame.slug || (editingGame.name || 'game-baru').toLowerCase().replace(/\s+/g, '-'),
                            logoUrl: finalLogoUrl,
                            items: editingGame.items.map((it) => ({
                              ...it,
                              basePrice: typeof it.basePrice === 'string' ? parseFloat(it.basePrice) || 0 : Number(it.basePrice) || 0,
                              sellPrice: typeof it.sellPrice === 'string' ? parseFloat(it.sellPrice) || 0 : Number(it.sellPrice) || 0,
                            })),
                          };
                          await onSaveGame(sanitizedGame);
                          setEditingGame(null);
                        }}
                        className="px-4 sm:px-6 py-2 sm:py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wide rounded-xl shadow-[0_0_20px_rgba(255,140,0,0.5)] flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Save className="w-4 h-4" />
                        <span>Simpan Game</span>
                      </button>
                    </div>
                  </header>

                  {/* Full Screen Main Body: 2-Column Responsive Workspace */}
                  <div className="flex-1 overflow-y-auto p-3 sm:p-6 lg:p-8 scrollbar-thin">
                    <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-start pb-24 sm:pb-12">
                      
                      {/* Left Column (4 Cols): Game Art, Preset Logos, Basic Info, Server Configuration */}
                      <div className="lg:col-span-4 space-y-4">
                        {/* 1. Poster & Logo Card */}
                        <div className="bg-[#0E131F] border border-slate-800 rounded-3xl p-4 sm:p-5 space-y-4 shadow-md">
                          <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                            <ImageIcon className="w-4 h-4 text-orange-400" />
                            <span>Poster / Logo Game</span>
                          </h3>

                          {/* Live Poster Preview */}
                          <div className="relative aspect-[4/5] w-full rounded-2xl overflow-hidden bg-slate-950 border-2 border-orange-500/50 shadow-lg group">
                            <img
                              src={editingGame.logoUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80'}
                              alt={editingGame.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80';
                              }}
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent flex items-end p-3.5">
                              <span className="text-[11px] font-bold text-amber-300 bg-black/80 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-amber-500/30">
                                {editingGame.name || 'Pratonton Poster'}
                              </span>
                            </div>
                          </div>

                          {/* Upload from Gallery Button */}
                          <div>
                            <label className="w-full py-2.5 px-4 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md transition-all">
                              <Upload className="w-4 h-4 text-slate-950" />
                              <span>📁 Pilih Poster Dari Galeri Telefon / PC</span>
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={async (e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    try {
                                      const compressed = await compressImage(file, 800, 0.75);
                                      setEditingGame({ ...editingGame, logoUrl: compressed });
                                    } catch (err) {
                                      console.error('Error reading image:', err);
                                    }
                                  }
                                }}
                              />
                            </label>
                            <span className="text-[10px] text-slate-400 mt-1.5 block text-center">
                              Auto-compress untuk muat naik pantas & paparan tajam
                            </span>
                          </div>

                          {/* Official Game Logo Presets Gallery */}
                          <div className="space-y-2 pt-2 border-t border-slate-800/80">
                            <label className="text-[11px] font-bold text-slate-300 block">
                              Atau Pilih Dari Preset Logo Game Rasmi:
                            </label>
                            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5 max-h-48 overflow-y-auto scrollbar-thin pr-0.5">
                              {[
                                { name: 'MLBB', url: 'https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?auto=format&fit=crop&w=600&q=80' },
                                { name: 'Free Fire', url: 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?auto=format&fit=crop&w=600&q=80' },
                                { name: 'PUBG', url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80' },
                                { name: 'FC Mobile', url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=600&q=80' },
                                { name: 'HOK', url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=600&q=80' },
                                { name: 'Genshin', url: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=600&q=80' },
                                { name: 'Roblox', url: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=600&q=80' },
                                { name: 'Valorant', url: 'https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&w=600&q=80' },
                                { name: 'CODM', url: 'https://images.unsplash.com/photo-1580234811497-9df7fd2f357e?auto=format&fit=crop&w=600&q=80' },
                                { name: 'Blood Strike', url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80' },
                                { name: 'Brawl Stars', url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=600&q=80' },
                                { name: 'Steam MYR', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80' },
                                { name: 'Google Play', url: 'https://images.unsplash.com/photo-1556742049-0a67daf4005a?auto=format&fit=crop&w=600&q=80' },
                              ].map((preset) => (
                                <button
                                  key={preset.name}
                                  type="button"
                                  onClick={() => setEditingGame({ ...editingGame, logoUrl: preset.url })}
                                  className={`p-1.5 rounded-xl border text-[10px] font-bold text-center truncate transition-all cursor-pointer ${
                                    editingGame.logoUrl === preset.url
                                      ? 'bg-orange-500 text-slate-950 border-orange-400 font-extrabold shadow-sm'
                                      : 'bg-slate-900 text-slate-300 border-slate-700/80 hover:border-orange-500/50'
                                  }`}
                                >
                                  {preset.name}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Direct URL input */}
                          <div>
                            <label className="text-[10px] text-slate-400 font-mono font-bold block mb-1">
                              URL Gambar Terus:
                            </label>
                            <input
                              type="text"
                              value={editingGame.logoUrl || ''}
                              onChange={(e) => setEditingGame({ ...editingGame, logoUrl: e.target.value })}
                              placeholder="https://..."
                              className="w-full bg-[#080B12] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                            />
                          </div>
                        </div>

                        {/* 2. Basic Info & Server Settings */}
                        <div className="bg-[#0E131F] border border-slate-800 rounded-3xl p-4 sm:p-5 space-y-3.5 shadow-md">
                          <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                            <Gamepad2 className="w-4 h-4 text-orange-400" />
                            <span>Maklumat & Format ID Game</span>
                          </h3>

                          <div>
                            <label className="block text-slate-300 font-bold text-xs mb-1">Nama Game</label>
                            <input
                              type="text"
                              value={editingGame.name}
                              onChange={(e) =>
                                setEditingGame({
                                  ...editingGame,
                                  name: e.target.value,
                                  slug: e.target.value.toLowerCase().replace(/\s+/g, '-'),
                                })
                              }
                              placeholder="Contoh: Mobile Legends: Bang Bang"
                              className="w-full bg-[#080B12] border border-slate-700 rounded-xl p-2.5 text-white font-extrabold text-xs focus:outline-none focus:border-orange-500"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-2.5">
                            <div>
                              <label className="block text-slate-300 font-bold text-xs mb-1">Kategori</label>
                              <select
                                value={editingGame.category}
                                onChange={(e) => setEditingGame({ ...editingGame, category: e.target.value as any })}
                                className="w-full bg-[#080B12] border border-slate-700 rounded-xl p-2.5 text-white font-bold text-xs focus:outline-none focus:border-orange-500"
                              >
                                <option value="mobile">🎮 Mobile</option>
                                <option value="pc">💻 PC Game</option>
                                <option value="voucher">🎟️ Voucher</option>
                              </select>
                            </div>

                            <div>
                              <label className="block text-slate-300 font-bold text-xs mb-1">Jenis ID / Server</label>
                              <select
                                value={editingGame.serverType}
                                onChange={(e) => setEditingGame({ ...editingGame, serverType: e.target.value as any })}
                                className="w-full bg-[#080B12] border border-slate-700 rounded-xl p-2.5 text-white font-bold text-xs focus:outline-none focus:border-orange-500"
                              >
                                <option value="none">User ID Sahaja</option>
                                <option value="zone_id">Zone ID (MLBB)</option>
                                <option value="server_list">Senarai Server (Genshin)</option>
                                <option value="tag">Tagline (Valorant)</option>
                              </select>
                            </div>
                          </div>

                          <div>
                            <label className="block text-slate-300 font-bold text-xs mb-1">Teks Panduan ID Pengguna</label>
                            <textarea
                              rows={2}
                              value={editingGame.idGuideText || ''}
                              onChange={(e) => setEditingGame({ ...editingGame, idGuideText: e.target.value })}
                              placeholder="Contoh: Sila masukkan User ID dan Zone ID anda..."
                              className="w-full bg-[#080B12] border border-slate-700 rounded-xl p-2.5 text-white text-xs focus:outline-none focus:border-orange-500 resize-none"
                            />
                          </div>

                          <div>
                            <label className="block text-slate-300 font-bold text-xs mb-1">Badge Label Atas Poster (Pilihan)</label>
                            <input
                              type="text"
                              value={editingGame.badgeText || ''}
                              onChange={(e) => setEditingGame({ ...editingGame, badgeText: e.target.value })}
                              placeholder="Contoh: 🔥 Top Up, 🎁 Via Gift, ⭐ PerStar Boost"
                              className="w-full bg-[#080B12] border border-slate-700 rounded-xl p-2.5 text-amber-300 font-bold text-xs focus:outline-none focus:border-orange-500"
                            />
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                            <label className="flex items-center gap-2 p-2 rounded-xl bg-orange-500/10 border border-orange-500/30 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={editingGame.isMostSearched || false}
                                onChange={(e) => setEditingGame({ ...editingGame, isMostSearched: e.target.checked })}
                                className="rounded text-orange-500 focus:ring-orange-500 w-4 h-4 bg-slate-900 border-slate-700"
                              />
                              <span className="text-xs font-black text-amber-300">⭐ Paling Banyak Dicari</span>
                            </label>

                            <label className="flex items-center gap-2 p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={editingGame.isPopular || false}
                                onChange={(e) => setEditingGame({ ...editingGame, isPopular: e.target.checked })}
                                className="rounded text-orange-500 focus:ring-orange-500 w-4 h-4 bg-slate-900 border-slate-700"
                              />
                              <span className="text-xs font-bold text-slate-300">🔥 Game Popular</span>
                            </label>

                            <label className="flex items-center gap-2 p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer sm:col-span-2">
                              <input
                                type="checkbox"
                                checked={editingGame.isDiscounted || false}
                                onChange={(e) => setEditingGame({ ...editingGame, isDiscounted: e.target.checked })}
                                className="rounded text-orange-500 focus:ring-orange-500 w-4 h-4 bg-slate-900 border-slate-700"
                              />
                              <span className="text-xs font-bold text-slate-300">⚡ Ada Badge PROMO</span>
                            </label>
                          </div>
                        </div>
                      </div>

                      {/* Right Column (8 Cols): Packages & Pricing Master Table */}
                      <div className="lg:col-span-8 space-y-4">
                        <div className="bg-[#0E131F] border border-slate-800 rounded-3xl p-4 sm:p-6 space-y-4 shadow-md">
                          
                          {/* Top Action Bar of Right Column */}
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                            <div>
                              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                                <Zap className="w-5 h-5 text-amber-400" />
                                <span>Senarai Pakej & Penetapan Harga Jualan</span>
                              </h3>
                              <p className="text-xs text-slate-400">
                                Tetapkan harga modal, harga jualan pelanggan (RM), dan bonus tag bagi setiap item.
                              </p>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              {/* Auto Calculate Margin Button */}
                              <button
                                type="button"
                                onClick={() => {
                                  const margin = settings.globalProfitMargin || 15;
                                  const updatedItems = editingGame.items.map((it) => {
                                    const base = typeof it.basePrice === 'string' ? parseFloat(it.basePrice) || 0 : Number(it.basePrice) || 0;
                                    return {
                                      ...it,
                                      sellPrice: Math.round((base * (1 + margin / 100)) * 100) / 100,
                                    };
                                  });
                                  setEditingGame({ ...editingGame, items: updatedItems });
                                }}
                                className="px-3 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/40 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-all"
                                title="Kira automatik semua harga jualan berdasarkan margin global"
                              >
                                <Zap className="w-3.5 h-3.5 text-amber-400" />
                                <span>Auto-Kira (+{settings.globalProfitMargin || 15}%)</span>
                              </button>

                              {/* Add Package Button */}
                              <button
                                type="button"
                                onClick={() =>
                                  setEditingGame({
                                    ...editingGame,
                                    items: [
                                      ...editingGame.items,
                                      {
                                        id: 'item_' + Date.now(),
                                        name: 'Pakej Baru',
                                        basePrice: 10.00,
                                        sellPrice: Math.round((10.00 * (1 + (settings.globalProfitMargin || 15) / 100)) * 100) / 100,
                                        bonusTag: '',
                                      },
                                    ],
                                  })
                                }
                                className="px-4 py-2 bg-orange-500 hover:bg-orange-400 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transition-all"
                              >
                                <Plus className="w-4 h-4" />
                                <span>+ Tambah Pakej</span>
                              </button>
                            </div>
                          </div>

                          {/* Packages List */}
                          {editingGame.items.length === 0 ? (
                            <div className="p-8 text-center bg-[#080B12] rounded-2xl border border-slate-800 text-slate-400 space-y-2">
                              <p className="text-sm font-bold text-slate-300">Belum ada pakej untuk game ini</p>
                              <button
                                type="button"
                                onClick={() =>
                                  setEditingGame({
                                    ...editingGame,
                                    items: [
                                      {
                                        id: 'item_' + Date.now(),
                                        name: 'Pakej 1',
                                        basePrice: 5.00,
                                        sellPrice: 6.00,
                                      },
                                    ],
                                  })
                                }
                                className="px-4 py-2 bg-orange-500 text-slate-950 font-bold text-xs rounded-xl cursor-pointer"
                              >
                                + Tambah Pakej Pertama
                              </button>
                            </div>
                          ) : (
                            <div className="space-y-3">
                              {editingGame.items.map((item, idx) => {
                                const base = typeof item.basePrice === 'string' ? parseFloat(item.basePrice) || 0 : Number(item.basePrice) || 0;
                                const sell = typeof item.sellPrice === 'string' ? parseFloat(item.sellPrice) || 0 : Number(item.sellPrice) || 0;
                                const profit = sell - base;
                                const profitMargin = base > 0 ? ((profit / base) * 100).toFixed(0) : '0';

                                return (
                                  <div
                                    key={item.id || idx}
                                    className="p-4 bg-[#080B12] border border-slate-800 hover:border-slate-700 rounded-2xl space-y-3 shadow-sm transition-all"
                                  >
                                    {/* Row 1: Item Name, Bonus Tag, Delete Button */}
                                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                                      <div className="flex-1">
                                        <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">
                                          Nama Pakej / Diamond ({idx + 1})
                                        </label>
                                        <input
                                          type="text"
                                          value={item.name}
                                          onChange={(e) => {
                                            const newItems = [...editingGame.items];
                                            newItems[idx].name = e.target.value;
                                            setEditingGame({ ...editingGame, items: newItems });
                                          }}
                                          placeholder="Contoh: 86 Diamonds / Weekly Diamond Pass"
                                          className="w-full bg-[#0E131F] border border-slate-700 focus:border-orange-500 rounded-xl px-3 py-2 text-white font-extrabold text-xs focus:outline-none focus:ring-1 focus:ring-orange-500"
                                        />
                                      </div>

                                      <div className="w-full sm:w-44">
                                        <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">
                                          Badge / Tag Bonus
                                        </label>
                                        <input
                                          type="text"
                                          value={item.bonusTag || ''}
                                          onChange={(e) => {
                                            const newItems = [...editingGame.items];
                                            newItems[idx].bonusTag = e.target.value;
                                            setEditingGame({ ...editingGame, items: newItems });
                                          }}
                                          placeholder="Contoh: HOT 🔥 / Laris"
                                          className="w-full bg-[#0E131F] border border-slate-700 focus:border-orange-500 rounded-xl px-3 py-2 text-amber-300 font-bold text-xs focus:outline-none"
                                        />
                                      </div>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          const newItems = editingGame.items.filter((_, i) => i !== idx);
                                          setEditingGame({ ...editingGame, items: newItems });
                                        }}
                                        className="self-end sm:self-center sm:mt-5 p-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-xl transition-all cursor-pointer shrink-0"
                                        title="Padam Pakej Ini"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </button>
                                    </div>

                                    {/* Row 2: Modal (Base Price) vs Harga Jual (Sell Price) + Live Profit Badge */}
                                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-800/80 items-end">
                                      {/* Base Price */}
                                      <div>
                                        <label className="text-[10px] text-slate-400 font-mono font-bold block mb-1">
                                          Harga Modal / Asal (RM)
                                        </label>
                                        <div className="relative flex items-center">
                                          <span className="absolute left-3 text-xs font-mono font-bold text-slate-500 select-none pointer-events-none">
                                            RM
                                          </span>
                                          <input
                                            type="number"
                                            step="0.01"
                                            inputMode="decimal"
                                            value={item.basePrice ?? ''}
                                            onChange={(e) => {
                                              const raw = e.target.value;
                                              const newItems = [...editingGame.items];
                                              newItems[idx].basePrice = raw as any;
                                              setEditingGame({ ...editingGame, items: newItems });
                                            }}
                                            placeholder="0.00"
                                            className="w-full bg-[#0E131F] border border-slate-700 focus:border-slate-500 rounded-xl pl-10 pr-3 py-2 text-slate-200 font-mono font-bold text-xs focus:outline-none"
                                          />
                                        </div>
                                      </div>

                                      {/* Sell Price */}
                                      <div>
                                        <label className="text-[10px] text-orange-400 font-mono font-black block mb-1">
                                          Harga Jual Pelanggan (RM)
                                        </label>
                                        <div className="relative flex items-center">
                                          <span className="absolute left-3 text-xs font-mono font-black text-orange-500 select-none pointer-events-none">
                                            RM
                                          </span>
                                          <input
                                            type="number"
                                            step="0.01"
                                            inputMode="decimal"
                                            value={item.sellPrice ?? ''}
                                            onChange={(e) => {
                                              const raw = e.target.value;
                                              const newItems = [...editingGame.items];
                                              newItems[idx].sellPrice = raw as any;
                                              setEditingGame({ ...editingGame, items: newItems });
                                            }}
                                            placeholder="0.00"
                                            className="w-full bg-[#0E131F] border-2 border-orange-500 focus:border-amber-400 rounded-xl pl-10 pr-3 py-2 text-orange-400 font-mono font-black text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/50 shadow-inner"
                                          />
                                        </div>
                                      </div>

                                      {/* Live Profit & Margin Indicator */}
                                      <div className="p-2 bg-[#0E131F] rounded-xl border border-slate-700/80 flex items-center justify-between text-xs font-mono">
                                        <span className="text-slate-400 text-[10px]">Untung Bersih:</span>
                                        <span className={`font-black ${profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                          {profit >= 0 ? '+' : ''}RM {profit.toFixed(2)} ({profitMargin}%)
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Games Grid - Sleek Poster Cards Grid (Macam Bar Games Kat Depan) */}
              {filteredGames.length === 0 && gameSearchQuery ? (
                <div className="p-12 text-center bg-[#121824] rounded-3xl border border-slate-800 text-slate-400 space-y-2">
                  <Gamepad2 className="w-8 h-8 text-slate-600 mx-auto" />
                  <p className="text-sm font-bold text-slate-300">Tiada game dijumpai untuk "{gameSearchQuery}"</p>
                  <p className="text-xs text-slate-500">Cuba ubah kata carian atau penapis kategori di atas.</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4.5">
                  {/* + Tambah Game Baru Poster Card */}
                  <div
                    onClick={() =>
                      setEditingGame({
                        id: 'g_' + Date.now(),
                        name: '',
                        slug: '',
                        category: 'mobile',
                        isPopular: false,
                        isDiscounted: false,
                        serverType: 'none',
                        logoUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
                        idGuideText: 'Sila masukkan User ID anda.',
                        items: [
                          { id: 'item_1', name: '86 Diamonds', basePrice: 5.00, sellPrice: 6.00, bonusTag: 'Paling Laris' },
                        ],
                      })
                    }
                    className="group relative aspect-[4/5] sm:aspect-[3/4] rounded-2xl sm:rounded-3xl border-2 border-dashed border-orange-500/50 hover:border-orange-400 bg-gradient-to-b from-[#141B28]/90 to-[#0B0E14] hover:bg-orange-500/10 transition-all duration-300 flex flex-col items-center justify-center p-4 text-center cursor-pointer shadow-lg hover:shadow-[0_0_30px_rgba(255,140,0,0.3)] hover:-translate-y-1 active:scale-97"
                  >
                    <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-orange-500/20 border border-orange-500/40 text-orange-400 group-hover:bg-orange-500 group-hover:text-slate-950 flex items-center justify-center transition-all mb-2.5 shadow-md">
                      <Plus className="w-6 h-6 sm:w-7 sm:h-7" />
                    </div>
                    <span className="font-extrabold text-white text-xs sm:text-sm">Tambah Game</span>
                    <span className="text-[10px] text-slate-400 mt-0.5">Bina katalog baru</span>
                  </div>

                  {/* All Games Poster Cards */}
                  {filteredGames.map((g) => {
                    const minPrice = g.items.length > 0 ? Math.min(...g.items.map((i) => i.sellPrice)) : 0;
                    const maxPrice = g.items.length > 0 ? Math.max(...g.items.map((i) => i.sellPrice)) : 0;

                    return (
                      <div
                        key={g.id}
                        onClick={() => setEditingGame(JSON.parse(JSON.stringify(g)))}
                        className="group relative aspect-[4/5] sm:aspect-[3/4] rounded-2xl sm:rounded-3xl bg-[#0D1117] border border-slate-800/90 hover:border-orange-500/80 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_0_25px_rgba(255,140,0,0.35)] cursor-pointer flex flex-col overflow-hidden shadow-md active:scale-97"
                      >
                        {/* Poster Image */}
                        <img
                          src={g.logoUrl}
                          alt={g.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500 ease-out"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src =
                              'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=400&q=80';
                          }}
                        />

                        {/* Dark Gradient Overlay for perfect readability */}
                        <div className="absolute inset-0 bg-gradient-to-t from-[#090D16] via-[#090D16]/40 to-black/30 pointer-events-none" />

                        {/* Top Badges */}
                        <div className="absolute top-2 left-2 right-2 flex items-center justify-between gap-1 z-10">
                          {/* Package Count Badge */}
                          <span className="px-2 py-0.5 rounded-lg text-[9px] sm:text-[10px] font-black bg-slate-950/85 backdrop-blur-md text-amber-300 border border-amber-500/40 uppercase tracking-wider flex items-center gap-1 shadow-md">
                            <Zap className="w-2.5 h-2.5 fill-current text-amber-400" />
                            <span>{g.items.length} Pakej</span>
                          </span>

                          {/* Category Badge or Promo */}
                          <div className="flex items-center gap-1">
                            {g.isMostSearched && (
                              <span className="px-1.5 py-0.5 rounded-lg text-[9px] font-black bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 shadow-md">
                                ⭐ Dicari
                              </span>
                            )}
                            <span className="px-1.5 sm:px-2 py-0.5 rounded-lg text-[9px] sm:text-[10px] font-bold bg-slate-900/85 backdrop-blur-md text-slate-300 border border-slate-700/60 uppercase">
                              {g.category === 'mobile' ? 'Mobile' : g.category === 'pc' ? 'PC' : 'Voucher'}
                            </span>
                          </div>
                        </div>

                        {/* Bottom Title & Price Range */}
                        <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3.5 z-10 flex flex-col justify-end space-y-1">
                          <h4 className="font-extrabold text-white text-xs sm:text-sm leading-tight drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] line-clamp-2 group-hover:text-orange-400 transition-colors">
                            {g.name}
                          </h4>

                          <div className="flex items-center justify-between text-[10px] sm:text-[11px] font-mono text-emerald-400 pt-0.5">
                            <span className="font-bold">RM {minPrice.toFixed(2)} - RM {maxPrice.toFixed(2)}</span>
                            <span className="opacity-0 group-hover:opacity-100 text-orange-400 font-bold transition-opacity hidden sm:inline">
                              Edit ➔
                            </span>
                          </div>
                        </div>

                        {/* Hover Quick Edit Button Pill */}
                        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-3 z-20 pointer-events-none sm:pointer-events-auto">
                          <div className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-[0_0_20px_rgba(255,140,0,0.6)] transform scale-90 group-hover:scale-100 transition-transform">
                            <Edit2 className="w-3.5 h-3.5" />
                            <span>Tekan Untuk Edit</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

            {/* Custom Game Deletion Confirmation Modal */}
              {gameToDelete && (
                <div className="fixed inset-0 z-[110] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
                  <div className="relative w-full max-w-md bg-[#0D1117] border border-rose-500/50 rounded-3xl p-6 space-y-5 shadow-[0_0_50px_rgba(244,63,94,0.35)] my-auto text-center">
                    
                    <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                      <Trash2 className="w-7 h-7" />
                    </div>

                    <div className="space-y-1.5">
                      <h3 className="text-lg font-extrabold text-white">Padam Game "{gameToDelete.name}"?</h3>
                      <p className="text-xs text-slate-400">
                        Adakah anda pasti mahu memadamkan game ini daripada sistem? Semua senarai pakej topup untuk game ini akan dipadamkan serta-merta.
                      </p>
                    </div>

                    {gameToDelete.logoUrl && (
                      <div className="flex items-center justify-center gap-3 p-3 bg-slate-900/90 rounded-2xl border border-slate-800">
                        <img src={gameToDelete.logoUrl} alt={gameToDelete.name} className="w-10 h-10 object-cover rounded-xl" />
                        <div className="text-left">
                          <div className="font-bold text-white text-xs">{gameToDelete.name}</div>
                          <div className="text-[10px] text-slate-400">{gameToDelete.items?.length || 0} Pakej Item Disediakan</div>
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => setGameToDelete(null)}
                        disabled={isDeletingGame}
                        className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-2xl text-xs transition-all cursor-pointer"
                      >
                        Batal
                      </button>

                      <button
                        type="button"
                        disabled={isDeletingGame}
                        onClick={async () => {
                          setIsDeletingGame(true);
                          try {
                            await onDeleteGame(gameToDelete.id);
                          } catch (err) {
                            console.error('Failed to delete game:', err);
                          } finally {
                            setIsDeletingGame(false);
                            setGameToDelete(null);
                          }
                        }}
                        className="py-3 px-4 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black rounded-2xl text-xs shadow-lg shadow-rose-600/30 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        {isDeletingGame ? (
                          <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        ) : (
                          <Trash2 className="w-4 h-4" />
                        )}
                        <span>{isDeletingGame ? 'Memadam...' : 'Ya, Padam Now'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

          {/* TAB 2: ORDERS MANAGEMENT */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              
              {/* Order Status & Search Bar */}
              <div className="bg-[#121824] p-3 sm:p-4 rounded-2xl border border-slate-800/90 space-y-3 shadow-md">
                <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
                  {/* Status Pills */}
                  <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-0.5">
                    {(
                      [
                        { id: 'all', label: 'Semua', count: orders.length, color: 'orange' },
                        { id: 'pending', label: '⏳ Pending', count: orders.filter((o) => o.status === 'pending').length, color: 'amber' },
                        { id: 'processing', label: '⚙️ Diproses', count: orders.filter((o) => o.status === 'processing').length, color: 'blue' },
                        { id: 'completed', label: '✅ Selesai', count: orders.filter((o) => o.status === 'completed').length, color: 'emerald' },
                        { id: 'cancelled', label: '❌ Batal', count: orders.filter((o) => o.status === 'cancelled').length, color: 'rose' },
                      ] as const
                    ).map((st) => (
                      <button
                        key={st.id}
                        onClick={() => setOrderStatusFilter(st.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                          orderStatusFilter === st.id
                            ? 'bg-orange-500 text-slate-950 font-black shadow-md'
                            : 'bg-slate-900/90 text-slate-400 hover:text-white border border-slate-800'
                        }`}
                      >
                        <span>{st.label}</span>
                        <span
                          className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${
                            orderStatusFilter === st.id
                              ? 'bg-slate-950/30 text-slate-950'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {st.count}
                        </span>
                      </button>
                    ))}
                  </div>

                  {/* Order Search Input */}
                  <div className="relative w-full md:w-72 shrink-0">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={orderSearchQuery}
                      onChange={(e) => setOrderSearchQuery(e.target.value)}
                      placeholder="Cari ID, Game, User ID, Tel..."
                      className="w-full bg-[#0D1117] border border-slate-700/80 rounded-xl pl-9 pr-8 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                    />
                    {orderSearchQuery && (
                      <button
                        onClick={() => setOrderSearchQuery('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Orders Table / Cards */}
              <div className="space-y-3">
                {filteredOrders.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs bg-[#121824] rounded-2xl border border-slate-800">
                    Tiada pesanan dijumpai untuk status ini.
                  </div>
                ) : (
                  filteredOrders.map((ord) => (
                    <div
                      key={ord.id}
                      className="p-4 bg-[#121824] border border-slate-800 rounded-2xl space-y-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-black text-orange-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-orange-500/30">
                            #{ord.id}
                          </span>
                          <span className="text-xs font-bold text-white">{ord.gameName}</span>
                          <span className="text-[11px] text-slate-400 font-mono">
                            ({new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})
                          </span>
                        </div>

                        {/* Status Updater */}
                        <div className="flex items-center gap-1.5">
                          <select
                            value={ord.status}
                            onChange={(e) =>
                              onUpdateOrderStatus(ord.id, e.target.value as Order['status'])
                            }
                            className="bg-[#0D1117] border border-slate-700 text-xs font-bold rounded-lg px-2.5 py-1 text-white focus:outline-none"
                          >
                            <option value="pending">Pending</option>
                            <option value="processing">Diproses</option>
                            <option value="completed">Selesai</option>
                            <option value="cancelled">Dibatalkan</option>
                          </select>

                          {ord.proofImageUrl && (
                            <button
                              onClick={() => setViewingProof(ord.proofImageUrl!)}
                              className="p-1.5 bg-blue-500/20 text-blue-400 border border-blue-500/40 rounded-lg hover:bg-blue-500/30 text-xs font-bold flex items-center gap-1"
                              title="Lihat Resit Transfer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>Resit</span>
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                        <div>
                          <span className="text-slate-400 block text-[10px]">Produk:</span>
                          <span className="text-white font-bold">{ord.itemName}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px]">User ID & Server:</span>
                          <span className="text-amber-300 font-bold">{ord.userId} {ord.serverId ? `(${ord.serverId})` : ''}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px]">Harga Jual:</span>
                          <span className="text-orange-400 font-bold">RM {ord.sellPrice.toFixed(2)}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px]">Bayaran:</span>
                          <span className="text-slate-300">{ord.paymentMethod}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                        <a
                          href={`https://wa.me/${(localSettings?.ownerWhatsApp || '').replace(/\D/g, '')}?text=Hai%20pelanggan,%20pesanan%20TopupBalz%20%23${ord.id}%20(${ord.gameName})%20anda%20kini%20status:%20${ord.status.toUpperCase()}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-xs text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>Mesej Pembeli di WhatsApp</span>
                        </a>

                        <span className="text-[10px] text-slate-500 font-mono">
                          {new Date(ord.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>

            </div>
          )}

          {/* TAB 3: PROMO BANNERS */}
          {activeTab === 'banners' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-sm font-black text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-orange-400" />
                    <span>Pengurusan Slaid Banner Promosi Homepage</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Banner akan bertukar secara automatik di skrin utama (Auto Slider). Anda boleh tukar gambar banner dengan memilih foto dari galeri telefon/komputer.
                  </p>
                </div>

                <button
                  onClick={() =>
                    setEditingBanner({
                      id: 'b_' + Date.now(),
                      title: 'Promosi Hebat Balz',
                      subtitle: 'Nikmati diskaun topup khas hari ini!',
                      badge: 'PROMO',
                      imageUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
                      isActive: true,
                    })
                  }
                  className="px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase rounded-xl shadow-lg flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>Tambah Banner Baru</span>
                </button>
              </div>

              {editingBanner && (
                <div className="p-5 bg-[#121824] border-2 border-orange-500/50 rounded-2xl space-y-4 shadow-[0_0_30px_rgba(255,140,0,0.15)] animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-xs font-black text-orange-400 uppercase tracking-wider flex items-center gap-1.5">
                      <ImageIcon className="w-4 h-4" />
                      <span>{editingBanner.id ? 'Sunting Banner Promosi' : 'Tambah Banner Promosi Baru'}</span>
                    </span>
                    <button
                      onClick={() => setEditingBanner(null)}
                      className="text-slate-400 hover:text-white text-xs"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Banner Image Preview Box */}
                  <div className="p-3 bg-[#0D1117] border border-slate-800 rounded-xl space-y-2">
                    <label className="text-slate-300 font-bold text-xs block">Pratonton Gambar Banner (Live Preview):</label>
                    <div className="relative aspect-[21/9] sm:aspect-[24/9] rounded-xl overflow-hidden bg-slate-950 border border-slate-700 flex items-center justify-center">
                      {editingBanner.imageUrl ? (
                        <img
                          src={editingBanner.imageUrl}
                          alt="Banner Preview"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="text-center text-slate-500 text-xs">
                          <ImageIcon className="w-8 h-8 mx-auto mb-1 opacity-50" />
                          <span>Tiada Gambar Dipilih</span>
                        </div>
                      )}
                      <div className="absolute top-2 left-2 px-2.5 py-1 bg-orange-500 text-slate-950 font-black text-[10px] uppercase rounded-full shadow">
                        {editingBanner.badge || 'PROMO'}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="text-slate-300 font-bold block mb-1">Tajuk Banner</label>
                      <input
                        type="text"
                        value={editingBanner.title}
                        onChange={(e) =>
                          setEditingBanner({ ...editingBanner, title: e.target.value })
                        }
                        className="w-full bg-[#0D1117] border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1">Penerangan Subtitle</label>
                      <input
                        type="text"
                        value={editingBanner.subtitle}
                        onChange={(e) =>
                          setEditingBanner({ ...editingBanner, subtitle: e.target.value })
                        }
                        className="w-full bg-[#0D1117] border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1">Lencana Promo (Badge Label)</label>
                      <input
                        type="text"
                        value={editingBanner.badge}
                        onChange={(e) =>
                          setEditingBanner({ ...editingBanner, badge: e.target.value })
                        }
                        placeholder="cth: SPECIAL, HOT, DISCOUNT 20%"
                        className="w-full bg-[#0D1117] border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1">Teks Diskaun (Pilihan)</label>
                      <input
                        type="text"
                        value={editingBanner.discountText || ''}
                        onChange={(e) =>
                          setEditingBanner({ ...editingBanner, discountText: e.target.value })
                        }
                        placeholder="cth: REBAT RM5"
                        className="w-full bg-[#0D1117] border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>
                  </div>

                  {/* GALLERY IMAGE PICKER & URL INPUT */}
                  <div className="p-4 bg-[#0D1117] border border-orange-500/40 rounded-xl space-y-3">
                    <label className="text-xs font-black text-white uppercase tracking-wider block">
                      📁 Pilih Gambar Dari Galeri Device / Muat Naik Gambar Baru:
                    </label>

                    <div className="flex flex-col sm:flex-row items-center gap-3">
                      <label className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md hover:scale-[1.02] transition-all">
                        <Upload className="w-4 h-4 text-slate-950" />
                        <span>Pilih Foto Dari Galeri Device</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const compressed = await compressImage(file, 1200, 0.75);
                              setEditingBanner({
                                ...editingBanner,
                                imageUrl: compressed,
                              });
                            }
                          }}
                        />
                      </label>
                      <span className="text-[11px] text-slate-400">Format disokong: PNG, JPG, WEBP, GIF</span>
                    </div>

                    {/* Presets Gallery Quick Buttons */}
                    <div className="pt-2 border-t border-slate-800 space-y-1.5">
                      <span className="text-[11px] font-bold text-slate-400 block">Atau Pilih Gambar Preset Templat Game:</span>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { name: 'Mobile Legends', url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80' },
                          { name: 'PUBG Mobile', url: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=1200&q=80' },
                          { name: 'Free Fire', url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80' },
                          { name: 'Genshin Impact', url: 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?auto=format&fit=crop&w=1200&q=80' },
                          { name: 'Roblox / General', url: 'https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?auto=format&fit=crop&w=1200&q=80' },
                        ].map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setEditingBanner({ ...editingBanner, imageUrl: preset.url })}
                            className="px-2.5 py-1 bg-slate-900 border border-slate-700 hover:border-orange-500 text-slate-300 hover:text-white rounded-lg text-[11px] font-semibold transition-all cursor-pointer"
                          >
                            📷 {preset.name}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Manual URL Input */}
                    <div className="pt-2 border-t border-slate-800">
                      <label className="text-[11px] text-slate-400 block mb-1 font-mono">Atau Pautan URL Gambar Direct:</label>
                      <input
                        type="text"
                        value={editingBanner.imageUrl}
                        onChange={(e) =>
                          setEditingBanner({ ...editingBanner, imageUrl: e.target.value })
                        }
                        placeholder="https://..."
                        className="w-full bg-[#121824] border border-slate-700 rounded-xl p-2.5 text-white font-mono text-xs focus:outline-none focus:border-orange-500"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => setEditingBanner(null)}
                      className="px-4 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      onClick={async () => {
                        let finalImageUrl = editingBanner.imageUrl;
                        if (finalImageUrl && finalImageUrl.startsWith('data:image/')) {
                          finalImageUrl = await compressImage(finalImageUrl, 1200, 0.75);
                        }
                        await onSaveBanner({ ...editingBanner, imageUrl: finalImageUrl });
                        setEditingBanner(null);
                      }}
                      className="px-6 py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase rounded-xl shadow-lg cursor-pointer"
                    >
                      Simpan Banner ✓
                    </button>
                  </div>
                </div>
              )}

              {/* BANNERS LIST GRID */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {banners.map((bn) => (
                  <div
                    key={bn.id}
                    className="p-3.5 bg-[#121824] border border-slate-800 hover:border-slate-700 rounded-2xl flex gap-3.5 items-center justify-between shadow-sm transition-all group"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="relative w-28 h-18 rounded-xl overflow-hidden border border-slate-700 shrink-0 bg-slate-950">
                        <img
                          src={bn.imageUrl}
                          alt={bn.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                        <span className="absolute top-1 left-1 px-1.5 py-0.5 bg-orange-500 text-slate-950 font-black rounded text-[8px] uppercase">
                          {bn.badge}
                        </span>
                      </div>

                      <div className="min-w-0 text-xs space-y-1">
                        <h4 className="font-extrabold text-white truncate text-sm">{bn.title}</h4>
                        <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">{bn.subtitle}</p>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => setEditingBanner({ ...bn })}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-orange-400 text-xs font-bold rounded-xl flex items-center gap-1 cursor-pointer transition-all"
                        title="Tukar Gambar / Sunting Banner"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Sunting</span>
                      </button>
                      <button
                        onClick={() => onDeleteBanner(bn.id)}
                        className="p-2 text-rose-400 hover:bg-rose-500/10 rounded-xl transition-all cursor-pointer"
                        title="Padam Banner"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* TAB 4: SYSTEM SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-4 max-w-2xl mx-auto">
              {/* STORE STATUS TOGGLE CARD (BUKA / TUTUP KEDAI) */}
              <div className={`p-5 rounded-2xl border transition-all ${
                localSettings.isStoreOpen !== false
                  ? 'bg-[#121824] border-emerald-500/40 shadow-[0_0_25px_rgba(16,185,129,0.15)]'
                  : 'bg-[#1a0f14] border-rose-500/50 shadow-[0_0_25px_rgba(244,63,94,0.2)]'
              }`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`w-3 h-3 rounded-full ${
                        localSettings.isStoreOpen !== false ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500 animate-ping'
                      }`} />
                      <h3 className="font-black text-white text-base">
                        Status Kedai: {localSettings.isStoreOpen !== false ? 'BUKA (ON)' : 'TUTUP / MAINTENANCE (OFF)'}
                      </h3>
                    </div>
                    <p className="text-xs text-slate-300">
                      {localSettings.isStoreOpen !== false
                        ? 'Kedai sedang beroperasi. Pelanggan boleh melihat harga dan membuat pembayaran pesanan topup seperti biasa.'
                        : 'Kedai sedang ditutup / maintenance. Pelanggan boleh melihat harga senarai diamond, tetapi pembelian tidak dapat diteruskan.'}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleToggleStoreStatus}
                    className={`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg active:scale-95 shrink-0 ${
                      localSettings.isStoreOpen !== false
                        ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:from-emerald-400 hover:to-teal-400 shadow-emerald-500/30'
                        : 'bg-gradient-to-r from-rose-600 to-red-600 text-white hover:from-rose-500 hover:to-red-500 shadow-rose-500/30'
                    }`}
                  >
                    <span className="text-sm">{localSettings.isStoreOpen !== false ? '🟢' : '🔴'}</span>
                    <span>{localSettings.isStoreOpen !== false ? 'Tutup Kedai (OFF)' : 'Buka Kedai (ON)'}</span>
                  </button>
                </div>

                {localSettings.isStoreOpen === false && (
                  <div className="mt-4 pt-4 border-t border-rose-500/30 space-y-2">
                    <label className="block text-rose-300 font-bold text-xs">
                      Mesej Notifikasi Penyelenggaraan (Dipaparkan kepada Pelanggan):
                    </label>
                    <textarea
                      rows={2}
                      value={localSettings.storeMaintenanceNotice || ''}
                      onChange={(e) =>
                        setLocalSettings({ ...localSettings, storeMaintenanceNotice: e.target.value })
                      }
                      className="w-full bg-[#0D1117] border border-rose-500/50 rounded-xl p-2.5 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-rose-400 font-medium"
                      placeholder="Kedai sedang ditutup sementara untuk penyelenggaraan sistem & kemaskini stok. Anda boleh melihat senarai harga diamond, tetapi pembelian tidak dapat dibuat buat masa ini."
                    />
                  </div>
                )}
              </div>

              <div className="p-5 bg-[#121824] border border-slate-800 rounded-2xl space-y-4 text-xs">
                <h3 className="font-black text-white text-base">Tetapan Owner &amp; Notifikasi</h3>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    Nombor Telefon WhatsApp Owner (Order Direct)
                  </label>
                  <input
                    type="text"
                    value={localSettings.ownerWhatsApp}
                    onChange={(e) =>
                      setLocalSettings({ ...localSettings, ownerWhatsApp: e.target.value })
                    }
                    className="w-full bg-[#0D1117] border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                    placeholder="e.g. 601112345678"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    Nama Pemegang Akaun Touch 'n Go eWallet
                  </label>
                  <input
                    type="text"
                    value={localSettings.tngAccountName}
                    onChange={(e) =>
                      setLocalSettings({ ...localSettings, tngAccountName: e.target.value })
                    }
                    className="w-full bg-[#0D1117] border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>

                {/* Touch 'n Go / DuitNow QR Image Gallery Upload */}
                <div className="p-4 bg-[#0D1117] border border-blue-500/40 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="block text-white font-black text-xs uppercase tracking-wide">
                      Gambar QR Code Bayaran (Touch 'n Go / DuitNow)
                    </label>
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 font-mono font-bold text-[10px] rounded-md border border-emerald-500/30">
                      ✓ Papar Online 24/7
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-4">
                    {/* QR Image Preview Box */}
                    <div className="w-28 h-28 bg-white p-2 rounded-2xl border-2 border-blue-500 shadow-md flex items-center justify-center shrink-0 overflow-hidden relative group">
                      {localSettings.tngQrImageUrl ? (
                        <img
                          src={localSettings.tngQrImageUrl}
                          alt="QR Code Preview"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <ImageIcon className="w-10 h-10 text-slate-400" />
                      )}
                    </div>

                    <div className="space-y-2 flex-1 w-full text-xs">
                      {/* Upload Button */}
                      <label className="w-full sm:w-auto px-4 py-2.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-extrabold rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-lg hover:scale-[1.02] transition-all">
                        <Upload className="w-4 h-4 text-cyan-300" />
                        <span>Pilih Gambar QR Dari Galeri Telefon</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const compressed = await compressImage(file, 1000, 0.75);
                              setLocalSettings({
                                ...localSettings,
                                tngQrImageUrl: compressed,
                              });
                            }
                          }}
                        />
                      </label>

                      <p className="text-[11px] text-slate-400">
                        Sila muat naik foto QR Code Touch 'n Go / DuitNow anda dari galeri. Selepas simpan, gambar ini akan automatik terpapar secara online kepada semua pelanggan.
                      </p>

                      <div className="pt-1">
                        <label className="text-[10px] text-slate-400 block mb-1 font-mono">Atau Tampal URL Gambar QR (Pilihan):</label>
                        <input
                          type="text"
                          value={localSettings.tngQrImageUrl}
                          onChange={(e) =>
                            setLocalSettings({ ...localSettings, tngQrImageUrl: e.target.value })
                          }
                          placeholder="https://..."
                          className="w-full bg-[#121824] border border-slate-700 rounded-lg p-2 text-white font-mono text-[11px]"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-[#0D1117] border border-cyan-500/40 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-cyan-400 uppercase tracking-wide flex items-center gap-1.5">
                      <Send className="w-4 h-4" />
                      <span>🤖 Konfigurasi Telegram Bot & Channel Siaran</span>
                    </label>
                    <span className="px-2 py-0.5 bg-cyan-500/20 text-cyan-300 font-mono font-bold text-[10px] rounded-md border border-cyan-500/30">
                      Auto Send Photo & Resit
                    </span>
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">
                      Telegram Bot Token
                    </label>
                    <input
                      type="text"
                      value={localSettings.telegramBotToken}
                      onChange={(e) =>
                        setLocalSettings({ ...localSettings, telegramBotToken: e.target.value })
                      }
                      className="w-full bg-[#121824] border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                      placeholder="e.g. 8734212773:AAF3wZS0nC5Vt29RoB7kcBwHKqEBJ2y8NTw"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-300 font-bold mb-1">
                        Telegram Chat ID Admin (Private Bot)
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={localSettings.telegramChatId}
                          onChange={(e) =>
                            setLocalSettings({ ...localSettings, telegramChatId: e.target.value })
                          }
                          className="w-full bg-[#121824] border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                          placeholder="e.g. 1290238834"
                        />
                        <button
                          type="button"
                          onClick={() => handleTestChannel(localSettings.telegramChatId)}
                          disabled={isTestingTg}
                          className="px-3 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded-xl text-xs font-bold shrink-0 cursor-pointer"
                          title="Uji hantar ke Chat ID Private"
                        >
                          🧪 Uji
                        </button>
                      </div>
                      <span className="text-[10px] text-slate-400 mt-0.5 block">Chat ID peribadi anda di bot</span>
                    </div>

                    <div>
                      <label className="block text-slate-300 font-bold mb-1">
                        Telegram Channel ID / Username (Siaran Awam)
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={localSettings.telegramChannelId || ''}
                          onChange={(e) =>
                            setLocalSettings({ ...localSettings, telegramChannelId: e.target.value })
                          }
                          className="w-full bg-[#121824] border border-cyan-500/50 rounded-xl p-2.5 text-white font-mono focus:border-cyan-400"
                          placeholder="e.g. -1002345678901 atau @NamaChannel"
                        />
                        <button
                          type="button"
                          onClick={() => handleTestChannel(localSettings.telegramChannelId || '')}
                          disabled={isTestingTg}
                          className="px-3.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-black shrink-0 cursor-pointer flex items-center gap-1 shadow-md"
                          title="Uji hantar terus ke Channel"
                        >
                          {isTestingTg ? (
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Send className="w-3.5 h-3.5" />
                          )}
                          <span>Uji Channel</span>
                        </button>
                      </div>
                      <span className="text-[10px] text-cyan-300 mt-0.5 block">Channel ID (bermula -100...) atau @username channel</span>
                    </div>
                  </div>

                  {/* Auto-Detect & Test Result Banner */}
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleDetectChannels}
                      disabled={isDetectingTg}
                      className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-cyan-500/40 text-cyan-300 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      {isDetectingTg ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Search className="w-3.5 h-3.5" />
                      )}
                      <span>🔍 Auto-Kesan ID Channel "Informasi TopupBalz"</span>
                    </button>
                  </div>

                  {/* Detected Channels List */}
                  {detectedTgChannels.length > 0 && (
                    <div className="p-3 bg-cyan-950/40 border border-cyan-700/50 rounded-xl space-y-2">
                      <span className="text-[11px] font-bold text-cyan-300 block">Saluran/Channel Dikesan dari Bot:</span>
                      <div className="flex flex-wrap gap-2">
                        {detectedTgChannels.map((ch, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => {
                              const targetVal = ch.username ? `@${ch.username}` : String(ch.id);
                              setLocalSettings((prev) => ({ ...prev, telegramChannelId: targetVal }));
                            }}
                            className="px-3 py-1.5 bg-[#121824] border border-cyan-500/60 hover:bg-cyan-500/20 text-white rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer transition-all"
                          >
                            <span>📢 {ch.title}</span>
                            <span className="text-[10px] text-cyan-300">({ch.username ? `@${ch.username}` : ch.id})</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Test Feedback Notice */}
                  {tgTestResult && (
                    <div
                      className={`p-3 rounded-xl border text-xs font-semibold flex items-start gap-2 animate-fadeIn ${
                        tgTestResult.success
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-200'
                          : 'bg-rose-500/20 border-rose-500 text-rose-200'
                      }`}
                    >
                      {tgTestResult.success ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <span>{tgTestResult.message}</span>
                    </div>
                  )}

                  <div className="p-3 bg-cyan-950/30 border border-cyan-800/40 rounded-xl text-[11px] text-cyan-200/90 leading-relaxed space-y-1">
                    <strong className="text-cyan-300 block font-bold">📢 Cara Mudah Menyambungkan Channel "Informasi TopupBalz":</strong>
                    <ol className="list-decimal pl-4 space-y-1 text-slate-300">
                      <li>Buka Channel Telegram anda &gt; Tambah <strong>@OrderBalz_bot</strong> sebagai <strong>Administrator</strong> (dengan kebenaran <em>Post Messages &amp; Edit Messages</em>).</li>
                      <li><strong>PILIHAN A (Channel Public):</strong> Di Telegram Channel &gt; Edit (Pensel) &gt; Tukar ke <strong>Public Channel</strong> &gt; Tetapkan link (cth: <code>t.me/informasitopupbalz</code>) &gt; Masukkan <code>@informasitopupbalz</code> di atas.</li>
                      <li><strong>PILIHAN B (Channel Private):</strong> Masukkan nombor Channel ID (cth: <code>-1002345678901</code>) atau tekan butang <strong>"Auto-Kesan ID Channel"</strong> di atas.</li>
                      <li>Tekan butang <strong>"🧪 Uji Channel"</strong> di atas untuk sahkan pesanan boleh masuk.</li>
                    </ol>
                  </div>
                </div>

                {/* --- SUPABASE CLOUD POSTGRESQL ENGINE CARD --- */}
                <div className="p-5 bg-gradient-to-br from-[#0D1520] to-[#121A28] border border-emerald-500/40 rounded-2xl space-y-4 text-xs shadow-xl">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold text-sm">
                        ⚡
                      </div>
                      <div>
                        <h4 className="font-black text-white text-sm flex items-center gap-2">
                          <span>Supabase Cloud PostgreSQL Database</span>
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                            Disambungkan
                          </span>
                        </h4>
                        <p className="text-[11px] text-slate-400 font-mono">
                          {supabaseStatus?.url || 'https://evvquwzrqkmmpoeytssr.supabase.co'}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={fetchSupabaseStatus}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-[11px] font-bold flex items-center gap-1 border border-slate-700 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Semak Status</span>
                    </button>
                  </div>

                  <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 text-[11px] space-y-2">
                    <p className="text-slate-300">
                      TopupBalz kini dilengkapi dengan sambungan <strong>Supabase Client</strong> rasmi. Semua transaksi, pesanan, akaun pengguna, katalog permainan, dan banner akan disegerakkan secara automatik ke projek Supabase anda.
                    </p>
                    {supabaseStatus?.message && (
                      <div className="p-2 bg-emerald-950/40 border border-emerald-500/30 rounded-lg text-emerald-300 text-[10px] font-medium flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>{supabaseStatus.message}</span>
                      </div>
                    )}
                  </div>

                  {/* Supabase Action Buttons */}
                  <div className="flex flex-wrap gap-2.5 pt-1">
                    <button
                      type="button"
                      onClick={handleCopySupabaseSql}
                      className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md ${
                        copiedSupabaseSql
                          ? 'bg-emerald-500 text-slate-950 font-black'
                          : 'bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/40'
                      }`}
                    >
                      {copiedSupabaseSql ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-slate-950" />
                          <span>✓ Skrip SQL Berjaya Disalin!</span>
                        </>
                      ) : (
                        <>
                          <Zap className="w-4 h-4 text-emerald-400" />
                          <span>📋 Salin Skrip SQL Schema Supabase</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={handleSyncToSupabase}
                      disabled={isSyncingSupabase}
                      className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs uppercase flex items-center gap-1.5 transition-all cursor-pointer shadow-md disabled:opacity-50"
                    >
                      {isSyncingSupabase ? (
                        <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                      ) : (
                        <Upload className="w-4 h-4 text-slate-950" />
                      )}
                      <span>Eksport &amp; Sync Semua Data ke Supabase</span>
                    </button>
                  </div>

                  {/* Feedback Message */}
                  {supabaseSyncMsg && (
                    <div
                      className={`p-3 rounded-xl border text-xs font-semibold flex items-center gap-2 animate-fadeIn ${
                        supabaseSyncMsg.success
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-200'
                          : 'bg-rose-500/20 border-rose-500 text-rose-200'
                      }`}
                    >
                      {supabaseSyncMsg.success ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      )}
                      <span>{supabaseSyncMsg.text}</span>
                    </div>
                  )}

                  {/* Instructions on running the SQL in Supabase Dashboard */}
                  <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl text-[11px] text-slate-400 space-y-1">
                    <span className="font-bold text-slate-200 block">💡 Langkah Mudah di Supabase Console:</span>
                    <ol className="list-decimal pl-4 space-y-1 text-slate-300">
                      <li>Tekan butang <strong>"Salin Skrip SQL Schema Supabase"</strong> di atas.</li>
                      <li>Buka <a href="https://supabase.com/dashboard" target="_blank" rel="noreferrer" className="text-emerald-400 underline font-bold">Supabase Dashboard</a> &gt; Projek <code>evvquwzrqkmmpoeytssr</code> &gt; <strong>SQL Editor</strong>.</li>
                      <li>Tampal (Paste) dan tekan <strong>Run</strong> untuk membina jadual &amp; RLS policies secara automatik.</li>
                      <li>Tekan <strong>"Eksport &amp; Sync Semua Data"</strong> untuk memindahkan semua data sedia ada.</li>
                    </ol>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex justify-end">
                  <button
                    onClick={async () => {
                      await onSaveSettings(localSettings);
                      alert('Tetapan berjaya disimpan!');
                    }}
                    className="px-6 py-2.5 bg-orange-500 hover:bg-orange-400 text-slate-950 font-black text-xs uppercase rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md"
                  >
                    <Save className="w-4 h-4" />
                    <span>Simpan Perubahan</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: USERS & LIVE ACTIVITY LOGS */}
          {activeTab === 'users' && (
            <div className="space-y-6">
              {/* Action Banner */}
              {userActionMessage && (
                <div
                  className={`p-3.5 rounded-2xl border text-xs font-bold flex items-center justify-between gap-3 animate-fadeIn ${
                    userActionMessage.isError
                      ? 'bg-rose-500/15 border-rose-500/50 text-rose-300'
                      : 'bg-emerald-500/15 border-emerald-500/50 text-emerald-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {userActionMessage.isError ? (
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    )}
                    <span>{userActionMessage.text}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setUserActionMessage(null)}
                    className="text-xs opacity-75 hover:opacity-100"
                  >
                    Tutup
                  </button>
                </div>
              )}

              {/* DELETE & BAN CONFIRMATION MODAL */}
              {deleteConfirmUser && (
                <div className="fixed inset-0 z-[160] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
                  <div className="bg-[#0D1117] border-2 border-rose-500/80 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-[0_0_60px_rgba(244,63,94,0.35)] text-white space-y-5">
                    <div className="flex items-center gap-3 text-rose-400">
                      <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/50 flex items-center justify-center shrink-0">
                        <Trash2 className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-lg font-black text-white">Padam &amp; Sekat Akaun</h3>
                        <p className="text-xs text-rose-300">Tindakan ini adalah kekal dan tidak boleh log masuk lagi.</p>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5 text-xs font-mono">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Username:</span>
                        <span className="font-bold text-amber-400">{deleteConfirmUser.name || deleteConfirmUser.username}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Emel:</span>
                        <span className="text-cyan-300">{deleteConfirmUser.email}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">ID:</span>
                        <span className="text-slate-300">{deleteConfirmUser.id}</span>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-left">
                      <label className="text-xs font-bold text-slate-300 block">
                        Sebab Pemadaman &amp; Sekatan:
                      </label>
                      <input
                        type="text"
                        value={deleteReason}
                        onChange={(e) => setDeleteReason(e.target.value)}
                        placeholder="cth: Melanggar syarat / Spam / Permintaan pengguna"
                        className="w-full bg-[#121824] border border-slate-700 focus:border-rose-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
                      />
                    </div>

                    <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-[11px] text-rose-300 space-y-1">
                      <span className="font-bold block">⚠️ Kesan Pemadaman:</span>
                      <ul className="list-disc pl-4 space-y-0.5 text-rose-300/90">
                        <li>Pengguna akan disekat serta merta dari log masuk semula.</li>
                        <li>Emel dan username ini akan disenarai hitam secara automatik.</li>
                      </ul>
                    </div>

                    <div className="flex items-center gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setDeleteConfirmUser(null);
                          setDeleteReason('');
                        }}
                        disabled={isDeleting}
                        className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer transition-colors"
                      >
                        Batal
                      </button>
                      <button
                        type="button"
                        onClick={handleDeleteAndBanUser}
                        disabled={isDeleting}
                        className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs uppercase shadow-[0_0_25px_rgba(244,63,94,0.5)] cursor-pointer transition-all flex items-center justify-center gap-2"
                      >
                        {isDeleting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                        <span>{isDeleting ? 'Memadam...' : 'Sahkan Padam & Sekat'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="p-4 bg-[#121824] border border-cyan-500/30 rounded-2xl flex items-center gap-3">
                  <div className="p-3 bg-cyan-500/10 text-cyan-400 rounded-xl border border-cyan-500/30">
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Jumlah Pengguna Aktif</p>
                    <p className="text-2xl font-black text-white">{localUsers.length}</p>
                  </div>
                </div>

                <div className="p-4 bg-[#121824] border border-emerald-500/30 rounded-2xl flex items-center gap-3">
                  <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/30">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Emel Gmail Sah</p>
                    <p className="text-2xl font-black text-emerald-400">
                      {localUsers.filter((u) => u.email && u.email.includes('@')).length}
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-[#121824] border border-rose-500/30 rounded-2xl flex items-center gap-3">
                  <div className="p-3 bg-rose-500/10 text-rose-400 rounded-xl border border-rose-500/30">
                    <Trash2 className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Akaun Disekat / Dipadam</p>
                    <p className="text-2xl font-black text-rose-400">{bannedUsersList.length}</p>
                  </div>
                </div>

                <div className="p-4 bg-[#121824] border border-orange-500/30 rounded-2xl flex items-center gap-3">
                  <div className="p-3 bg-orange-500/10 text-orange-400 rounded-xl border border-orange-500/30">
                    <Activity className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Total Log Aktiviti</p>
                    <p className="text-2xl font-black text-orange-400">{activityLogs.length}</p>
                  </div>
                </div>
              </div>

              {/* Registered Users Table */}
              <div className="bg-[#121824] border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-base font-black text-white flex items-center gap-2">
                      <Users className="w-5 h-5 text-cyan-400" />
                      <span>Senarai Akaun Pengguna &amp; Emel Berdaftar</span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Admin boleh melihat siapa yang log masuk, menyalin emel semua pengguna, atau memadam/menyekat akaun.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={handleCopyAllEmails}
                      className="px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      <span>{copiedAllEmails ? 'Emel Disalin!' : 'Salin Semua Emel'}</span>
                    </button>

                    <div className="relative w-full sm:w-60">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        placeholder="Cari username, emel..."
                        value={userSearch}
                        onChange={(e) => setUserSearch(e.target.value)}
                        className="w-full bg-[#0D1117] border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>
                </div>

                {localUsers.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-6">Belum ada pengguna yang berdaftar.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                          <th className="py-3 px-3">Username &amp; Profil</th>
                          <th className="py-3 px-3">Alamat Emel Gmail</th>
                          <th className="py-3 px-3">ID Akaun</th>
                          <th className="py-3 px-3">No Telefon</th>
                          <th className="py-3 px-3">Tarikh Daftar &amp; Log Masuk</th>
                          <th className="py-3 px-3">Pesanan</th>
                          <th className="py-3 px-3 text-right">Tindakan Admin</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 font-medium">
                        {localUsers
                          .filter(
                            (u) =>
                              !userSearch ||
                              u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
                              (u.username && u.username.toLowerCase().includes(userSearch.toLowerCase())) ||
                              (u.email && u.email.toLowerCase().includes(userSearch.toLowerCase())) ||
                              (u.phoneNumber && u.phoneNumber.includes(userSearch)) ||
                              u.id.toLowerCase().includes(userSearch.toLowerCase())
                          )
                          .map((u) => (
                            <tr key={u.id} className="hover:bg-slate-900/60 transition-colors">
                              <td className="py-3 px-3">
                                <div className="flex items-center gap-2.5">
                                  <div
                                    className="relative group cursor-pointer"
                                    onClick={() => setPreviewAvatarUser(u)}
                                    title="Klik untuk lihat gambar profil penuh"
                                  >
                                    <img
                                      src={u.avatarUrl}
                                      alt={u.name}
                                      className="w-9 h-9 rounded-xl object-cover border border-cyan-400/50 group-hover:border-orange-400 transition-all"
                                      onError={(e) => {
                                        (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(u.name)}`;
                                      }}
                                    />
                                    <div className="absolute inset-0 bg-black/40 rounded-xl opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                      <Eye className="w-3.5 h-3.5 text-white" />
                                    </div>
                                  </div>
                                  <div>
                                    <div className="flex items-center gap-1.5">
                                      <p className="font-mono font-black text-amber-400 text-sm leading-tight">
                                        {u.name.startsWith('@') ? u.name : `@${u.name}`}
                                      </p>
                                      <button
                                        type="button"
                                        onClick={() => setPreviewAvatarUser(u)}
                                        className="p-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-cyan-400 transition-colors"
                                        title="Lihat foto profil"
                                      >
                                        <Camera className="w-3 h-3" />
                                      </button>
                                    </div>
                                    <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                                      Aktif
                                    </span>
                                  </div>
                                </div>
                              </td>

                              <td className="py-3 px-3 font-mono">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-cyan-300 text-xs font-semibold">{u.email || 'N/A'}</span>
                                  {u.email && (
                                    <button
                                      type="button"
                                      onClick={() => onOpenGmailModal?.(u.email)}
                                      title="Hantar emel kepada pengguna"
                                      className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-cyan-300"
                                    >
                                      <Mail className="w-3 h-3" />
                                    </button>
                                  )}
                                </div>
                              </td>

                              <td className="py-3 px-3 font-mono text-slate-300">
                                <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px] font-bold border border-slate-700">
                                  {u.id}
                                </span>
                              </td>

                              <td className="py-3 px-3 font-mono text-slate-300">
                                {u.phoneNumber ? (
                                  <div className="flex items-center gap-1.5">
                                    <span>{u.phoneNumber}</span>
                                    <a
                                      href={`https://wa.me/60${u.phoneNumber.replace(/\D/g, '').replace(/^0/, '')}`}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="p-1 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400"
                                      title="WhatsApp"
                                    >
                                      <ExternalLink className="w-3 h-3" />
                                    </a>
                                  </div>
                                ) : (
                                  <span className="text-slate-500 italic">Belum isi</span>
                                )}
                              </td>

                              <td className="py-3 px-3 text-slate-300 text-[11px]">
                                <div>Daftar: {new Date(u.createdAt).toLocaleDateString('ms-MY')}</div>
                                <div className="text-cyan-400 text-[10px]">
                                  Log Masuk: {new Date(u.lastLoginAt).toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' })}
                                </div>
                              </td>

                              <td className="py-3 px-3">
                                <span className="font-bold text-orange-400">{u.totalOrders || 0} Tx</span>
                                <span className="text-slate-400 text-[10px] block">RM {(u.totalSpent || 0).toFixed(2)}</span>
                              </td>

                              <td className="py-3 px-3 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  {/* Delete & Ban Button */}
                                  <button
                                    type="button"
                                    onClick={() => setDeleteConfirmUser(u)}
                                    title="Padam &amp; Sekat Akaun"
                                    className="px-2.5 py-1.5 bg-rose-500/15 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 transition-all cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                                    <span>Padam &amp; Sekat</span>
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Banned Users Table */}
              {bannedUsersList.length > 0 && (
                <div className="bg-[#121824] border border-rose-500/30 rounded-2xl p-4 sm:p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <Trash2 className="w-5 h-5 text-rose-400" />
                      <h3 className="text-base font-black text-white">Senarai Akaun Yang Telah Disekat &amp; Dipadam</h3>
                    </div>
                    <span className="text-xs font-mono text-rose-400 font-bold">{bannedUsersList.length} Akaun Disekat</span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                          <th className="py-2.5 px-3">Username</th>
                          <th className="py-2.5 px-3">Emel</th>
                          <th className="py-2.5 px-3">Tarikh Sekatan</th>
                          <th className="py-2.5 px-3">Sebab</th>
                          <th className="py-2.5 px-3 text-right">Tindakan</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 font-medium">
                        {bannedUsersList.map((b) => (
                          <tr key={b.id || b.email} className="hover:bg-slate-900/60 transition-colors">
                            <td className="py-2.5 px-3 font-mono font-bold text-rose-300">{b.username || 'Pengguna'}</td>
                            <td className="py-2.5 px-3 font-mono text-slate-300">{b.email || 'N/A'}</td>
                            <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                              {b.bannedAt ? new Date(b.bannedAt).toLocaleDateString('ms-MY') : 'Hari ini'}
                            </td>
                            <td className="py-2.5 px-3 text-slate-300 text-[11px] italic">{b.reason || 'Dipadam oleh Admin'}</td>
                            <td className="py-2.5 px-3 text-right">
                              <button
                                type="button"
                                onClick={() => handleUnbanUser(b.id, b.email)}
                                className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-[10px] font-bold inline-flex items-center gap-1 transition-all cursor-pointer"
                              >
                                <span>Buka Sekatan</span>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* User Avatars Wall / Gallery */}
              <div className="bg-[#121824] border border-cyan-500/30 rounded-2xl p-4 sm:p-5 space-y-4 shadow-lg">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <Camera className="w-5 h-5 text-cyan-400" />
                    <h3 className="text-base font-black text-white">Galeri Gambar Profil Pengguna</h3>
                  </div>
                  <span className="text-xs font-mono text-cyan-400 font-bold">{localUsers.length} Gambar Dipilih</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                  {localUsers.map((u) => (
                    <div
                      key={u.id}
                      onClick={() => setPreviewAvatarUser(u)}
                      className="p-3 rounded-2xl bg-[#0D1117] border border-slate-800 hover:border-cyan-500/60 transition-all cursor-pointer group space-y-2 text-center flex flex-col items-center shadow-md"
                    >
                      <div className="relative">
                        <img
                          src={u.avatarUrl}
                          alt={u.name}
                          className="w-16 h-16 rounded-2xl object-cover border-2 border-cyan-500/40 group-hover:border-cyan-400 group-hover:scale-105 transition-all shadow-md bg-[#121824]"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(u.name)}`;
                          }}
                        />
                        <div className="absolute inset-0 bg-black/40 rounded-2xl opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <Eye className="w-4 h-4 text-white" />
                        </div>
                      </div>
                      <div className="w-full">
                        <p className="font-mono font-bold text-amber-400 text-xs truncate">
                          {u.name.startsWith('@') ? u.name : `@${u.name}`}
                        </p>
                        <p className="text-[10px] text-slate-400 truncate">
                          {u.email || 'Tiada emel'}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Live Activity Logs */}
              <div className="bg-[#121824] border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-amber-400" />
                    <h3 className="text-base font-black text-white">Log Aktiviti &amp; Login Live</h3>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">{activityLogs.length} Rekod</span>
                </div>

                {activityLogs.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-4">Tiada rekod aktiviti.</p>
                ) : (
                  <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                    {activityLogs.map((log) => (
                      <div
                        key={log.id}
                        className="p-3 bg-[#0D1117] border border-slate-800/80 rounded-xl flex items-center justify-between gap-3 text-xs"
                      >
                        <div className="flex items-center gap-2.5">
                          <span
                            className={`p-1.5 rounded-lg text-[10px] font-black uppercase ${
                              log.type === 'register'
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                : log.type === 'login'
                                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                                : log.type === 'account_deleted'
                                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                : 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                            }`}
                          >
                            {log.type === 'register' ? 'NEW USER' : log.type === 'login' ? 'LOGIN' : log.type === 'account_deleted' ? 'DELETED' : 'LOG'}
                          </span>
                          <div>
                            <p className="font-mono font-black text-amber-400">
                              {log.userName.startsWith('@') ? log.userName : `@${log.userName}`}
                            </p>
                            <p className="text-[11px] text-slate-300">{log.details}</p>
                          </div>
                        </div>

                        <span className="text-[10px] text-slate-500 font-mono shrink-0">
                          {new Date(log.timestamp).toLocaleTimeString('ms-MY')}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 6: REAL-TIME LIVE CHAT ADMIN */}
          {activeTab === 'chat' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-teal-500/10 to-emerald-500/15 border border-emerald-500/40 text-xs text-slate-200 flex items-center justify-between gap-4">
                <div>
                  <span className="font-bold text-emerald-400 uppercase font-mono block">
                    💬 LIVE CHAT ADMIN 24/7 (SAMA SEPERTI WHATSAPP)
                  </span>
                  <p className="text-slate-300">
                    Balas perbualan pelanggan secara langsung secara real-time. Notifikasi pesanan baharu akan dikemaskini automatik.
                  </p>
                </div>
                <button
                  onClick={fetchAdminChats}
                  className="px-3 py-1.5 bg-emerald-500 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1 hover:bg-emerald-400 transition-all cursor-pointer shrink-0"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh Chat</span>
                </button>
              </div>

              {/* Chat Interface Container */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-0 md:gap-4 h-[550px] bg-[#07090D] rounded-2xl border border-slate-800 overflow-hidden">
                
                {/* Left Column: WhatsApp-style Session List */}
                <div className={`md:col-span-1 border-r border-slate-800 flex-col bg-[#0B0E14] h-full min-h-0 ${selectedSessionId ? 'hidden md:flex' : 'flex'}`}>
                  <div className="p-3 border-b border-slate-800 bg-[#121824] space-y-2 shrink-0">
                    <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <MessageCircle className="w-4 h-4 text-emerald-400" />
                        <span>Mesej Pelanggan</span>
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono text-[10px]">
                        {chatSessions.length}
                      </span>
                    </h3>

                    {/* Search Input for Users */}
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
                      <input
                        type="text"
                        placeholder="Cari username pelanggan..."
                        value={chatSearchQuery}
                        onChange={(e) => setChatSearchQuery(e.target.value)}
                        className="w-full bg-[#080B10] border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  {/* Scrollable WhatsApp Chat List */}
                  <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60 min-h-0">
                    {(() => {
                      const filteredSessions = chatSessions.filter((s) =>
                        s.senderName.toLowerCase().includes(chatSearchQuery.toLowerCase()) ||
                        s.sessionId.toLowerCase().includes(chatSearchQuery.toLowerCase())
                      );

                      if (filteredSessions.length === 0) {
                        return (
                          <div className="p-6 text-center text-slate-500 text-xs">
                            Tiada perbualan dijumpai.
                          </div>
                        );
                      }

                      return filteredSessions.map((session) => {
                        const isSelected = selectedSessionId === session.sessionId;
                        return (
                          <button
                            key={session.sessionId}
                            onClick={() => {
                              setSelectedSessionId(session.sessionId);
                              fetch('/api/chat/read', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ sessionId: session.sessionId }),
                              });
                            }}
                            className={`w-full p-3 text-left transition-all flex items-center justify-between gap-2.5 cursor-pointer ${
                              isSelected
                                ? 'bg-emerald-500/15 border-l-4 border-emerald-500'
                                : 'hover:bg-slate-900/60'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 min-w-0 flex-1">
                              <div className="relative shrink-0">
                                <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-400 font-bold text-xs uppercase">
                                  {(session.senderName || 'Pelanggan').replace(/^@/, '').substring(0, 2) || 'US'}
                                </div>
                                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-slate-950" />
                              </div>

                              <div className="min-w-0 flex-1">
                                <div className="flex items-center justify-between gap-1">
                                  <p className="text-xs font-black text-white truncate">
                                    {session.senderName}
                                  </p>
                                  <span className="text-[9px] text-slate-500 font-mono shrink-0">
                                    {session.lastTime}
                                  </span>
                                </div>
                                <p className="text-[11px] text-slate-400 truncate mt-0.5">
                                  {session.lastMessage || 'Mula chat...'}
                                </p>
                              </div>
                            </div>

                            {session.unreadCount > 0 && (
                              <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white font-mono font-bold text-[9px] animate-pulse shrink-0">
                                {session.unreadCount}
                              </span>
                            )}
                          </button>
                        );
                      });
                    })()}
                  </div>
                </div>

                {/* Right Column: Chat Window */}
                <div className={`md:col-span-2 flex-col bg-[#0D1117] h-full min-h-0 ${selectedSessionId ? 'flex' : 'hidden md:flex'}`}>
                  {selectedSessionId ? (
                    (() => {
                      const activeSession = chatSessions.find(
                        (s) => s.sessionId === selectedSessionId
                      );
                      const activeMsgs = activeSession ? activeSession.messages : [];

                      return (
                        <>
                          {/* Chat Header with Back Button */}
                          <div className="p-3 bg-[#121824] border-b border-slate-800 flex items-center justify-between shrink-0">
                            <div className="flex items-center gap-2.5">
                              <button
                                type="button"
                                onClick={() => setSelectedSessionId(null)}
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 text-xs font-bold cursor-pointer transition-all border border-slate-700"
                                title="Kembali ke senarai mesej"
                              >
                                <ArrowLeft className="w-4 h-4 text-emerald-400" />
                                <span className="text-[11px] font-bold">Kembali</span>
                              </button>

                              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold text-xs shrink-0">
                                <Users className="w-4 h-4" />
                              </div>
                              <div className="min-w-0">
                                <h4 className="text-xs font-bold text-white truncate">
                                  {activeSession?.senderName || 'Pelanggan'}
                                </h4>
                                <span className="text-[10px] text-emerald-400 font-mono block truncate">
                                  Session ID: {selectedSessionId}
                                </span>
                              </div>
                            </div>

                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shrink-0">
                              24/7 Live Connected
                            </span>
                          </div>

                          {/* Chat Messages */}
                          <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 bg-[#080B10] min-h-0">
                            {activeMsgs.map((m) => {
                              const isAdmin = m.sender === 'admin';
                              return (
                                <div
                                  key={m.id}
                                  className={`flex flex-col ${isAdmin ? 'items-end' : 'items-start'}`}
                                >
                                  <div
                                    className={`max-w-[85%] sm:max-w-[80%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed ${
                                      isAdmin
                                        ? 'bg-orange-500 text-slate-950 font-medium rounded-br-none'
                                        : 'bg-[#161D2E] text-slate-200 border border-slate-700 rounded-bl-none'
                                    }`}
                                  >
                                    <p className="whitespace-pre-wrap">{m.message}</p>
                                    <span
                                      className={`text-[9px] font-mono block text-right mt-1 ${
                                        isAdmin ? 'text-slate-900' : 'text-slate-400'
                                      }`}
                                    >
                                      {m.timestamp}
                                    </span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>

                          {/* Quick Admin Responses */}
                          <div className="px-3 py-1.5 bg-[#0B0E14] border-t border-slate-800 flex items-center gap-1.5 overflow-x-auto text-[10px] shrink-0">
                            <span className="text-slate-500 font-bold shrink-0">Balasan Pantas:</span>
                            <button
                              type="button"
                              onClick={() => setAdminReplyText('Pesanan anda sedang diproses dalam masa 1-3 minit. Terima kasih!')}
                              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 whitespace-nowrap cursor-pointer"
                            >
                              ⚡ Sedang Diproses
                            </button>
                            <button
                              type="button"
                              onClick={() => setAdminReplyText('Sila lampirkan tangkapan skrin (screenshot) resit pembayaran.')}
                              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 whitespace-nowrap cursor-pointer"
                            >
                              📑 Minta Resit
                            </button>
                            <button
                              type="button"
                              onClick={() => setAdminReplyText('Topup telah BERJAYA dikreditkan ke akaun game anda! Selamat bermain! 🎉')}
                              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 whitespace-nowrap cursor-pointer"
                            >
                              ✅ Topup Selesai
                            </button>
                          </div>

                          {/* Reply Input Bar */}
                          <form
                            onSubmit={handleSendReply}
                            className="p-3 bg-[#121824] border-t border-slate-800 flex items-center gap-2 shrink-0"
                          >
                            <input
                              type="text"
                              placeholder="Tulis balasan kepada pelanggan..."
                              value={adminReplyText}
                              onChange={(e) => setAdminReplyText(e.target.value)}
                              className="flex-1 bg-[#080B10] border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-all"
                            />
                            <button
                              type="submit"
                              disabled={!adminReplyText.trim() || sendingReply}
                              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs uppercase transition-all disabled:opacity-40 cursor-pointer flex items-center gap-1.5 shrink-0 shadow-md"
                            >
                              <Send className="w-4 h-4" />
                              <span>Balas</span>
                            </button>
                          </form>
                        </>
                      );
                    })()
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-slate-500 text-xs">
                      <MessageCircle className="w-12 h-12 text-slate-700 mb-3 animate-pulse" />
                      <p className="font-bold text-slate-300 text-sm mb-1">Tiada Chat Dipilih</p>
                      <p className="max-w-xs text-slate-400">Sila tekan nama pelanggan di senarai sebelah kiri untuk mula membaca & membalas mesej.</p>
                    </div>
                  )}
                </div>

              </div>
            </div>
          )}

          {/* TAB 7: FLASH SALE (JUALAN KILAT) ADMIN CONTROL */}
          {activeTab === 'flash_sale' && (
            <div className="space-y-6 animate-fadeIn pb-12">
              {/* Alert Notification Message */}
              {flashSaleMsg && (
                <div
                  className={`p-3.5 rounded-2xl text-xs font-bold flex items-center justify-between border ${
                    flashSaleMsg.isError
                      ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                      : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    <span>{flashSaleMsg.text}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFlashSaleMsg(null)}
                    className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Master Flash Sale Settings Card */}
              <div className="bg-[#121824] border-2 border-orange-500/40 rounded-3xl p-4 sm:p-6 space-y-6 shadow-[0_10px_35px_rgba(249,115,22,0.15)] relative overflow-hidden">
                <div className="absolute top-0 right-0 -mt-10 -mr-10 w-48 h-48 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-orange-500/30">
                      <Zap className="w-6 h-6 fill-current animate-pulse" />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-white flex items-center gap-2">
                        Kawalan Jualan Kilat (Flash Sale)
                        <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-400 border border-orange-500/40">
                          Live 24/7
                        </span>
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Urus tawaran diskaun istimewa, tetapkan masa tamat dan had bilangan pembeli.
                      </p>
                    </div>
                  </div>

                  {/* Master Enable/Disable Toggle */}
                  <div className="flex items-center gap-3 bg-[#090C12] px-4 py-2.5 rounded-2xl border border-slate-800 self-start sm:self-auto">
                    <span className="text-xs font-bold text-slate-300">Status Jualan:</span>
                    <button
                      type="button"
                      onClick={() => {
                        const nextState = !localFlashSale.isEnabled;
                        const updated = { ...localFlashSale, isEnabled: nextState };
                        persistFlashSale(
                          updated,
                          nextState
                            ? '⚡ Jualan Kilat Diaktifkan di Laman Utama!'
                            : '⚠️ Jualan Kilat Ditutup dari Laman Utama'
                        );
                      }}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                        localFlashSale.isEnabled ? 'bg-orange-500' : 'bg-slate-700'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          localFlashSale.isEnabled ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                    <span className={`text-xs font-black ${localFlashSale.isEnabled ? 'text-orange-400' : 'text-slate-500'}`}>
                      {localFlashSale.isEnabled ? 'AKTIF' : 'TUTUP'}
                    </span>
                  </div>
                </div>

                {/* Title & Countdown End Time Configuration */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Flash Sale Title */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 block">
                      Tajuk Promosi Jualan Kilat:
                    </label>
                    <input
                      type="text"
                      value={localFlashSale.title || ''}
                      onChange={(e) =>
                        setLocalFlashSale((prev) => ({ ...prev, title: e.target.value }))
                      }
                      placeholder="cth: JUALAN KILAT ⚡"
                      className="w-full bg-[#090C12] border border-slate-700 focus:border-orange-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none"
                    />
                  </div>

                  {/* End Time Configuration by Typing Jam | Minit | Saat */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-300 block">
                      Tempoh Masa Promosi (Jam : Minit : Saat):
                    </label>

                    <div className="grid grid-cols-3 gap-2">
                      {/* Jam Input */}
                      <div className="space-y-1">
                        <span className="text-[11px] font-extrabold text-orange-400 block text-center uppercase tracking-wider">
                          Jam
                        </span>
                        <input
                          type="number"
                          min="0"
                          value={durationHours}
                          onChange={(e) => setDurationHours(e.target.value)}
                          placeholder="0"
                          className="w-full text-center bg-[#090C12] border border-slate-700 focus:border-orange-500 rounded-xl py-2.5 px-2 text-base font-black font-mono text-white placeholder-slate-600 focus:outline-none"
                        />
                      </div>

                      {/* Minit Input */}
                      <div className="space-y-1">
                        <span className="text-[11px] font-extrabold text-amber-400 block text-center uppercase tracking-wider">
                          Minit
                        </span>
                        <input
                          type="number"
                          min="0"
                          max="59"
                          value={durationMinutes}
                          onChange={(e) => setDurationMinutes(e.target.value)}
                          placeholder="0"
                          className="w-full text-center bg-[#090C12] border border-slate-700 focus:border-orange-500 rounded-xl py-2.5 px-2 text-base font-black font-mono text-white placeholder-slate-600 focus:outline-none"
                        />
                      </div>

                      {/* Saat Input */}
                      <div className="space-y-1">
                        <span className="text-[11px] font-extrabold text-red-400 block text-center uppercase tracking-wider">
                          Saat
                        </span>
                        <input
                          type="number"
                          min="0"
                          max="59"
                          value={durationSeconds}
                          onChange={(e) => setDurationSeconds(e.target.value)}
                          placeholder="0"
                          className="w-full text-center bg-[#090C12] border border-slate-700 focus:border-orange-500 rounded-xl py-2.5 px-2 text-base font-black font-mono text-white placeholder-slate-600 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* NEW: Teks Pengumuman Khas Merdeka & Background Bendera Malaysia */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0c1322] via-[#1a0a10] to-[#090d1a] border border-amber-500/40 space-y-4 shadow-inner">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">🇲🇾</span>
                      <div>
                        <h4 className="text-xs sm:text-sm font-black text-amber-300 flex items-center gap-1.5">
                          Teks Pengumuman / Tema Khas Atas Kotak Jualan Kilat
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Teks ini akan dipaparkan di bahagian paling atas kotak jualan kilat (contoh: Sempena Sambutan Bulan Kemerdekaan).
                        </p>
                      </div>
                    </div>

                    {/* Toggle Show Announcement */}
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-bold text-slate-300">Papar Banner:</span>
                      <button
                        type="button"
                        onClick={() =>
                          setLocalFlashSale((prev) => ({
                            ...prev,
                            showAnnouncement: prev.showAnnouncement === false ? true : false,
                          }))
                        }
                        className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer ${
                          localFlashSale.showAnnouncement !== false ? 'bg-amber-500' : 'bg-slate-700'
                        }`}
                      >
                        <span
                          className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                            localFlashSale.showAnnouncement !== false ? 'translate-x-4.5' : 'translate-x-0.5'
                          }`}
                        />
                      </button>
                    </div>
                  </div>

                  {/* Announcement Text Input */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 block">
                      Ayat Pengumuman Promosi (Boleh Diedit):
                    </label>
                    <input
                      type="text"
                      value={localFlashSale.announcementText ?? '🇲🇾 SEMPENA BULAN KEMERDEKAAN MALAYSIA KE-69 • DISKAUN MERDEKA 🇲🇾'}
                      onChange={(e) =>
                        setLocalFlashSale((prev) => ({ ...prev, announcementText: e.target.value }))
                      }
                      placeholder="cth: 🇲🇾 SEMPENA BULAN KEMERDEKAAN MALAYSIA KE-69 • DISKAUN MERDEKA 🇲🇾"
                      className="w-full bg-[#090C12] border border-amber-500/50 focus:border-amber-400 rounded-xl px-3.5 py-2.5 text-xs font-bold text-yellow-300 placeholder-slate-500 focus:outline-none shadow-sm"
                    />
                  </div>

                  {/* Quick Preset Buttons */}
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                      Pilihan Pantas (Klik untuk pilih):
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        '🇲🇾 SEMPENA BULAN KEMERDEKAAN MALAYSIA KE-69 • DISKAUN MERDEKA 🇲🇾',
                        '🎉 PROMO SAMBUTAN HARI KEBANGSAAN KE-69 • HARGA JIMAT HABIS 🇲🇾',
                        '⚡ JUALAN KILAT MERDEKA TERHAD HARI INI • SIAPA CEPAT DIA DAPAT 🔥',
                        '💎 MEGA DEALS TOPUPBALZ MERDEKA • JIMAT SEHINGGA 40% 🚀',
                      ].map((presetText) => (
                        <button
                          key={presetText}
                          type="button"
                          onClick={() =>
                            setLocalFlashSale((prev) => ({
                              ...prev,
                              announcementText: presetText,
                              showAnnouncement: true,
                            }))
                          }
                          className="px-2.5 py-1 rounded-lg bg-slate-900/90 hover:bg-amber-500/20 border border-slate-700 hover:border-amber-500/50 text-[10px] font-semibold text-slate-300 hover:text-yellow-300 transition-colors cursor-pointer"
                        >
                          {presetText}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Background Gambar Merdeka & Pilihan Dari Galeri / Muat Naik */}
                  <div className="space-y-3 pt-2 border-t border-slate-800">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="text-xs font-bold text-slate-300 block">
                        🖼️ Gambar Background Kotak Jualan Kilat (Pilih Dari Galeri):
                      </label>
                      <span className="text-[11px] text-amber-400 font-semibold">
                        Admin boleh muat naik gambar sendiri atau pilih dari galeri
                      </span>
                    </div>

                    {/* Live Background Image Preview Box */}
                    <div className="relative h-28 sm:h-36 rounded-2xl overflow-hidden border-2 border-amber-500/50 shadow-md flex items-center justify-center bg-slate-950">
                      {localFlashSale.customBgUrl ? (
                        <>
                          <img
                            src={localFlashSale.customBgUrl}
                            alt="Background Preview"
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex items-end justify-between p-3">
                            <span className="text-[11px] font-bold text-yellow-300 bg-black/60 px-2 py-0.5 rounded-md border border-yellow-500/30">
                              Pratonton Background Aktif
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                const updated = {
                                  ...localFlashSale,
                                  customBgUrl: 'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&w=1200&q=80',
                                  themeStyle: 'merdeka' as any,
                                };
                                setLocalFlashSale(updated);
                                persistFlashSale(updated, '🇲🇾 Latar belakang diset semula ke Bendera Malaysia (Jalur Gemilang)!');
                              }}
                              className="text-[10px] font-extrabold text-amber-300 bg-amber-500/20 hover:bg-amber-500 hover:text-slate-950 border border-amber-500/40 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                            >
                              🇲🇾 Reset Bendera Merdeka
                            </button>
                          </div>
                        </>
                      ) : (
                        <div className="text-center text-slate-500 text-xs">
                          <ImageIcon className="w-8 h-8 mx-auto mb-1 opacity-50 text-amber-400" />
                          <span>Tiada Gambar Background Dipilih</span>
                        </div>
                      )}
                    </div>

                    {/* File Upload Button from Gallery & Presets */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {/* Pick from Device Gallery */}
                      <div>
                        <label className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md hover:scale-[1.01] transition-all">
                          <Upload className="w-4 h-4 text-slate-950" />
                          <span>📁 Pilih Gambar Dari Galeri Telefon / Laptop</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                try {
                                  const compressed = await compressImage(file, 1200, 0.75);
                                  const updated = {
                                    ...localFlashSale,
                                    customBgUrl: compressed,
                                  };
                                  setLocalFlashSale(updated);
                                  persistFlashSale(updated, '📁 Gambar galeri berjaya dimuat naik & disimpan sebagai background jualan kilat!');
                                } catch (err) {
                                  console.error('Error reading image:', err);
                                }
                              }
                            }}
                          />
                        </label>
                        <span className="text-[10px] text-slate-400 mt-1 block">
                          Format: PNG, JPG, WEBP (auto-compress untuk kelajuan optimum)
                        </span>
                      </div>

                      {/* Theme Style selector */}
                      <div className="space-y-1">
                        <select
                          value={localFlashSale.themeStyle || 'merdeka'}
                          onChange={(e) => {
                            const updated = {
                              ...localFlashSale,
                              themeStyle: e.target.value as any,
                            };
                            setLocalFlashSale(updated);
                            persistFlashSale(updated, 'Tema Jualan Kilat dikemaskini!');
                          }}
                          className="w-full bg-[#090C12] border border-slate-700 focus:border-amber-500 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none"
                        >
                          <option value="merdeka">🇲🇾 Tema Kemerdekaan Malaysia (Bendera & Jalur Gemilang)</option>
                          <option value="fire">🔥 Tema Api & Kilat (Cyber Orange / Red)</option>
                          <option value="dark">🌌 Tema Gelap & Neon Titanium</option>
                        </select>
                      </div>
                    </div>

                    {/* Presets Gallery Quick Wallpapers */}
                    <div className="pt-2 border-t border-slate-800 space-y-1.5">
                      <span className="text-[11px] font-bold text-slate-300 block">
                        Pilihan Galeri Templat Merdeka & Background Sedia Ada:
                      </span>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {[
                          {
                            title: '🇲🇾 Bendera Malaysia',
                            desc: 'Jalur Gemilang Berkibar',
                            url: 'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&w=1200&q=80',
                            theme: 'merdeka',
                          },
                          {
                            title: '🇲🇾 Mercu Tanda KLCC',
                            desc: 'Kuala Lumpur Skyline',
                            url: 'https://images.unsplash.com/photo-1596422846543-75c6fc197f07?auto=format&fit=crop&w=1200&q=80',
                            theme: 'merdeka',
                          },
                          {
                            title: '🔥 Cyber Flame Red',
                            desc: 'Gelombang Api Jualan Kilat',
                            url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
                            theme: 'fire',
                          },
                          {
                            title: '🌌 Titanium Dark Night',
                            desc: 'Tema Gaming Gelap & Moden',
                            url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80',
                            theme: 'dark',
                          },
                        ].map((preset) => (
                          <div
                            key={preset.title}
                            onClick={() => {
                              const updated = {
                                ...localFlashSale,
                                customBgUrl: preset.url,
                                themeStyle: preset.theme as any,
                              };
                              setLocalFlashSale(updated);
                              persistFlashSale(updated, `Wallpaper "${preset.title}" berjaya dipilih & disimpan!`);
                            }}
                            className={`group relative p-2 rounded-xl border transition-all cursor-pointer overflow-hidden ${
                              localFlashSale.customBgUrl === preset.url
                                ? 'bg-amber-500/20 border-amber-400 ring-1 ring-amber-400'
                                : 'bg-slate-900/80 border-slate-700 hover:border-amber-500/50'
                            }`}
                          >
                            <div className="h-12 rounded-lg overflow-hidden mb-1.5 bg-slate-950">
                              <img
                                src={preset.url}
                                alt={preset.title}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                              />
                            </div>
                            <span className="text-[10px] font-black text-white block truncate">
                              {preset.title}
                            </span>
                            <span className="text-[9px] text-slate-400 block truncate">
                              {preset.desc}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Manual URL Input */}
                    <div className="pt-2">
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">
                        Atau Tampal URL Gambar Background Terus:
                      </label>
                      <input
                        type="text"
                        value={localFlashSale.customBgUrl || ''}
                        onChange={(e) =>
                          setLocalFlashSale((prev) => ({
                            ...prev,
                            customBgUrl: e.target.value,
                          }))
                        }
                        placeholder="https://..."
                        className="w-full bg-[#090C12] border border-slate-700 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Save Flash Sale Button */}
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleSaveFlashSaleConfig}
                    disabled={isSavingFlashSale}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 hover:from-amber-400 hover:via-orange-400 hover:to-red-400 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-[0_0_20px_rgba(249,115,22,0.4)] disabled:opacity-50 transition-all cursor-pointer"
                  >
                    {isSavingFlashSale ? (
                      <>
                        <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                        <span>Menyimpan...</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>Simpan Tetapan Jualan Kilat</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Add New Flash Sale Item Form */}
              <div className="bg-[#121824] border border-slate-800 rounded-3xl p-4 sm:p-6 space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
                  <Plus className="w-5 h-5 text-orange-400" />
                  <h3 className="text-base font-black text-white">
                    Tambah Pakej Game ke Jualan Kilat
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                  {/* Game Selector */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-400 block">1. Pilih Game:</label>
                    <select
                      value={selectedGameForNewItem}
                      onChange={(e) => {
                        setSelectedGameForNewItem(e.target.value);
                        const g = games.find((x) => x.id === e.target.value);
                        if (g && g.items.length > 0) {
                          setSelectedPackageForNewItem(g.items[0].id);
                        }
                      }}
                      className="w-full bg-[#090C12] border border-slate-700 focus:border-orange-500 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                    >
                      {games.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.name} ({g.items?.length || 0} pakej)
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Package / Diamond Selector */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-400 block">2. Pilih Pakej Diamond / Item:</label>
                    {(() => {
                      const curGame = games.find((g) => g.id === selectedGameForNewItem) || games[0];
                      const itemsList = curGame?.items || [];
                      return (
                        <select
                          value={selectedPackageForNewItem || itemsList[0]?.id || ''}
                          onChange={(e) => setSelectedPackageForNewItem(e.target.value)}
                          className="w-full bg-[#090C12] border border-slate-700 focus:border-orange-500 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                        >
                          {itemsList.map((it) => (
                            <option key={it.id} value={it.id}>
                              {it.name} — Asal: RM {(it.sellPrice || it.basePrice || 0).toFixed(2)}
                            </option>
                          ))}
                        </select>
                      );
                    })()}
                  </div>

                  {/* Flash Sale Price Input */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-400 block">
                      3. Harga Jualan Kilat (RM):
                    </label>
                    <input
                      type="number"
                      step="0.10"
                      min="0.10"
                      value={newFlashPrice}
                      onChange={(e) => setNewFlashPrice(e.target.value)}
                      placeholder="cth: 42.50"
                      className="w-full bg-[#090C12] border border-slate-700 focus:border-orange-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none font-mono"
                    />
                  </div>

                  {/* Quota Input */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-400 block">
                      4. Berapa Orang Boleh Beli (Kuota):
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={newMaxQuota}
                      onChange={(e) => setNewMaxQuota(e.target.value)}
                      placeholder="cth: 20"
                      className="w-full bg-[#090C12] border border-slate-700 focus:border-orange-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="button"
                    onClick={handleAddNewFlashItem}
                    className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
                  >
                    <Plus className="w-4 h-4 stroke-[3]" />
                    <span>Masukkan Item ke Jualan Kilat</span>
                  </button>
                </div>
              </div>

              {/* Flash Sale Active Items List & Live Preview */}
              <div className="bg-[#121824] border border-slate-800 rounded-3xl p-4 sm:p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-amber-400" />
                    <h3 className="text-base font-black text-white">
                      Senarai Pakej Jualan Kilat Semasa ({localFlashSale.items?.length || 0})
                    </h3>
                  </div>
                  <span className="text-xs font-mono text-slate-400">
                    Auto hilang bila cukup kuota
                  </span>
                </div>

                {(!localFlashSale.items || localFlashSale.items.length === 0) ? (
                  <div className="p-8 text-center bg-[#090C12] rounded-2xl border border-dashed border-slate-800 text-slate-500 text-xs">
                    <Zap className="w-10 h-10 text-slate-700 mx-auto mb-2" />
                    <p className="font-bold text-slate-400">Tiada Item Jualan Kilat Didaftarkan</p>
                    <p className="text-[11px] text-slate-600 mt-1">
                      Gunakan borang di atas untuk memasukkan pakej diamond game.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {localFlashSale.items.map((item) => {
                      const matchedGame = games.find((g) => g.id === item.gameId);
                      const remaining = Math.max(0, item.maxQuota - item.soldCount);
                      const percent = item.maxQuota > 0 ? Math.min(100, Math.round((item.soldCount / item.maxQuota) * 100)) : 0;
                      const savings = item.savings > 0 ? item.savings : Math.max(0, item.originalPrice - item.flashPrice);

                      return (
                        <div
                          key={item.id}
                          className={`relative rounded-2xl p-4 border transition-all space-y-3 ${
                            item.isActive
                              ? 'bg-[#0D1117] border-orange-500/40 shadow-lg'
                              : 'bg-[#0D1117]/50 border-slate-800 opacity-60'
                          }`}
                        >
                          {/* Top row: Game Info & Actions */}
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <img
                                src={item.gameLogoUrl || matchedGame?.logoUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=200&q=80'}
                                alt={item.gameName}
                                className="w-10 h-10 rounded-xl object-cover border border-slate-700 shrink-0"
                              />
                              <div className="min-w-0">
                                <span className="text-[10px] font-bold text-orange-400 uppercase block truncate">
                                  {item.gameName}
                                </span>
                                <h4 className="text-xs font-black text-white truncate">
                                  {item.itemName}
                                </h4>
                              </div>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              {/* Toggle active */}
                              <button
                                type="button"
                                onClick={() => handleToggleFlashItemActive(item.id)}
                                title={item.isActive ? 'Nyahaktifkan item' : 'Aktifkan item'}
                                className={`p-1.5 rounded-lg border text-xs cursor-pointer transition-colors ${
                                  item.isActive
                                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/30'
                                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                                }`}
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>

                              {/* Delete item */}
                              <button
                                type="button"
                                onClick={() => handleDeleteFlashItem(item.id)}
                                title="Padam item dari jualan kilat"
                                className="p-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs cursor-pointer transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          {/* Price Display */}
                          <div className="bg-[#121824] p-2.5 rounded-xl border border-slate-800/80 flex items-center justify-between">
                            <div>
                              <span className="text-[9px] text-slate-400 block font-medium">Harga Asal:</span>
                              {/* CRITICAL: Harga sebenar coret oren tua (DARK ORANGE) */}
                              <span className="text-xs font-bold text-orange-700 dark:text-amber-600 line-through">
                                RM {item.originalPrice.toFixed(2)}
                              </span>
                            </div>

                            <div className="text-center">
                              <span className="text-[9px] text-red-400 font-bold block">Penjimatan:</span>
                              <span className="text-xs font-black text-red-400">
                                Jimat RM {savings.toFixed(2)}
                              </span>
                            </div>

                            <div className="text-right">
                              <span className="text-[9px] text-orange-400 font-bold block uppercase">Kilat:</span>
                              <span className="text-sm font-black text-amber-400">
                                RM {item.flashPrice.toFixed(2)}
                              </span>
                            </div>
                          </div>

                          {/* Quota Progress & Quick Counter */}
                          <div className="space-y-1 text-[11px]">
                            <div className="flex items-center justify-between font-bold">
                              <span className="text-slate-400">
                                Terjual: <span className="text-white">{item.soldCount}</span> / {item.maxQuota} orang
                              </span>
                              <span className={remaining <= 3 ? 'text-red-400 font-black' : 'text-amber-400'}>
                                {remaining === 0 ? 'HABIS (Hilang Dari Kedai)' : `Tinggal ${remaining} slot`}
                              </span>
                            </div>

                            <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                              <div
                                className="h-full bg-gradient-to-r from-amber-500 to-red-500 rounded-full"
                                style={{ width: `${percent}%` }}
                              />
                            </div>
                          </div>

                          {/* Edit Quota & Sold Count Quick Inputs */}
                          <div className="grid grid-cols-2 gap-2 pt-1">
                            <div>
                              <label className="text-[9px] text-slate-400 block font-medium">Kuota Max:</label>
                              <input
                                type="number"
                                min="1"
                                value={item.maxQuota}
                                onChange={(e) => {
                                  const val = Number(e.target.value);
                                  setLocalFlashSale((prev) => ({
                                    ...prev,
                                    items: prev.items.map((it) =>
                                      it.id === item.id ? { ...it, maxQuota: val } : it
                                    ),
                                  }));
                                }}
                                className="w-full bg-[#080B10] border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono"
                              />
                            </div>

                            <div>
                              <label className="text-[9px] text-slate-400 block font-medium">Terjual:</label>
                              <input
                                type="number"
                                min="0"
                                value={item.soldCount}
                                onChange={(e) => {
                                  const val = Number(e.target.value);
                                  setLocalFlashSale((prev) => ({
                                    ...prev,
                                    items: prev.items.map((it) =>
                                      it.id === item.id ? { ...it, soldCount: val } : it
                                    ),
                                  }));
                                }}
                                className="w-full bg-[#080B10] border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono"
                              />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                <div className="flex justify-end pt-3">
                  <button
                    type="button"
                    onClick={handleSaveFlashSaleConfig}
                    disabled={isSavingFlashSale}
                    className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition-all shadow-md cursor-pointer disabled:opacity-50"
                  >
                    <Check className="w-4 h-4 stroke-[3]" />
                    <span>Simpan Perubahan Senarai Item</span>
                  </button>
                </div>
              </div>

            </div>
          )}

          {/* TAB 8: GAMBAR TF GENERATOR */}
          {activeTab === 'gambar_tf' && (
            <GambarTfGenerator onBackToHub={() => setActiveTab('hub')} />
          )}

        </div>

      </div>

      {/* Proof Viewer Modal */}
      {viewingProof && (
        <div
          onClick={() => setViewingProof(null)}
          className="fixed inset-0 z-60 bg-black/90 flex items-center justify-center p-4 cursor-pointer"
        >
          <div className="max-w-md w-full p-2 bg-slate-900 rounded-2xl border border-orange-500/50">
            <img
              src={viewingProof}
              alt="Resit Bayaran Transfer"
              className="w-full h-auto max-h-[80vh] object-contain rounded-xl"
            />
            <p className="text-center text-xs text-slate-400 mt-2">Tekan di mana-mana untuk tutup</p>
          </div>
        </div>
      )}

      {/* MODAL PREVIEW GAMBAR PROFIL USER (ADMIN) */}
      {previewAvatarUser && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0D1117] border border-cyan-500/50 rounded-3xl p-6 sm:p-8 max-w-sm w-full shadow-[0_0_50px_rgba(6,182,212,0.3)] space-y-5 animate-scaleIn text-center relative">
            <button
              type="button"
              onClick={() => setPreviewAvatarUser(null)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center justify-center gap-2 text-cyan-400">
              <Camera className="w-5 h-5" />
              <span className="text-xs font-black uppercase tracking-wider">Gambar Profil Pengguna</span>
            </div>

            <div className="flex justify-center">
              <img
                src={previewAvatarUser.avatarUrl}
                alt={previewAvatarUser.name}
                className="w-48 h-48 rounded-3xl object-cover border-4 border-cyan-500/60 shadow-2xl bg-[#121824]"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(previewAvatarUser.name)}`;
                }}
              />
            </div>

            <div className="space-y-1">
              <h4 className="text-lg font-black text-amber-400 font-mono">
                {previewAvatarUser.name.startsWith('@') ? previewAvatarUser.name : `@${previewAvatarUser.name}`}
              </h4>
              <p className="text-xs text-slate-300 font-mono">{previewAvatarUser.email || 'Tiada emel'}</p>
              <p className="text-[11px] text-slate-500 font-mono">ID: {previewAvatarUser.id}</p>
              {previewAvatarUser.phoneNumber && (
                <p className="text-[11px] text-emerald-400 font-mono">Tel: {previewAvatarUser.phoneNumber}</p>
              )}
            </div>

            <button
              type="button"
              onClick={() => setPreviewAvatarUser(null)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all cursor-pointer"
            >
              Tutup Pratonton
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
