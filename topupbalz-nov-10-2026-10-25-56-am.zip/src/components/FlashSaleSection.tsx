import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Clock,
  Flame,
} from 'lucide-react';
import { FlashSaleConfig, Game } from '../types';

interface FlashSaleSectionProps {
  flashSale: FlashSaleConfig;
  games: Game[];
  onSelectItem: (game: Game, itemId: string) => void;
  theme?: 'dark' | 'light';
}

export const FlashSaleSection: React.FC<FlashSaleSectionProps> = ({
  flashSale,
  games,
  onSelectItem,
  theme = 'dark',
}) => {
  const isLight = theme === 'light';

  // Countdown Timer State with Days, Hours, Minutes, Seconds
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    isExpired: boolean;
  }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    isExpired: false,
  });

  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Filter items that are active and still have remaining quota
  const activeItems = useMemo(() => {
    const raw = (flashSale?.items || []).filter(
      (item) => (item.isActive ?? true) && (item.maxQuota <= 0 || item.soldCount < item.maxQuota)
    );
    return raw;
  }, [flashSale?.items]);

  // Display the active items for clean manual scrolling
  const displayItems = activeItems;

  useEffect(() => {
    const calculateTimeLeft = () => {
      if (!flashSale?.endTime) {
        return { days: 0, hours: 23, minutes: 59, seconds: 59, isExpired: false };
      }

      const difference = new Date(flashSale.endTime).getTime() - new Date().getTime();
      if (difference <= 0) {
        return { days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: true };
      }

      const totalSeconds = Math.floor(difference / 1000);
      const days = Math.floor(totalSeconds / (3600 * 24));
      const hours = Math.floor((totalSeconds % (3600 * 24)) / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;

      return { days, hours, minutes, seconds, isExpired: false };
    };

    setTimeLeft(calculateTimeLeft());

    const timer = setInterval(() => {
      const tl = calculateTimeLeft();
      setTimeLeft(tl);
    }, 1000);

    return () => clearInterval(timer);
  }, [flashSale?.endTime]);

  // Manual step-by-step scroll (One card at a time)
  const scrollManual = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const cardWidth = container.clientWidth > 640 ? 295 + 16 : 255 + 12;
      container.scrollBy({
        left: direction === 'left' ? -cardWidth : cardWidth,
        behavior: 'smooth',
      });
    }
  };

  // If flash sale is explicitly disabled, has no active items, or the timer has expired, hide the section completely
  if (flashSale?.isEnabled === false) return null;
  if (activeItems.length === 0) return null;
  if (timeLeft.isExpired) return null;
  if (flashSale?.endTime && new Date(flashSale.endTime).getTime() <= Date.now()) return null;

  return (
    <section className="relative w-full select-none pt-1 pb-3 space-y-3 overflow-hidden">
      
      {/* 1. TOP HEADER & TIMER (Clean, open layout without a surrounding card box) */}
      <div className="px-1 space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          
          {/* JUALAN KILAT Badge/Title */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-gradient-to-r from-orange-600 via-amber-500 to-orange-600 text-white font-black text-sm sm:text-base tracking-wider uppercase shadow-[0_4px_16px_rgba(249,115,22,0.4)] border border-orange-400/40">
            <span>{flashSale.title || 'JUALAN KILAT'}</span>
            <span className="text-base sm:text-lg animate-bounce">⚡</span>
          </div>

          {/* TIMER ROW: "Berakhir dalam" + Red/Orange Digital Timer Boxes */}
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <div className="flex items-center gap-1.5">
              <Clock className={`w-4 h-4 ${isLight ? 'text-orange-600' : 'text-orange-400'} animate-spin`} style={{ animationDuration: '10s' }} />
              <span className={`font-extrabold text-xs sm:text-sm tracking-tight ${
                isLight ? 'text-slate-800' : 'text-slate-200'
              }`}>
                Berakhir dalam
              </span>
            </div>

            {/* Digit Boxes with Colons */}
            <div className="flex items-center gap-1 sm:gap-1.5">
              {timeLeft.days > 0 && (
                <>
                  <div className="flex items-center justify-center min-w-[28px] sm:min-w-[34px] h-7 sm:h-8 px-1.5 rounded-lg sm:rounded-xl bg-red-600 text-white font-mono font-black text-xs sm:text-sm shadow-[0_2px_8px_rgba(220,38,38,0.5)] border border-red-400/40">
                    {String(timeLeft.days).padStart(2, '0')}h
                  </div>
                  <span className="text-red-500 font-black text-xs sm:text-sm">:</span>
                </>
              )}

              {/* Box: Hours */}
              <div className="flex items-center justify-center min-w-[28px] sm:min-w-[34px] h-7 sm:h-8 px-1.5 rounded-lg sm:rounded-xl bg-red-600 text-white font-mono font-black text-xs sm:text-sm shadow-[0_2px_8px_rgba(220,38,38,0.5)] border border-red-400/40">
                {String(timeLeft.hours).padStart(2, '0')}
              </div>

              <span className="text-red-500 font-black text-xs sm:text-sm">:</span>

              {/* Box: Minutes */}
              <div className="flex items-center justify-center min-w-[28px] sm:min-w-[34px] h-7 sm:h-8 px-1.5 rounded-lg sm:rounded-xl bg-red-600 text-white font-mono font-black text-xs sm:text-sm shadow-[0_2px_8px_rgba(220,38,38,0.5)] border border-red-400/40">
                {String(timeLeft.minutes).padStart(2, '0')}
              </div>

              <span className="text-red-500 font-black text-xs sm:text-sm">:</span>

              {/* Box: Seconds */}
              <div className="flex items-center justify-center min-w-[28px] sm:min-w-[34px] h-7 sm:h-8 px-1.5 rounded-lg sm:rounded-xl bg-red-600 text-white font-mono font-black text-xs sm:text-sm shadow-[0_2px_8px_rgba(220,38,38,0.5)] border border-red-400/40 animate-pulse">
                {String(timeLeft.seconds).padStart(2, '0')}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. CARDS HORIZONTAL SCROLL LIST (Free, smooth scrolling - stays right where you scroll) */}
      <div className="w-full relative overflow-hidden">
        <div
          ref={scrollContainerRef}
          className="flex items-stretch gap-3 sm:gap-4 overflow-x-auto no-scrollbar py-1.5 px-1 sm:px-2 touch-pan-x"
          style={{
            scrollbarWidth: 'none',
            msOverflowStyle: 'none',
            WebkitOverflowScrolling: 'touch',
          }}
        >
          {displayItems.map((item, index) => {
            const matchedGame = games.find(
              (g) => g.id === item.gameId || g.slug === item.gameId
            );
            const remainingQuota = Math.max(0, item.maxQuota > 0 ? item.maxQuota - item.soldCount : 17);
            const maxQuotaDisplay = item.maxQuota > 0 ? item.maxQuota : 25;
            const percentClaimed = Math.min(100, Math.round(((maxQuotaDisplay - remainingQuota) / maxQuotaDisplay) * 100));
            const savingsAmount =
              item.savings > 0
                ? item.savings
                : Math.max(0, item.originalPrice - item.flashPrice);

            return (
              <div
                key={`${item.id}-${index}`}
                onClick={() => {
                  if (matchedGame) {
                    onSelectItem(matchedGame, item.itemId);
                  }
                }}
                className={`shrink-0 w-[245px] sm:w-[275px] md:w-[295px] snap-start rounded-2xl sm:rounded-3xl overflow-hidden border-2 transition-all duration-300 cursor-pointer flex flex-col justify-between group active:scale-[0.98] ${
                  isLight
                    ? 'bg-white hover:bg-orange-50/40 border-orange-300 hover:border-orange-500 shadow-[0_6px_20px_rgba(249,115,22,0.12)] hover:shadow-[0_10px_25px_rgba(249,115,22,0.22)]'
                    : 'bg-[#0E0602] hover:bg-[#150903] border-orange-500/70 hover:border-orange-400 shadow-[0_6px_25px_rgba(0,0,0,0.8),0_0_15px_rgba(249,115,22,0.15)] hover:shadow-[0_0_25px_rgba(249,115,22,0.35)]'
                }`}
              >
                {/* Top & Middle Card Content */}
                <div className="p-3 sm:p-3.5 space-y-2.5 relative">
                  
                  {/* Header Row: Game Avatar + Title + Diamonds + Prices */}
                  <div className="flex items-start gap-2.5 relative z-10">
                    
                    {/* Game Avatar Thumbnail with flame badge */}
                    <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-xl sm:rounded-2xl overflow-hidden bg-slate-900 border border-orange-400/60 shrink-0 shadow-md group-hover:scale-105 transition-transform">
                      <img
                        src={
                          item.gameLogoUrl ||
                          matchedGame?.logoUrl ||
                          'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=200&q=80'
                        }
                        alt={item.gameName}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute bottom-0.5 right-0.5 w-3.5 h-3.5 rounded-full bg-red-600 border border-white flex items-center justify-center shadow-sm">
                        <Flame className="w-2 h-2 text-white fill-current" />
                      </div>
                    </div>

                    {/* Game Details & Prices */}
                    <div className="min-w-0 flex-1 space-y-0.5">
                      <h3 className={`text-xs font-extrabold truncate ${
                        isLight ? 'text-slate-900' : 'text-white'
                      }`}>
                        {item.gameName || matchedGame?.name}
                      </h3>
                      
                      <p className={`text-[11px] sm:text-xs font-semibold truncate ${
                        isLight ? 'text-slate-600' : 'text-slate-300'
                      }`}>
                        {item.itemName}
                      </p>

                      {/* Crossed Original Price in Red */}
                      <div className="pt-0.5">
                        <span className="text-[11px] sm:text-xs font-extrabold text-red-500 line-through decoration-red-500 decoration-2">
                          RM {item.originalPrice.toFixed(2)}
                        </span>
                      </div>

                      {/* Prominent Flash Sale Price */}
                      <div>
                        <span className={`text-sm sm:text-base font-black font-mono tracking-tight ${
                          isLight ? 'text-orange-600' : 'text-amber-400'
                        }`}>
                          RM {item.flashPrice.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Middle Progress/Stock Capsule: "X berbaki" */}
                  <div className="relative z-10 pt-0.5">
                    <div className={`relative w-full rounded-full py-1 px-2.5 overflow-hidden border text-center shadow-inner flex items-center justify-center ${
                      isLight
                        ? 'bg-orange-100/70 border-orange-300'
                        : 'bg-[#180A03] border-orange-500/40'
                    }`}>
                      {/* Gradient fill indicator */}
                      <div
                        className="absolute inset-y-0 left-0 bg-gradient-to-r from-orange-600/40 via-amber-500/40 to-orange-500/40 transition-all duration-500 pointer-events-none"
                        style={{ width: `${Math.max(20, percentClaimed)}%` }}
                      />
                      
                      <span className={`relative z-10 font-bold text-[10px] sm:text-[11px] ${
                        isLight ? 'text-orange-950 font-black' : 'text-white drop-shadow-sm'
                      }`}>
                        {remainingQuota} berbaki
                      </span>
                    </div>
                  </div>
                </div>

                {/* Bottom Full-Width Strip: "Penjimatan RM X.XX" + FLASH SALE ⚡ Sticker */}
                <div className={`relative z-10 px-3 py-2 flex items-center justify-between border-t transition-colors ${
                  isLight
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 border-orange-400 text-white'
                    : 'bg-gradient-to-r from-orange-600 via-amber-500 to-orange-600 border-orange-500/60 text-slate-950'
                }`}>
                  {/* Left: Penjimatan RM X.XX */}
                  <span className={`font-black text-[11px] sm:text-xs tracking-wide ${
                    isLight ? 'text-white drop-shadow-sm' : 'text-slate-950'
                  }`}>
                    Penjimatan RM {savingsAmount.toFixed(2)}
                  </span>

                  {/* Right: FLASH SALE Sticker */}
                  <div className="relative transform rotate-[-3deg] group-hover:rotate-0 transition-transform">
                    <div className="px-1.5 py-0.5 rounded bg-yellow-400 text-black font-black text-[9px] sm:text-[10px] tracking-tighter uppercase shadow-sm border border-yellow-200 flex items-center gap-0.5">
                      <span className="text-[10px]">⚡</span>
                      <span>FLASH SALE</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
