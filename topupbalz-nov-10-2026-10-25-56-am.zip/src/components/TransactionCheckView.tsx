import React, { useState, useMemo } from 'react';
import { Search, CheckCircle2, Clock, AlertCircle, RefreshCw, MessageCircle, ShieldCheck, ReceiptText } from 'lucide-react';
import { Order, Game } from '../types';

interface TransactionCheckViewProps {
  orders: Order[];
  games?: Game[];
  ownerPhone?: string;
  onSelectGame?: (game: Game) => void;
  onGoToProfile?: () => void;
  theme?: 'dark' | 'light';
}

const topupbalzBanner = '/src/assets/images/topupbalz_hero_banner_1785751313639.jpg';

// Masking helper function to convert ID into format like ORDER*****1400FY
function maskOrderId(orderId: string): string {
  if (!orderId) return 'ORDER*****0000';
  const clean = orderId.replace(/^#/, '').toUpperCase();
  
  if (clean.length <= 4) {
    return `ORDER*****${clean}`;
  }
  
  // Take last 4-6 characters
  const suffix = clean.slice(-5);
  return `ORDER*****${suffix}`;
}

export const TransactionCheckView: React.FC<TransactionCheckViewProps> = ({
  orders = [],
  ownerPhone = '60145975056',
  onGoToProfile,
  theme = 'dark',
}) => {
  const isLight = theme === 'light';
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Generate recent 10 transactions or combined with fallback realistic orders
  const recentOrders = useMemo(() => {
    // If real orders exist, take them first
    const sorted = [...orders].sort((a, b) => {
      const timeA = new Date(a.createdAt || 0).getTime();
      const timeB = new Date(b.createdAt || 0).getTime();
      return timeB - timeA;
    });

    if (sorted.length >= 10) {
      return sorted.slice(0, 10);
    }

    // Default sample transaction feed matching the screenshot aesthetics
    const fallbackList: Order[] = [
      {
        id: 'ORDER1400FY',
        userId: '12498102',
        serverId: '2001',
        gameId: 'g1',
        gameName: 'Mobile Legends Malaysia',
        itemId: 'ml-14',
        itemName: '14 (13+1) Diamond',
        basePrice: 1.20,
        sellPrice: 1.50,
        status: 'completed',
        paymentMethod: "Touch 'n Go eWallet",
        notes: 'Topup dihantar secara automatik.',
        createdAt: new Date(Date.now() - 1000 * 60 * 2).toISOString(),
      },
      {
        id: 'ORDER077C19',
        userId: 'BalzGamerz',
        gameId: 'g4',
        gameName: 'Roblox Top Up (Via Username)',
        itemId: 'rbx-100',
        itemName: '100 Robux',
        basePrice: 6.50,
        sellPrice: 7.50,
        status: 'completed',
        paymentMethod: "Touch 'n Go eWallet",
        notes: 'Pesanan berjaya dikreditkan ke akaun Roblox.',
        createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
      },
      {
        id: 'ORDER8819XA',
        userId: '89102451',
        gameId: 'g2',
        gameName: 'Free Fire Malaysia',
        itemId: 'ff-140',
        itemName: '140 Diamonds (Bonus 14)',
        basePrice: 5.00,
        sellPrice: 6.00,
        status: 'completed',
        paymentMethod: "Touch 'n Go eWallet",
        notes: 'Selesai dalam 3 saat.',
        createdAt: new Date(Date.now() - 1000 * 60 * 9).toISOString(),
      },
      {
        id: 'ORDER9931BZ',
        userId: '51928490',
        gameId: 'g3',
        gameName: 'PUBG Mobile UC',
        itemId: 'pubg-60',
        itemName: '60 UC Unknown Cash',
        basePrice: 4.20,
        sellPrice: 5.20,
        status: 'processing',
        paymentMethod: "Touch 'n Go eWallet",
        notes: 'Sistem sedang menghantar UC ke server...',
        createdAt: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
      },
      {
        id: 'ORDER4412KL',
        userId: '77129481',
        serverId: '2150',
        gameId: 'g1',
        gameName: 'Mobile Legends Malaysia',
        itemId: 'ml-wdp',
        itemName: 'Weekly Diamond Pass (WDP)',
        basePrice: 8.50,
        sellPrice: 9.90,
        status: 'completed',
        paymentMethod: "Touch 'n Go eWallet",
        notes: 'Pass Mingguan aktif.',
        createdAt: new Date(Date.now() - 1000 * 60 * 18).toISOString(),
      },
      {
        id: 'ORDER3319TR',
        userId: 'GamerBalz01',
        gameId: 'g5',
        gameName: 'Steam Wallet Code MYR',
        itemId: 'steam-10',
        itemName: 'RM 10 Steam Wallet Code',
        basePrice: 10.00,
        sellPrice: 11.00,
        status: 'completed',
        paymentMethod: "Touch 'n Go eWallet",
        notes: 'Kod baucar dihantar.',
        createdAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
      },
      {
        id: 'ORDER7721GG',
        userId: '44810294',
        serverId: '2024',
        gameId: 'g1',
        gameName: 'Mobile Legends Malaysia',
        itemId: 'ml-86',
        itemName: '86 Diamonds',
        basePrice: 4.50,
        sellPrice: 5.50,
        status: 'completed',
        paymentMethod: "Touch 'n Go eWallet",
        notes: 'Berjaya.',
        createdAt: new Date(Date.now() - 1000 * 60 * 34).toISOString(),
      },
      {
        id: 'ORDER6610PW',
        userId: '99214012',
        gameId: 'g2',
        gameName: 'Free Fire Malaysia',
        itemId: 'ff-70',
        itemName: '70 Diamonds',
        basePrice: 2.80,
        sellPrice: 3.50,
        status: 'completed',
        paymentMethod: "Touch 'n Go eWallet",
        notes: 'Berjaya.',
        createdAt: new Date(Date.now() - 1000 * 60 * 42).toISOString(),
      },
      {
        id: 'ORDER5520ZZ',
        userId: '66201948',
        gameId: 'g4',
        gameName: 'Roblox Top Up (Via Username)',
        itemId: 'rbx-400',
        itemName: '400 Robux',
        basePrice: 24.00,
        sellPrice: 26.00,
        status: 'completed',
        paymentMethod: "Touch 'n Go eWallet",
        notes: 'Berjaya diproses.',
        createdAt: new Date(Date.now() - 1000 * 60 * 50).toISOString(),
      },
      {
        id: 'ORDER1109MY',
        userId: '33109482',
        serverId: '2008',
        gameId: 'g1',
        gameName: 'Mobile Legends Malaysia',
        itemId: 'ml-257',
        itemName: '257 Diamonds',
        basePrice: 13.50,
        sellPrice: 15.00,
        status: 'completed',
        paymentMethod: "Touch 'n Go eWallet",
        notes: 'Berjaya.',
        createdAt: new Date(Date.now() - 1000 * 60 * 59).toISOString(),
      }
    ];

    const combined = [...sorted, ...fallbackList];
    return combined.slice(0, 10);
  }, [orders]);

  // Filtered list based on search query (User searching exact order ID or partial)
  const displayedOrders = useMemo(() => {
    const q = searchQuery.trim().toLowerCase().replace(/^#/, '');
    if (!q) return recentOrders;

    // Search across real orders and fallback list
    const pool = [...orders, ...recentOrders];
    const uniquePool = Array.from(new Map(pool.map((item) => [item.id, item])).values());

    return uniquePool.filter((o) => {
      const matchId = (o.id || '').toLowerCase().includes(q);
      const matchGame = (o.gameName || '').toLowerCase().includes(q);
      const matchItem = (o.itemName || '').toLowerCase().includes(q);
      const matchUser = (o.userId || '').toLowerCase().includes(q);
      return matchId || matchGame || matchItem || matchUser;
    });
  }, [searchQuery, recentOrders, orders]);

  const getStatusDisplay = (status: Order['status']) => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>Selesai</span>
          </span>
        );
      case 'processing':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
            <RefreshCw className="w-3 h-3 text-amber-400 animate-spin" />
            <span>Diproses</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
            <AlertCircle className="w-3 h-3 text-rose-400" />
            <span>Dibatalkan</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-orange-500/20 text-orange-300 border border-orange-500/40">
            <Clock className="w-3 h-3 text-orange-400" />
            <span>Menunggu</span>
          </span>
        );
    }
  };

  return (
    <div className={`space-y-6 max-w-5xl mx-auto animate-fadeIn ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
      
      {/* 1. Header Banner Card with TopupBalz Logo Background */}
      <div className={`relative rounded-3xl overflow-hidden border shadow-xl ${
        isLight
          ? 'bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 border-orange-300 text-slate-950'
          : 'bg-[#0A0502] border-orange-500/50 shadow-[0_10px_40px_rgba(255,102,0,0.25)] text-white'
      }`}>
        
        {/* Background Image: TopupBalz Hero Logo with gradient overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src={topupbalzBanner}
            alt="TopupBalz"
            className={`w-full h-full object-cover object-center ${
              isLight
                ? 'opacity-20 mix-blend-overlay scale-105 filter contrast-125'
                : 'opacity-35 mix-blend-luminosity scale-105 filter contrast-150'
            }`}
          />
          {/* Multi-layered gradient overlays */}
          {!isLight && (
            <>
              <div className="absolute inset-0 bg-gradient-to-r from-[#080401] via-[#0F0702]/95 to-[#1A0C04]/90" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0502] via-transparent to-black/70" />
              <div className="absolute top-0 right-0 w-96 h-96 bg-orange-600/20 rounded-full blur-3xl pointer-events-none" />
            </>
          )}
        </div>

        {/* Banner Content */}
        <div className="relative z-10 p-6 sm:p-8 md:p-10 space-y-4">
          
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-bold tracking-wider uppercase border ${
            isLight
              ? 'bg-black/15 border-black/20 text-slate-950 shadow-sm'
              : 'bg-orange-500/15 border-orange-500/40 text-orange-400 shadow-[0_0_15px_rgba(249,115,22,0.15)]'
          }`}>
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Sistem Semakan Privasi 24/7</span>
          </div>

          <h1 className={`text-2xl sm:text-3xl md:text-4xl font-black tracking-tight ${
            isLight
              ? 'text-slate-950 drop-shadow-sm'
              : 'text-transparent bg-clip-text bg-gradient-to-r from-white via-orange-100 to-amber-400 drop-shadow-[0_2px_10px_rgba(255,102,0,0.5)]'
          }`}>
            Semak Transaksi
          </h1>

          <p className={`text-xs sm:text-sm md:text-base max-w-3xl leading-relaxed font-normal ${
            isLight ? 'text-slate-900 font-medium' : 'text-slate-200/90'
          }`}>
            Transaksi anda akan diproses secara automatik, biasanya selesai dalam masa 1-2 saat, tetapi jika anda menghadapi sebarang masalah, sila cari transaksi anda di sini. Nombor ID pesanan sila semak di <span className={`font-bold underline cursor-pointer ${isLight ? 'text-slate-950 hover:text-black' : 'text-amber-400 hover:text-amber-300'}`} onClick={onGoToProfile}>Profil</span> di bahagian <span className={`font-bold ${isLight ? 'text-slate-950' : 'text-amber-400'}`}>Pesanan</span>.
          </p>
        </div>
      </div>

      {/* 2. Sub-title & Search Form */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${
            isLight ? 'text-slate-800' : 'text-orange-200'
          }`}>
            <ReceiptText className="w-4 h-4 text-orange-500" />
            <span>{searchQuery.trim() ? `Hasil Carian Transaksi ("${searchQuery}")` : 'Memaparkan 10 Transaksi Terkini'}</span>
          </h2>
          <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded-lg border ${
            isLight
              ? 'bg-orange-50 text-orange-700 border-orange-200'
              : 'text-orange-400 bg-[#140802] border-orange-500/40'
          }`}>
            {displayedOrders.length} Rekod
          </span>
        </div>

        {/* Search Input Box with Glowing Orange Search Icon Button */}
        <div className="relative flex items-center">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ID Pesanan (cth: ORDER...)"
            className={`w-full font-semibold text-sm sm:text-base rounded-2xl py-3.5 pl-5 pr-14 border transition-all focus:outline-none focus:ring-2 focus:ring-orange-500 ${
              isLight
                ? 'bg-white text-slate-900 placeholder:text-slate-400 border-slate-300 shadow-sm'
                : 'bg-[#120803] text-white placeholder:text-slate-500 border-orange-500/40 shadow-[0_0_20px_rgba(249,115,22,0.15)]'
            }`}
          />
          <button
            type="button"
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl bg-gradient-to-tr from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white flex items-center justify-center shadow-md transition-transform active:scale-95 cursor-pointer"
            title="Cari ID Pesanan"
          >
            <Search className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      {/* 3. Transaction Table Section */}
      <div className={`rounded-3xl overflow-hidden border shadow-xl ${
        isLight
          ? 'bg-white border-slate-200 shadow-lg'
          : 'border-orange-500/50 bg-[#0C0602] shadow-[0_10px_35px_rgba(0,0,0,0.9)]'
      }`}>
        
        {/* Table Container with Horizontal Scroll support on smaller screens */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            {/* Header */}
            <thead>
              <tr className={`border-b text-xs sm:text-sm font-extrabold uppercase tracking-wider ${
                isLight
                  ? 'bg-slate-100 text-slate-800 border-slate-200'
                  : 'bg-[#190C04] border-orange-500/50 text-orange-200'
              }`}>
                <th className={`py-4 px-4 sm:px-6 border-r min-w-[150px] ${isLight ? 'border-slate-200' : 'border-orange-900/50'}`}>
                  ID Pesanan
                </th>
                <th className={`py-4 px-4 sm:px-6 border-r min-w-[170px] ${isLight ? 'border-slate-200' : 'border-orange-900/50'}`}>
                  Kategori
                </th>
                <th className={`py-4 px-4 sm:px-6 border-r min-w-[170px] ${isLight ? 'border-slate-200' : 'border-orange-900/50'}`}>
                  Perkhidmatan
                </th>
                <th className="py-4 px-4 sm:px-6 min-w-[130px] text-center">
                  Status
                </th>
              </tr>
            </thead>

            {/* Table Rows */}
            <tbody className={`divide-y text-xs sm:text-sm font-medium ${
              isLight ? 'divide-slate-200' : 'divide-orange-950/60'
            }`}>
              {displayedOrders.length === 0 ? (
                <tr>
                  <td colSpan={4} className={`py-12 text-center ${isLight ? 'text-slate-500 bg-slate-50' : 'text-slate-400 bg-[#0A0502]'}`}>
                    <div className="max-w-md mx-auto space-y-2">
                      <AlertCircle className="w-8 h-8 text-amber-500 mx-auto" />
                      <p className={`font-bold text-sm ${isLight ? 'text-slate-900' : 'text-white'}`}>Tiada Transaksi Ditemui</p>
                      <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                        Sila pastikan ID pesanan yang dimasukkan adalah betul. Anda boleh menyemak senarai pesanan anda di halaman Profil.
                      </p>
                      {searchQuery && (
                        <button
                          onClick={() => setSearchQuery('')}
                          className="mt-2 px-3.5 py-1.5 bg-orange-600 hover:bg-orange-500 text-white rounded-xl text-xs font-bold transition"
                        >
                          Papar Semula 10 Transaksi Terkini
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                displayedOrders.map((ord, idx) => {
                  const maskedId = maskOrderId(ord.id);
                  const isSelected = selectedOrder?.id === ord.id;
                  
                  return (
                    <tr
                      key={`${ord.id}-${idx}`}
                      onClick={() => setSelectedOrder(isSelected ? null : ord)}
                      className={`cursor-pointer transition-colors duration-150 ${
                        isSelected 
                          ? isLight ? 'bg-orange-50 text-slate-900 border-l-4 border-l-orange-500' : 'bg-[#221004] text-white border-l-4 border-l-orange-500' 
                          : isLight
                          ? idx % 2 === 0 ? 'bg-white hover:bg-orange-50/50' : 'bg-slate-50/50 hover:bg-orange-50/50'
                          : idx % 2 === 0 ? 'bg-[#0E0702] hover:bg-[#1A0D04]' : 'bg-[#0A0501] hover:bg-[#1A0D04]'
                      }`}
                    >
                      {/* Column 1: ID Pesanan (Masked with *) */}
                      <td className={`py-4 px-4 sm:px-6 border-r font-mono font-bold tracking-wider ${
                        isLight ? 'border-slate-200 text-slate-900' : 'border-orange-950/60 text-slate-100'
                      }`}>
                        <div className="flex items-center justify-between gap-2">
                          <span className={`text-xs sm:text-sm ${isLight ? 'text-orange-600' : 'text-orange-200'}`}>{maskedId}</span>
                          <span className="text-[10px] text-orange-500 opacity-80 hidden sm:inline">Info ➔</span>
                        </div>
                      </td>

                      {/* Column 2: Kategori */}
                      <td className={`py-4 px-4 sm:px-6 border-r font-semibold ${
                        isLight ? 'border-slate-200 text-slate-800' : 'border-orange-950/60 text-slate-200'
                      }`}>
                        {ord.gameName || 'Mobile Legends Malaysia'}
                      </td>

                      {/* Column 3: Perkhidmatan */}
                      <td className={`py-4 px-4 sm:px-6 border-r font-semibold ${
                        isLight ? 'border-slate-200 text-slate-800' : 'border-orange-950/60 text-slate-200'
                      }`}>
                        {ord.itemName || `${ord.sellPrice} Topup`}
                      </td>

                      {/* Column 4: Status */}
                      <td className="py-4 px-4 sm:px-6 text-center">
                        {getStatusDisplay(ord.status)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer Hint */}
        <div className={`p-3.5 border-t flex flex-col sm:flex-row items-center justify-between gap-2 text-xs ${
          isLight
            ? 'bg-slate-50 border-slate-200 text-slate-600'
            : 'bg-[#140A03] border-orange-900/50 text-orange-300/80'
        }`}>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Sistem live transaksi dikemas kini secara automatik.</span>
          </span>
          <span className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
            *Nombor ID dirahsiakan sebahagian bagi melindungi privasi pembeli.
          </span>
        </div>

      </div>

      {/* 4. Detail Modal or Card when an Order is Clicked */}
      {selectedOrder && (
        <div className={`p-5 sm:p-6 rounded-3xl border shadow-2xl space-y-4 animate-fadeIn ${
          isLight
            ? 'bg-white border-orange-300 text-slate-900 shadow-xl'
            : 'bg-[#140903] border-orange-500/50 text-slate-100'
        }`}>
          <div className={`flex items-center justify-between border-b pb-3 ${
            isLight ? 'border-slate-200' : 'border-orange-900/60'
          }`}>
            <div className="flex items-center gap-2">
              <span className={`text-sm font-black font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Butiran Transaksi ({maskOrderId(selectedOrder.id)})
              </span>
              {getStatusDisplay(selectedOrder.status)}
            </div>
            <button
              onClick={() => setSelectedOrder(null)}
              className={`text-xs px-2.5 py-1 border rounded-lg cursor-pointer transition-colors ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-700'
                  : 'bg-black/60 hover:text-white border-orange-900/60 text-slate-400'
              }`}
            >
              Tutup
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
            <div className={`p-3.5 rounded-2xl border space-y-1 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-black/60 border-orange-900/50'
            }`}>
              <span className={`block font-sans ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Kategori Game:</span>
              <span className={`font-bold text-sm block ${isLight ? 'text-slate-900' : 'text-white'}`}>{selectedOrder.gameName}</span>
            </div>
            <div className={`p-3.5 rounded-2xl border space-y-1 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-black/60 border-orange-900/50'
            }`}>
              <span className={`block font-sans ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Pakej Topup:</span>
              <span className="text-orange-500 font-bold text-sm block">{selectedOrder.itemName}</span>
            </div>
            <div className={`p-3.5 rounded-2xl border space-y-1 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-black/60 border-orange-900/50'
            }`}>
              <span className={`block font-sans ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Masa Pesanan:</span>
              <span className={`font-bold block ${isLight ? 'text-slate-800' : 'text-slate-300'}`}>
                {selectedOrder.createdAt 
                  ? new Date(selectedOrder.createdAt).toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                  : 'Baru sahaja'}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
              💡 Jika terdapat sebarang kelewatan, hubungi admin melalui WhatsApp untuk semakan manual segera.
            </p>
            <a
              href={`https://wa.me/${ownerPhone.replace(/\D/g, '')}?text=Assalamualaikum%20admin%20TopupBalz,%20saya%20nak%20semak%20status%20transaksi%20pesanan%20${encodeURIComponent(selectedOrder.id)}`}
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition shadow-md"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Admin</span>
            </a>
          </div>
        </div>
      )}

    </div>
  );
};
