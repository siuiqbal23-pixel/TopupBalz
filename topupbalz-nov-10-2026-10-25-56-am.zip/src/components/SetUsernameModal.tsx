import React, { useState, useEffect } from 'react';
import { User, Lock, ArrowRight, AlertCircle, Sparkles, CheckCircle2, X } from 'lucide-react';
import { ADMIN_USERNAME, ADMIN_PIN_CODE } from '../lib/clerkConfig';
import { UserProfile } from '../types';

interface SetUsernameModalProps {
  isOpen: boolean;
  currentUser: UserProfile | null;
  onSaveUsername: (username: string, isPinVerified?: boolean) => void;
  onClose?: () => void;
  theme?: 'dark' | 'light';
}

export const SetUsernameModal: React.FC<SetUsernameModalProps> = ({
  isOpen,
  currentUser,
  onSaveUsername,
  onClose,
  theme = 'dark',
}) => {
  const [usernameInput, setUsernameInput] = useState('');
  const [step, setStep] = useState<'enter_username' | 'enter_pin'>('enter_username');
  const [pinInput, setPinInput] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isLight = theme === 'light';

  useEffect(() => {
    if (isOpen) {
      setUsernameInput('');
      setStep('enter_username');
      setPinInput('');
      setErrorMessage(null);
    }
  }, [isOpen, currentUser?.id]);

  if (!isOpen) return null;

  const clean = usernameInput.trim().replace(/^@+/, '');
  const isTargetAdmin =
    clean.toLowerCase() === 'siuiqbal23' ||
    clean.toLowerCase() === ADMIN_USERNAME.toLowerCase() ||
    clean.toLowerCase() === 'balzltdsdn' ||
    clean.toLowerCase() === 'balzz';

  const handleUsernameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!clean) {
      setErrorMessage('Sila masukkan nama username yang sah!');
      return;
    }

    if (isTargetAdmin) {
      setStep('enter_pin');
      setPinInput('');
      return;
    }

    setIsSubmitting(true);
    onSaveUsername(clean, false);
    setIsSubmitting(false);
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (pinInput.trim() === ADMIN_PIN_CODE) {
      setIsSubmitting(true);
      onSaveUsername(clean, true);
      setIsSubmitting(false);
    } else {
      setErrorMessage('PIN keselamatan tidak sah. Sila masukkan PIN yang tepat.');
    }
  };

  return (
    <div className={`fixed inset-0 z-[150] backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn ${
      isLight ? 'bg-slate-900/50' : 'bg-black/85'
    }`}>
      <div className={`relative w-full max-w-md rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl overflow-hidden border transition-colors duration-300 ${
        isLight
          ? 'bg-white border-orange-200 text-slate-900 shadow-2xl'
          : 'bg-[#0D1117] border-orange-500/50 text-white shadow-[0_0_50px_rgba(255,140,0,0.25)]'
      }`}>
        
        {/* Glow Background */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Icon & Heading */}
        <div className="text-center space-y-2 relative z-10">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500 to-amber-500 p-0.5 mx-auto shadow-lg">
            <div className={`w-full h-full rounded-[14px] flex items-center justify-center ${
              isLight ? 'bg-white text-orange-600' : 'bg-[#0D1117] text-orange-400'
            }`}>
              {step === 'enter_pin' ? <Lock className="w-8 h-8" /> : <User className="w-8 h-8" />}
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/15 border border-orange-500/30 text-orange-600 dark:text-orange-300 text-[11px] font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{step === 'enter_pin' ? 'Pengesahan Keselamatan' : 'Tetapan Profil'}</span>
          </div>

          <h3 className={`text-xl font-black tracking-tight ${isLight ? 'text-slate-900' : 'text-white'}`}>
            {step === 'enter_pin' ? 'Masukkan PIN Keselamatan' : 'Pilih Username Anda'}
          </h3>
          <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
            {step === 'enter_pin'
              ? 'Sila masukkan 6-digit PIN keselamatan untuk meneruskan.'
              : 'Sila pilih username pilihan anda untuk dipaparkan pada profil & rekod pesanan.'}
          </p>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-500/50 text-rose-600 dark:text-rose-300 text-xs font-bold flex items-center gap-2.5 animate-shake relative z-10">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* STEP 1: Enter Username */}
        {step === 'enter_username' && (
          <form onSubmit={handleUsernameSubmit} className="space-y-4 relative z-10">
            <div className="space-y-1.5">
              <label className={`text-xs font-bold block ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                Username Pilihan:
              </label>
              <div className="relative flex items-center">
                <span className="absolute left-3.5 text-orange-500 font-mono font-black text-base select-none">
                  @
                </span>
                <input
                  type="text"
                  required
                  autoFocus
                  value={usernameInput}
                  onChange={(e) => {
                    setUsernameInput(e.target.value.replace(/\s+/g, ''));
                    setErrorMessage(null);
                  }}
                  placeholder="masukkan_username_anda"
                  className={`w-full rounded-2xl pl-8 pr-4 py-3.5 font-mono font-bold text-sm focus:outline-none transition-all border shadow-sm ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400 focus:border-orange-500'
                      : 'bg-[#121824] border-slate-700 text-white placeholder:text-slate-600 focus:border-orange-500'
                  }`}
                />
              </div>
              <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Contoh: @gamer_sejati, @balz_legend
              </p>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || !clean}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-slate-950 font-black text-sm uppercase tracking-wider rounded-2xl transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-40"
            >
              <span>Simpan &amp; Teruskan</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* STEP 2: Enter PIN */}
        {step === 'enter_pin' && (
          <form onSubmit={handlePinSubmit} className="space-y-4 relative z-10">
            <div className="space-y-1.5">
              <label className={`text-xs font-bold block ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                PIN Keselamatan (6 Digit):
              </label>
              <input
                type="password"
                maxLength={6}
                autoFocus
                required
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value.replace(/\D/g, ''));
                  setErrorMessage(null);
                }}
                placeholder="••••••"
                className={`w-full rounded-2xl px-4 py-3.5 text-center font-mono font-black text-xl tracking-[0.4em] focus:outline-none transition-all border ${
                  isLight
                    ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400 focus:border-orange-500'
                    : 'bg-[#121824] border-slate-700 text-white placeholder:text-slate-600 focus:border-orange-500'
                }`}
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting || pinInput.length < 6}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-slate-950 font-black text-sm uppercase tracking-wider rounded-2xl transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-40"
            >
              <span>Sahkan PIN</span>
              <CheckCircle2 className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => {
                setStep('enter_username');
                setPinInput('');
                setErrorMessage(null);
              }}
              className={`w-full text-center text-xs hover:underline cursor-pointer ${
                isLight ? 'text-slate-600' : 'text-slate-400'
              }`}
            >
              Tukar Username Lain
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
