import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { PromoBanner } from '../types';

interface HeroBannerProps {
  banners: PromoBanner[];
  onSelectGame?: (gameSlug: string) => void;
  onTopupNowClick?: () => void;
  ownerWhatsApp?: string;
  onOpenAdmin?: () => void;
  onlineCount?: number;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  banners,
  onSelectGame,
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const startXRef = useRef<number>(0);
  const currentXRef = useRef<number>(0);
  const activeBanners = banners.filter((b) => b.isActive);

  const nextSlide = () => {
    if (activeBanners.length <= 1) return;
    setCurrentSlide((prev) => (prev + 1) % activeBanners.length);
  };

  const prevSlide = () => {
    if (activeBanners.length <= 1) return;
    setCurrentSlide((prev) => (prev - 1 + activeBanners.length) % activeBanners.length);
  };

  // Auto slide interval (4.5 seconds)
  useEffect(() => {
    if (activeBanners.length <= 1 || isPaused || isDragging) return;
    const interval = setInterval(() => {
      nextSlide();
    }, 4500);
    return () => clearInterval(interval);
  }, [activeBanners.length, isPaused, isDragging, currentSlide]);

  // Touch Handlers with real-time drag feedback
  const handleTouchStart = (e: React.TouchEvent) => {
    if (activeBanners.length <= 1) return;
    setIsPaused(true);
    setIsDragging(true);
    startXRef.current = e.touches[0].clientX;
    currentXRef.current = e.touches[0].clientX;
    setDragOffset(0);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || activeBanners.length <= 1) return;
    currentXRef.current = e.touches[0].clientX;
    const diff = currentXRef.current - startXRef.current;
    // Dampen drag to prevent overflowing the banner space
    setDragOffset(Math.max(-150, Math.min(150, diff)));
  };

  const handleTouchEnd = () => {
    if (!isDragging) return;
    setIsDragging(false);
    setIsPaused(false);

    const diff = currentXRef.current - startXRef.current;
    const threshold = 40; // Pixels needed to trigger slide change

    if (diff < -threshold) {
      nextSlide();
    } else if (diff > threshold) {
      prevSlide();
    }
    setDragOffset(0);
  };

  // Mouse Drag Handlers for Desktop
  const handleMouseDown = (e: React.MouseEvent) => {
    if (activeBanners.length <= 1) return;
    setIsPaused(true);
    setIsDragging(true);
    startXRef.current = e.clientX;
    currentXRef.current = e.clientX;
    setDragOffset(0);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || activeBanners.length <= 1) return;
    currentXRef.current = e.clientX;
    const diff = currentXRef.current - startXRef.current;
    setDragOffset(diff);
  };

  const handleMouseUp = () => {
    if (!isDragging) return;
    setIsDragging(false);
    setIsPaused(false);

    const diff = currentXRef.current - startXRef.current;
    const threshold = 40;

    if (diff < -threshold) {
      nextSlide();
    } else if (diff > threshold) {
      prevSlide();
    }
    setDragOffset(0);
  };

  const handleMouseLeave = () => {
    if (isDragging) {
      handleMouseUp();
    }
    setIsPaused(false);
  };

  if (activeBanners.length === 0) return null;

  return (
    <div className="relative -mx-3 sm:-mx-6 lg:-mx-8 w-[calc(100%+1.5rem)] sm:w-[calc(100%+3rem)] lg:w-[calc(100%+4rem)] -mt-3 sm:-mt-6 mb-2 overflow-hidden bg-transparent">
      {/* Full-bleed edge-to-edge Promo Banner Slider Container */}
      <div
        ref={containerRef}
        className="relative w-full select-none overflow-hidden touch-pan-y"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={handleMouseLeave}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
      >
        <div className="relative bg-[#0D1117] overflow-hidden aspect-[16/8] sm:aspect-[21/8] md:aspect-[24/8] w-full cursor-grab active:cursor-grabbing">
          
          {/* Sliding Track for all slides */}
          <div
            className={`flex h-full w-full ${
              isDragging ? 'transition-none' : 'transition-transform duration-500 ease-out'
            }`}
            style={{
              transform: `translateX(calc(-${currentSlide * 100}% + ${dragOffset}px))`,
            }}
          >
            {activeBanners.map((banner) => (
              <div
                key={banner.id}
                onClick={() => {
                  // Only trigger click if not actively dragging
                  if (Math.abs(dragOffset) < 10 && banner.gameSlug) {
                    onSelectGame?.(banner.gameSlug);
                  }
                }}
                className={`w-full h-full shrink-0 relative overflow-hidden ${
                  banner.gameSlug ? 'cursor-pointer' : ''
                }`}
              >
                <img
                  src={banner.imageUrl}
                  alt={banner.title || 'Promo Banner'}
                  referrerPolicy="no-referrer"
                  draggable={false}
                  className="w-full h-full object-cover select-none pointer-events-none"
                />
                {/* Subtle dark gradient overlay at the bottom for readability */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
              </div>
            ))}
          </div>

          {/* Previous & Next Navigation Buttons (Desktop) */}
          {activeBanners.length > 1 && (
            <>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  prevSlide();
                }}
                aria-label="Banner sebelumnya"
                className="hidden sm:flex absolute left-3 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-black/60 hover:bg-orange-600 text-white items-center justify-center backdrop-blur-md border border-white/20 transition-all cursor-pointer shadow-lg hover:scale-110"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  nextSlide();
                }}
                aria-label="Banner seterusnya"
                className="hidden sm:flex absolute right-3 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-black/60 hover:bg-orange-600 text-white items-center justify-center backdrop-blur-md border border-white/20 transition-all cursor-pointer shadow-lg hover:scale-110"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </>
          )}

          {/* Dots Indicator */}
          {activeBanners.length > 1 && (
            <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 bg-black/50 backdrop-blur-md px-3 py-1 rounded-full border border-white/10 shadow-lg">
              {activeBanners.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setCurrentSlide(idx);
                  }}
                  aria-label={`Pergi ke banner ${idx + 1}`}
                  className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                    idx === currentSlide
                      ? 'w-6 bg-gradient-to-r from-orange-400 to-amber-400 shadow-[0_0_10px_rgba(255,140,0,0.8)]'
                      : 'w-1.5 bg-white/40 hover:bg-white/80'
                  }`}
                />
              ))}
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
