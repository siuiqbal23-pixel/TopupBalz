import React, { useState, useEffect } from 'react';
import { ShoppingCart, X, Trash2, Plus, Minus, MessageCircle, CheckCircle2, ShieldCheck, ArrowRight, CreditCard, Sparkles, Image as ImageIcon, Send, AlertTriangle, Copy, Check, QrCode } from 'lucide-react';
import { CartItem, SystemSettings, UserProfile } from '../types';
import { TngQrCodeCard } from './TngQrCodeCard';
import { compressImage } from '../lib/imageCompressor';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart?: CartItem[];
  items?: CartItem[];
  currentUser?: UserProfile | null;
  onRequestLogin?: () => void;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onUpdateItemUserId?: (id: string, userId: string, serverId?: string) => void;
  onUpdateUserId?: (id: string, userId: string, serverId?: string) => void;
  onClearCart: () => void;
  settings: SystemSettings;
  onSubmitCartOrders: (orderPayload: {
    items: CartItem[];
    paymentMethod: string;
    customerPhone?: string;
    proofImageUrl?: string;
  }) => Promise<{ success: boolean; whatsappUrl?: string; orderId?: string; proofImageUrl?: string }>;
  theme?: 'dark' | 'light';
}

export const CartModal: React.FC<CartModalProps> = ({
  isOpen,
  onClose,
  cart,
  items,
  currentUser,
  onRequestLogin,
  onUpdateQuantity,
  onRemoveItem,
  onUpdateItemUserId,
  onUpdateUserId,
  onClearCart,
  settings,
  onSubmitCartOrders,
  theme = 'dark',
}) => {
  const activeCart = (cart && cart.length > 0 ? cart : items) || [];
  const handleUpdateUserId = onUpdateItemUserId || onUpdateUserId || (() => {});
  const isLight = theme === 'light';

  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'tng' | 'fpx' | 'duitnow'>('tng');
  const [proofImage, setProofImage] = useState<string | null>(null);
  const [formError, setFormError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedAccount, setCopiedAccount] = useState(false);
  const [orderCompleteInfo, setOrderCompleteInfo] = useState<{
    whatsappUrl: string;
    orderId?: string;
    proofImageUrl?: string;
  } | null>(null);

  useEffect(() => {
    if (isOpen && activeCart.length > 0) {
      setOrderCompleteInfo(null);
      setFormError('');
    }
  }, [isOpen, activeCart.length]);

  useEffect(() => {
    if (currentUser?.phoneNumber && !customerPhone) {
      setCustomerPhone(currentUser.phoneNumber);
    }
  }, [currentUser]);

  if (!isOpen) return null;

  const totalAmount = activeCart.reduce((sum, item) => sum + item.sellPrice * item.quantity, 0);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFormError('Sila pilih fail imej yang sah (JPG, PNG, JPEG).');
      return;
    }

    try {
      const compressed = await compressImage(file);
      setProofImage(compressed);
      setFormError('');
    } catch (err) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProofImage(reader.result as string);
        setFormError('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCopyAccountName = () => {
    navigator.clipboard.writeText(settings.tngAccountName);
    setCopiedAccount(true);
    setTimeout(() => setCopiedAccount(false), 2000);
  };

  const handleCloseModal = () => {
    setOrderCompleteInfo(null);
    setFormError('');
    onClose();
  };

  const handleSubmitCart = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (activeCart.length === 0) {
      setFormError('Troli anda kosong. Sila pilih item topup terlebih dahulu!');
      return;
    }

    // Check if each item has a filled User ID
    const missingUserIdItem = activeCart.find((i) => !i.userId || !i.userId.trim());
    if (missingUserIdItem) {
      setFormError(`Sila masukkan User ID game untuk item: "${missingUserIdItem.itemName} (${missingUserIdItem.gameName})"`);
      return;
    }

    const cleanPhone = customerPhone.replace(/\D/g, '');
    if (!cleanPhone || cleanPhone.length < 8) {
      setFormError('Sila masukkan nombor WhatsApp yang sah (Contoh: 0123456789).');
      return;
    }

    // Check mandatory receipt proof
    if (!proofImage) {
      setFormError('Sila muat naik GAMBAR RESIT BUKTI BAYARAN terlebih dahulu! (Wajib sebelum membuat pesanan troli)');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await onSubmitCartOrders({
        items: activeCart.map((i) => ({
          ...i,
          userId: i.userId.replace(/\D/g, ''),
          serverId: i.serverId ? i.serverId.replace(/\D/g, '') : undefined,
        })),
        paymentMethod:
          paymentMethod === 'tng'
            ? "Touch 'n Go eWallet"
            : paymentMethod === 'fpx'
            ? 'FPX Online Banking'
            : 'DuitNow QR',
        customerPhone: cleanPhone,
        proofImageUrl: proofImage,
      });

      if (res.success && res.whatsappUrl) {
        setOrderCompleteInfo({
          whatsappUrl: res.whatsappUrl,
          orderId: res.orderId,
          proofImageUrl: res.proofImageUrl || proofImage || undefined,
        });
        onClearCart();
      }
    } catch (err: any) {
      setFormError('Gagal membuat pesanan trolley: ' + (err.message || 'Sila cuba lagi.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={`fixed inset-0 z-[110] backdrop-blur-md flex items-center justify-center p-3 sm:p-4 md:p-6 animate-fadeIn overflow-y-auto ${
      isLight ? 'bg-slate-900/50' : 'bg-black/85'
    }`}>
      <div className={`relative w-full max-w-2xl rounded-3xl overflow-hidden my-auto border shadow-2xl transition-colors duration-300 ${
        isLight
          ? 'bg-white border-orange-200 text-slate-900 shadow-2xl'
          : 'bg-[#0D1117] border-orange-500/40 text-white shadow-[0_0_50px_rgba(255,140,0,0.3)]'
      }`}>
        
        {/* Top Accent Line */}
        <div className="h-1 w-full bg-gradient-to-r from-orange-500 via-amber-400 to-orange-600" />

        {/* Modal Header */}
        <div className={`p-4 sm:p-5 border-b flex items-center justify-between transition-colors ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-gradient-to-r from-[#121824] via-[#161D2E] to-[#121824] border-slate-800'
        }`}>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-orange-500/15 text-orange-500 rounded-2xl border border-orange-500/40 shadow-inner">
              <ShoppingCart className="w-6 h-6" />
            </div>
            <div>
              <h2 className={`text-lg sm:text-xl font-black flex items-center gap-2 ${isLight ? 'text-slate-900' : 'text-white'}`}>
                <span>Troli Pembelian Topup</span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-black bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 shadow-sm">
                  {activeCart.reduce((a, b) => a + b.quantity, 0)} Item
                </span>
              </h2>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Beli pelbagai topup game sekaligus dalam satu transaksi pantas
              </p>
            </div>
          </div>

          <button
            onClick={handleCloseModal}
            aria-label="Tutup Troli"
            className={`p-2 rounded-xl transition-all cursor-pointer border ${
              isLight
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-200'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-slate-700'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ORDER SUCCESS COMPLETE SCREEN */}
        {orderCompleteInfo ? (
          <div className="p-6 sm:p-8 text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-500 text-emerald-500 flex items-center justify-center mx-auto shadow-md">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <h3 className={`text-xl sm:text-2xl font-black ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Pesanan Troli Berjaya Dihantar!
              </h3>
              <p className={`text-xs sm:text-sm max-w-md mx-auto ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                Rekod pesanan &amp; resit pembayaran telah disimpan dan dihantar ke sistem bot Telegram kami.
              </p>
            </div>

            <div className="space-y-3 max-w-sm mx-auto pt-2">
              <a
                href={orderCompleteInfo.whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all cursor-pointer"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Buka WhatsApp Admin</span>
              </a>

              <button
                type="button"
                onClick={handleCloseModal}
                className="w-full py-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-slate-950 font-black text-xs uppercase tracking-wider transition-all cursor-pointer"
              >
                Selesai &amp; Kembali ke Menu
              </button>
            </div>
          </div>
        ) : activeCart.length === 0 ? (
          <div className="p-10 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-slate-800/40 text-slate-500 flex items-center justify-center mx-auto">
              <ShoppingCart className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h3 className={`text-base font-bold ${isLight ? 'text-slate-800' : 'text-slate-200'}`}>
                Troli Anda Masih Kosong
              </h3>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Pilih mana-mana game dan tekan butang "Tambah Troli" untuk menambah pesanan.
              </p>
            </div>
            <button
              onClick={handleCloseModal}
              className="px-6 py-2.5 bg-orange-500 hover:bg-orange-600 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-md"
            >
              Lihat Senarai Game
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmitCart} className="p-4 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
            {/* Cart Items List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                  Senarai Item Dipilih ({activeCart.length})
                </span>
                <button
                  type="button"
                  onClick={onClearCart}
                  className="text-xs text-rose-500 hover:text-rose-600 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Padam Semua</span>
                </button>
              </div>

              {activeCart.map((item) => (
                <div
                  key={item.id}
                  className={`p-3.5 rounded-2xl border space-y-3 transition-colors ${
                    isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      {item.gameLogoUrl && (
                        <img
                          src={item.gameLogoUrl}
                          alt={item.gameName}
                          className="w-10 h-10 rounded-xl object-cover border border-orange-500/30"
                        />
                      )}
                      <div>
                        <h4 className={`text-xs sm:text-sm font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                          {item.itemName}
                        </h4>
                        <span className="text-[11px] text-orange-600 dark:text-orange-400 font-medium">
                          {item.gameName}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black font-mono text-orange-600 dark:text-amber-400">
                        RM {(item.sellPrice * item.quantity).toFixed(2)}
                      </span>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
                        title="Buang Item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* User ID & Server Input for item */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-200 dark:border-slate-800/80">
                    <div>
                      <label className={`block text-[10px] font-bold mb-1 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                        User ID Game <span className="text-orange-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Masukkan ID Game"
                        value={item.userId}
                        onChange={(e) => handleUpdateUserId(item.id, e.target.value, item.serverId)}
                        className={`w-full rounded-lg px-2.5 py-1.5 text-xs font-mono focus:outline-none ${
                          isLight
                            ? 'bg-white border border-slate-300 text-slate-900 focus:border-orange-500'
                            : 'bg-[#0D1117] border border-slate-700 text-white focus:border-orange-500'
                        }`}
                      />
                    </div>

                    <div>
                      <label className={`block text-[10px] font-bold mb-1 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                        Zone ID / Server (Jika Ada)
                      </label>
                      <input
                        type="text"
                        placeholder="Contoh: 1234"
                        value={item.serverId || ''}
                        onChange={(e) => handleUpdateUserId(item.id, item.userId, e.target.value)}
                        className={`w-full rounded-lg px-2.5 py-1.5 text-xs font-mono focus:outline-none ${
                          isLight
                            ? 'bg-white border border-slate-300 text-slate-900 focus:border-orange-500'
                            : 'bg-[#0D1117] border border-slate-700 text-white focus:border-orange-500'
                        }`}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Payment Method in Cart */}
            <div className={`p-4 rounded-2xl border space-y-3 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
            }`}>
              <h4 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-800' : 'text-white'}`}>
                Pilih Kaedah Bayaran
              </h4>
              <div className="grid grid-cols-3 gap-2">
                <div
                  onClick={() => setPaymentMethod('tng')}
                  className={`p-2.5 rounded-xl border cursor-pointer text-center text-xs font-bold transition-all ${
                    paymentMethod === 'tng'
                      ? 'bg-orange-500 text-slate-950 border-orange-500 shadow-md font-black'
                      : isLight
                      ? 'bg-white border-slate-300 text-slate-700'
                      : 'bg-[#0D1117] border-slate-700 text-slate-300'
                  }`}
                >
                  Touch 'n Go QR
                </div>
                <div
                  onClick={() => setPaymentMethod('fpx')}
                  className={`p-2.5 rounded-xl border cursor-pointer text-center text-xs font-bold transition-all ${
                    paymentMethod === 'fpx'
                      ? 'bg-orange-500 text-slate-950 border-orange-500 shadow-md font-black'
                      : isLight
                      ? 'bg-white border-slate-300 text-slate-700'
                      : 'bg-[#0D1117] border-slate-700 text-slate-300'
                  }`}
                >
                  FPX Banking
                </div>
                <div
                  onClick={() => setPaymentMethod('duitnow')}
                  className={`p-2.5 rounded-xl border cursor-pointer text-center text-xs font-bold transition-all ${
                    paymentMethod === 'duitnow'
                      ? 'bg-orange-500 text-slate-950 border-orange-500 shadow-md font-black'
                      : isLight
                      ? 'bg-white border-slate-300 text-slate-700'
                      : 'bg-[#0D1117] border-slate-700 text-slate-300'
                  }`}
                >
                  DuitNow QR
                </div>
              </div>

              {/* QR Code */}
              {(paymentMethod === 'tng' || paymentMethod === 'duitnow') && (
                <div className={`p-3 border rounded-xl flex flex-col items-center space-y-2 ${
                  isLight ? 'bg-white border-orange-200' : 'bg-[#0D1117] border-orange-500/30'
                }`}>
                  <TngQrCodeCard
                    accountName={settings.tngAccountName}
                    customQrImageUrl={settings.tngQrImageUrl}
                  />
                  <span className={`text-[11px] font-mono ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                    Nama: <strong>{settings.tngAccountName}</strong>
                  </span>
                </div>
              )}
            </div>

            {/* Receipt Upload & Phone */}
            <div className={`p-4 rounded-2xl border space-y-3 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#121824] border-slate-800'
            }`}>
              <div className="flex items-center justify-between">
                <span className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-800' : 'text-white'}`}>
                  Muat Naik Resit Bayaran <span className="text-orange-500">*</span>
                </span>
                <span className="text-[10px] text-rose-500 font-bold font-mono uppercase">Wajib</span>
              </div>

              <div className={`relative border-2 border-dashed rounded-xl p-3 text-center transition-all ${
                proofImage
                  ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20'
                  : isLight
                  ? 'border-orange-300 bg-white'
                  : 'border-rose-500/60 bg-[#0D1117]'
              }`}>
                <input
                  type="file"
                  accept="image/*"
                  required
                  onChange={handleFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                {proofImage ? (
                  <div className="flex items-center justify-center gap-3">
                    <img src={proofImage} alt="Resit" className="w-12 h-12 object-cover rounded-lg border border-emerald-500" />
                    <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold">Resit Sah &amp; Berjaya Dimuat Naik ✓</span>
                  </div>
                ) : (
                  <p className={`text-xs font-bold py-1 ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                    Tekan di sini untuk muat naik gambar resit bayaran
                  </p>
                )}
              </div>

              <div>
                <label className={`block text-xs font-bold mb-1 ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  Nombor WhatsApp Anda <span className="text-orange-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  placeholder="Contoh: 0123456789"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value.replace(/\D/g, ''))}
                  className={`w-full rounded-xl px-3 py-2 text-xs font-mono focus:outline-none ${
                    isLight
                      ? 'bg-white border border-slate-300 text-slate-900 focus:border-orange-500'
                      : 'bg-[#0D1117] border border-slate-700 text-white focus:border-orange-500'
                  }`}
                />
              </div>
            </div>

            {formError && (
              <div className="p-3 bg-rose-500/20 border border-rose-500 rounded-xl text-rose-600 dark:text-rose-300 text-xs font-bold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Bottom Total & Submit */}
            <div className={`p-4 rounded-2xl border flex items-center justify-between gap-3 ${
              isLight ? 'bg-orange-50 border-orange-200' : 'bg-[#161D2E] border-orange-500/30'
            }`}>
              <div>
                <span className={`text-[11px] block ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                  Jumlah Keseluruhan:
                </span>
                <span className="text-xl sm:text-2xl font-black text-orange-600 dark:text-amber-400 font-mono">
                  RM {totalAmount.toFixed(2)}
                </span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-40"
              >
                {isSubmitting ? 'Memproses...' : 'Hantar Semua Pesanan'}
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
