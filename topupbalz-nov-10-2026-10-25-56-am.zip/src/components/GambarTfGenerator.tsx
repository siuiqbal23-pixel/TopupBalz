import React, { useState, useRef, useEffect } from 'react';
import {
  Download,
  Copy,
  RefreshCw,
  Clock,
  Share2,
  Check,
  Smartphone,
  DollarSign,
} from 'lucide-react';

interface GambarTfGeneratorProps {
  onBackToHub?: () => void;
}

export const GambarTfGenerator: React.FC<GambarTfGeneratorProps> = () => {
  // Generate current Malaysia Time (UTC+8)
  const getMalaysiaDateTime = () => {
    const now = new Date();
    const utc = now.getTime() + now.getTimezoneOffset() * 60000;
    const myTime = new Date(utc + 3600000 * 8);

    const day = String(myTime.getDate()).padStart(2, '0');
    const month = String(myTime.getMonth() + 1).padStart(2, '0');
    const year = myTime.getFullYear();

    const hours = String(myTime.getHours()).padStart(2, '0');
    const minutes = String(myTime.getMinutes()).padStart(2, '0');
    const seconds = String(myTime.getSeconds()).padStart(2, '0');

    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
  };

  const getMalaysiaStatusTime = () => {
    const now = new Date();
    const utc = now.getTime() + now.getTimezoneOffset() * 60000;
    const myTime = new Date(utc + 3600000 * 8);

    let hours = myTime.getHours();
    const minutes = String(myTime.getMinutes()).padStart(2, '0');
    let period = 'PTG';

    if (hours >= 0 && hours < 12) period = 'PG';
    else if (hours >= 12 && hours < 14) period = 'TGH';
    else if (hours >= 14 && hours < 19) period = 'PTG';
    else period = 'MLM';

    if (hours > 12) hours -= 12;
    if (hours === 0) hours = 12;

    return `${hours}:${minutes} ${period}`;
  };

  // Receipt States
  const [amount, setAmount] = useState<string>('19.50');
  const [penerima, setPenerima] = useState<string>('BALZLTD');
  const [rujukan, setRujukan] = useState<string>('BALZLTD');
  const [dateTime, setDateTime] = useState<string>(getMalaysiaDateTime());
  const [statusTime, setStatusTime] = useState<string>(getMalaysiaStatusTime());
  const [batteryLevel, setBatteryLevel] = useState<string>('74');
  const [isDownloading, setIsDownloading] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  const hiddenCanvasRef = useRef<HTMLCanvasElement>(null);

  // Set to Current Malaysia Time
  const handleSyncCurrentTime = () => {
    setDateTime(getMalaysiaDateTime());
    setStatusTime(getMalaysiaStatusTime());
  };

  // Render Pixel-Perfect 1:1 Canvas (Exact Typography Weight & Dimensions as Original Screenshot 2)
  const drawReceiptToCanvas = (canvas: HTMLCanvasElement): void => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // High resolution canvas matching standard phone aspect ratio (720x1560)
    const width = 720;
    const height = 1560;
    canvas.width = width;
    canvas.height = height;

    // 1. Pure Crisp White Background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);

    // 2. Android Status Bar Top
    // Time on top-left (e.g., 4:34 PTG)
    ctx.fillStyle = '#1A1A1A';
    ctx.font = '500 24px -apple-system, Roboto, Arial, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(statusTime, 40, 50);

    // App notification icons on left
    ctx.fillStyle = '#555555';
    ctx.font = '19px -apple-system, Roboto, sans-serif';
    ctx.fillText('💬 📱 ✉️', 185, 49);

    // Right Status Bar elements (Network Speed, VoLTE, 4G, Battery)
    ctx.textAlign = 'right';
    ctx.font = '500 18px -apple-system, Roboto, sans-serif';
    ctx.fillStyle = '#333333';
    ctx.fillText('2.92 K/S', 515, 48);

    // VoLTE Badge
    ctx.strokeStyle = '#666666';
    ctx.lineWidth = 1.2;
    ctx.strokeRect(525, 34, 48, 18);
    ctx.font = 'bold 13px -apple-system, Roboto, sans-serif';
    ctx.fillText('VoLTE', 568, 48);

    // 4G Label
    ctx.font = 'bold 18px -apple-system, Roboto, sans-serif';
    ctx.fillText('4G', 606, 48);

    // Battery Icon
    ctx.strokeStyle = '#444444';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(618, 32, 54, 22);
    ctx.fillRect(672, 38, 3, 10); // terminal cap
    ctx.fillStyle = '#1A1A1A';
    ctx.font = 'bold 14px -apple-system, Roboto, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(batteryLevel, 645, 48);

    // 3. Green Circle Checkmark (Exact shade #00C853 from screenshot)
    const circleX = width / 2;
    const circleY = 230;
    const circleRadius = 66;

    ctx.beginPath();
    ctx.arc(circleX, circleY, circleRadius, 0, Math.PI * 2);
    ctx.fillStyle = '#00C853';
    ctx.fill();

    // Checkmark
    ctx.beginPath();
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 9;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.moveTo(circleX - 28, circleY + 2);
    ctx.lineTo(circleX - 8, circleY + 22);
    ctx.lineTo(circleX + 28, circleY - 18);
    ctx.stroke();

    // 4. Amount "RM [amount]" - Deep black & strong weight
    const displayAmount = amount.trim() || '0.00';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#111827';
    ctx.font = '600 58px -apple-system, Roboto, "Segoe UI", sans-serif';
    ctx.fillText(`RM ${displayAmount}`, width / 2, 375);

    // Subtitle: "Penghantaran duit selesai"
    ctx.fillStyle = '#222222';
    ctx.font = '400 28px -apple-system, Roboto, "Segoe UI", sans-serif';
    ctx.fillText('Penghantaran duit selesai', width / 2, 435);

    // 5. Details Table (Penerima, Rujukan, Tarikh & Waktu)
    // Left Labels: gray #666666, regular weight 400
    // Right Values: deep dark #111827, semi-bold weight 600
    const tableStartY = 530;
    const leftX = 55;
    const rightX = width - 55;

    // Row 1: Penerima
    ctx.textAlign = 'left';
    ctx.fillStyle = '#666666';
    ctx.font = '400 27px -apple-system, Roboto, "Segoe UI", sans-serif';
    ctx.fillText('Penerima', leftX, tableStartY);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#1e1e1e';
    ctx.font = '500 27px -apple-system, Roboto, "Segoe UI", sans-serif';

    const recipientText = (penerima.trim() || 'BALZLTD').toUpperCase();
    if (recipientText.length > 25) {
      const words = recipientText.split(' ');
      let line1 = '';
      let line2 = '';
      words.forEach((w) => {
        if ((line1 + w).length < 24) line1 += (line1 ? ' ' : '') + w;
        else line2 += (line2 ? ' ' : '') + w;
      });
      ctx.fillText(line1, rightX, tableStartY);
      if (line2) ctx.fillText(line2, rightX, tableStartY + 38);
    } else {
      ctx.fillText(recipientText, rightX, tableStartY);
    }

    // Row 2: Rujukan
    const refStartY = tableStartY + 115;
    ctx.textAlign = 'left';
    ctx.fillStyle = '#666666';
    ctx.font = '400 27px -apple-system, Roboto, "Segoe UI", sans-serif';
    ctx.fillText('Rujukan', leftX, refStartY);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#1e1e1e';
    ctx.font = '500 27px -apple-system, Roboto, "Segoe UI", sans-serif';
    const refText = (rujukan.trim() || 'BALZLTD').toUpperCase();
    if (refText.length > 25) {
      const words = refText.split(' ');
      let line1 = '';
      let line2 = '';
      words.forEach((w) => {
        if ((line1 + w).length < 24) line1 += (line1 ? ' ' : '') + w;
        else line2 += (line2 ? ' ' : '') + w;
      });
      ctx.fillText(line1, rightX, refStartY);
      if (line2) ctx.fillText(line2, rightX, refStartY + 38);
    } else {
      ctx.fillText(refText, rightX, refStartY);
    }

    // Row 3: Tarikh & Waktu
    const dateStartY = refStartY + 115;
    ctx.textAlign = 'left';
    ctx.fillStyle = '#666666';
    ctx.font = '400 27px -apple-system, Roboto, "Segoe UI", sans-serif';
    ctx.fillText('Tarikh & Waktu', leftX, dateStartY);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#1e1e1e';
    ctx.font = '400 27px -apple-system, Roboto, "Segoe UI", sans-serif';
    ctx.fillText(dateTime, rightX, dateStartY);

    // * Long empty white space exists here naturally between dateStartY (approx 760) and 1340 *

    // 6. Subtle faint divider line right above buttons (hampir tak kelihatan macam dalam gambar)
    const lineY = 1335;
    ctx.beginPath();
    ctx.strokeStyle = '#EEEEEE'; // Very faint, subtle separator line
    ctx.lineWidth = 1.2;
    ctx.moveTo(0, lineY);
    ctx.lineTo(width, lineY);
    ctx.stroke();

    // 7. Bottom Action Controls
    const btnY = 1365;

    // Circular Share Button
    const shareCenterX = 85;
    const shareCenterY = btnY + 44;
    const shareRadius = 42;

    ctx.beginPath();
    ctx.arc(shareCenterX, shareCenterY, shareRadius, 0, Math.PI * 2);
    ctx.fillStyle = '#FFFFFF';
    ctx.fill();
    ctx.strokeStyle = '#0066FF';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // Share Icon
    ctx.strokeStyle = '#0066FF';
    ctx.fillStyle = '#0066FF';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(shareCenterX + 10, shareCenterY - 12, 4.5, 0, Math.PI * 2);
    ctx.arc(shareCenterX - 12, shareCenterY, 4.5, 0, Math.PI * 2);
    ctx.arc(shareCenterX + 10, shareCenterY + 12, 4.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(shareCenterX + 8, shareCenterY - 10);
    ctx.lineTo(shareCenterX - 8, shareCenterY - 2);
    ctx.lineTo(shareCenterX + 8, shareCenterY + 10);
    ctx.stroke();

    // Blue "Selesai" Button (#0066FF)
    const selesaiLeft = 150;
    const selesaiWidth = width - 195;
    const selesaiHeight = 88;
    const selesaiRadius = 44;

    ctx.beginPath();
    ctx.roundRect(selesaiLeft, btnY, selesaiWidth, selesaiHeight, selesaiRadius);
    ctx.fillStyle = '#0066FF';
    ctx.fill();

    // "Selesai" Label
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '600 32px -apple-system, Roboto, "Segoe UI", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Selesai', selesaiLeft + selesaiWidth / 2, btnY + 55);

    // 8. Android Bottom Navigation Keys (|||  O  ◁)
    const navY = height - 40;
    ctx.fillStyle = '#888888';
    ctx.font = '400 30px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('|||', 180, navY);

    // Home Circle
    ctx.beginPath();
    ctx.arc(width / 2, navY - 10, 12, 0, Math.PI * 2);
    ctx.strokeStyle = '#888888';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // Back Triangle
    ctx.font = '28px sans-serif';
    ctx.fillText('◁', width - 180, navY);
  };

  // Trigger Download as High-Res PNG
  const handleDownloadReceipt = () => {
    try {
      setIsDownloading(true);
      const canvas = hiddenCanvasRef.current || document.createElement('canvas');
      drawReceiptToCanvas(canvas);

      const image = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.href = image;
      const cleanAmount = amount.replace(/[^0-9.]/g, '') || 'tf';
      link.download = `Resit_Tf_RM${cleanAmount}_BALZLTD_${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('Failed to download receipt image:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  // Copy Receipt Image (Blob) or Fallback Text to Clipboard
  const handleCopyReceipt = () => {
    try {
      const canvas = hiddenCanvasRef.current || document.createElement('canvas');
      drawReceiptToCanvas(canvas);

      if (navigator.clipboard && window.ClipboardItem) {
        canvas.toBlob(async (blob) => {
          if (blob) {
            try {
              await navigator.clipboard.write([
                new ClipboardItem({ 'image/png': blob })
              ]);
              setCopySuccess(true);
              setTimeout(() => setCopySuccess(false), 2500);
            } catch {
              // Fallback to text copy
              await navigator.clipboard.writeText(
                `✅ Penghantaran duit selesai\nJumlah: RM ${amount}\nPenerima: ${penerima}\nRujukan: ${rujukan}\nTarikh & Waktu: ${dateTime}`
              );
              setCopySuccess(true);
              setTimeout(() => setCopySuccess(false), 2500);
            }
          }
        }, 'image/png');
      } else {
        navigator.clipboard.writeText(
          `✅ Penghantaran duit selesai\nJumlah: RM ${amount}\nPenerima: ${penerima}\nRujukan: ${rujukan}\nTarikh & Waktu: ${dateTime}`
        );
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2500);
      }
    } catch (err) {
      console.error('Clipboard copy failed:', err);
    }
  };

  // Keep hidden canvas in sync
  useEffect(() => {
    if (hiddenCanvasRef.current) {
      drawReceiptToCanvas(hiddenCanvasRef.current);
    }
  }, [amount, penerima, rujukan, dateTime, statusTime, batteryLevel]);

  const quickAmounts = ['10.00', '19.50', '25.00', '50.00', '100.00', '150.00', '200.00', '500.00'];

  return (
    <div className="space-y-6 max-w-6xl mx-auto animate-fadeIn pb-12">
      
      {/* Hidden offscreen canvas for rendering clean PNGs */}
      <canvas ref={hiddenCanvasRef} className="hidden" />

      {/* Top Breadcrumb & Info Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-teal-500/10 to-emerald-500/15 border border-emerald-500/40 text-xs text-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold font-mono text-[10px] uppercase border border-emerald-500/30">
              📸 Generator Resit Tf Mirip 100%
            </span>
            <span className="text-slate-400 text-xs">• Touch 'n Go / DuitNow Style</span>
          </div>
          <p className="text-white text-sm font-black">
            Penjana Gambar Bukti Penghantaran Duit (Gambar Tf)
          </p>
          <p className="text-slate-300 text-xs">
            Format tulisan hitam kemas (medium-semibold) mengikut tangkapan skrin telefon sebenar. Edit harga sesuka hati (RM kekal), penerima &amp; rujukan <strong>BALZLTD</strong>, serta masa Malaysia.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleDownloadReceipt}
            disabled={isDownloading}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg cursor-pointer transition-all active:scale-95 disabled:opacity-50"
          >
            {isDownloading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Download className="w-4 h-4" />
            )}
            <span>{isDownloading ? 'Menjana...' : 'Muat Turun Gambar (PNG)'}</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Control Panel (Left) + Phone Receipt Mockup (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT: Controls Editor */}
        <div className="lg:col-span-6 space-y-5 bg-[#121824] p-5 sm:p-6 rounded-3xl border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>Sunting Butiran Resit Tf</span>
            </h3>
            <button
              type="button"
              onClick={handleSyncCurrentTime}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 text-[11px] font-bold flex items-center gap-1 border border-slate-700 cursor-pointer transition-all"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Waktu Semasa MY</span>
            </button>
          </div>

          {/* 1. EDIT HARGA (RM Cannot be edited, only number) */}
          <div className="space-y-2">
            <label className="text-xs font-black text-slate-300 uppercase tracking-wider flex items-center justify-between">
              <span>Jumlah Bayaran (RM)</span>
              <span className="text-[10px] text-emerald-400 font-mono font-normal">
                *Teks "RM" kekal tetap
              </span>
            </label>
            <div className="relative flex items-center rounded-2xl bg-slate-900 border-2 border-emerald-500/50 focus-within:border-emerald-400 shadow-inner overflow-hidden">
              <div className="px-4 py-3 bg-emerald-500/10 text-emerald-400 font-black text-lg sm:text-xl border-r border-emerald-500/30 select-none font-mono">
                RM
              </div>
              <input
                type="text"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Contoh: 19.50 atau 100"
                className="w-full px-4 py-3 bg-transparent text-white font-black text-xl sm:text-2xl focus:outline-none font-mono"
              />
            </div>

            {/* Quick Price Buttons */}
            <div className="pt-1.5 flex flex-wrap gap-1.5">
              {quickAmounts.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => setAmount(q)}
                  className={`px-2.5 py-1 rounded-xl text-xs font-bold font-mono transition-all cursor-pointer ${
                    amount === q
                      ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                      : 'bg-slate-800/90 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700/60'
                  }`}
                >
                  RM {q}
                </button>
              ))}
            </div>
          </div>

          {/* 2. PENERIMA & RUJUKAN (Defaults to BALZLTD) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>Penerima</span>
                <span className="text-[10px] text-slate-500">Tulisan biasa</span>
              </label>
              <input
                type="text"
                value={penerima}
                onChange={(e) => setPenerima(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>Rujukan</span>
                <span className="text-[10px] text-slate-500">Tulisan biasa</span>
              </label>
              <input
                type="text"
                value={rujukan}
                onChange={(e) => setRujukan(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* 3. TARIKH & WAKTU MALAYSIA */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-400" />
                <span>Tarikh &amp; Waktu (Format Malaysia)</span>
              </span>
              <span className="text-[10px] text-emerald-400 font-mono">DD/MM/YYYY HH:mm:ss</span>
            </label>
            <input
              type="text"
              value={dateTime}
              onChange={(e) => setDateTime(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono font-bold focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* 4. STATUS BAR PHONE SETTINGS (OPTIONAL CUSTOMIZATION) */}
          <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-slate-800 space-y-3">
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-slate-400" />
              <span>Tetapan Status Bar Telefon</span>
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 block">Jam Bar Atas:</span>
                <input
                  type="text"
                  value={statusTime}
                  onChange={(e) => setStatusTime(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs font-mono font-bold"
                />
              </div>
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 block">Bateri (%):</span>
                <input
                  type="text"
                  value={batteryLevel}
                  onChange={(e) => setBatteryLevel(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs font-mono font-bold"
                />
              </div>
            </div>
          </div>

          {/* ACTION BUTTONS */}
          <div className="pt-2 flex flex-col sm:flex-row items-stretch gap-3">
            <button
              type="button"
              onClick={handleDownloadReceipt}
              disabled={isDownloading}
              className="flex-1 py-3 px-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 disabled:opacity-50"
            >
              {isDownloading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              <span>{isDownloading ? 'Menjana Gambar...' : 'Muat Turun Gambar Resit'}</span>
            </button>

            <button
              type="button"
              onClick={handleCopyReceipt}
              className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
            >
              {copySuccess ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400">Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-300" />
                  <span>Salin Gambar</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* RIGHT: Live Phone Screen Receipt Mockup (Exact 100% Mirror of Screenshot 2) */}
        <div className="lg:col-span-6 flex flex-col items-center justify-center">
          
          <div className="w-full max-w-[360px] sm:max-w-[390px] bg-slate-950 p-2 sm:p-3 rounded-[40px] border-4 border-slate-800 shadow-[0_20px_60px_rgba(0,0,0,0.8)] relative">
            
            {/* Phone Speaker Notch */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 w-20 h-4 bg-slate-900 rounded-full z-20 flex items-center justify-center">
              <div className="w-8 h-1 bg-slate-800 rounded-full" />
            </div>

            {/* RECEIPT PREVIEW CONTAINER (Matching Screenshot 2 Perfectly) */}
            <div
              className="w-full bg-[#FFFFFF] text-[#111827] rounded-[32px] overflow-hidden flex flex-col justify-between select-none shadow-sm min-h-[720px] sm:min-h-[760px]"
              style={{ fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif' }}
            >
              
              {/* Top Container: Status Bar + Receipt Details */}
              <div className="flex flex-col">
                {/* 1. REALISTIC PHONE STATUS BAR */}
                <div className="pt-3 pb-2 px-5 bg-transparent flex items-center justify-between text-[11px] font-normal text-slate-700 tracking-tight">
                  <div className="flex items-center gap-1.5">
                    <span className="font-normal text-slate-900 text-[12px]">{statusTime}</span>
                    <span className="text-[10px] text-slate-500 font-sans">💬 📱 ✉️</span>
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-slate-700 font-sans">
                    <span>2.92 K/S</span>
                    <span className="text-[9px] font-bold border border-slate-400 px-0.5 rounded leading-none">VoLTE</span>
                    <span className="font-bold">4G</span>
                    <div className="flex items-center gap-0.5 border border-slate-500 rounded px-1 text-[9px] font-bold">
                      <span>{batteryLevel}</span>
                    </div>
                  </div>
                </div>

                {/* 2. RECEIPT MAIN CONTENT */}
                <div className="px-6 pt-5 pb-4 flex flex-col items-center text-center space-y-4">
                  
                  {/* Large Green Success Circle Badge (Flat Solid / Tiada Menyala) */}
                  <div className="w-18 h-18 sm:w-20 sm:h-20 rounded-full bg-[#00C853] flex items-center justify-center mt-2">
                    <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </div>

                  {/* Amount Display: Bold, crisp black matching screenshot 2 */}
                  <div className="space-y-1 pt-1">
                    <h1 className="text-3xl sm:text-4xl font-semibold text-[#111827] tracking-tight flex items-center justify-center gap-2">
                      <span className="text-[#111827]">RM</span>
                      <span className="text-[#111827]">{amount || '0.00'}</span>
                    </h1>
                    <p className="text-sm sm:text-base font-normal text-[#222222]">
                      Penghantaran duit selesai
                    </p>
                  </div>

                  {/* Receipt Data Table: Dark, medium text matching screenshot */}
                  <div className="w-full pt-4 space-y-4 text-left text-xs sm:text-sm">
                    
                    {/* Penerima */}
                    <div className="flex items-start justify-between gap-4">
                      <span className="text-[#666666] font-normal shrink-0 w-24">
                        Penerima
                      </span>
                      <span className="text-[#1e1e1e] font-medium text-right uppercase leading-tight max-w-[210px] break-words">
                        {penerima || 'BALZLTD'}
                      </span>
                    </div>

                    {/* Rujukan */}
                    <div className="flex items-start justify-between gap-4">
                      <span className="text-[#666666] font-normal shrink-0 w-24">
                        Rujukan
                      </span>
                      <span className="text-[#1e1e1e] font-medium text-right uppercase leading-tight max-w-[210px] break-words">
                        {rujukan || 'BALZLTD'}
                      </span>
                    </div>

                    {/* Tarikh & Waktu */}
                    <div className="flex items-center justify-between gap-4 pt-1">
                      <span className="text-[#666666] font-normal shrink-0 w-24">
                        Tarikh &amp; Waktu
                      </span>
                      <span className="text-[#1e1e1e] font-normal text-right text-xs sm:text-[13px]">
                        {dateTime}
                      </span>
                    </div>
                  </div>

                </div>
              </div>

              {/* Generous White Space (Bawah tarikh dan waktu dikosongkan panjang macam ori) */}
              <div className="flex-1 min-h-[140px] sm:min-h-[180px]" />

              {/* 3. RECEIPT BOTTOM BAR (Subtle faint line on top + Share + Blue Selesai Button) */}
              <div className="border-t border-[#EDEDED] px-5 pb-4 pt-4 space-y-3">
                <div className="flex items-center gap-3">
                  
                  {/* Circular Share Button with Thin Blue Border */}
                  <button
                    type="button"
                    className="w-12 h-12 rounded-full border border-[#0066FF] flex items-center justify-center text-[#0066FF] bg-white shadow-sm shrink-0"
                  >
                    <Share2 className="w-5 h-5" />
                  </button>

                  {/* Blue Full Width "Selesai" Button (Flat Solid / Tiada Menyala) */}
                  <button
                    type="button"
                    className="flex-1 h-12 rounded-full bg-[#0066FF] text-white font-semibold text-base flex items-center justify-center"
                  >
                    Selesai
                  </button>
                </div>

                {/* Realistic Android Navigation Bar Bottom */}
                <div className="pt-2 flex items-center justify-around text-slate-400 text-xs px-6 opacity-60">
                  <span className="font-normal tracking-widest text-sm">|||</span>
                  <div className="w-3 h-3 rounded-full border border-slate-400" />
                  <span className="font-normal text-sm">◁</span>
                </div>
              </div>

            </div>

            {/* Bottom Screen Label */}
            <div className="mt-3 text-center">
              <span className="text-[11px] text-slate-400 font-mono">
                📱 Pratonton Format Resit 1:1 Mengikut Gambar 2
              </span>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
