import React from 'react';
import { Zap, Flame } from 'lucide-react';
import { Game } from '../types';

interface GameCardProps {
  game: Game;
  onSelectGame: (game: Game) => void;
  isCompact?: boolean;
  theme?: 'dark' | 'light';
}

export const GameCard: React.FC<GameCardProps> = ({
  game,
  onSelectGame,
  isCompact = false,
  theme = 'dark',
}) => {
  const isLight = theme === 'light';

  return (
    <div
      onClick={() => onSelectGame(game)}
      className={`group relative rounded-2xl border transition-all duration-300 hover:-translate-y-1 cursor-pointer flex flex-col overflow-hidden backdrop-blur-md active:scale-95 select-none ${
        isLight
          ? 'bg-white border-slate-200 hover:border-orange-500 hover:shadow-[0_8px_20px_rgba(249,115,22,0.2)] shadow-sm'
          : 'bg-[#0D1117]/95 border-slate-800/90 hover:border-orange-500/70 hover:shadow-[0_0_20px_rgba(255,140,0,0.3)]'
      }`}
    >
      {/* Game Logo / Poster Box */}
      <div className={`relative aspect-[4/5] w-full overflow-hidden ${isLight ? 'bg-slate-100' : 'bg-slate-900/90'}`}>
        <img
          src={game.logoUrl}
          alt={game.name}
          referrerPolicy="no-referrer"
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-106 transition-transform duration-500 ease-out"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=400&q=80';
          }}
        />
        
        {/* Subtle Vignette Overlay */}
        <div className={`absolute inset-0 pointer-events-none ${isLight ? 'bg-gradient-to-t from-white/20 via-transparent to-black/10' : 'bg-gradient-to-t from-[#0D1117] via-transparent to-black/30'}`} />

        {/* Top Badges */}
        <div className="absolute top-1.5 left-1.5 right-1.5 z-10 flex items-center justify-between gap-1 pointer-events-none">
          {game.badgeText ? (
            <span className="px-2 py-0.5 rounded-lg text-[9px] sm:text-[10px] font-black bg-black/80 backdrop-blur-md text-amber-300 border border-amber-400/40 tracking-tight shadow-md truncate max-w-full">
              {game.badgeText}
            </span>
          ) : game.isMostSearched ? (
            <span className="px-1.5 py-0.5 rounded-lg text-[9px] sm:text-[10px] font-black bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 flex items-center gap-0.5 shadow-md">
              <Flame className="w-2.5 h-2.5 fill-current" />
              <span>TOP</span>
            </span>
          ) : game.isDiscounted ? (
            <span className="px-1.5 py-0.5 rounded-lg text-[9px] sm:text-[10px] font-black bg-amber-400 text-slate-950 uppercase tracking-wider flex items-center gap-0.5 shadow-md">
              <Zap className="w-2.5 h-2.5 fill-current" />
              <span>PROMO</span>
            </span>
          ) : null}
        </div>
      </div>

      {/* Game Title Section */}
      <div className={`p-2 sm:p-2.5 flex items-center justify-center text-center min-h-[42px] sm:min-h-[48px] border-t ${
        isLight
          ? 'bg-slate-50/90 border-slate-100'
          : 'bg-[#0D1117] border-slate-800/60'
      }`}>
        <h3 className={`font-extrabold text-[11px] sm:text-xs leading-tight transition-colors line-clamp-2 ${
          isLight
            ? 'text-slate-900 group-hover:text-orange-600'
            : 'text-white group-hover:text-orange-400'
        }`}>
          {game.name}
        </h3>
      </div>
    </div>
  );
};
