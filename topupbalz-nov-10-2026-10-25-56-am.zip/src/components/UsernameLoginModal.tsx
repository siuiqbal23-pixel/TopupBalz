import React, { useState, useEffect } from 'react';
import { X, UserCheck, AlertCircle, Sparkles, LogIn, Lock, ShieldAlert } from 'lucide-react';
import { UserProfile } from '../types';
import { ADMIN_USERNAME, ADMIN_PIN_CODE } from '../lib/clerkConfig';

interface UsernameLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile) => void;
  titleMessage?: string;
  titlePrompt?: string;
  theme?: 'dark' | 'light';
}

export const UsernameLoginModal: React.FC<UsernameLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  titleMessage,
  titlePrompt,
  theme = 'dark',
}) => {
  const displayTitle = titlePrompt || titleMessage || 'Log Masuk Username TopupBalz';
  const [usernameInput, setUsernameInput] = useState('');
  const [adminCodeInput, setAdminCodeInput] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const isLight = theme === 'light';

  useEffect(() => {
    if (isOpen) {
      setUsernameInput('');
      setAdminCodeInput('');
      setErrorMessage(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const clean = usernameInput.trim().replace(/^@+/, '');
  const isTargetAdmin =
    clean.toLowerCase() === 'siuiqbal23' ||
    clean.toLowerCase() === ADMIN_USERNAME.toLowerCase() ||
    clean.toLowerCase() === 'balzltdsdn' ||
    clean.toLowerCase() === 'balzz';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!clean) {
      setErrorMessage('Sila letak nama username anda dahulu!');
      return;
    }

    if (isTargetAdmin && (!adminCodeInput.trim() || adminCodeInput.trim() !== ADMIN_PIN_CODE)) {
      setErrorMessage('PIN keselamatan tidak sah. Sila cuba lagi.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/user/set-username', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: `usr-${Date.now()}`,
          username: clean,
          pinCode: isTargetAdmin ? adminCodeInput.trim() : undefined,
        }),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setErrorMessage(data.error || 'Tak boleh, nama ini sudah digunakan!');
        setLoading(false);
        return;
      }

      if (data.user) {
        localStorage.setItem('topupbalz_current_user', JSON.stringify(data.user));
        if (isTargetAdmin) {
          localStorage.setItem('topupbalz_admin_pin_verified', 'true');
        }
        onLoginSuccess(data.user);
        onClose();
      }
    } catch (err: any) {
      setErrorMessage('Ralat sambungan ke pelayan. Sila cuba lagi.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`fixed inset-0 z-[130] backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn ${
      isLight ? 'bg-slate-900/50' : 'bg-black/80'
    }`}>
      <div className={`relative w-full max-w-md rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl overflow-hidden border transition-colors duration-300 ${
        isLight
          ? 'bg-white border-orange-200 text-slate-900 shadow-2xl'
          : 'bg-[#0D1117] border-orange-500/40 text-white shadow-[0_0_50px_rgba(255,140,0,0.2)]'
      }`}>
        
        {/* Glow Background Accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-72 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Tutup Log Masuk"
          className={`absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all cursor-pointer z-10 border ${
            isLight
              ? 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'
              : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
          }`}
        >
          <X className="w-4 h-4" />
        </button>

        {/* Icon & Heading */}
        <div className="text-center space-y-2 relative z-10">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500 to-amber-500 p-0.5 mx-auto shadow-lg">
            <div className={`w-full h-full rounded-[14px] flex items-center justify-center ${
              isLight ? 'bg-white text-orange-600' : 'bg-[#0D1117] text-orange-400'
            }`}>
              <UserCheck className="w-8 h-8" />
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/15 border border-orange-500/30 text-orange-600 dark:text-orange-300 text-[11px] font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Sistem Akaun Username</span>
          </div>

          <h3 className={`text-xl font-black tracking-tight ${isLight ? 'text-slate-900' : 'text-white'}`}>{displayTitle}</h3>
          <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
            Sila tetapkan username unik anda untuk identiti tempahan & perbualan Live Chat.
          </p>
        </div>

        {/* Error Alert Message */}
        {errorMessage && (
          <div className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-500/50 text-rose-600 dark:text-rose-300 text-xs font-bold flex items-center gap-2.5 animate-shake">
            <ShieldAlert className="w-5 h-5 text-rose-500 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 relative z-10">
          <div className="space-y-1.5">
            <label className={`text-xs font-bold block ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
              Username Anda:
            </label>
            <div className="relative flex items-center">
              <span className="absolute left-3.5 text-orange-500 font-mono font-black text-base select-none">
                @
              </span>
              <input
                type="text"
                required
                autoFocus
                value={usernameInput}
                onChange={(e) => {
                  setUsernameInput(e.target.value.replace(/\s+/g, ''));
                  setErrorMessage(null);
                }}
                placeholder="masukkan_username"
                className={`w-full rounded-2xl pl-8 pr-4 py-3.5 font-mono font-bold text-sm focus:outline-none transition-all border shadow-sm ${
                  isLight
                    ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400 focus:border-orange-500'
                    : 'bg-[#121824] border-slate-700 text-white placeholder:text-slate-600 focus:border-orange-500'
                }`}
              />
            </div>
          </div>

          {isTargetAdmin && (
            <div className="space-y-1.5 animate-fadeIn">
              <label className={`text-xs font-bold block ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                PIN Keselamatan (Admin):
              </label>
              <div className="relative flex items-center">
                <span className="absolute left-3.5 text-amber-500">
                  <Lock className="w-4 h-4" />
                </span>
                <input
                  type="password"
                  maxLength={6}
                  required
                  value={adminCodeInput}
                  onChange={(e) => {
                    setAdminCodeInput(e.target.value.replace(/\D/g, ''));
                    setErrorMessage(null);
                  }}
                  placeholder="••••••"
                  className={`w-full rounded-2xl pl-10 pr-4 py-3.5 font-mono font-black text-base tracking-widest focus:outline-none transition-all border ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400 focus:border-orange-500'
                      : 'bg-[#121824] border-slate-700 text-white placeholder:text-slate-600 focus:border-orange-500'
                  }`}
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !clean}
            className="w-full py-3.5 px-4 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-slate-950 font-black text-sm uppercase tracking-wider rounded-2xl transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-40"
          >
            {loading ? (
              <span>Menyemak Username...</span>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>Masuk Sekarang</span>
              </>
            )}
          </button>
        </form>

      </div>
    </div>
  );
};
