import React, { createContext, useContext, useState, useEffect } from 'react';
import { useUser, useClerk } from '@clerk/clerk-react';
import { CLERK_PUBLISHABLE_KEY, ADMIN_USERNAME, ADMIN_PIN_CODE, isAuthorizedAdmin } from '../lib/clerkConfig';
import { UserProfile } from '../types';

export interface AuthContextType {
  isClerkConfigured: boolean;
  isSignedIn: boolean;
  user: UserProfile | null;
  userEmail: string | null;
  isAdmin: boolean;
  adminUsername: string;
  adminPinVerified: boolean;
  verifyAdminPin: (pin: string) => boolean;
  setUsername: (username: string, pin?: string) => { success: boolean; message?: string };
  loginWithGoogle: () => void;
  openSignInModal: () => void;
  openSignUpModal: () => void;
  isClerkModalOpen: boolean;
  clerkModalMode: 'signin' | 'signup';
  closeClerkModal: () => void;
  isGoogleModalOpen: boolean;
  openGoogleModal: () => void;
  closeGoogleModal: () => void;
  handleGoogleLoginSuccess: (googleUser: { email: string; name: string; avatarUrl?: string; id?: string }) => void;
  logout: () => Promise<void>;
  updateUserPhone: (phone: string) => void;
  updateUserAvatar: (avatarUrl: string) => void;
  localUser: UserProfile | null;
  setLocalUser: (u: UserProfile | null) => void;
  showOnboardingUsername: boolean;
  openOnboardingUsername: () => void;
  closeOnboardingUsername: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

// Component that connects to Clerk's real hook
const ClerkConsumerBridge: React.FC<{
  children: (props: {
    isSignedIn: boolean;
    clerkUser: ReturnType<typeof useUser>['user'];
    clerk: ReturnType<typeof useClerk>;
  }) => React.ReactNode;
}> = ({ children }) => {
  const { isSignedIn, user } = useUser();
  const clerk = useClerk();
  return <>{children({ isSignedIn: !!isSignedIn, clerkUser: user, clerk })}</>;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isClerkModalOpen, setIsClerkModalOpen] = useState(false);
  const [clerkModalMode, setClerkModalMode] = useState<'signin' | 'signup'>('signin');
  const [isGoogleModalOpen, setIsGoogleModalOpen] = useState(false);
  const [showOnboardingUsername, setShowOnboardingUsername] = useState(false);

  const [localUser, setLocalUser] = useState<UserProfile | null>(() => {
    try {
      const stored = localStorage.getItem('topupbalz_current_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const [adminPinVerified, setAdminPinVerified] = useState<boolean>(() => {
    try {
      return localStorage.getItem('topupbalz_admin_pin_verified') === 'true';
    } catch {
      return false;
    }
  });

  const updateUserPhone = (phone: string) => {
    if (localUser) {
      const updated = { ...localUser, phoneNumber: phone };
      setLocalUser(updated);
      localStorage.setItem('topupbalz_current_user', JSON.stringify(updated));
    }
  };

  const updateUserAvatar = (avatarUrl: string) => {
    if (localUser) {
      const updated = { ...localUser, avatarUrl };
      setLocalUser(updated);
      localStorage.setItem('topupbalz_current_user', JSON.stringify(updated));
    }
  };

  const verifyAdminPin = (pin: string): boolean => {
    if (pin.trim() === ADMIN_PIN_CODE) {
      setAdminPinVerified(true);
      localStorage.setItem('topupbalz_admin_pin_verified', 'true');
      return true;
    }
    return false;
  };

  // Google Login Success Handler
  const handleGoogleLoginSuccess = (googleUser: {
    email: string;
    name: string;
    avatarUrl?: string;
    id?: string;
  }) => {
    const rawDefaultName = googleUser.name || googleUser.email.split('@')[0] || 'Gamer';
    const cleanUsername = rawDefaultName.replace(/\s+/g, '_');
    const newUser: UserProfile = {
      id: googleUser.id || `google-${Date.now()}`,
      name: rawDefaultName,
      username: cleanUsername,
      email: googleUser.email,
      avatarUrl: googleUser.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(rawDefaultName)}`,
      googleId: googleUser.id || '',
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      isOnline: true,
      isEmailVerified: true,
      totalOrders: 0,
      totalSpent: 0,
    };

    setLocalUser(newUser);
    localStorage.setItem('topupbalz_current_user', JSON.stringify(newUser));
    setIsGoogleModalOpen(false);
    setIsClerkModalOpen(false);
    setShowOnboardingUsername(false);
  };

  // Helper to set or change username and check admin PIN if BalzLtdSdn
  const handleSetUsername = (newUsername: string, pin?: string): { success: boolean; message?: string } => {
    const clean = newUsername.trim().replace(/^@+/, '');
    if (!clean) {
      return { success: false, message: 'Sila masukkan username yang sah.' };
    }

    const isAdminTarget =
      clean.toLowerCase() === 'siuiqbal23' ||
      clean.toLowerCase() === ADMIN_USERNAME.toLowerCase() ||
      clean.toLowerCase() === 'balzltdsdn' ||
      clean.toLowerCase() === 'balzz';
    if (isAdminTarget) {
      if (!pin || pin.trim() !== ADMIN_PIN_CODE) {
        return { success: false, message: 'PIN keselamatan tidak sah. Sila semak semula.' };
      }
      setAdminPinVerified(true);
      localStorage.setItem('topupbalz_admin_pin_verified', 'true');
    } else {
      setAdminPinVerified(false);
      localStorage.removeItem('topupbalz_admin_pin_verified');
    }

    const updated: UserProfile = {
      ...(localUser || ({} as any)),
      id: localUser?.id || `user-${Date.now()}`,
      email: localUser?.email || `${clean.toLowerCase()}@gmail.com`,
      name: clean,
      username: clean,
      createdAt: localUser?.createdAt || new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      isOnline: true,
      isEmailVerified: true,
    };
    setLocalUser(updated);
    localStorage.setItem('topupbalz_current_user', JSON.stringify(updated));

    setShowOnboardingUsername(false);
    return { success: true };
  };

  // If Clerk Publishable Key is provided
  if (CLERK_PUBLISHABLE_KEY) {
    return (
      <ClerkConsumerBridge>
        {({ isSignedIn, clerkUser, clerk }) => {
          const email = clerkUser?.primaryEmailAddress?.emailAddress || clerkUser?.emailAddresses?.[0]?.emailAddress || null;
          
          // Check stored custom username
          let activeName = localUser?.username || localUser?.name;
          const hasChosenCustomUsername = !!(localUser?.username && localUser.username.trim().length > 0);

          if (!activeName && clerkUser) {
            activeName = clerkUser.username || clerkUser.firstName || (email ? email.split('@')[0] : 'Gamer');
          }
          if (!activeName) activeName = 'Gamer';

          const avatar = clerkUser?.imageUrl || localUser?.avatarUrl || '';
          const cleanName = (activeName || '').replace(/^@+/, '');
          const isTargetAdmin =
            cleanName.toLowerCase() === 'siuiqbal23' ||
            cleanName.toLowerCase() === ADMIN_USERNAME.toLowerCase() ||
            cleanName.toLowerCase() === 'balzltdsdn' ||
            cleanName.toLowerCase() === 'balzz';
          const hasAdminAccess = isTargetAdmin && adminPinVerified;

          const activeProfile: UserProfile | null = (isSignedIn && clerkUser) || localUser ? {
            id: clerkUser?.id || localUser?.id || 'TB-USER',
            email: email || localUser?.email || '',
            name: activeName,
            username: cleanName,
            avatarUrl: avatar,
            googleId: clerkUser?.id || localUser?.googleId || '',
            phoneNumber: clerkUser?.phoneNumbers?.[0]?.phoneNumber || localUser?.phoneNumber || '',
            createdAt: clerkUser?.createdAt ? new Date(clerkUser.createdAt).toISOString() : (localUser?.createdAt || new Date().toISOString()),
            lastLoginAt: new Date().toISOString(),
            totalOrders: localUser?.totalOrders || 0,
            totalSpent: localUser?.totalSpent || 0,
            isOnline: true,
            isEmailVerified: true,
          } : null;

          // If signed in with Clerk but hasn't set custom username yet, trigger onboarding prompt
          useEffect(() => {
            if (isSignedIn && clerkUser && !hasChosenCustomUsername) {
              setShowOnboardingUsername(true);
            }
          }, [isSignedIn, clerkUser?.id, hasChosenCustomUsername]);

          const contextValue: AuthContextType = {
            isClerkConfigured: true,
            isSignedIn: isSignedIn || !!localUser,
            user: activeProfile,
            userEmail: email || localUser?.email || null,
            isAdmin: hasAdminAccess,
            adminUsername: ADMIN_USERNAME,
            adminPinVerified,
            verifyAdminPin,
            setUsername: handleSetUsername,
            isClerkModalOpen,
            clerkModalMode,
            openSignInModal: () => {
              setClerkModalMode('signin');
              setIsClerkModalOpen(true);
            },
            openSignUpModal: () => {
              setClerkModalMode('signup');
              setIsClerkModalOpen(true);
            },
            closeClerkModal: () => setIsClerkModalOpen(false),
            isGoogleModalOpen,
            openGoogleModal: () => setIsGoogleModalOpen(true),
            closeGoogleModal: () => setIsGoogleModalOpen(false),
            handleGoogleLoginSuccess,
            loginWithGoogle: () => {
              setIsGoogleModalOpen(true);
            },
            logout: async () => {
              try {
                if (clerk && clerk.signOut) {
                  await clerk.signOut();
                }
              } catch (e) {
                console.warn('Clerk signOut caught:', e);
              }
              localStorage.removeItem('topupbalz_current_user');
              localStorage.removeItem('topupbalz_admin_pin_verified');
              sessionStorage.clear();
              setAdminPinVerified(false);
              setLocalUser(null);
            },
            updateUserPhone,
            updateUserAvatar,
            localUser,
            setLocalUser,
            showOnboardingUsername,
            openOnboardingUsername: () => setShowOnboardingUsername(true),
            closeOnboardingUsername: () => setShowOnboardingUsername(false),
          };

          return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>;
        }}
      </ClerkConsumerBridge>
    );
  }

  // Fallback when Clerk key is not provided
  const activeName = localUser?.username || localUser?.name || '';
  const cleanName = activeName.replace(/^@+/, '');
  const isTargetAdmin =
    cleanName.toLowerCase() === 'siuiqbal23' ||
    cleanName.toLowerCase() === ADMIN_USERNAME.toLowerCase() ||
    cleanName.toLowerCase() === 'balzltdsdn' ||
    cleanName.toLowerCase() === 'balzz';
  const hasAdminAccess = isTargetAdmin && adminPinVerified;

  const contextValue: AuthContextType = {
    isClerkConfigured: false,
    isSignedIn: !!localUser,
    user: localUser,
    userEmail: localUser?.email || null,
    isAdmin: hasAdminAccess,
    adminUsername: ADMIN_USERNAME,
    adminPinVerified,
    verifyAdminPin,
    setUsername: handleSetUsername,
    isClerkModalOpen,
    clerkModalMode,
    openSignInModal: () => {
      setClerkModalMode('signin');
      setIsClerkModalOpen(true);
    },
    openSignUpModal: () => {
      setClerkModalMode('signup');
      setIsClerkModalOpen(true);
    },
    closeClerkModal: () => setIsClerkModalOpen(false),
    isGoogleModalOpen,
    openGoogleModal: () => setIsGoogleModalOpen(true),
    closeGoogleModal: () => setIsGoogleModalOpen(false),
    handleGoogleLoginSuccess,
    loginWithGoogle: () => {
      setIsGoogleModalOpen(true);
    },
    logout: async () => {
      localStorage.removeItem('topupbalz_current_user');
      localStorage.removeItem('topupbalz_admin_pin_verified');
      sessionStorage.clear();
      setAdminPinVerified(false);
      setLocalUser(null);
    },
    updateUserPhone,
    updateUserAvatar,
    localUser,
    setLocalUser,
    showOnboardingUsername,
    openOnboardingUsername: () => setShowOnboardingUsername(true),
    closeOnboardingUsername: () => setShowOnboardingUsername(false),
  };

  return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>;
};

export const useAppAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAppAuth must be used within an AuthProvider');
  }
  return context;
};
