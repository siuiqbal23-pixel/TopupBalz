/**
 * TopupBalz Privacy & Masking Utilities
 * Protects customer privacy on digital receipts, Telegram channels, and public feeds.
 */

/**
 * Masks Order ID (e.g. "BZ-382148" -> "BZ***148", "#BZ-382148" -> "#BZ***148")
 */
export function maskOrderId(orderId: string): string {
  if (!orderId) return '';
  const clean = orderId.trim();
  const hasHash = clean.startsWith('#');
  const withoutHash = hasHash ? clean.slice(1) : clean;

  const match = withoutHash.match(/^([A-Za-z]+)-?(\d+)$/);
  if (match) {
    const prefix = match[1]; // e.g. "BZ", "TB"
    const num = match[2];
    if (num.length > 3) {
      const last3 = num.slice(-3);
      return `${hasHash ? '#' : ''}${prefix}***${last3}`;
    }
  }

  if (withoutHash.length > 5) {
    return `${hasHash ? '#' : ''}${withoutHash.slice(0, 2)}***${withoutHash.slice(-3)}`;
  }
  return clean;
}

/**
 * Masks In-Game User ID: 2 front digits visible, middle ***, 3 last digits visible
 * (e.g. "5349564670" -> "53***670")
 */
export function maskGameUserId(userId: string): string {
  if (!userId) return '';
  const str = String(userId).trim();
  if (str.length <= 5) {
    if (str.length <= 2) return str;
    return `${str.slice(0, 2)}***${str.slice(-1)}`;
  }
  const front = str.slice(0, 2);
  const end = str.slice(-3);
  return `${front}***${end}`;
}

/**
 * Masks Server / Zone ID (e.g. "2105" -> "**05", "2112" -> "**12")
 * Shows last 2 digits preceded by **
 */
export function maskServerId(serverId?: string): string {
  if (!serverId) return '';
  const str = String(serverId).trim();
  if (str.length <= 2) return str;
  const last2 = str.slice(-2);
  return `**${last2}`;
}

/**
 * Masks Phone Number: front masked with asterisks, last 3 digits visible
 * (e.g. "0136845957" -> "*******957")
 */
export function maskPhoneNumber(phone?: string): string {
  if (!phone) return '';
  const digits = String(phone).trim().replace(/\D/g, '');
  if (digits.length <= 3) return digits;
  const last3 = digits.slice(-3);
  const frontAsterisks = '*'.repeat(Math.max(3, digits.length - 3));
  return `${frontAsterisks}${last3}`;
}

