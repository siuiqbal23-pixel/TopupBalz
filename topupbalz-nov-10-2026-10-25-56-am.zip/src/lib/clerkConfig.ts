// Clerk Configuration & Helper Utilities for TopupBalz
export const CLERK_PUBLISHABLE_KEY: string = 
  (import.meta as any).env?.VITE_CLERK_PUBLISHABLE_KEY || 
  'pk_test_cHJvbXB0LWJveGVyLTI2Ni5jbGVyay5hY2NvdW50cy5kZXYk';

// Main business admin credentials
export const ADMIN_USERNAME = 'Balzbalz';
export const ADMIN_EMAIL = 'siuiqbal23@gmail.com';
export const ADMIN_PASSWORD = 'balz12344321';
export const ADMIN_PIN_CODE = '030926';

export const isAuthorizedAdmin = (usernameOrEmail?: string | null, pinVerified?: boolean): boolean => {
  if (!usernameOrEmail) return false;
  const clean = usernameOrEmail.trim().replace(/^@+/, '').toLowerCase();
  const isAdminIdentity =
    clean === 'balzbalz' ||
    clean === 'siuiqbal23@gmail.com' ||
    clean === 'siuiqbal23' ||
    clean === 'balzltdsdn' ||
    clean === 'balzz';
  return isAdminIdentity && (pinVerified !== undefined ? pinVerified : true);
};
