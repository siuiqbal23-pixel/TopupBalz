/**
 * Safe JSON Fetch Helper
 * Handles HTML fallback responses (404/500) safely without throwing
 * "Unexpected token '<', "<!doctype "... is not valid JSON"
 */
export async function safeFetchJson<T = any>(
  url: string,
  options?: RequestInit,
  fallback?: T
): Promise<T> {
  try {
    const res = await fetch(url, options);
    if (!res.ok) {
      return fallback as T;
    }
    const contentType = res.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      return fallback as T;
    }
    const data = await res.json();
    return data;
  } catch (err) {
    return fallback as T;
  }
}
