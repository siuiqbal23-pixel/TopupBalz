/**
 * TopupBalz Robust WhatsApp Utility & Template Generator
 * Handles cross-browser URL encoding, phone number normalization, and game-specific order message templates.
 */

export interface OrderWhatsAppParams {
  orderId: string;
  gameName: string;
  itemName: string;
  price: number;
  userId: string;
  serverId?: string;
  customerPhone?: string;
  paymentMethod?: string;
  ownerPhone?: string;
  gameCategory?: string; // e.g. 'voucher', 'mobile_legend', 'direct_id'
  date?: string;
  proofImageUrl?: string;
  receiptUrl?: string;
}

export interface CartWhatsAppParams {
  items: Array<{
    gameName: string;
    itemName: string;
    quantity: number;
    sellPrice: number;
    userId: string;
    serverId?: string;
  }>;
  totalAmount: number;
  paymentMethod: string;
  customerPhone?: string;
  ownerPhone?: string;
  proofImageUrl?: string;
  receiptUrl?: string;
}

/**
 * Sanitizes and normalizes phone numbers into standard international format (default: Malaysia +60)
 */
export function sanitizePhone(phone?: string, fallbackPhone = '60145975056'): string {
  if (!phone) return fallbackPhone;
  let digits = phone.replace(/\D/g, '');
  if (!digits) return fallbackPhone;

  // Convert Malaysian local '01...' format to international '601...'
  if (digits.startsWith('0') && digits.length >= 10) {
    digits = '60' + digits.substring(1);
  }

  return digits;
}

/**
 * Builds clean, single-link WhatsApp template as requested:
 * "Hi saya dah order admin" followed directly by the digital detail/receipt link.
 */
export function buildOrderMessage(params: OrderWhatsAppParams): string {
  const { orderId, receiptUrl } = params;
  const targetUrl = receiptUrl || (typeof window !== 'undefined' ? `${window.location.origin}/receipt/${orderId}` : `/receipt/${orderId}`);

  return `Hi saya dah order admin\n\n${targetUrl}`;
}

/**
 * Builds clean WhatsApp message for Shopping Cart orders with link
 */
export function buildCartMessage(params: CartWhatsAppParams): string {
  const { receiptUrl } = params;
  const targetUrl = receiptUrl || (typeof window !== 'undefined' ? `${window.location.origin}` : '/');

  return `Hi saya dah order admin\n\n${targetUrl}`;
}

/**
 * Converts a Base64 Data URL to a browser File object for Web Share API
 */
export function dataUrlToFile(dataUrl: string, filename: string): File | null {
  try {
    const arr = dataUrl.split(',');
    const mimeMatch = arr[0].match(/:(.*?);/);
    const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  } catch (err) {
    console.error('Failed to convert dataUrl to File:', err);
    return null;
  }
}

/**
 * Safe WhatsApp opener that prevents navigation crashes inside iframes
 */
export function openWhatsAppSafely(url: string): boolean {
  if (!url) return false;
  try {
    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
    }, 100);
    return true;
  } catch (err) {
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
      return true;
    } catch {
      return false;
    }
  }
}

/**
 * Attempts to share order message or opens WhatsApp direct URL safely without breaking iframes.
 */
export async function shareOrderWithReceipt(options: {
  whatsappUrl: string;
  messageText?: string;
  proofImageUrl?: string;
  orderId?: string;
}): Promise<boolean> {
  const { whatsappUrl } = options;
  if (!whatsappUrl) return false;
  return openWhatsAppSafely(whatsappUrl);
}

/**
 * Robust WhatsApp URL Generator
 * Generates direct wa.me link, api.whatsapp.com fallback, and web.whatsapp.com link safely formatted for all browsers.
 */
export function generateWhatsAppUrl(
  message: string,
  targetPhone?: string,
  fallbackPhone = '60145975056'
): { waUrl: string; apiUrl: string; webUrl: string; encodedText: string } {
  const cleanPhone = sanitizePhone(targetPhone, fallbackPhone);
  const encodedText = encodeURIComponent(message);

  return {
    waUrl: `https://wa.me/${cleanPhone}?text=${encodedText}`,
    apiUrl: `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`,
    webUrl: `https://web.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`,
    encodedText,
  };
}

/**
 * Helper to open WhatsApp URL seamlessly without crashing iframes
 */
export function openWhatsAppDirectly(
  message: string,
  targetPhone?: string,
  fallbackPhone = '60145975056'
): void {
  const { waUrl } = generateWhatsAppUrl(message, targetPhone, fallbackPhone);
  openWhatsAppSafely(waUrl);
}
