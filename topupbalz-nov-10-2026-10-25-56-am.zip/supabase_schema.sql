-- ==========================================================
-- TOPUPBALZ SUPABASE DATABASE SCHEMA
-- Jalankan skrip ini di SQL Editor dalam Dashboard Supabase anda
-- ==========================================================

-- 1. Jadual Tetapan Sistem (System Settings)
CREATE TABLE IF NOT EXISTS system_settings (
  id TEXT PRIMARY KEY DEFAULT 'system',
  data JSONB NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Jadual Senarai Game & Produk
CREATE TABLE IF NOT EXISTS games (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT,
  category TEXT,
  image_url TEXT,
  banner_url TEXT,
  developer TEXT,
  description TEXT,
  input_type TEXT,
  placeholder TEXT,
  help_image TEXT,
  is_popular BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  items JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Jadual Pesanan Pelanggan (Orders)
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  game_id TEXT,
  game_name TEXT NOT NULL,
  item_id TEXT,
  item_name TEXT NOT NULL,
  base_price NUMERIC(10,2) DEFAULT 0,
  sell_price NUMERIC(10,2) NOT NULL DEFAULT 0,
  user_id TEXT NOT NULL,
  server_id TEXT,
  customer_phone TEXT,
  payment_method TEXT DEFAULT 'Touch ''n Go eWallet',
  proof_image_url TEXT,
  status TEXT DEFAULT 'pending',
  notes TEXT,
  whatsapp_url TEXT,
  account_user_id TEXT,
  account_username TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Jadual Pengguna (Users)
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE,
  name TEXT,
  avatar_url TEXT,
  google_id TEXT,
  phone_number TEXT,
  balance NUMERIC(10,2) DEFAULT 0,
  total_orders INTEGER DEFAULT 0,
  total_spent NUMERIC(10,2) DEFAULT 0,
  is_online BOOLEAN DEFAULT FALSE,
  is_email_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_login_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Jadual Banner Promosi (Banners)
CREATE TABLE IF NOT EXISTS promo_banners (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  subtitle TEXT,
  image_url TEXT NOT NULL,
  link_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. Jadual Ulasan Pelanggan (Reviews)
CREATE TABLE IF NOT EXISTS reviews (
  id TEXT PRIMARY KEY,
  user_name TEXT NOT NULL,
  game_name TEXT NOT NULL,
  item_name TEXT,
  rating INTEGER DEFAULT 5,
  comment TEXT,
  avatar_url TEXT,
  is_verified BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. Jadual Log Aktiviti (Activity Logs)
CREATE TABLE IF NOT EXISTS activity_logs (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  user_name TEXT,
  user_email TEXT,
  type TEXT NOT NULL,
  details TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. Jadual Mesej Live Chat (Chat Messages)
CREATE TABLE IF NOT EXISTS chat_messages (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  sender TEXT NOT NULL,
  sender_name TEXT NOT NULL,
  message TEXT NOT NULL,
  timestamp TEXT,
  read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Hidupkan Row Level Security (RLS) dengan polisi baca/tulis awam untuk anon key
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE games ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE promo_banners ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Cipta Polisi Akses Penuh untuk Anon API Key
DO $$ 
BEGIN
  -- Polisi system_settings
  DROP POLICY IF EXISTS "Anon public access system_settings" ON system_settings;
  CREATE POLICY "Anon public access system_settings" ON system_settings FOR ALL USING (true) WITH CHECK (true);

  -- Polisi games
  DROP POLICY IF EXISTS "Anon public access games" ON games;
  CREATE POLICY "Anon public access games" ON games FOR ALL USING (true) WITH CHECK (true);

  -- Polisi orders
  DROP POLICY IF EXISTS "Anon public access orders" ON orders;
  CREATE POLICY "Anon public access orders" ON orders FOR ALL USING (true) WITH CHECK (true);

  -- Polisi users
  DROP POLICY IF EXISTS "Anon public access users" ON users;
  CREATE POLICY "Anon public access users" ON users FOR ALL USING (true) WITH CHECK (true);

  -- Polisi promo_banners
  DROP POLICY IF EXISTS "Anon public access promo_banners" ON promo_banners;
  CREATE POLICY "Anon public access promo_banners" ON promo_banners FOR ALL USING (true) WITH CHECK (true);

  -- Polisi reviews
  DROP POLICY IF EXISTS "Anon public access reviews" ON reviews;
  CREATE POLICY "Anon public access reviews" ON reviews FOR ALL USING (true) WITH CHECK (true);

  -- Polisi activity_logs
  DROP POLICY IF EXISTS "Anon public access activity_logs" ON activity_logs;
  CREATE POLICY "Anon public access activity_logs" ON activity_logs FOR ALL USING (true) WITH CHECK (true);

  -- Polisi chat_messages
  DROP POLICY IF EXISTS "Anon public access chat_messages" ON chat_messages;
  CREATE POLICY "Anon public access chat_messages" ON chat_messages FOR ALL USING (true) WITH CHECK (true);
END $$;
