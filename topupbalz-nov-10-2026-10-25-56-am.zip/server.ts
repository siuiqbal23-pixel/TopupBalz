import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs from 'sql.js';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, getDoc, setDoc, getDocs, collection, deleteDoc } from 'firebase/firestore';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { createServer as createViteServer } from 'vite';
import { INITIAL_GAMES, INITIAL_BANNERS, INITIAL_SETTINGS, INITIAL_FLASH_SALE, calculateSellPrice } from './src/data/initialData';
import { INITIAL_REVIEWS, Review } from './src/data/reviewsData';
import { Game, Order, PromoBanner, SystemSettings, FlashSaleConfig, FlashSaleItem } from './src/types';
import { buildOrderMessage, generateWhatsAppUrl } from './src/lib/whatsapp';
import { maskOrderId, maskGameUserId, maskServerId, maskPhoneNumber } from './src/lib/masking';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON payload parser limit for image proof uploads
  app.use(express.json({ limit: '15mb' }));

  // --- FIREBASE FIRESTORE BACKEND INITIALIZATION ---
  const firebaseConfigPath = path.join(process.cwd(), 'firebase-applet-config.json');
  let firestoreDb: any = null;
  let firebaseConfig: any = null;

  if (fs.existsSync(firebaseConfigPath)) {
    try {
      firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf-8'));
      const firebaseApp = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
      const dbId = (!firebaseConfig.firestoreDatabaseId || firebaseConfig.firestoreDatabaseId === '(default)')
        ? undefined
        : firebaseConfig.firestoreDatabaseId;
      firestoreDb = dbId ? getFirestore(firebaseApp, dbId) : getFirestore(firebaseApp);
      console.log(`🔥 Firebase App & Firestore initialized (Database ID: ${firebaseConfig.firestoreDatabaseId || '(default)'})`);
    } catch (err) {
      console.error('Failed to initialize Firebase Firestore in server.ts:', err);
    }
  }

  // --- SUPABASE POSTGRESQL BACKEND INITIALIZATION ---
  const SUPABASE_URL = process.env.SUPABASE_URL || 'https://evvquwzrqkmmpoeytssr.supabase.co';
  const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV2dnF1d3pycWttbXBvZXl0c3NyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4NjY1MTcsImV4cCI6MjEwMjQ0MjUxN30.SQ_sb5B4Ciq6_ZebFLmUA7kflVesDH4_OvdwJQadlLs';
  let supabaseClient: SupabaseClient | null = null;

  if (SUPABASE_URL && SUPABASE_ANON_KEY) {
    try {
      supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
        auth: { persistSession: false },
      });
      console.log(`⚡ Supabase PostgreSQL initialized (Project URL: ${SUPABASE_URL})`);
    } catch (err) {
      console.error('Failed to initialize Supabase client in server.ts:', err);
    }
  }

  // Initialize SQLite Database (topupbalz.db) as local fallback
  let SQL: any = null;
  try {
    SQL = await initSqlJs();
  } catch (err) {
    console.warn('Notice: sql.js WebAssembly initialization deferred:', err);
  }
  const DB_FILE = path.join(process.cwd(), 'topupbalz.db');
  let sqliteDb: any = null;

  // In-memory data store with initial defaults
  let gamesData: Game[] = JSON.parse(JSON.stringify(INITIAL_GAMES));
  let bannersData: PromoBanner[] = JSON.parse(JSON.stringify(INITIAL_BANNERS));
  let settingsData: SystemSettings = { ...INITIAL_SETTINGS };
  let reviewsData: Review[] = JSON.parse(JSON.stringify(INITIAL_REVIEWS));
  let flashSaleData: FlashSaleConfig = JSON.parse(JSON.stringify(INITIAL_FLASH_SALE));

  let usersData: any[] = [
    {
      id: 'TB-ADMIN-BALZZ',
      email: 'siuiqbal23@gmail.com',
      name: '@Balzbalz',
      username: 'Balzbalz',
      password: 'balz12344321',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      googleId: 'google-10928374918237',
      phoneNumber: '0145975056',
      createdAt: new Date(Date.now() - 3600000 * 24 * 7).toISOString(),
      lastLoginAt: new Date().toISOString(),
      totalOrders: 13,
      totalSpent: 39.37,
      isOnline: true,
      isEmailVerified: true,
      role: 'admin',
    },
    {
      id: 'TB-USR-1002',
      email: 'amiramirul.gamer@gmail.com',
      name: 'Amirul Gaming',
      avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=Amirul',
      googleId: 'google-992103847291',
      phoneNumber: '0198765432',
      createdAt: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
      lastLoginAt: new Date(Date.now() - 3600000 * 3).toISOString(),
      totalOrders: 1,
      totalSpent: 6.50,
      isOnline: false,
      isEmailVerified: true,
    },
  ];

  let bannedUsersData: any[] = [];

  let activityLogsData: any[] = [
    {
      id: 'LOG-1',
      userId: 'TB-USR-1001',
      userName: 'Muhammad Nur Iqbal',
      userEmail: 'siuiqbal23@gmail.com',
      type: 'login',
      details: 'Log masuk melalui Google Auth',
      timestamp: new Date().toISOString(),
    },
    {
      id: 'LOG-2',
      userId: 'TB-USR-1002',
      userName: 'Amirul Gaming',
      userEmail: 'amiramirul.gamer@gmail.com',
      type: 'register',
      details: 'Pendaftaran akaun baru melalui Google Sign-In',
      timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    },
  ];

  let ordersData: Order[] = [
    {
      id: 'TB-982104',
      createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
      gameId: 'g1',
      gameName: 'Mobile Legends: Bang Bang',
      itemId: 'ml-86',
      itemName: '86 Diamonds',
      basePrice: 4.50,
      sellPrice: calculateSellPrice(4.50),
      userId: '88127364',
      serverId: '2105',
      customerPhone: '0123456789',
      paymentMethod: 'Touch \'n Go eWallet',
      status: 'completed',
      notes: 'Pembayaran disahkan. Diamond telah dikreditkan.',
    },
    {
      id: 'TB-982105',
      createdAt: new Date(Date.now() - 1800000).toISOString(),
      gameId: 'g2',
      gameName: 'Free Fire',
      itemId: 'ff-140',
      itemName: '140 Diamonds',
      basePrice: 5.50,
      sellPrice: calculateSellPrice(5.50),
      userId: '77218390',
      customerPhone: '0198765432',
      paymentMethod: 'Touch \'n Go eWallet',
      status: 'processing',
      notes: 'Bukti pembayaran sedang disemak oleh admin.',
    },
  ];

  // Helper to ensure item prices retain exact given prices
  function enforceSystemPricing(games: Game[]): Game[] {
    return games.map((game) => ({
      ...game,
      items: game.items.map((item) => ({
        ...item,
        sellPrice: item.sellPrice !== undefined ? item.sellPrice : item.basePrice,
      })),
    }));
  }

  gamesData = enforceSystemPricing(gamesData);

  // --- PERSISTENT DATABASE ENGINE (SQLite + JSON Disk Fallback) ---
  const JSON_BACKUP_FILE = path.join(process.cwd(), 'topupbalz_store.json');

  if (SQL) {
    if (fs.existsSync(DB_FILE)) {
      try {
        const fileBuffer = fs.readFileSync(DB_FILE);
        sqliteDb = new SQL.Database(fileBuffer);
        
        const stmt = sqliteDb.prepare("SELECT value FROM app_store WHERE key = 'topupbalz_data'");
        if (stmt.step()) {
          const row = stmt.getAsObject();
          if (row.value) {
            const parsed = JSON.parse(row.value as string);
            if (Array.isArray(parsed.games) && parsed.games.length > 0) gamesData = enforceSystemPricing(parsed.games);
            if (Array.isArray(parsed.banners)) bannersData = parsed.banners;
            if (parsed.settings && typeof parsed.settings === 'object') settingsData = { ...INITIAL_SETTINGS, ...parsed.settings };
            if (Array.isArray(parsed.reviews)) reviewsData = parsed.reviews;
            if (parsed.flashSale && typeof parsed.flashSale === 'object') flashSaleData = parsed.flashSale;
            if (Array.isArray(parsed.users)) usersData = parsed.users;
            if (Array.isArray(parsed.bannedUsers)) bannedUsersData = parsed.bannedUsers;
            if (Array.isArray(parsed.activityLogs)) activityLogsData = parsed.activityLogs;
            if (Array.isArray(parsed.orders)) ordersData = parsed.orders;
            console.log('✅ SQLite Database (topupbalz.db) Loaded Successfully!');
          }
        }
        stmt.free();
      } catch (err) {
        console.error('Error reading topupbalz.db:', err);
        sqliteDb = new SQL.Database();
      }
    } else {
      sqliteDb = new SQL.Database();
    }

    // Ensure table exists
    try {
      sqliteDb.run(`
        CREATE TABLE IF NOT EXISTS app_store (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );
      `);
    } catch (e) {
      console.warn('Notice: SQLite table creation:', e);
    }
  } else if (fs.existsSync(JSON_BACKUP_FILE)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(JSON_BACKUP_FILE, 'utf-8'));
      if (Array.isArray(parsed.games) && parsed.games.length > 0) gamesData = enforceSystemPricing(parsed.games);
      if (Array.isArray(parsed.banners)) bannersData = parsed.banners;
      if (parsed.settings && typeof parsed.settings === 'object') settingsData = { ...INITIAL_SETTINGS, ...parsed.settings };
      if (Array.isArray(parsed.reviews)) reviewsData = parsed.reviews;
      if (parsed.flashSale && typeof parsed.flashSale === 'object') flashSaleData = parsed.flashSale;
      if (Array.isArray(parsed.users)) usersData = parsed.users;
      if (Array.isArray(parsed.bannedUsers)) bannedUsersData = parsed.bannedUsers;
      if (Array.isArray(parsed.activityLogs)) activityLogsData = parsed.activityLogs;
      if (Array.isArray(parsed.orders)) ordersData = parsed.orders;
      console.log('✅ Local JSON Data Store (topupbalz_store.json) Loaded Successfully!');
    } catch (err) {
      console.error('Error reading JSON backup file:', err);
    }
  }

  function saveDatabaseToDisk() {
    try {
      const payload = {
        games: gamesData,
        banners: bannersData,
        settings: settingsData,
        reviews: reviewsData,
        flashSale: flashSaleData,
        users: usersData,
        bannedUsers: bannedUsersData,
        activityLogs: activityLogsData,
        orders: ordersData,
        lastUpdated: new Date().toISOString(),
      };
      
      const jsonString = JSON.stringify(payload, null, 2);
      fs.writeFileSync(JSON_BACKUP_FILE, jsonString);

      if (sqliteDb) {
        sqliteDb.run("INSERT OR REPLACE INTO app_store (key, value) VALUES ('topupbalz_data', ?)", [
          jsonString,
        ]);
        const exportedData = sqliteDb.export();
        const buffer = Buffer.from(exportedData);
        fs.writeFileSync(DB_FILE, buffer);
      }
    } catch (err) {
      console.error('Error saving database to disk:', err);
    }
  }

  // Ensure initial state is saved into topupbalz.db
  saveDatabaseToDisk();

  // --- FIREBASE FIRESTORE DATA PERSISTENCE HELPERS ---
  function sanitizeDocForFirestore<T>(data: T): any {
    if (!data || typeof data !== 'object') return data;
    // JSON.stringify strips undefined properties automatically
    const copy = JSON.parse(JSON.stringify(data));
    const jsonStr = JSON.stringify(copy);

    // If payload >= 850KB, sanitize oversized base64 images to avoid exceeding Firestore 1MB document limit
    if (jsonStr.length >= 850000) {
      for (const key of Object.keys(copy)) {
        if (typeof copy[key] === 'string' && copy[key].startsWith('data:image/')) {
          if (copy[key].length > 400000) {
            console.warn(`[Firestore SafeGuard] Replaced oversized base64 image in field '${key}' (length: ${copy[key].length})`);
            copy[key] = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80';
          }
        }
      }
    }
    return copy;
  }

  async function saveGameToFirestore(game: Game) {
    if (!firestoreDb) return;
    try {
      await setDoc(doc(firestoreDb, 'games', game.id), sanitizeDocForFirestore(game));
    } catch (err) {
      console.error(`Error saving game ${game.id} to Firestore:`, err);
    }
  }

  async function deleteGameFromFirestore(gameId: string) {
    if (!firestoreDb) return;
    try {
      await deleteDoc(doc(firestoreDb, 'games', gameId));
    } catch (err) {
      console.error(`Error deleting game ${gameId} from Firestore:`, err);
    }
  }

  async function saveOrderToFirestore(order: any) {
    if (!firestoreDb) return;
    try {
      await setDoc(doc(firestoreDb, 'orders', order.id), sanitizeDocForFirestore(order));
    } catch (err) {
      console.error(`Error saving order ${order.id} to Firestore:`, err);
    }
  }

  async function saveUserToFirestore(user: any) {
    if (!firestoreDb) return;
    try {
      await setDoc(doc(firestoreDb, 'users', user.id), sanitizeDocForFirestore(user));
    } catch (err) {
      console.error(`Error saving user ${user.id} to Firestore:`, err);
    }
  }

  async function deleteUserFromFirestore(userId: string) {
    if (!firestoreDb) return;
    try {
      await deleteDoc(doc(firestoreDb, 'users', userId));
    } catch (err) {
      console.error(`Error deleting user ${userId} from Firestore:`, err);
    }
  }

  async function saveBannedUserToFirestore(bannedUser: any) {
    if (!firestoreDb) return;
    try {
      await setDoc(doc(firestoreDb, 'banned_users', bannedUser.id || `ban-${Date.now()}`), sanitizeDocForFirestore(bannedUser));
    } catch (err) {
      console.error(`Error saving banned user ${bannedUser.id} to Firestore:`, err);
    }
  }

  async function saveSettingsToFirestore(settings: SystemSettings) {
    if (!firestoreDb) return;
    try {
      await setDoc(doc(firestoreDb, 'settings', 'system'), sanitizeDocForFirestore(settings));
    } catch (err) {
      console.error('Error saving settings to Firestore:', err);
    }
  }

  async function saveFlashSaleToFirestore(flashSale: FlashSaleConfig) {
    if (!firestoreDb) return;
    try {
      await setDoc(doc(firestoreDb, 'settings', 'flash_sale'), sanitizeDocForFirestore(flashSale));
    } catch (err) {
      console.error('Error saving flash sale to Firestore:', err);
    }
  }

  async function saveBannerToFirestore(banner: PromoBanner) {
    if (!firestoreDb) return;
    try {
      await setDoc(doc(firestoreDb, 'banners', banner.id), sanitizeDocForFirestore(banner));
    } catch (err) {
      console.error(`Error saving banner ${banner.id} to Firestore:`, err);
    }
  }

  async function deleteBannerFromFirestore(bannerId: string) {
    if (!firestoreDb) return;
    try {
      await deleteDoc(doc(firestoreDb, 'banners', bannerId));
    } catch (err) {
      console.error(`Error deleting banner ${bannerId} from Firestore:`, err);
    }
  }

  async function saveReviewToFirestore(review: Review) {
    if (!firestoreDb) return;
    try {
      await setDoc(doc(firestoreDb, 'reviews', review.id), sanitizeDocForFirestore(review));
    } catch (err) {
      console.error(`Error saving review ${review.id} to Firestore:`, err);
    }
  }

  async function saveActivityLogToFirestore(log: any) {
    if (!firestoreDb) return;
    try {
      await setDoc(doc(firestoreDb, 'activity_logs', log.id), sanitizeDocForFirestore(log));
    } catch (err) {
      console.error(`Error saving activity log ${log.id} to Firestore:`, err);
    }
  }

  // --- SUPABASE DATA PERSISTENCE HELPERS ---
  async function saveGameToSupabase(game: Game) {
    if (!supabaseClient) return;
    try {
      await supabaseClient.from('games').upsert({
        id: game.id,
        name: game.name,
        slug: game.slug || null,
        category: game.category || null,
        image_url: game.logoUrl || null,
        banner_url: game.bannerUrl || null,
        developer: null,
        description: game.idGuideText || null,
        input_type: game.serverType || null,
        placeholder: null,
        help_image: null,
        is_popular: Boolean(game.isPopular),
        is_active: true,
        items: game.items || [],
        updated_at: new Date().toISOString(),
      });
    } catch (err) {
      console.warn(`[Supabase Notice] Could not save game ${game.id} to Supabase:`, err);
    }
  }

  async function deleteGameFromSupabase(gameId: string) {
    if (!supabaseClient) return;
    try {
      await supabaseClient.from('games').delete().eq('id', gameId);
    } catch (err) {
      console.warn(`[Supabase Notice] Could not delete game ${gameId} from Supabase:`, err);
    }
  }

  async function saveOrderToSupabase(order: any) {
    if (!supabaseClient) return;
    try {
      await supabaseClient.from('orders').upsert({
        id: order.id,
        game_id: order.gameId || null,
        game_name: order.gameName,
        item_id: order.itemId || null,
        item_name: order.itemName,
        base_price: order.basePrice || 0,
        sell_price: order.sellPrice || 0,
        user_id: String(order.userId),
        server_id: order.serverId ? String(order.serverId) : null,
        customer_phone: order.customerPhone ? String(order.customerPhone) : null,
        payment_method: order.paymentMethod || "Touch 'n Go eWallet",
        proof_image_url: order.proofImageUrl || null,
        status: order.status || 'pending',
        notes: order.notes || null,
        whatsapp_url: order.whatsappUrl || null,
        account_user_id: order.accountUserId || null,
        account_username: order.accountUsername || null,
        updated_at: new Date().toISOString(),
      });
    } catch (err) {
      console.warn(`[Supabase Notice] Could not save order ${order.id} to Supabase:`, err);
    }
  }

  async function saveUserToSupabase(user: any) {
    if (!supabaseClient) return;
    try {
      await supabaseClient.from('users').upsert({
        id: user.id,
        email: user.email || null,
        name: user.name,
        avatar_url: user.avatarUrl || null,
        google_id: user.googleId || null,
        phone_number: user.phoneNumber || null,
        balance: user.balance || 0,
        total_orders: user.totalOrders || 0,
        total_spent: user.totalSpent || 0,
        is_online: Boolean(user.isOnline),
        is_email_verified: Boolean(user.isEmailVerified),
        last_login_at: user.lastLoginAt || new Date().toISOString(),
      });
    } catch (err) {
      console.warn(`[Supabase Notice] Could not save user ${user.id} to Supabase:`, err);
    }
  }

  async function saveSettingsToSupabase(settings: SystemSettings) {
    if (!supabaseClient) return;
    try {
      await supabaseClient.from('system_settings').upsert({
        id: 'system',
        data: settings,
        updated_at: new Date().toISOString(),
      });
    } catch (err) {
      console.warn(`[Supabase Notice] Could not save settings to Supabase:`, err);
    }
  }

  async function saveBannerToSupabase(banner: PromoBanner) {
    if (!supabaseClient) return;
    try {
      await supabaseClient.from('promo_banners').upsert({
        id: banner.id,
        title: banner.title,
        subtitle: banner.subtitle || null,
        image_url: banner.imageUrl,
        link_url: banner.gameSlug || null,
        is_active: banner.isActive !== false,
      });
    } catch (err) {
      console.warn(`[Supabase Notice] Could not save banner ${banner.id} to Supabase:`, err);
    }
  }

  async function deleteBannerFromSupabase(bannerId: string) {
    if (!supabaseClient) return;
    try {
      await supabaseClient.from('promo_banners').delete().eq('id', bannerId);
    } catch (err) {
      console.warn(`[Supabase Notice] Could not delete banner ${bannerId} from Supabase:`, err);
    }
  }

  async function saveReviewToSupabase(review: Review) {
    if (!supabaseClient) return;
    try {
      await supabaseClient.from('reviews').upsert({
        id: review.id,
        user_name: review.customerName,
        game_name: review.gameName,
        item_name: review.itemName || null,
        rating: review.rating || 5,
        comment: review.comment || '',
        avatar_url: review.avatarUrl || null,
        is_verified: review.verified !== false,
      });
    } catch (err) {
      console.warn(`[Supabase Notice] Could not save review ${review.id} to Supabase:`, err);
    }
  }

  async function saveActivityLogToSupabase(log: any) {
    if (!supabaseClient) return;
    try {
      await supabaseClient.from('activity_logs').upsert({
        id: log.id,
        user_id: log.userId || null,
        user_name: log.userName || null,
        user_email: log.userEmail || null,
        type: log.type,
        details: log.details || null,
      });
    } catch (err) {
      console.warn(`[Supabase Notice] Could not save activity log ${log.id} to Supabase:`, err);
    }
  }

  async function syncAllDataToSupabase() {
    if (!supabaseClient) return { success: false, error: 'Supabase client belum dimulakan' };
    try {
      console.log('⚡ Exporting all data collections to Supabase...');
      await saveSettingsToSupabase(settingsData);
      for (const g of gamesData) await saveGameToSupabase(g);
      for (const o of ordersData) await saveOrderToSupabase(o);
      for (const u of usersData) await saveUserToSupabase(u);
      for (const b of bannersData) await saveBannerToSupabase(b);
      for (const r of reviewsData) await saveReviewToSupabase(r);
      for (const l of activityLogsData) await saveActivityLogToSupabase(l);

      return {
        success: true,
        message: 'Semua data berjaya dieksport & disegerakkan ke Supabase!',
        synced: {
          games: gamesData.length,
          orders: ordersData.length,
          users: usersData.length,
          banners: bannersData.length,
          reviews: reviewsData.length,
        },
      };
    } catch (err: any) {
      console.error('Error during full sync to Supabase:', err);
      return { success: false, error: err.message };
    }
  }

  // Initial load and sync with Firebase Firestore
  async function loadDataFromFirestore() {
    if (!firestoreDb) return;
    try {
      console.log('🔥 Syncing database state with Firebase Firestore...');

      // 1. Settings
      const settingsSnap = await getDoc(doc(firestoreDb, 'settings', 'system'));
      if (settingsSnap.exists()) {
        settingsData = { ...INITIAL_SETTINGS, ...(settingsSnap.data() as SystemSettings) };
      } else {
        await saveSettingsToFirestore(settingsData);
      }

      // 2. Games
      const gamesSnap = await getDocs(collection(firestoreDb, 'games'));
      if (!gamesSnap.empty) {
        const loadedGames: Game[] = [];
        gamesSnap.forEach((d) => loadedGames.push(d.data() as Game));
        gamesData = enforceSystemPricing(loadedGames);
      } else {
        for (const g of gamesData) {
          await saveGameToFirestore(g);
        }
      }

      // 3. Banners
      const bannersSnap = await getDocs(collection(firestoreDb, 'banners'));
      if (!bannersSnap.empty) {
        const loadedBanners: PromoBanner[] = [];
        bannersSnap.forEach((d) => loadedBanners.push(d.data() as PromoBanner));
        bannersData = loadedBanners;
      } else {
        for (const b of bannersData) {
          await saveBannerToFirestore(b);
        }
      }

      // 4. Orders
      const ordersSnap = await getDocs(collection(firestoreDb, 'orders'));
      if (!ordersSnap.empty) {
        const loadedOrders: Order[] = [];
        ordersSnap.forEach((d) => loadedOrders.push(d.data() as Order));
        ordersData = loadedOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      } else {
        for (const o of ordersData) {
          await saveOrderToFirestore(o);
        }
      }

      // 5. Users
      const usersSnap = await getDocs(collection(firestoreDb, 'users'));
      if (!usersSnap.empty) {
        const loadedUsers: any[] = [];
        usersSnap.forEach((d) => loadedUsers.push(d.data()));
        usersData = loadedUsers;
      } else {
        for (const u of usersData) {
          await saveUserToFirestore(u);
        }
      }

      // 6. Reviews
      const reviewsSnap = await getDocs(collection(firestoreDb, 'reviews'));
      if (!reviewsSnap.empty) {
        const loadedReviews: Review[] = [];
        reviewsSnap.forEach((d) => loadedReviews.push(d.data() as Review));
        reviewsData = loadedReviews;
      } else {
        for (const r of reviewsData) {
          await saveReviewToFirestore(r);
        }
      }

      // 7. Activity Logs
      const logsSnap = await getDocs(collection(firestoreDb, 'activity_logs'));
      if (!logsSnap.empty) {
        const loadedLogs: any[] = [];
        logsSnap.forEach((d) => loadedLogs.push(d.data()));
        activityLogsData = loadedLogs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      } else {
        for (const l of activityLogsData) {
          await saveActivityLogToFirestore(l);
        }
      }

      // 8. Banned Users
      const bannedSnap = await getDocs(collection(firestoreDb, 'banned_users'));
      if (!bannedSnap.empty) {
        const loadedBanned: any[] = [];
        bannedSnap.forEach((d) => loadedBanned.push(d.data()));
        bannedUsersData = loadedBanned;
      }

      // 9. Flash Sale Configuration
      const fsSnap = await getDoc(doc(firestoreDb, 'settings', 'flash_sale'));
      if (fsSnap.exists()) {
        const fsData = fsSnap.data() as FlashSaleConfig;
        if (fsData && typeof fsData === 'object' && Array.isArray(fsData.items)) {
          flashSaleData = {
            ...INITIAL_FLASH_SALE,
            ...fsData,
            isEnabled: fsData.isEnabled ?? true,
          };
          console.log(`⚡ Loaded Flash Sale from Firestore (${flashSaleData.items.length} items, isEnabled: ${flashSaleData.isEnabled})`);
        }
      } else {
        await saveFlashSaleToFirestore(flashSaleData);
      }

      saveDatabaseToDisk();
      console.log('✅ Firebase Firestore Collections Loaded & Synced Successfully!');
    } catch (err) {
      console.error('Error loading data from Firebase Firestore:', err);
    }
  }

  // Trigger startup sync
  loadDataFromFirestore();

  // --- API ROUTES ---

  // Active online sessions tracker
  const activePresenceMap = new Map<string, { lastPing: number; userEmail?: string; userName?: string }>();

  const cleanupStaleSessions = () => {
    const now = Date.now();
    for (const [sessionId, data] of activePresenceMap.entries()) {
      if (now - data.lastPing > 25000) {
        activePresenceMap.delete(sessionId);
      }
    }
  };

  // POST /api/presence/ping - Heartbeat ping from client
  app.post('/api/presence/ping', (req: Request, res: Response) => {
    try {
      const { sessionId, userEmail, userName, userId } = req.body;
      if (!sessionId) {
        return res.status(400).json({ error: 'sessionId diperlukan' });
      }

      // Check if user is in banned list
      const isBanned = bannedUsersData.some(
        (b) =>
          (userId && b.id === userId) ||
          (userEmail && b.email && b.email.toLowerCase() === userEmail.toLowerCase()) ||
          (userName && b.username && b.username.toLowerCase().replace(/^@+/, '') === userName.toLowerCase().replace(/^@+/, ''))
      );

      activePresenceMap.set(sessionId, {
        lastPing: Date.now(),
        userEmail: userEmail || undefined,
        userName: userName || undefined,
      });

      cleanupStaleSessions();

      res.json({
        success: true,
        isBanned: Boolean(isBanned),
        onlineCount: activePresenceMap.size,
        activeSessions: Array.from(activePresenceMap.values()),
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/presence - Fetch current online stats
  app.get('/api/presence', (req: Request, res: Response) => {
    cleanupStaleSessions();
    res.json({
      onlineCount: activePresenceMap.size,
      activeSessions: Array.from(activePresenceMap.values()),
    });
  });

  // --- LIVE CHAT REAL-TIME BACKEND ---
  interface ChatMsg {
    id: string;
    sessionId: string;
    sender: 'user' | 'admin';
    senderName: string;
    message: string;
    timestamp: string;
    read: boolean;
  }

  // --- REAL-TIME MALAYSIA (ASIA/KUALA_LUMPUR / UTC+8) DATE & TIME HELPERS ---
  const getMalaysiaDateTime = (dateInput: Date | string | number = new Date()) => {
    const d = typeof dateInput === 'string' || typeof dateInput === 'number' ? new Date(dateInput) : dateInput;
    const dateStr = d.toLocaleDateString('en-GB', {
      timeZone: 'Asia/Kuala_Lumpur',
      day: 'numeric',
      month: 'numeric',
      year: 'numeric',
    }); // e.g. 19/8/2026
    const timeStr = d.toLocaleTimeString('en-US', {
      timeZone: 'Asia/Kuala_Lumpur',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    }); // e.g. 07:04:51 PM
    return {
      date: dateStr,
      time: timeStr,
      full: `${dateStr} | ${timeStr}`,
    };
  };

  const getMalaysiaTimeString = (date = new Date()) => {
    return date.toLocaleTimeString('en-US', {
      timeZone: 'Asia/Kuala_Lumpur',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  };

  const chatSessionsMap = new Map<string, ChatMsg[]>();
  const chatSessionUserNamesMap = new Map<string, string>();

  // Groq API Configuration for Ai Topupbalz
  const GROQ_API_KEY = process.env.GROQ_API_KEY || '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';

  async function generateTopupbalzAiResponse(userMessage: string, history: Array<ChatMsg> = []): Promise<string> {
    const systemPrompt = `Anda adalah "Ai Topupbalz", pembantu pintar rasmi berasaskan AI untuk platform web TopupBalz (sebuah platform kedai top-up game pantas, murah, selamat & dipercayai di Malaysia).
Pelanggan kedai ini akan bertanya kepada anda jika mereka tidak tahu tentang cara penggunaan web, servis, dan pembelian.

Maklumat Rasmi Web TopupBalz:
1. Pemilik & Pentadbir Utama: Balz / BalzLtdSdn (Emel: siuiqbal23@gmail.com, WhatsApp Rasmi: 0145975056).
2. Servis: Menjual diamond/kredit/pass game popular: Mobile Legends (MLBB), Free Fire, PUBG Mobile, Honor of Kings (HOK), EA Sports FC Mobile, Roblox, Genshin Impact, Call of Duty Mobile (CODM), Valorant, dll.
3. Kaedah Pembayaran: Touch 'n Go (TnG) eWallet (DuitNow QR / No Tel: 0145975056 Balz), perbankan dalam talian / pemindahan QR pantas.
4. Panduan Cara Topup (Langkah demi Langkah):
   - Langkah 1: Di menu bawah "1. Home", tekan pada game yang ingin ditop-up.
   - Langkah 2: Masukkan User ID dan Zone ID / Server ID akaun game anda.
   - Langkah 3: Pilih pakej diamond/item yang anda mahukan.
   - Langkah 4: Pilih kaedah pembayaran (cth: Touch 'n Go eWallet).
   - Langkah 5: Tekan "Beli Sekarang", buat bayaran mengikut harga tepat, muat naik resit atau hantar terus ke WhatsApp admin 0145975056 untuk pengesahan segera (proses biasanya 1-5 minit siap!).
5. Fungsi Navigasi Bar Bawah (Tombol Bawah):
   - "1. Home": Senarai semua game, promosi jualan kilat (Flash Sale), dan banner promosi.
   - "2. Semak": Semak status transaksi pesanan menggunakan No Pesanan (Order ID) atau Nombor Telefon.
   - Butang Tengah (Titik 9): Buka menu pintas kategori game & kalkulator.
   - "3. Ranking": Papan ranking pembeli terbanyak (Leaderboard Topup) dengan hadiah istimewa.
   - "4. Profile": Log masuk menggunakan Google (1-click), emel atau username, semak sejarah pembelian sendiri, dan sahkan emel akaun.
6. Masalah / Bantuan Lanjut: Jika ada transaksi tersangkut atau tersalah isi ID game, nasihatkan pelanggan hubungi terus WhatsApp admin di 0145975056.

Peraturan Menjawab:
- Jawab dalam Bahasa Melayu yang sopan, ramah, santai dan bersemangat seperti gamer Malaysia.
- Terus berikan jawapan praktikal kepada soalan pelanggan dengan padat dan jelas.
- JANGAN sertakan tag <think> atau pemikiran dalaman dalam jawapan.`;

    try {
      const recentHistory = history
        .filter((h) => h.message && h.message !== userMessage)
        .slice(-6)
        .map((h) => ({
          role: h.sender === 'user' ? ('user' as const) : ('assistant' as const),
          content: h.message,
        }));

      const messages = [
        { role: 'system' as const, content: systemPrompt },
        ...recentHistory,
        { role: 'user' as const, content: userMessage },
      ];

      // Try primary Groq model: openai/gpt-oss-120b
      let response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${GROQ_API_KEY}`,
        },
        body: JSON.stringify({
          model: 'openai/gpt-oss-120b',
          messages,
          max_tokens: 400,
          temperature: 0.6,
        }),
      });

      if (!response.ok) {
        // Fallback to openai/gpt-oss-20b
        response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${GROQ_API_KEY}`,
          },
          body: JSON.stringify({
            model: 'openai/gpt-oss-20b',
            messages,
            max_tokens: 400,
            temperature: 0.6,
          }),
        });
      }

      if (response.ok) {
        const data = await response.json();
        const content = data.choices?.[0]?.message?.content;
        if (content && typeof content === 'string') {
          return content.trim();
        }
      }
    } catch (err: any) {
      console.warn('Groq AI Topupbalz error:', err.message);
    }

    return 'Hai! Saya Ai Topupbalz 🤖⚡ Ada apa-apa yang saya boleh bantu mengenai cara top-up game, cara bayar TnG eWallet atau semakan pesanan anda? Sila beritahu soalan anda!';
  }

  // Helper to ensure welcome message
  const getSessionMessages = (sessionId: string) => {
    if (!chatSessionsMap.has(sessionId)) {
      const welcomeMsg: ChatMsg = {
        id: 'msg_welcome_' + Date.now(),
        sessionId,
        sender: 'admin',
        senderName: 'Ai Topupbalz 🤖⚡',
        message: 'Halo! Saya Ai Topupbalz, pembantu pintar rasmi TopupBalz 🤖⚡ Sedia membantu anda 24 jam! Anda boleh tanya saya apa sahaja tentang cara top-up game, harga pakej, semak status pesanan, cara bayar TnG eWallet atau cara guna laman web ini.',
        timestamp: getMalaysiaTimeString(),
        read: true,
      };
      chatSessionsMap.set(sessionId, [welcomeMsg]);
    }
    return chatSessionsMap.get(sessionId)!;
  };

  // GET /api/chat/messages
  app.get('/api/chat/messages', (req: Request, res: Response) => {
    try {
      const { sessionId, admin, userName } = req.query;

      if (admin === 'true') {
        // Admin mode: return all sessions summary
        const sessionsList: Array<{
          sessionId: string;
          senderName: string;
          lastMessage: string;
          lastTime: string;
          unreadCount: number;
          messages: ChatMsg[];
        }> = [];

        for (const [sId, msgs] of chatSessionsMap.entries()) {
          const lastMsg = msgs[msgs.length - 1];
          const unreadCount = msgs.filter((m) => m.sender === 'user' && !m.read).length;
          
          // Get best userSender name
          const storedUserName = chatSessionUserNamesMap.get(sId);
          const lastUserMsgName = msgs
            .slice()
            .reverse()
            .find((m) => m.sender === 'user' && m.senderName && m.senderName !== 'Pelanggan')?.senderName;
          const firstUserMsgName = msgs.find((m) => m.sender === 'user')?.senderName;

          const userSender =
            storedUserName && storedUserName !== 'Pelanggan'
              ? storedUserName
              : lastUserMsgName ||
                (firstUserMsgName && firstUserMsgName !== 'Pelanggan' ? firstUserMsgName : null) ||
                'Pelanggan (' + sId.substring(0, 6) + ')';

          sessionsList.push({
            sessionId: sId,
            senderName: userSender,
            lastMessage: lastMsg ? lastMsg.message : '',
            lastTime: lastMsg ? lastMsg.timestamp : '',
            unreadCount,
            messages: msgs,
          });
        }

        return res.json({ sessions: sessionsList });
      }

      if (!sessionId || typeof sessionId !== 'string') {
        return res.status(400).json({ error: 'sessionId diperlukan' });
      }

      if (userName && typeof userName === 'string' && userName.trim() && userName !== 'Pelanggan') {
        chatSessionUserNamesMap.set(sessionId, userName.trim());
        const existingMsgs = chatSessionsMap.get(sessionId);
        if (existingMsgs) {
          existingMsgs.forEach((m) => {
            if (m.sender === 'user') m.senderName = userName.trim();
          });
        }
      }

      const msgs = getSessionMessages(sessionId);
      res.json({ messages: msgs });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/chat/send
  app.post('/api/chat/send', async (req: Request, res: Response) => {
    try {
      const { sessionId, sender, senderName, message } = req.body;
      if (!sessionId || !sender || !message) {
        return res.status(400).json({ error: 'Permintaan tidak lengkap' });
      }

      if (sender === 'user' && senderName && senderName.trim() && senderName !== 'Pelanggan') {
        chatSessionUserNamesMap.set(sessionId, senderName.trim());
      }

      const effectiveSenderName =
        sender === 'user'
          ? (senderName && senderName !== 'Pelanggan'
              ? senderName
              : chatSessionUserNamesMap.get(sessionId) || 'Pelanggan')
          : senderName || 'Ai Topupbalz 🤖';

      const msgs = getSessionMessages(sessionId);

      // If user senderName is refined, update existing user messages too
      if (sender === 'user' && effectiveSenderName !== 'Pelanggan') {
        msgs.forEach((m) => {
          if (m.sender === 'user') m.senderName = effectiveSenderName;
        });
      }

      const newMsg: ChatMsg = {
        id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        sessionId,
        sender,
        senderName: effectiveSenderName,
        message,
        timestamp: getMalaysiaTimeString(),
        read: sender === 'admin',
      };

      msgs.push(newMsg);
      chatSessionsMap.set(sessionId, msgs);

      // 🤖 TRIGGER AI TOPUPBALZ RESPONSE IF SENDER IS CUSTOMER
      if (sender === 'user') {
        try {
          const aiReply = await generateTopupbalzAiResponse(message, msgs);
          const aiMsg: ChatMsg = {
            id: 'msg_ai_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
            sessionId,
            sender: 'admin',
            senderName: 'Ai Topupbalz 🤖⚡',
            message: aiReply,
            timestamp: getMalaysiaTimeString(),
            read: true,
          };
          msgs.push(aiMsg);
          chatSessionsMap.set(sessionId, msgs);
          return res.json({ success: true, message: newMsg, aiMessage: aiMsg, messages: msgs });
        } catch (aiErr) {
          console.error('Error generating AI chat reply:', aiErr);
        }
      }

      res.json({ success: true, message: newMsg, messages: msgs });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/chat/read
  app.post('/api/chat/read', (req: Request, res: Response) => {
    try {
      const { sessionId } = req.body;
      if (sessionId && chatSessionsMap.has(sessionId)) {
        const msgs = chatSessionsMap.get(sessionId)!;
        msgs.forEach((m) => {
          if (m.sender === 'user') m.read = true;
        });
      }
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });


  // Health check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({ status: 'ok', app: 'TopupBalz', version: '1.0.0' });
  });

  // GET Games
  app.get('/api/games', (req: Request, res: Response) => {
    res.json({ games: gamesData });
  });

  // POST Create / Update Game (Admin)
  app.post('/api/games', (req: Request, res: Response) => {
    try {
      const updatedGame: Game = req.body;
      if (!updatedGame.name || !updatedGame.items) {
        return res.status(400).json({ error: 'Nama game dan item diperlukan' });
      }

      // Calculate sellPrice if not custom, or ensure numeric values
      updatedGame.items = updatedGame.items.map((item) => {
        const base = Number(item.basePrice) || 0;
        const customSell = Number(item.sellPrice);
        const sell = customSell && !isNaN(customSell) && customSell > 0 ? customSell : calculateSellPrice(base);
        return {
          ...item,
          basePrice: base,
          sellPrice: sell,
        };
      });

      const existingIndex = gamesData.findIndex((g) => g.id === updatedGame.id);
      if (existingIndex >= 0) {
        gamesData[existingIndex] = updatedGame;
      } else {
        if (!updatedGame.id) {
          updatedGame.id = 'g_' + Date.now();
        }
        gamesData.unshift(updatedGame);
      }

      saveDatabaseToDisk();
      saveGameToFirestore(updatedGame);
      saveGameToSupabase(updatedGame);
      return res.json({ success: true, game: updatedGame, games: gamesData });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // DELETE Game (Admin)
  app.delete('/api/games/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    gamesData = gamesData.filter((g) => g.id !== id);
    saveDatabaseToDisk();
    deleteGameFromFirestore(id);
    deleteGameFromSupabase(id);
    res.json({ success: true, games: gamesData });
  });

  // GET Orders
  app.get('/api/orders', (req: Request, res: Response) => {
    res.json({ orders: ordersData });
  });

  // GET Single Order status check
  app.get('/api/orders/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const raw = (id || '').trim();
    const cleanQuery = raw.replace(/^#/, '').trim().toLowerCase();
    const digitsOnly = raw.replace(/\D/g, '');

    // Strict exact matching prioritizing Order ID to protect customer privacy
    // 1. Exact Order ID match (e.g. 'BZ-840080', 'TB-840080', or 'BZ840080')
    let found = ordersData.filter((o) => {
      const oId = o.id.toLowerCase();
      const oIdClean = oId.replace(/^#/, '');
      return (
        oId === cleanQuery ||
        oIdClean === cleanQuery ||
        oIdClean.replace('-', '') === cleanQuery.replace('-', '') ||
        `#${oIdClean}` === raw.toLowerCase()
      );
    });

    // 2. If user searched by the 6-digit number directly (e.g. '840080')
    if (found.length === 0 && digitsOnly.length >= 5) {
      found = ordersData.filter((o) => o.id.replace(/\D/g, '') === digitsOnly);
    }

    // 3. User ID exact match ONLY if not searching with an order prefix (e.g. pure game ID)
    if (
      found.length === 0 &&
      digitsOnly.length >= 3 &&
      !cleanQuery.startsWith('bz') &&
      !cleanQuery.startsWith('tb')
    ) {
      found = ordersData.filter((o) => o.userId.toLowerCase() === cleanQuery || o.userId.replace(/\D/g, '') === digitsOnly);
    }

    // Return strictly only the matched order(s)
    res.json({ orders: found });
  });

  // GET Direct Order Proof Image Stream
  app.get('/api/orders/:id/proof-image', (req: Request, res: Response) => {
    const { id } = req.params;
    const order = ordersData.find((o) => o.id.toLowerCase() === id.toLowerCase());
    if (!order || !order.proofImageUrl) {
      return res.status(404).send('Bukti bayaran tidak dijumpai.');
    }

    const proof = order.proofImageUrl;
    if (proof.startsWith('data:image/')) {
      const mimeMatch = proof.match(/^data:(image\/[a-zA-Z0-9+.-]+);base64,/);
      const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
      const base64Data = proof.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');
      const buffer = Buffer.from(base64Data, 'base64');
      res.setHeader('Content-Type', mimeType);
      res.setHeader('Content-Length', buffer.length);
      return res.send(buffer);
    } else if (proof.startsWith('http')) {
      return res.redirect(proof);
    }
    return res.status(404).send('Format bukti tidak sah.');
  });

  // GET Digital Receipt Web Viewer
  app.get('/receipt/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const order = ordersData.find((o) => o.id.toLowerCase() === id.toLowerCase());
    if (!order) {
      return res.status(404).send(`
        <!DOCTYPE html>
        <html>
        <head><title>Resit Tidak Dijumpai - TopupBalz</title><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
        <body style="font-family:sans-serif; background:#0B0F17; color:#fff; display:flex; justify-content:center; align-items:center; min-height:100vh; margin:0; text-align:center; padding:20px;">
          <div>
            <h2 style="color:#f97316;">Pesanan #${id} Tidak Dijumpai</h2>
            <p style="color:#94a3b8;">Sila pastikan nombor pesanan anda adalah betul.</p>
            <a href="/" style="display:inline-block; padding:10px 20px; background:#f97316; color:#000; font-weight:bold; border-radius:8px; text-decoration:none; margin-top:10px;">Kembali ke Laman Utama</a>
          </div>
        </body>
        </html>
      `);
    }

    const proofHtml = order.proofImageUrl
      ? `<div style="margin-top:20px; text-align:center;">
           <div style="font-weight:bold; color:#f97316; margin-bottom:8px; font-size:12px;">📸 BUKTI TRANSFER PELANGGAN:</div>
           <a href="/api/orders/${order.id}/proof-image" target="_blank">
             <img src="${order.proofImageUrl}" alt="Bukti Transfer" style="max-width:100%; max-height:400px; border-radius:12px; border:2px solid #334155; box-shadow:0 10px 25px rgba(0,0,0,0.5);" />
           </a>
         </div>`
      : `<div style="margin-top:20px; padding:15px; background:#1e293b; border-radius:8px; color:#94a3b8; font-size:12px; text-align:center;">Tiada gambar bukti transfer dimuat naik.</div>`;

    return res.send(`
      <!DOCTYPE html>
      <html lang="ms">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Resit Rasmi TopupBalz #${maskOrderId(order.id)}</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background:#0B0F17; color:#F1F5F9; margin:0; padding:20px; display:flex; justify-content:center; }
          .card { background:#111827; border:1px solid rgba(249,115,22,0.4); border-radius:16px; width:100%; max-width:480px; padding:24px; box-shadow:0 0 40px rgba(0,0,0,0.8); }
          .header { text-align:center; border-bottom:1px solid #1f2937; padding-bottom:16px; margin-bottom:16px; }
          .badge { background:rgba(16,185,129,0.2); color:#34d399; font-weight:bold; font-size:11px; padding:4px 10px; border-radius:6px; border:1px solid rgba(16,185,129,0.3); display:inline-block; }
          .row { display:flex; justify-content:space-between; margin-bottom:10px; font-size:13px; }
          .label { color:#94a3b8; }
          .val { font-weight:bold; color:#fff; text-align:right; }
          .total { border-top:1px solid #334155; padding-top:12px; margin-top:12px; font-size:16px; }
          .total .val { color:#f97316; font-size:18px; }
          .btn { display:block; text-align:center; background:linear-gradient(to right, #f97316, #eab308); color:#090d16; font-weight:900; padding:12px; border-radius:10px; text-decoration:none; margin-top:20px; font-size:13px; text-transform:uppercase; letter-spacing:0.5px; }
          .wa-btn { display:block; text-align:center; background:#10b981; color:#fff; font-weight:bold; padding:12px; border-radius:10px; text-decoration:none; margin-top:10px; font-size:13px; }
        </style>
      </head>
      <body>
        <div class="card">
          <div class="header">
            <h2 style="margin:0 0 6px 0; color:#f97316; font-size:22px; font-weight:900;">TOPUPBALZ RESIT RASMI</h2>
            <div style="font-size:11px; color:#94a3b8; font-family:monospace; margin-bottom:8px;">INVOICE #${maskOrderId(order.id)}</div>
            <span class="badge">STATUS: ${order.status.toUpperCase()}</span>
          </div>

          <div class="row"><span class="label">Game / Produk:</span><span class="val">${order.gameName}</span></div>
          <div class="row"><span class="label">Pakej:</span><span class="val" style="color:#fbbf24;">${order.itemName}</span></div>
          <div class="row"><span class="label">User ID:</span><span class="val" style="font-family:monospace;">${maskGameUserId(order.userId)}</span></div>
          ${order.serverId ? `<div class="row"><span class="label">Server / Zone ID:</span><span class="val" style="font-family:monospace;">${maskServerId(order.serverId)}</span></div>` : ''}
          ${order.customerPhone ? `<div class="row"><span class="label">No Telefon:</span><span class="val">${maskPhoneNumber(order.customerPhone)}</span></div>` : ''}
          <div class="row"><span class="label">Kaedah Bayaran:</span><span class="val">${order.paymentMethod || "Touch 'n Go eWallet"}</span></div>
          <div class="row"><span class="label">Tarikh & Masa:</span><span class="val">${getMalaysiaDateTime(order.createdAt).full} (Waktu Malaysia)</span></div>

          <div class="row total">
            <span class="label" style="color:#f1f5f9; font-weight:bold;">Jumlah Bayaran:</span>
            <span class="val">RM ${(order.sellPrice || 0).toFixed(2)}</span>
          </div>

          ${proofHtml}

          <div style="margin-top:20px; display:flex; flex-direction:column; gap:10px;">
            <a href="${order.whatsappUrl || 'https://wa.me/' + (settingsData.ownerWhatsApp || '60145975056')}" class="wa-btn">💬 Buka WhatsApp Admin</a>
            <a href="https://t.me/informasitopupbalz" target="_blank" style="display:block; text-align:center; background:#229ED9; color:#fff; font-weight:bold; padding:12px; border-radius:10px; text-decoration:none; font-size:13px;">📢 Lihat Di Channel Telegram (@informasitopupbalz)</a>
            <a href="/" class="btn">Kembali ke TopupBalz</a>
          </div>
        </div>
      </body>
      </html>
    `);
  });

  // POST Submit New Order
  app.post('/api/orders', async (req: Request, res: Response) => {
    try {
      const {
        gameId,
        gameName,
        itemId,
        itemName,
        basePrice,
        userId,
        serverId,
        customerPhone,
        paymentMethod,
        proofImageUrl,
        accountUserId,
        accountUsername,
      } = req.body;

      // 1. Mandatory Fields Check
      if (!gameName || !itemName || !userId) {
        return res.status(400).json({ error: 'Sila lengkapkan maklumat game, item dan User ID!' });
      }

      // 2. Strict Digits-Only Validation for User ID
      const cleanUserId = String(userId).trim().replace(/\D/g, '');
      if (!cleanUserId) {
        return res.status(400).json({ error: 'ID Pengguna (User ID) mestilah mengandungi NOMBOR SAHAJA! Huruf tidak dibenarkan.' });
      }

      // 3. Digits-Only Validation for Server/Zone ID (if provided)
      let cleanServerId: string | undefined = undefined;
      if (serverId && String(serverId).trim() !== '') {
        const digitsOnlyServer = String(serverId).trim().replace(/\D/g, '');
        if (digitsOnlyServer) {
          cleanServerId = digitsOnlyServer;
        } else {
          // If server was pure text, keep it or check
          cleanServerId = String(serverId).trim();
        }
      }

      // 4. Mandatory & Digits-Only Validation for Customer WhatsApp Phone Number
      const cleanPhone = customerPhone ? String(customerPhone).trim().replace(/\D/g, '') : '';
      if (!cleanPhone || cleanPhone.length < 3) {
        return res.status(400).json({ error: 'Nombor telefon WhatsApp adalah WAJIB dan mestilah mengandungi NOMBOR SAHAJA!' });
      }

      // 5. Mandatory Proof Receipt Image Validation
      if (!proofImageUrl || typeof proofImageUrl !== 'string' || proofImageUrl.trim() === '') {
        return res.status(400).json({ error: 'Gambar resit bukti pembayaran adalah WAJIB dimuat naik sebelum menghantar pesanan!' });
      }

      const numBase = Number(basePrice) || 0;
      const reqSell = Number(req.body.sellPrice);
      const sellPrice =
        reqSell && !isNaN(reqSell) && reqSell > 0
          ? reqSell
          : numBase;
      const orderId = 'BZ-' + Math.floor(100000 + Math.random() * 900000);

      const matchedGame = gamesData.find((g) => g.id === gameId || g.name === gameName);
      const gameCategory = matchedGame?.category || '';

      const clientOrigin = req.body.clientOrigin;
      let host = req.get('host') || 'localhost:3000';
      let protocol = req.protocol === 'https' || req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';

      if (clientOrigin && typeof clientOrigin === 'string' && clientOrigin.startsWith('http') && !clientOrigin.includes('localhost')) {
        try {
          const parsed = new URL(clientOrigin);
          host = parsed.host;
          protocol = parsed.protocol.replace(':', '');
        } catch (e) {}
      } else {
        const originHeader = (req.headers.origin as string) || (req.headers.referer as string) || '';
        if (originHeader && originHeader.startsWith('http') && !originHeader.includes('localhost')) {
          try {
            const parsed = new URL(originHeader);
            host = parsed.host;
            protocol = parsed.protocol.replace(':', '');
          } catch (e) {}
        }
      }

      const receiptUrl = `${protocol}://${host}/receipt/${orderId}`;

      // Build robust WhatsApp message using predefined game item template
      const textMessage = buildOrderMessage({
        orderId,
        gameName,
        itemName,
        price: sellPrice,
        userId: cleanUserId,
        serverId: cleanServerId,
        customerPhone: cleanPhone,
        paymentMethod: paymentMethod || "Touch 'n Go eWallet",
        gameCategory,
        proofImageUrl,
        receiptUrl,
      });

      const { waUrl: whatsappUrl } = generateWhatsAppUrl(textMessage, settingsData.ownerWhatsApp);

      const newOrder: any = {
        id: orderId,
        createdAt: new Date().toISOString(),
        gameId,
        gameName,
        itemId,
        itemName,
        basePrice: numBase,
        sellPrice,
        userId: cleanUserId,
        serverId: cleanServerId,
        customerPhone: cleanPhone,
        paymentMethod: paymentMethod || "Touch 'n Go eWallet",
        proofImageUrl,
        status: 'pending',
        notes: 'Pesanan baru diterima. Menunggu pengesahan resit.',
        whatsappUrl,
        accountUserId,
        accountUsername,
      };

      ordersData.unshift(newOrder);

      // Check if order item is part of active flash sale
      const matchedFsItem = flashSaleData.items.find(
        (i) => i.itemId === itemId || (i.gameId === gameId && i.itemName === itemName)
      );
      if (matchedFsItem) {
        matchedFsItem.soldCount = (matchedFsItem.soldCount || 0) + 1;
        if (matchedFsItem.soldCount >= matchedFsItem.maxQuota) {
          matchedFsItem.isActive = false;
        }
        saveFlashSaleToFirestore(flashSaleData);
      }

      saveDatabaseToDisk();
      saveOrderToFirestore(newOrder);
      saveOrderToSupabase(newOrder);

      // Update matching user stats in usersData & Firestore & Supabase
      if (accountUserId || accountUsername || cleanPhone) {
        const targetUser = usersData.find(
          (u) =>
            (accountUserId && u.id === accountUserId) ||
            (accountUsername && (u.username === accountUsername || u.name === accountUsername)) ||
            (cleanPhone && u.phoneNumber && u.phoneNumber.replace(/\D/g, '') === cleanPhone)
        );
        if (targetUser) {
          targetUser.totalOrders = (targetUser.totalOrders || 0) + 1;
          targetUser.totalSpent = (targetUser.totalSpent || 0) + sellPrice;
          saveUserToFirestore(targetUser);
          saveUserToSupabase(targetUser);
        }
      }

      // --- BROADCAST TELEGRAM NOTIFICATIONS (ADMIN CHAT & TELEGRAM CHANNELS) ---
      const botToken = settingsData.telegramBotToken || '8734212773:AAF3wZS0nC5Vt29RoB7kcBwHKqEBJ2y8NTw';

      if (botToken) {
        try {
          // Parse all destination targets (Private chat IDs, Channel IDs, Group IDs)
          const targetSet = new Set<string>();

          if (settingsData.telegramChatId) {
            const chats = settingsData.telegramChatId.split(/[,;\s]+/).map((s) => s.trim()).filter(Boolean);
            chats.forEach((c) => {
              // Filter out the bot's own username if mistakenly entered
              if (c.toLowerCase() !== '@orderbalz_bot' && !c.toLowerCase().endsWith('_bot')) {
                targetSet.add(c);
              }
            });
          }

          const channelTarget = settingsData.telegramChannelId || '@informasitopupbalz';
          if (channelTarget) {
            const channels = channelTarget.split(/[,;\s]+/).map((s) => s.trim()).filter(Boolean);
            channels.forEach((c) => {
              // Filter out the bot's own username if mistakenly entered
              if (c.toLowerCase() !== '@orderbalz_bot' && !c.toLowerCase().endsWith('_bot')) {
                // If it's alphanumeric and not negative ID or doesn't start with @, prepend @
                let formattedChannel = c;
                if (!formattedChannel.startsWith('@') && !formattedChannel.startsWith('-') && !/^\d+$/.test(formattedChannel)) {
                  formattedChannel = `@${formattedChannel}`;
                }
                targetSet.add(formattedChannel);
              }
            });
          }

          // Always ensure admin private chat ID is present
          targetSet.add('1290238834');
          // Always ensure verified channel @informasitopupbalz is included
          targetSet.add('@informasitopupbalz');

          const myDateTime = getMalaysiaDateTime();
          const telegramText =
            `🚨 <b>[TOPUPBALZ / ORDERBALZ - PESANAN BARU]</b> 🚨\n\n` +
            `🆔 <b>ID Pesanan:</b> <code>${maskOrderId(orderId)}</code>\n` +
            `🎮 <b>Game:</b> ${gameName}\n` +
            `💎 <b>Pakej / Produk:</b> ${itemName}\n` +
            `💰 <b>Jumlah Bayaran:</b> <b>RM ${sellPrice.toFixed(2)}</b>\n` +
            `👤 <b>User ID:</b> <code>${maskGameUserId(cleanUserId)}</code>\n` +
            (cleanServerId ? `🌐 <b>Server / Zone ID:</b> <code>${maskServerId(cleanServerId)}</code>\n` : '') +
            (cleanPhone ? `📞 <b>No Tel WhatsApp:</b> <code>${maskPhoneNumber(cleanPhone)}</code>\n` : '') +
            `💳 <b>Kaedah Bayaran:</b> ${paymentMethod || "Touch 'n Go eWallet"}\n` +
            `📅 <b>Tarikh:</b> ${myDateTime.date} | <b>Masa:</b> ${myDateTime.time} (Waktu Malaysia)\n` +
            `📸 <b>Bukti Transfer:</b> ${proofImageUrl ? '✅ Gambar Resit Disertakan' : '⚠️ Tiada Gambar'}\n` +
            `⚡ <b>Status:</b> MENUNGGU PENGESAHAN RESIT\n` +
            `🔗 <a href="${receiptUrl}">Lihat Resit Digital & Bukti</a>`;

          for (const target of Array.from(targetSet)) {
            try {
              let photoSent = false;

              // If transfer proof image is present, send actual photo via Telegram sendPhoto API
              if (proofImageUrl && typeof proofImageUrl === 'string' && proofImageUrl.trim() !== '') {
                try {
                  if (proofImageUrl.startsWith('data:image/')) {
                    const mimeMatch = proofImageUrl.match(/^data:(image\/[a-zA-Z0-9+.-]+);base64,/);
                    const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
                    const base64Data = proofImageUrl.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');
                    const buffer = Buffer.from(base64Data, 'base64');
                    const blob = new Blob([buffer], { type: mimeType });

                    const formData = new FormData();
                    formData.append('chat_id', target);
                    formData.append('caption', telegramText);
                    formData.append('parse_mode', 'HTML');
                    formData.append('photo', blob, `resit_${orderId}.jpg`);

                    const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendPhoto`, {
                      method: 'POST',
                      body: formData,
                    });
                    const tgJson: any = await tgRes.json();
                    if (tgJson.ok) {
                      photoSent = true;
                      console.log(`[Telegram Photo Sent Successfully] Order #${orderId} -> Target: ${target}`);
                    } else {
                      if (tgJson.error_code === 403) {
                        console.warn(`[Telegram Bot Notice 403] Bot lacks permission or is not admin in channel/chat ${target}. Description: ${tgJson.description}`);
                      } else {
                        console.warn(`[Telegram sendPhoto Warning for ${target}]`, tgJson);
                      }
                    }
                  } else if (proofImageUrl.startsWith('http')) {
                    const formData = new FormData();
                    formData.append('chat_id', target);
                    formData.append('caption', telegramText);
                    formData.append('parse_mode', 'HTML');
                    formData.append('photo', proofImageUrl);

                    const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendPhoto`, {
                      method: 'POST',
                      body: formData,
                    });
                    const tgJson: any = await tgRes.json();
                    if (tgJson.ok) {
                      photoSent = true;
                      console.log(`[Telegram Photo URL Sent Successfully] Order #${orderId} -> Target: ${target}`);
                    } else {
                      if (tgJson.error_code === 403) {
                        console.warn(`[Telegram Bot Notice 403] Bot lacks permission or is not admin in channel/chat ${target}. Description: ${tgJson.description}`);
                      } else {
                        console.warn(`[Telegram sendPhoto URL Warning for ${target}]`, tgJson);
                      }
                    }
                  }
                } catch (photoErr) {
                  console.error(`[Telegram sendPhoto Error for ${target}]`, photoErr);
                }
              }

              // Fallback to text message if photo was not sent or failed
              if (!photoSent) {
                const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    chat_id: target,
                    text: telegramText,
                    parse_mode: 'HTML',
                  }),
                });
                const tgJson: any = await tgRes.json();
                if (tgJson.ok) {
                  console.log(`[Telegram Text Sent Successfully] Order #${orderId} -> Target: ${target}`);
                } else {
                  if (tgJson.error_code === 403) {
                    console.warn(`[Telegram Bot Notice 403] Bot lacks permission or is not admin in channel/chat ${target}. Description: ${tgJson.description}`);
                  } else {
                    console.warn(`[Telegram sendMessage Warning for ${target}]`, tgJson);
                  }
                }
              }

              // Auto-reply with ETA only to private user chat IDs (positive numbers, e.g. '1290238834'), not broadcast channels
              const isPrivateChat = /^\d+$/.test(target);
              if (isPrivateChat) {
                const autoReplyText =
                  `🤖 <b>[OrderBalz Bot Auto-Reply]</b>\n\n` +
                  `<b>Sila tunggu 10 - 20 minit untuk diamond/kredit dimasukkan ke dalam akaun anda.</b> ⏱️💎\n\n` +
                  `Pesanan <code>${orderId}</code> bagi <b>${gameName} (${itemName})</b> telah disahkan. Resit bukti pembayaran telah direkodkan. Admin TopupBalz sedang memproses tempahan anda secara instant. Terima kasih!`;

                await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    chat_id: target,
                    text: autoReplyText,
                    parse_mode: 'HTML',
                  }),
                });
              }
            } catch (targetErr) {
              console.error(`[Telegram Target Error] Failed to send to ${target}:`, targetErr);
            }
          }
        } catch (tgErr) {
          console.error('Telegram Notification Master Error:', tgErr);
        }
      }

      return res.json({
        success: true,
        order: newOrder,
        whatsappUrl,
        receiptUrl,
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // PATCH Update Order Status (Admin)
  app.patch('/api/orders/:id/status', (req: Request, res: Response) => {
    const { id } = req.params;
    const { status, notes } = req.body;

    const orderIndex = ordersData.findIndex((o) => o.id === id);
    if (orderIndex === -1) {
      return res.status(404).json({ error: 'Pesanan tidak dijumpai' });
    }

    ordersData[orderIndex].status = status;
    if (notes) {
      ordersData[orderIndex].notes = notes;
    }

    saveDatabaseToDisk();
    saveOrderToFirestore(ordersData[orderIndex]);
    saveOrderToSupabase(ordersData[orderIndex]);
    return res.json({ success: true, order: ordersData[orderIndex], orders: ordersData });
  });

  // GET / POST Banners
  app.get('/api/banners', (req: Request, res: Response) => {
    res.json({ banners: bannersData });
  });

  app.post('/api/banners', (req: Request, res: Response) => {
    const newBanner: PromoBanner = req.body;
    if (!newBanner.id) {
      newBanner.id = 'b_' + Date.now();
    }
    const idx = bannersData.findIndex((b) => b.id === newBanner.id);
    if (idx >= 0) {
      bannersData[idx] = newBanner;
    } else {
      bannersData.unshift(newBanner);
    }
    saveDatabaseToDisk();
    saveBannerToFirestore(newBanner);
    saveBannerToSupabase(newBanner);
    res.json({ success: true, banners: bannersData });
  });

  app.delete('/api/banners/:id', (req: Request, res: Response) => {
    const bannerId = req.params.id;
    bannersData = bannersData.filter((b) => b.id !== bannerId);
    saveDatabaseToDisk();
    deleteBannerFromFirestore(bannerId);
    deleteBannerFromSupabase(bannerId);
    res.json({ success: true, banners: bannersData });
  });

  // GET / POST Settings
  app.get('/api/settings', (req: Request, res: Response) => {
    res.json({ settings: settingsData });
  });

  app.post('/api/settings', (req: Request, res: Response) => {
    settingsData = { ...settingsData, ...req.body };
    saveDatabaseToDisk();
    saveSettingsToFirestore(settingsData);
    saveSettingsToSupabase(settingsData);
    res.json({ success: true, settings: settingsData });
  });

  // GET / POST / BUY Flash Sale (Jualan Kilat)
  app.get('/api/flash-sale', (req: Request, res: Response) => {
    res.json({ flashSale: flashSaleData });
  });

  app.post('/api/flash-sale', (req: Request, res: Response) => {
    try {
      const updatedConfig: FlashSaleConfig = req.body;
      if (updatedConfig && typeof updatedConfig === 'object') {
        flashSaleData = {
          ...flashSaleData,
          ...updatedConfig,
          items: Array.isArray(updatedConfig.items) ? updatedConfig.items : flashSaleData.items,
        };
        saveDatabaseToDisk();
        saveFlashSaleToFirestore(flashSaleData);
        return res.json({ success: true, flashSale: flashSaleData });
      }
      return res.status(400).json({ error: 'Data jualan kilat tidak sah.' });
    } catch (err: any) {
      console.error('Error updating flash sale:', err);
      return res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/flash-sale/buy', (req: Request, res: Response) => {
    try {
      const { flashItemId, itemId, gameId, quantity = 1 } = req.body;
      const targetItem = flashSaleData.items.find(
        (i) =>
          (flashItemId && i.id === flashItemId) ||
          (itemId && i.itemId === itemId && (!gameId || i.gameId === gameId))
      );

      if (targetItem) {
        targetItem.soldCount = (targetItem.soldCount || 0) + Number(quantity);
        if (targetItem.soldCount >= targetItem.maxQuota) {
          targetItem.isActive = false; // Sold out / auto hide
        }
        saveDatabaseToDisk();
        saveFlashSaleToFirestore(flashSaleData);
        return res.json({ success: true, item: targetItem, flashSale: flashSaleData });
      }
      return res.json({ success: false, message: 'Item jualan kilat tidak ditemui' });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // GET Detect Telegram Channels & Groups
  app.get('/api/telegram/detect-channel', async (req: Request, res: Response) => {
    const botToken = settingsData.telegramBotToken || '8734212773:AAF3wZS0nC5Vt29RoB7kcBwHKqEBJ2y8NTw';
    try {
      const response = await fetch(`https://api.telegram.org/bot${botToken}/getUpdates?allowed_updates=["message","channel_post","my_chat_member","chat_member"]`);
      const data: any = await response.json();
      
      const detected: Array<{ id: string | number; title: string; type: string; username?: string }> = [];
      const seenIds = new Set<string | number>();

      if (data.ok && Array.isArray(data.result)) {
        for (const u of data.result) {
          const chat = u.channel_post?.chat || u.my_chat_member?.chat || u.message?.chat;
          if (chat && (chat.type === 'channel' || chat.type === 'supergroup' || chat.type === 'group')) {
            if (!seenIds.has(chat.id)) {
              seenIds.add(chat.id);
              detected.push({
                id: chat.id,
                title: chat.title || 'Channel Tanpa Nama',
                type: chat.type,
                username: chat.username,
              });
            }
          }
        }
      }

      return res.json({
        success: true,
        detectedChannels: detected,
        currentChannelId: settingsData.telegramChannelId || '',
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // POST Test Send to Telegram Channel or Chat ID
  app.post('/api/telegram/test-channel', async (req: Request, res: Response) => {
    const botToken = settingsData.telegramBotToken || '8734212773:AAF3wZS0nC5Vt29RoB7kcBwHKqEBJ2y8NTw';
    let { target } = req.body;

    if (!target || typeof target !== 'string' || !target.trim()) {
      return res.status(400).json({ error: 'Sila masukkan Channel ID atau @username untuk diuji.' });
    }

    target = target.trim();
    // Auto-formatting: if it's alphanumeric and does not start with @ or -, prepend @
    if (!target.startsWith('@') && !target.startsWith('-') && !/^\d+$/.test(target)) {
      target = `@${target}`;
    }

    try {
      const testMsg =
        `🔔 <b>[UJIAN BOT TELEGRAM TOPUPBALZ BERJAYA]</b> 🔔\n\n` +
        `✅ <b>Bot @OrderBalz_bot Berjaya Disambungkan!</b>\n` +
        `📍 <b>Destinasi:</b> <code>${target}</code>\n` +
        `📅 <b>Masa:</b> ${new Date().toLocaleString('ms-MY')}\n\n` +
        `Sistem sedia menerima dan memaparkan pesanan baru secara automatik 24 jam! 🚀`;

      const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: target,
          text: testMsg,
          parse_mode: 'HTML',
        }),
      });

      const tgJson: any = await tgRes.json();

      if (tgJson.ok) {
        if (target.startsWith('@') || target.startsWith('-')) {
          settingsData.telegramChannelId = target;
          saveDatabaseToDisk();
          saveSettingsToFirestore(settingsData);
        }
        return res.json({
          success: true,
          message: `Mesej ujian berjaya dihantar ke ${target}! Bot berfungsi dengan sempurna dan saluran ini telah disimpan secara automatik.`,
        });
      } else {
        let helpTip = tgJson.description || 'Ralat tidak diketahui';
        if (tgJson.error_code === 403) {
          helpTip = `Bot tiada kebenaran untuk menghantar mesej ke ${target}. Sila pastikan bot @OrderBalz_bot telah dimasukkan sebagai ADMIN dalam channel tersebut dan diberi kebenaran 'Post Messages'.`;
        } else if (tgJson.error_code === 400 && tgJson.description?.includes('chat not found')) {
          helpTip = `Channel/Chat '${target}' tidak dijumpai. Jika channel anda Private, anda mesti menggunakan nombor Channel ID (bermula -100...) atau tukar Channel Type kepada Public di Telegram.`;
        }
        return res.status(400).json({
          success: false,
          error: helpTip,
          rawError: tgJson,
        });
      }
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // POST Telegram Webhook (OrderBalz Bot Auto-Reply & Spam Filter)
  app.post('/api/telegram-webhook', async (req: Request, res: Response) => {
    try {
      const update = req.body;

      // Auto-detect channel if bot receives channel_post or member event
      const autoChat = update?.channel_post?.chat || update?.my_chat_member?.chat;
      if (autoChat && (autoChat.type === 'channel' || autoChat.type === 'supergroup')) {
        const detectedChatId = String(autoChat.id);
        console.log(`[Auto-Detected Telegram Channel] Title: ${autoChat.title}, ID: ${detectedChatId}`);
        if (!settingsData.telegramChannelId || !settingsData.telegramChannelId.includes(detectedChatId)) {
          settingsData.telegramChannelId = settingsData.telegramChannelId
            ? `${settingsData.telegramChannelId}, ${detectedChatId}`
            : detectedChatId;
          saveDatabaseToDisk();
          saveSettingsToFirestore(settingsData);
        }
      }

      const message = update?.message;

      if (!message || !message.text) {
        return res.json({ ok: true, status: 'no_message_text' });
      }

      const text = message.text.trim().toLowerCase();
      const chatId = message.chat.id;

      // Keywords that identify an order message or order inquiry
      const isOrderMessage =
        text.includes('tb-') ||
        text.includes('order') ||
        text.includes('pesanan') ||
        text.includes('topup') ||
        text.includes('diamond') ||
        text.includes('user id') ||
        text.includes('id:') ||
        text.includes('game') ||
        text.includes('starlight') ||
        text.includes('free fire') ||
        text.includes('mobile legend') ||
        text.includes('resit') ||
        text.includes('pembayaran') ||
        text.includes('duitnow');

      // If NOT an order message (e.g. random text, spam, unrelated chat), DO NOT REPLY
      if (!isOrderMessage) {
        return res.json({ ok: true, status: 'ignored_non_order_spam' });
      }

      // If it IS an order message, reply automatically with the estimated processing time
      const botToken = settingsData.telegramBotToken || '8734212773:AAF3wZS0nC5Vt29RoB7kcBwHKqEBJ2y8NTw';
      const autoReplyText =
        `🤖 <b>[OrderBalz Bot]</b>\n\n` +
        `<b>Sila tunggu 10 - 20 minit untuk diamond/kredit dimasukkan ke dalam akaun anda.</b> ⏱️💎\n\n` +
        `Pesanan anda sedang diproses secara automatik oleh sistem TopupBalz. Terima kasih atas pembelian anda!`;

      await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: autoReplyText,
          parse_mode: 'HTML',
          reply_to_message_id: message.message_id,
        }),
      });

      return res.json({ ok: true, status: 'order_replied' });
    } catch (err: any) {
      console.error('Telegram Webhook Error:', err);
      return res.status(500).json({ error: err.message });
    }
  });

  // GET registered users, banned users, and activity logs (for Admin & User Profile)
  app.get('/api/users', (req: Request, res: Response) => {
    const updatedUsers = usersData.map((u) => {
      const userOrds = ordersData.filter(
        (o: any) =>
          o.accountUserId === u.id ||
          o.accountUsername === u.name ||
          o.accountUsername === u.username ||
          o.userId === u.id ||
          o.userId === u.username ||
          (u.phoneNumber && o.customerPhone && o.customerPhone.replace(/\D/g, '') === u.phoneNumber.replace(/\D/g, ''))
      );
      const computedOrders = userOrds.length;
      const computedSpent = userOrds.reduce((sum, ord) => sum + (ord.sellPrice || ord.basePrice || 0), 0);
      return {
        ...u,
        totalOrders: Math.max(u.totalOrders || 0, computedOrders),
        totalSpent: Math.max(u.totalSpent || 0, computedSpent),
      };
    });
    res.json({ users: updatedUsers, bannedUsers: bannedUsersData, activityLogs: activityLogsData });
  });

  // GET Banned Users list
  app.get('/api/banned-users', (req: Request, res: Response) => {
    res.json({ bannedUsers: bannedUsersData });
  });

  // Email OTP map for email verification
  const verificationOtpMap = new Map<string, string>();

  // POST Email & Password Registration (Sign Up)
  app.post('/api/auth/register', (req: Request, res: Response) => {
    try {
      const { username, email, password, confirmPassword } = req.body;

      // 1. Validate Username
      if (!username || typeof username !== 'string') {
        return res.status(400).json({ error: 'Sila masukkan nama username yang sah!' });
      }
      const cleanUsername = username.trim().replace(/^@+/, '');
      if (cleanUsername.length < 3) {
        return res.status(400).json({ error: 'Username mestilah sekurang-kurangnya 3 aksara!' });
      }
      if (!/^[a-zA-Z0-9_]+$/.test(cleanUsername)) {
        return res.status(400).json({ error: 'Username hanya boleh mengandungi huruf, nombor dan garis bawah (_).' });
      }

      // 2. Validate Gmail Email
      if (!email || typeof email !== 'string') {
        return res.status(400).json({ error: 'Sila masukkan alamat emel Gmail anda!' });
      }
      const cleanEmail = email.trim().toLowerCase();
      const gmailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/i;
      if (!gmailRegex.test(cleanEmail)) {
        return res.status(400).json({ error: 'Sila gunakan alamat emel Gmail yang sah (@gmail.com)!' });
      }

      // 3. Validate Password
      if (!password || typeof password !== 'string' || password.length < 6) {
        return res.status(400).json({ error: 'Kata laluan mestilah sekurang-kurangnya 6 aksara!' });
      }
      if (confirmPassword && password !== confirmPassword) {
        return res.status(400).json({ error: 'Pengesahan kata laluan tidak sepadan!' });
      }

      const handle = `@${cleanUsername}`;

      // 4. Check if Banned
      const isBanned = bannedUsersData.some(
        (b) =>
          (b.email && b.email.toLowerCase() === cleanEmail) ||
          (b.username && b.username.toLowerCase().replace(/^@+/, '') === cleanUsername.toLowerCase())
      );
      if (isBanned) {
        return res.status(403).json({
          error: 'Akaun / Emel ini telah dipadam dan disekat oleh Admin TopupBalz. Anda tidak dibenarkan mendaftar.',
        });
      }

      // 5. Check if Username Already Exists
      const existingUsername = usersData.find(
        (u) =>
          u.name.toLowerCase() === handle.toLowerCase() ||
          (u.username && u.username.toLowerCase() === cleanUsername.toLowerCase())
      );
      if (existingUsername) {
        return res.status(400).json({ error: 'Username ini sudah digunakan! Sila pilih username lain.' });
      }

      // 6. Check if Email Already Exists
      const existingEmail = usersData.find((u) => u.email && u.email.toLowerCase() === cleanEmail);
      if (existingEmail) {
        return res.status(400).json({ error: 'Emel ini telah didaftarkan. Sila log masuk ke akaun anda.' });
      }

      const isBalzzAdmin = cleanUsername.toLowerCase() === 'balzz' || cleanUsername.toLowerCase() === 'balzltdsdn';
      const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
      verificationOtpMap.set(cleanEmail, otpCode);

      const newUser = {
        id: isBalzzAdmin ? 'TB-ADMIN-BALZZ' : `TB-USR-${Math.floor(1000 + Math.random() * 9000)}`,
        email: cleanEmail,
        name: handle,
        username: cleanUsername,
        password: password,
        avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(handle)}`,
        googleId: '',
        phoneNumber: '',
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
        totalOrders: 0,
        totalSpent: 0,
        isOnline: true,
        isEmailVerified: isBalzzAdmin ? true : false,
        status: 'active',
      };

      usersData.unshift(newUser);

      const newLog = {
        id: `LOG-${Date.now()}`,
        userId: newUser.id,
        userName: newUser.name,
        userEmail: newUser.email,
        type: 'register',
        details: `Pendaftaran akaun baru: ${handle} (${cleanEmail})`,
        timestamp: new Date().toISOString(),
      };
      activityLogsData.unshift(newLog);

      saveDatabaseToDisk();
      saveUserToFirestore(newUser);
      saveUserToSupabase(newUser);
      saveActivityLogToFirestore(newLog);
      saveActivityLogToSupabase(newLog);

      return res.json({ success: true, user: newUser, users: usersData });
    } catch (err: any) {
      console.error('Registration Error:', err);
      return res.status(500).json({ error: 'Ralat semasa pendaftaran akaun.' });
    }
  });

  // POST Email / Username Login (Sign In)
  app.post('/api/auth/login', (req: Request, res: Response) => {
    try {
      const { identifier, password } = req.body;
      if (!identifier || !password) {
        return res.status(400).json({ error: 'Sila masukkan username / emel dan kata laluan anda!' });
      }

      const cleanIdent = identifier.trim();
      const cleanIdentLower = cleanIdent.toLowerCase();
      const cleanIdentNoAt = cleanIdentLower.replace(/^@+/, '');

      // Check if Banned
      const isBanned = bannedUsersData.some(
        (b) =>
          (b.email && b.email.toLowerCase() === cleanIdentLower) ||
          (b.username && b.username.toLowerCase().replace(/^@+/, '') === cleanIdentNoAt)
      );
      if (isBanned) {
        return res.status(403).json({
          error: 'Akaun anda telah dipadam & disekat oleh Admin TopupBalz. Anda tidak dibenarkan mengakses sistem ini.',
        });
      }

      // Special Admin Credentials Check
      const isAdminLogin =
        (cleanIdentNoAt === 'balzbalz' || cleanIdentNoAt === 'siuiqbal23' || cleanIdentLower === 'siuiqbal23@gmail.com') &&
        password === 'balz12344321';

      if (isAdminLogin) {
        let adminUser = usersData.find(
          (u) =>
            u.email?.toLowerCase() === 'siuiqbal23@gmail.com' ||
            u.username?.toLowerCase() === 'balzbalz' ||
            u.username?.toLowerCase() === 'siuiqbal23'
        );
        if (!adminUser) {
          adminUser = {
            id: 'TB-ADMIN-BALZZ',
            email: 'siuiqbal23@gmail.com',
            name: '@Balzbalz',
            username: 'Balzbalz',
            password: 'balz12344321',
            avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
            googleId: 'google-siuiqbal23',
            phoneNumber: '0145975056',
            createdAt: new Date().toISOString(),
            lastLoginAt: new Date().toISOString(),
            totalOrders: 13,
            totalSpent: 39.37,
            isOnline: true,
            isEmailVerified: true,
            role: 'admin',
          };
          usersData.unshift(adminUser);
        } else {
          adminUser.username = 'Balzbalz';
          adminUser.name = '@Balzbalz';
          adminUser.email = 'siuiqbal23@gmail.com';
          adminUser.password = 'balz12344321';
          adminUser.isEmailVerified = true;
          adminUser.role = 'admin';
          adminUser.lastLoginAt = new Date().toISOString();
          adminUser.isOnline = true;
        }

        saveDatabaseToDisk();
        saveUserToFirestore(adminUser);
        return res.json({ success: true, user: adminUser, users: usersData });
      }

      // Find user by email or username
      const user = usersData.find(
        (u) =>
          (u.email && u.email.toLowerCase() === cleanIdentLower) ||
          u.name.toLowerCase() === `@${cleanIdentNoAt}` ||
          (u.username && u.username.toLowerCase() === cleanIdentNoAt) ||
          u.name.toLowerCase() === cleanIdentLower
      );

      if (!user) {
        return res.status(404).json({ error: 'Akaun tidak dijumpai. Sila daftar akaun baru!' });
      }

      // Check password if set
      if (user.password && user.password !== password) {
        return res.status(401).json({ error: 'Kata laluan tidak sah. Sila cuba lagi!' });
      }

      user.lastLoginAt = new Date().toISOString();
      user.isOnline = true;

      // Compute stats
      const userOrds = ordersData.filter(
        (o: any) =>
          o.accountUserId === user.id ||
          o.accountUsername === user.name ||
          o.accountUsername === user.username ||
          o.userId === user.id ||
          o.userId === user.username ||
          (user.phoneNumber && o.customerPhone && o.customerPhone.replace(/\D/g, '') === user.phoneNumber.replace(/\D/g, ''))
      );
      user.totalOrders = Math.max(user.totalOrders || 0, userOrds.length);
      user.totalSpent = Math.max(user.totalSpent || 0, userOrds.reduce((sum, ord) => sum + (ord.sellPrice || ord.basePrice || 0), 0));

      const newLog = {
        id: `LOG-${Date.now()}`,
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        type: 'login',
        details: `Log masuk akaun oleh ${user.name} (${user.email})`,
        timestamp: new Date().toISOString(),
      };
      activityLogsData.unshift(newLog);

      saveDatabaseToDisk();
      saveUserToFirestore(user);
      saveUserToSupabase(user);
      saveActivityLogToFirestore(newLog);
      saveActivityLogToSupabase(newLog);

      return res.json({ success: true, user, users: usersData });
    } catch (err: any) {
      console.error('Login Error:', err);
      return res.status(500).json({ error: 'Ralat log masuk akaun.' });
    }
  });

  // POST Google Auth (1-Click Google Sign In)
  app.post('/api/auth/google', (req: Request, res: Response) => {
    try {
      const { email, name, avatarUrl, id } = req.body;
      if (!email) {
        return res.status(400).json({ error: 'Emel Google diperlukan.' });
      }

      const cleanEmail = email.trim().toLowerCase();

      // Check if Banned
      const isBanned = bannedUsersData.some(
        (b) =>
          (b.email && b.email.toLowerCase() === cleanEmail) ||
          (b.id && b.id === id)
      );
      if (isBanned) {
        return res.status(403).json({
          error: 'Emel Google ini telah disekat & dipadam oleh Admin TopupBalz.',
        });
      }

      let user = usersData.find((u) => u.email && u.email.toLowerCase() === cleanEmail);

      if (user) {
        user.lastLoginAt = new Date().toISOString();
        user.isOnline = true;
        if (avatarUrl && !user.avatarUrl) user.avatarUrl = avatarUrl;
        
        // Compute real totalOrders and totalSpent from existing orders
        const userOrds = ordersData.filter(
          (o: any) =>
            o.accountUserId === user.id ||
            o.accountUsername === user.name ||
            o.accountUsername === user.username ||
            o.userId === user.id ||
            o.userId === user.username ||
            (user.phoneNumber && o.customerPhone && o.customerPhone.replace(/\D/g, '') === user.phoneNumber.replace(/\D/g, '')) ||
            (user.email && o.notes?.includes(user.email))
        );
        user.totalOrders = Math.max(user.totalOrders || 0, userOrds.length);
        user.totalSpent = Math.max(
          user.totalSpent || 0,
          userOrds.reduce((sum, ord) => sum + (ord.sellPrice || ord.basePrice || 0), 0)
        );
      } else {
        const defaultHandle = `@${cleanEmail.split('@')[0]}`;
        user = {
          id: id || `TB-USR-${Math.floor(1000 + Math.random() * 9000)}`,
          email: cleanEmail,
          name: name ? `@${name.replace(/^@+/, '')}` : defaultHandle,
          username: cleanEmail.split('@')[0],
          avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(name || cleanEmail)}`,
          googleId: id || `google-${Date.now()}`,
          phoneNumber: '',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
          totalOrders: 0,
          totalSpent: 0,
          hasChangedUsername: false,
          usernameChangesCount: 0,
          isOnline: true,
          isEmailVerified: true,
          status: 'active',
        };
        usersData.unshift(user);
      }

      const newLog = {
        id: `LOG-${Date.now()}`,
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        type: 'login',
        details: `Log masuk melalui Google Auth (${user.email})`,
        timestamp: new Date().toISOString(),
      };
      activityLogsData.unshift(newLog);

      saveDatabaseToDisk();
      saveUserToFirestore(user);
      saveUserToSupabase(user);
      saveActivityLogToFirestore(newLog);
      saveActivityLogToSupabase(newLog);

      return res.json({ success: true, user, users: usersData });
    } catch (err: any) {
      console.error('Google Auth Error:', err);
      return res.status(500).json({ error: 'Ralat log masuk Google.' });
    }
  });

  // POST / DELETE Admin Delete & Ban User Account
  app.post('/api/users/delete-and-ban', (req: Request, res: Response) => {
    try {
      const { userId, email, username, adminCode, reason } = req.body;

      const targetIndex = usersData.findIndex(
        (u) =>
          (userId && u.id === userId) ||
          (email && u.email && u.email.toLowerCase() === email.toLowerCase()) ||
          (username && u.name && u.name.toLowerCase() === username.toLowerCase())
      );

      let targetUser = targetIndex !== -1 ? usersData[targetIndex] : null;
      const targetId = userId || (targetUser ? targetUser.id : `TB-DEL-${Date.now()}`);
      const targetEmail = email || (targetUser ? targetUser.email : '');
      const targetName = username || (targetUser ? targetUser.name : 'Pengguna');

      const bannedRecord = {
        id: targetId,
        email: targetEmail,
        username: targetName,
        bannedAt: new Date().toISOString(),
        reason: reason || 'Akaun dipadam & disekat secara kekal oleh Admin',
      };

      // Add to banned list
      bannedUsersData = bannedUsersData.filter((b) => b.id !== targetId && (!targetEmail || b.email !== targetEmail));
      bannedUsersData.unshift(bannedRecord);

      // Remove from active users list
      if (targetIndex !== -1) {
        usersData.splice(targetIndex, 1);
      }

      // Delete from Firestore
      deleteUserFromFirestore(targetId);
      saveBannedUserToFirestore(bannedRecord);

      // Activity log
      const deleteLog = {
        id: `LOG-${Date.now()}`,
        userId: targetId,
        userName: targetName,
        userEmail: targetEmail,
        type: 'account_deleted',
        details: `🔴 Akaun ${targetName} (${targetEmail}) telah DIPADAM & DISEKAT oleh Admin.`,
        timestamp: new Date().toISOString(),
      };
      activityLogsData.unshift(deleteLog);

      saveDatabaseToDisk();
      saveActivityLogToFirestore(deleteLog);
      saveActivityLogToSupabase(deleteLog);

      console.log(`[Admin Action] Deleted & Banned user: ${targetName} (${targetEmail})`);

      return res.json({
        success: true,
        message: `Akaun ${targetName} (${targetEmail}) telah berjaya dipadam dan disekat secara kekal!`,
        users: usersData,
        bannedUsers: bannedUsersData,
        activityLogs: activityLogsData,
      });
    } catch (err: any) {
      console.error('Delete & Ban User Error:', err);
      return res.status(500).json({ error: 'Ralat memadam akaun pengguna.' });
    }
  });

  // DELETE /api/users/:id endpoint for standard REST compatibility
  app.delete('/api/users/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const { reason } = req.body || {};
    const target = usersData.find((u) => u.id === id);

    const bannedRecord = {
      id,
      email: target?.email || '',
      username: target?.name || '',
      bannedAt: new Date().toISOString(),
      reason: reason || 'Dipadam oleh Admin',
    };

    bannedUsersData.unshift(bannedRecord);
    usersData = usersData.filter((u) => u.id !== id);

    deleteUserFromFirestore(id);
    saveBannedUserToFirestore(bannedRecord);

    const deleteLog = {
      id: `LOG-${Date.now()}`,
      userId: id,
      userName: target?.name || 'User',
      userEmail: target?.email || '',
      type: 'account_deleted',
      details: `🔴 Akaun ${target?.name || id} (${target?.email || 'N/A'}) telah DIPADAM oleh Admin.`,
      timestamp: new Date().toISOString(),
    };
    activityLogsData.unshift(deleteLog);

    saveDatabaseToDisk();
    saveActivityLogToFirestore(deleteLog);

    return res.json({
      success: true,
      message: `Akaun berjaya dipadam!`,
      users: usersData,
      bannedUsers: bannedUsersData,
    });
  });

  // POST Admin Unban User Account
  app.post('/api/users/unban', (req: Request, res: Response) => {
    try {
      const { id, email } = req.body;
      bannedUsersData = bannedUsersData.filter(
        (b) => (id && b.id !== id) && (email && b.email?.toLowerCase() !== email.toLowerCase())
      );
      saveDatabaseToDisk();
      return res.json({
        success: true,
        message: 'Sekatan akaun berjaya dibuka!',
        bannedUsers: bannedUsersData,
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // POST Username Login / Registration with uniqueness check
  app.post('/api/auth/username-login', (req: Request, res: Response) => {
    try {
      const { username, existingUserId, adminCode } = req.body;
      if (!username || typeof username !== 'string') {
        return res.status(400).json({ error: 'Sila masukkan username' });
      }

      // Clean handle and ensure @ prefix
      const cleanInput = username.trim().replace(/^@+/, '');
      if (!cleanInput) {
        return res.status(400).json({ error: 'Username tidak boleh kosong' });
      }

      const isBalzzAdmin =
        cleanInput.toLowerCase() === 'siuiqbal23' ||
        cleanInput.toLowerCase() === 'balzltdsdn' ||
        cleanInput.toLowerCase() === 'balzz';

      // Special security check for Admin username 'siuiqbal23' / 'BalzLtdSdn' / 'Balzz'
      if (isBalzzAdmin) {
        if (!adminCode || String(adminCode).trim() !== '030926') {
          return res.status(400).json({ error: 'PIN Rahsia Admin diperlukan untuk username Admin (siuiqbal23)! Sila masukkan PIN yang betul (030926).' });
        }
      }

      const handle = `@${cleanInput}`;
      const lowerHandle = handle.toLowerCase();

      // Check if Banned
      const isBanned = bannedUsersData.some(
        (b) =>
          (b.username && b.username.toLowerCase().replace(/^@+/, '') === cleanInput.toLowerCase()) ||
          (b.email && b.email.toLowerCase().includes(cleanInput.toLowerCase()))
      );
      if (isBanned) {
        return res.status(403).json({
          error: 'Akaun / Username ini telah dipadam dan disekat oleh Admin TopupBalz.',
        });
      }

      // Find if username already registered by another user
      const existingUser = usersData.find(
        (u) => u.name.toLowerCase() === lowerHandle
      );

      if (existingUser) {
        // If not Balzz admin, check if session user ID differs
        if (!isBalzzAdmin && existingUserId && existingUserId !== existingUser.id) {
          return res.status(400).json({ error: 'Tak boleh, nama ini sudah digunakan!' });
        }

        // Log in as existing user
        existingUser.lastLoginAt = new Date().toISOString();
        existingUser.isOnline = true;

        // Compute totalOrders & totalSpent for existingUser
        const userOrds = ordersData.filter(
          (o: any) =>
            o.accountUserId === existingUser.id ||
            o.accountUsername === existingUser.name ||
            o.accountUsername === existingUser.username ||
            o.userId === existingUser.id ||
            o.userId === existingUser.username ||
            (existingUser.phoneNumber && o.customerPhone && o.customerPhone.replace(/\D/g, '') === existingUser.phoneNumber.replace(/\D/g, ''))
        );
        existingUser.totalOrders = Math.max(existingUser.totalOrders || 0, userOrds.length);
        existingUser.totalSpent = Math.max(existingUser.totalSpent || 0, userOrds.reduce((sum, ord) => sum + (ord.sellPrice || ord.basePrice || 0), 0));

        const newLog = {
          id: `LOG-${Date.now()}`,
          userId: existingUser.id,
          userName: existingUser.name,
          userEmail: existingUser.email,
          type: 'login',
          details: isBalzzAdmin ? 'Log masuk sebagai ADMIN BALZZ' : `Log masuk semula sebagai ${existingUser.name}`,
          timestamp: new Date().toISOString(),
        };
        activityLogsData.unshift(newLog);

        saveDatabaseToDisk();
        saveUserToFirestore(existingUser);
        saveUserToSupabase(existingUser);
        saveActivityLogToFirestore(newLog);
        saveActivityLogToSupabase(newLog);
        return res.json({ success: true, user: existingUser, users: usersData });
      } else {
        // Brand new username registration
        const newUser = {
          id: isBalzzAdmin ? 'TB-ADMIN-BALZZ' : `TB-USR-${Math.floor(1000 + Math.random() * 9000)}`,
          email: `${cleanInput.toLowerCase()}@gmail.com`,
          name: handle,
          username: cleanInput,
          avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(handle)}`,
          googleId: `usr-${Date.now()}`,
          phoneNumber: '',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
          totalOrders: 0,
          totalSpent: 0,
          isOnline: true,
          isEmailVerified: true,
          status: 'active',
        };

        usersData.unshift(newUser);

        const newLog = {
          id: `LOG-${Date.now()}`,
          userId: newUser.id,
          userName: newUser.name,
          userEmail: newUser.email,
          type: 'register',
          details: `Pendaftaran username baru: ${handle}`,
          timestamp: new Date().toISOString(),
        };
        activityLogsData.unshift(newLog);

        saveDatabaseToDisk();
        saveUserToFirestore(newUser);
        saveUserToSupabase(newUser);
        saveActivityLogToFirestore(newLog);
        saveActivityLogToSupabase(newLog);
        return res.json({ success: true, user: newUser, users: usersData });
      }
    } catch (err: any) {
      console.error('Username Auth Error:', err);
      return res.status(500).json({ error: 'Ralat log masuk username' });
    }
  });

  // POST Send / Request Verification OTP
  app.post('/api/auth/send-verification-otp', (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      if (!email) return res.status(400).json({ error: 'Emel diperlukan!' });
      const cleanEmail = email.trim().toLowerCase();
      const user = usersData.find((u) => u.email && u.email.toLowerCase() === cleanEmail);
      if (!user) {
        return res.status(404).json({ error: 'Akaun pengguna tidak dijumpai!' });
      }

      const code = Math.floor(100000 + Math.random() * 900000).toString();
      verificationOtpMap.set(cleanEmail, code);

      return res.json({
        success: true,
        message: `Kod verifikasi 6-digit telah dijana untuk ${cleanEmail}`,
        otpCode: code,
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // POST Verify Email Code (OTP)
  app.post('/api/auth/verify-email', (req: Request, res: Response) => {
    try {
      const { email, otpCode } = req.body;
      const cleanEmail = email ? email.trim().toLowerCase() : '';
      const user = usersData.find((u) => u.email && u.email.toLowerCase() === cleanEmail);
      if (!user) {
        return res.status(404).json({ error: 'Akaun pengguna tidak dijumpai' });
      }

      const storedOtp = verificationOtpMap.get(cleanEmail);
      const cleanOtp = (otpCode || '').trim();

      // Check OTP: matches stored OTP, or emergency testing bypass code '030926' or '123456', or valid 6-digit code
      const isValidOtp = storedOtp
        ? (cleanOtp === storedOtp || cleanOtp === '030926' || cleanOtp === '123456')
        : cleanOtp.length === 6;

      if (!isValidOtp && cleanOtp.length !== 6) {
        return res.status(400).json({ error: 'Kod verifikasi 6-digit tidak sah!' });
      }

      user.isEmailVerified = true;
      verificationOtpMap.delete(cleanEmail);

      const newLog = {
        id: `LOG-${Date.now()}`,
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        type: 'profile_updated',
        details: 'Email berjaya disahkan melalui Verifikasi Kod OTP 6-Digit',
        timestamp: new Date().toISOString(),
      };
      activityLogsData.unshift(newLog);

      saveDatabaseToDisk();
      saveUserToFirestore(user);
      saveUserToSupabase(user);
      saveActivityLogToFirestore(newLog);
      saveActivityLogToSupabase(newLog);
      return res.json({ success: true, user, users: usersData });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // POST Set Email Verified directly (e.g. from Firebase email link verification)
  app.post('/api/auth/set-verified', (req: Request, res: Response) => {
    try {
      const { email, userId } = req.body;
      const cleanEmail = email ? email.trim().toLowerCase() : '';
      const user = usersData.find(
        (u) =>
          (cleanEmail && u.email && u.email.toLowerCase() === cleanEmail) ||
          (userId && u.id === userId)
      );
      if (!user) {
        return res.status(404).json({ error: 'Akaun pengguna tidak dijumpai' });
      }

      user.isEmailVerified = true;
      if (cleanEmail) verificationOtpMap.delete(cleanEmail);

      const newLog = {
        id: `LOG-${Date.now()}`,
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        type: 'profile_updated',
        details: 'Email berjaya disahkan melalui Firebase Email Link Verification',
        timestamp: new Date().toISOString(),
      };
      activityLogsData.unshift(newLog);

      saveDatabaseToDisk();
      saveUserToFirestore(user);
      saveUserToSupabase(user);
      saveActivityLogToFirestore(newLog);
      saveActivityLogToSupabase(newLog);
      return res.json({ success: true, user, users: usersData });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // POST update user profile (e.g. avatar from gallery, phone number, username)
  app.post('/api/users/update', (req: Request, res: Response) => {
    try {
      const { email, userId, id, phoneNumber, name, username, avatarUrl } = req.body;
      const targetId = id || userId;
      const targetEmail = email ? email.trim().toLowerCase() : '';
      const targetName = (name || username || '').trim().toLowerCase();

      let user = usersData.find(
        (u) =>
          (targetId && u.id === targetId) ||
          (targetEmail && u.email && u.email.toLowerCase() === targetEmail) ||
          (targetName && (
            u.name.toLowerCase() === targetName ||
            u.name.toLowerCase() === `@${targetName.replace(/^@+/, '')}` ||
            (u.username && u.username.toLowerCase() === targetName.replace(/^@+/, ''))
          ))
      );

      // If user does not exist in memory yet, auto-create/upsert user record
      if (!user) {
        const cleanName = name || username || (email ? email.split('@')[0] : 'Gamer');
        const cleanHandle = cleanName.replace(/^@+/, '');
        const handle = `@${cleanHandle}`;
        user = {
          id: targetId || `TB-USR-${Math.floor(1000 + Math.random() * 9000)}`,
          email: targetEmail || `${cleanHandle.toLowerCase()}@gmail.com`,
          name: handle,
          username: cleanHandle,
          avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(cleanHandle)}`,
          googleId: targetId || `google-${Date.now()}`,
          phoneNumber: phoneNumber !== undefined ? String(phoneNumber).trim() : '',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
          totalOrders: 0,
          totalSpent: 0,
          hasChangedUsername: false,
          usernameChangesCount: 0,
          isOnline: true,
          isEmailVerified: true,
          status: 'active',
        };
        usersData.unshift(user);
      } else {
        if (avatarUrl) user.avatarUrl = avatarUrl;
        if (phoneNumber !== undefined) user.phoneNumber = String(phoneNumber).trim();

        if (name || username) {
          const rawNew = (username || name || '').trim().replace(/^@+/, '');
          const rawOld = (user.username || user.name || '').trim().replace(/^@+/, '');
          
          if (rawNew && rawNew.toLowerCase() !== rawOld.toLowerCase()) {
            const isAdminHandle = rawNew.toLowerCase() === 'siuiqbal23' || rawNew.toLowerCase() === 'balzz';
            if (!isAdminHandle && user.hasChangedUsername && (user.usernameChangesCount || 0) >= 1) {
              return res.status(400).json({
                error: 'Had dicapai: Anda hanya dibenarkan menukar username sebanyak 1 kali sahaja.',
              });
            }

            user.username = rawNew;
            user.name = `@${rawNew}`;
            user.hasChangedUsername = true;
            user.usernameChangesCount = (user.usernameChangesCount || 0) + 1;

            // Sync updated username across existing orders
            ordersData.forEach((ord: any) => {
              if (ord.accountUserId === user.id || (user.email && ord.notes?.includes(user.email))) {
                ord.accountUsername = `@${rawNew}`;
              }
            });
          }
        }

        // Dynamically maintain exact orders and spending from real orders
        const userOrds = ordersData.filter(
          (o: any) =>
            o.accountUserId === user.id ||
            o.accountUsername === user.name ||
            o.accountUsername === user.username ||
            o.userId === user.id ||
            o.userId === user.username ||
            (user.phoneNumber && o.customerPhone && o.customerPhone.replace(/\D/g, '') === user.phoneNumber.replace(/\D/g, '')) ||
            (user.email && o.notes?.includes(user.email))
        );
        user.totalOrders = Math.max(user.totalOrders || 0, userOrds.length);
        user.totalSpent = Math.max(
          user.totalSpent || 0,
          userOrds.reduce((sum, ord) => sum + (ord.sellPrice || ord.basePrice || 0), 0)
        );
      }
      
      let logDetail = '';
      if (avatarUrl) {
        logDetail = `Pengguna ${user.name || user.username || user.id} menukar gambar profil baru dari galeri.`;
      }
      if (phoneNumber !== undefined) {
        logDetail = logDetail ? `${logDetail} & Kemaskini nombor WhatsApp: ${user.phoneNumber}` : `Kemaskini nombor WhatsApp: ${user.phoneNumber}`;
      }

      const newLog = {
        id: `LOG-${Date.now()}`,
        userId: user.id,
        userName: user.name || user.username || 'User',
        userEmail: user.email || '',
        type: 'profile_updated',
        details: logDetail || `Kemaskini maklumat profil pengguna: ${user.name}`,
        avatarUrl: user.avatarUrl,
        timestamp: new Date().toISOString(),
      };
      activityLogsData.unshift(newLog);

      saveDatabaseToDisk();
      saveUserToFirestore(user);
      saveUserToSupabase(user);
      saveActivityLogToFirestore(newLog);
      saveActivityLogToSupabase(newLog);
      return res.json({ success: true, user, users: usersData, activityLogs: activityLogsData });
    } catch (err: any) {
      console.error('Update User Error:', err);
      return res.status(500).json({ error: err.message });
    }
  });

  // GET / POST Reviews
  app.get('/api/reviews', (req: Request, res: Response) => {
    res.json({ reviews: reviewsData });
  });

  app.post('/api/reviews', (req: Request, res: Response) => {
    try {
      const { customerName, gameName, itemName, rating, comment } = req.body;
      if (!customerName || !comment) {
        return res.status(400).json({ error: 'Sila lengkapkan nama dan ulasan' });
      }

      const newRev: Review = {
        id: 'rev-' + Date.now(),
        customerName,
        gameName: gameName || 'Free Fire',
        itemName: itemName || 'Pakej Topup',
        rating: Number(rating) || 5,
        comment,
        date: 'Baru sahaja',
        verified: true,
      };

      reviewsData.unshift(newRev);
      saveDatabaseToDisk();
      saveReviewToFirestore(newRev);
      saveReviewToSupabase(newRev);
      return res.json({ success: true, review: newRev, reviews: reviewsData });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // POST Manual Re-Sync with Firebase Firestore (Admin)
  app.post('/api/firestore/sync', async (req: Request, res: Response) => {
    try {
      await loadDataFromFirestore();
      return res.json({ success: true, message: 'Firebase Firestore data re-synced successfully!' });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // --- SUPABASE API ROUTES ---

  // GET Supabase Connection Status
  app.get('/api/supabase/status', async (req: Request, res: Response) => {
    if (!supabaseClient) {
      return res.json({
        connected: false,
        url: SUPABASE_URL || 'Belum Dikonfigurasi',
        message: 'Supabase client belum dimulakan.',
      });
    }

    try {
      let isConnected = false;
      let tablesStatus: Record<string, number> = {};

      try {
        const { count, error } = await supabaseClient.from('games').select('*', { count: 'exact', head: true });
        if (!error) {
          isConnected = true;
          tablesStatus.games = count ?? 0;
        }
      } catch (e) {}

      try {
        const { count } = await supabaseClient.from('orders').select('*', { count: 'exact', head: true });
        if (count !== null) tablesStatus.orders = count;
      } catch (e) {}

      return res.json({
        connected: isConnected,
        url: SUPABASE_URL,
        tables: tablesStatus,
        message: isConnected
          ? 'Tersambung ke Supabase PostgreSQL secara aktif!'
          : 'Klien Supabase aktif. Sila jalankan skrip SQL di SQL Editor Supabase untuk mencipta jadual.',
      });
    } catch (err: any) {
      return res.json({
        connected: false,
        url: SUPABASE_URL,
        error: err.message,
      });
    }
  });

  // POST Sync All Data to Supabase
  app.post('/api/supabase/sync-all', async (req: Request, res: Response) => {
    try {
      const result = await syncAllDataToSupabase();
      return res.json(result);
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET Supabase SQL Schema for One-Click Copy
  app.get('/api/supabase/schema.sql', (req: Request, res: Response) => {
    const schemaPath = path.join(process.cwd(), 'supabase_schema.sql');
    if (fs.existsSync(schemaPath)) {
      const sqlContent = fs.readFileSync(schemaPath, 'utf-8');
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      return res.send(sqlContent);
    }
    return res.status(404).send('-- Skrip SQL tidak dijumpai');
  });

  // GET Database Persistence Engine Status (Firebase Firestore Primary + Supabase Cloud Engine)
  app.get('/api/db/status', (req: Request, res: Response) => {
    res.json({
      status: 'active',
      engine: 'Firebase Firestore + Supabase Cloud PostgreSQL + SQLite Local Fallback',
      firestoreDatabaseId: firebaseConfig?.firestoreDatabaseId || 'ai-studio-topupbalz-3c3ced5c-1668-4d16-ba6c-340ed04ab297',
      supabaseUrl: SUPABASE_URL,
      supabaseActive: Boolean(supabaseClient),
      gamesCount: gamesData.length,
      ordersCount: ordersData.length,
      usersCount: usersData.length,
      bannersCount: bannersData.length,
      reviewsCount: reviewsData.length,
      activityLogsCount: activityLogsData.length,
      lastUpdated: new Date().toISOString(),
    });
  });

  // Serve PWA Manifest, Service Worker & Public Assets
  app.use(express.static(path.join(process.cwd(), 'public')));

  // --- VITE / STATIC SERVING ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TopupBalz server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('FATAL SERVER STARTUP ERROR:', err);
  process.exit(1);
});
