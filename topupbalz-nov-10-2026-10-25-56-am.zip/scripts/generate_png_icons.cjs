const fs = require('fs');
const zlib = require('zlib');

// Minimal pure Node.js PNG encoder without external dependencies
function createPNG(width, height, getPixelRGBA) {
  // Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR Chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // 8 bit depth
  ihdr[9] = 6; // RGBA color type
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace
  const ihdrChunk = makeChunk('IHDR', ihdr);

  // Raw image data with filter byte (0) per row
  const rowBytes = width * 4;
  const rawData = Buffer.alloc(height * (rowBytes + 1));
  let offset = 0;

  for (let y = 0; y < height; y++) {
    rawData[offset++] = 0; // Filter: None
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = getPixelRGBA(x, y, width, height);
      rawData[offset++] = r;
      rawData[offset++] = g;
      rawData[offset++] = b;
      rawData[offset++] = a;
    }
  }

  // Compress with zlib
  const compressed = zlib.deflateSync(rawData);
  const idatChunk = makeChunk('IDAT', compressed);

  // IEND Chunk
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function makeChunk(type, data) {
  const len = data.length;
  const buf = Buffer.alloc(4 + 4 + len + 4);
  buf.writeUInt32BE(len, 0);
  buf.write(type, 4, 4, 'ascii');
  data.copy(buf, 8);
  const crc = crc32(buf.subarray(4, 8 + len));
  buf.writeUInt32BE(crc >>> 0, 8 + len);
  return buf;
}

// CRC32 table & calculator
let crcTable = null;
function makeCrcTable() {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      if (c & 1) c = 0xedb88320 ^ (c >>> 1);
      else c = c >>> 1;
    }
    table[n] = c;
  }
  return table;
}

function crc32(buf) {
  if (!crcTable) crcTable = makeCrcTable();
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = crcTable[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

// Draw TopupBalz Glowing Icon
function getIconPixel(x, y, w, h) {
  const nx = x / w;
  const ny = y / h;
  const cx = 0.5;
  const cy = 0.48;
  const dist = Math.sqrt((nx - cx) ** 2 + (ny - cy) ** 2);

  // Rounded corners for the icon container
  const cornerRadius = 0.22;
  const qx = Math.max(Math.abs(nx - 0.5) - (0.5 - cornerRadius), 0);
  const qy = Math.max(Math.abs(ny - 0.5) - (0.5 - cornerRadius), 0);
  const cornerDist = Math.sqrt(qx * qx + qy * qy);

  if (cornerDist > cornerRadius) {
    return [0, 0, 0, 0]; // Transparent outside rounded corner
  }

  // Border glow
  const isNearBorder = cornerDist > cornerRadius - 0.015 || (Math.abs(nx - 0.5) > 0.48 || Math.abs(ny - 0.5) > 0.48);
  if (isNearBorder) {
    return [255, 109, 0, 240]; // Orange border
  }

  // Ambient core radial glow
  const glowIntensity = Math.max(0, 1 - dist * 2.2);

  // Background deep dark gradient with orange glow
  let r = Math.floor(13 + glowIntensity * 120);
  let g = Math.floor(17 + glowIntensity * 45);
  let b = Math.floor(26);

  // Center 'B' Lightning shape approximation for PNG preview
  const isInsideB = (
    (nx >= 0.28 && nx <= 0.72 && ny >= 0.22 && ny <= 0.72) &&
    // Cutouts
    !(nx >= 0.42 && nx <= 0.58 && ny >= 0.32 && ny <= 0.44) &&
    !(nx >= 0.44 && nx <= 0.60 && ny >= 0.50 && ny <= 0.62)
  );

  if (isInsideB) {
    // Fiery orange-gold gradient inside 'B'
    const grad = (ny - 0.22) / 0.5;
    r = 255;
    g = Math.floor(180 - grad * 120); // 180 to 60
    b = Math.floor(0);
    return [r, g, b, 255];
  }

  return [Math.min(255, r), Math.min(255, g), Math.min(255, b), 255];
}

// Generate 192x192 and 512x512 icons in /public
if (!fs.existsSync('public')) {
  fs.mkdirSync('public');
}

const png192 = createPNG(192, 192, getIconPixel);
fs.writeFileSync('public/icon-192.png', png192);
console.log('Created public/icon-192.png (' + png192.length + ' bytes)');

const png512 = createPNG(512, 512, getIconPixel);
fs.writeFileSync('public/icon-512.png', png512);
console.log('Created public/icon-512.png (' + png512.length + ' bytes)');
